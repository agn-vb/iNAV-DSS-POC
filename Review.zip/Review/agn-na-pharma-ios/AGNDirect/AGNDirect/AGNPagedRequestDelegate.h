//
//  AGNPagedRequestDelegate.h
//  AGNDirect
//
//  Created by Dennis Jacobs on 10/19/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGNPagedRequestDelegate : NSObject <SFRestDelegate>
- (AGNPagedRequestDelegate *)initWithParent:(id <SFRestDelegate>)delegate;
@end
