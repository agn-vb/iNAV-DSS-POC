//
//  AGNDownstreamSync.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/9/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "DDSFDownstreamSync.h"
#import "DDSFSyncItem.h"
#import "DDSFSyncStep.h"
#import "DDSFSyncGroup.h"
#import "AGNAddress.h"
#import "AGNProductBrand.h"
#import "AGNProductSKU.h"
#import "AGNSampleInventoryLine.h"
#import "AGNAccount.h"
#import "AGNSalesRep.h"
#import "AGNCall.h"
#import "AGNDetailPosition.h"
#import "AGNContactRole.h"
#import "AGNSuppressedAddress.h"
#import "AGNRequestFormProduct.h"
#import "AGNRSS.h"
#import "AGNMarketingDisbursement.h"

#import "SFRestAPI.h"
#import "RestKit.h"
#import "RKRequestSerialization.h"
#import "JSONKit.h"


extern NSString * const kAGNAppStatusKill;
extern NSString * const kAGNAppStatusWarn;
static int AGNMaxGenericIDs = 49000;



@class AGNSyncManager;

@interface AGNDownstreamSync : DDSFDownstreamSync

+ (NSDictionary *)dictionaryWithStandardizedKeysFrom:(NSDictionary *)dict;


@property (nonatomic, weak) AGNSyncManager * syncManager;

// Properties shared by categories
@property (nonatomic, strong) AGNSalesRep *loggedInSalesRep;
@property (copy, nonatomic) NSSet *deletedHCPIds; // We will delete these accounts when processing account ID sync group
@property (copy, nonatomic) NSSet *addedHCPIds; // We will handle these separately during incremental sync
@property (copy, nonatomic) NSSet *addedCallIds;
@property (copy, nonatomic) NSSet *allHCPIds;

@property (strong, nonatomic) NSMutableSet *deletedFormIds;
@property (strong, nonatomic) NSMutableSet *remainingFormIds;
@property (strong, nonatomic) NSSet *addedFormIds;

@property (strong, nonatomic) NSMutableSet *deletedReprintIds;
@property (strong, nonatomic) NSMutableSet *remainingReprintIds;
@property (strong, nonatomic) NSSet *addedReprintIds;

// Utility methods - for categories
- (id)nullCheck:(id)value;
+ (id)nullCheck:(id)value;
- (void)deleteAllEntities:(NSString*)entityName;
- (NSArray *)allEntities:(NSString*)entityName;
- (void)addEntities:(NSArray *)entities withName:(NSString *)entityName;
+ (void)addEntities:(NSArray *)entities withName:(NSString *)entityName moc:(NSManagedObjectContext*)moc;
- (void)updateEntities:(NSArray *)entities withName:(NSString *)entityName whereIdWithKey:(NSString *)key notIn:(NSSet *)addedIds;
- (void)saveContext;
- (NSArray*)objectsOfType:(NSString*)entityName forAccount:(NSString*)accountId;
- (RKRequestSerialization *)requestSerializationForIds:(NSSet *)accountIds;

// Caching

- (void)registerAddress:(AGNAddress*)address;
- (AGNAddress*)addressBySFDCID:(NSString*)sfdcId;

- (void)registerProductBrand:(AGNProductBrand*)productBrand;
- (AGNProductBrand*)productBrandBySFDCID:(NSString*)sfdcId;

- (void)registerProductSKU:(AGNProductSKU*)product;
- (AGNProductSKU*)productSKUBySFDCID:(NSString*)sfdcId;

- (void)registerSampleInventoryLine:(AGNSampleInventoryLine*)inventoryLine;
- (AGNSampleInventoryLine*)inventoryLineBySFDCID:(NSString*)sfdcId;

- (void)registerAccount:(AGNAccount*)account;
- (AGNAccount*)accountBySFDCID:(NSString*)sfdcId;

- (void)registerContact:(AGNContact*)contact;
- (AGNContact*)contactBySFDCID:(NSString*)sfdcId;

- (void)registerSalesRep:(AGNSalesRep*)salesRep;
- (AGNSalesRep*)salesRepBySFDCID:(NSString*)sfdcId;

- (AGNRSS*)rssBySFDCID:(NSString *)sfdcId;
- (void)registerRSS:(AGNRSS *)rss;

- (void)resetCalls;
- (void)registerCall:(AGNCall*)call;
- (AGNCall*)callBySFDCID:(NSString*)sfdcId;

@property (nonatomic, strong) AGNCall * currentCall;

- (void)registerDetailPosition:(AGNDetailPosition*)detailPosition;
- (AGNDetailPosition*)detailPositionBySFDCID:(NSString*)sfdcId;

- (void)registerMarketingDisbursement:(AGNMarketingDisbursement*)disbursement;
- (AGNMarketingDisbursement*)disbursementBySFDCID:(NSString*)sfdcId;


- (void)registerMarketingContent:(AGNMarketingCollateral*)content;
- (AGNMarketingCollateral*)marketingContentBySFDCID:(NSString*)sfdcId;


-(void)handleAuthenticationFailure;
-(void)handleServerBusyError;


@end
