//
//  AGNDownstreamSync+AccountsGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+AccountsGroup.h"
#import "NSManagedObjectContext+DDSFExtensions.h"

@implementation AGNDownstreamSync (AccountsGroup)

-(void)deleteOrphanedAddressSuppressions{
    for (AGNSuppressedAddress *obj in [self allEntities:@"AGNSuppressedAddress"]) {
        NSString *addressId = obj.salesForceAddressId;
        AGNAddress * addr = (AGNAddress *)[self.managedContext ddsf_objectOfType:@"AGNAddress" forId:addressId];
        if (!addr)
            [self.managedContext deleteObject:obj];
    }
}

- (DDSFSyncItem *)accountsGroup {
    __weak AGNDownstreamSync * _self = self;
    
    // Need to create a group since we have different steps depending on incremental vs. full
    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];
    
    ////////////////////////////////////////////// Full  sync ////////////////////////////////////////
    DDSFSyncStep * fullAccounts = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest requestWithQueryFromFileNamed:@"AllAccountsQueryString.txt"]];
    fullAccounts.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        [_self addEntities:json[@"records"] withName:@"AGNAccount"];
        log4Debug(@"Added %d  accounts.", [json[@"records"] count]);
    };
    fullAccounts.name = @"full-accounts";
    
    fullAccounts.preFetch = ^(DDSFDownstreamSync * sync) {
        self.allHCPIds = [NSSet set]; // Create an empty set
    };
    
    fullAccounts.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        NSArray * accounts = json[@"records"];
        NSArray * ids = [accounts valueForKey:@"Id"];
        self.allHCPIds = [self.allHCPIds setByAddingObjectsFromArray:ids];
    };        

    DDSFSyncStep * fullLicenses = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest requestWithQueryFromFileNamed:@"AllLicensesQueryString.txt"]];
    fullLicenses.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        [_self addEntities:json[@"records"] withName:@"AGNLicense"];
        log4Debug(@"Added %d licenses.", [json[@"records"] count]);
    };
    fullLicenses.name = @"full-licenses";
    
    
    DDSFSyncStep * fullAddresses = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest requestWithQueryFromFileNamed:@"AllAddressesQueryString.txt"]];
    fullAddresses.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        [_self addEntities:json[@"records"] withName:@"AGNAddress"];
        log4Debug(@"Added %d records.", [json[@"records"] count]);
    };
    fullAddresses.name = @"full-addresses";
    
    
    DDSFSyncStep * primaryAddresses = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"PrimaryAddressIdsQueryString.txt", _self.loggedInSalesRep.salesForceSalesTeamId, nil];
    }];
    primaryAddresses.name = @"full-primary-addresses";
    
    primaryAddresses.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        NSArray *accounts = (NSArray *)[json objectForKey:@"records"];
        for (NSDictionary *acct in accounts) {
            NSDictionary *callList = acct[@"Call_List__r"];
            if (callList && ![callList isEqual: [NSNull null]]) {
                NSArray *addresses = [callList objectForKey:@"records"];
                if ([addresses count] > 0) {
                    NSString *addrId = [addresses[0] objectForKey:@"Address__c"];
                    if (addrId && ![addrId isEqual:[NSNull null]]) {
                        AGNAddress * addr = [_self addressBySFDCID:addrId];
                        [addr setPrimary:[NSNumber numberWithBool:YES]];
                    }
                }
            }
        }
        log4Debug(@"Marked %d addresses as primary.", [json[@"records"] count]);
    };
    
    DDSFSyncStep * fullContacts = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest requestWithQueryFromFileNamed:@"AllContactsQueryString.txt"]];
    fullContacts.name = @"full-contacts";
    fullContacts.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        int count = 0;
        for (NSDictionary *acctDict in json[@"records"]) {
            if (![acctDict[@"Contacts__r"] isEqual:[NSNull null]]) {
                NSDictionary *acctContactsDict = acctDict[@"Contacts__r"];
                for (NSDictionary *contactDict in acctContactsDict[@"records"]) {
                    if ([AGNContact canCreateFromDictionary:contactDict]) {
                        id <AGNModelProtocol> mp = [NSEntityDescription insertNewObjectForEntityForName:@"AGNContact" inManagedObjectContext:_self.managedContext];
                        [mp initWithDictionary:contactDict];
                        count++;
                    }
                }
            }
        }
        log4Debug(@"Added %d contacts.", count);
    };
        
    [group setSteps:@[fullAccounts, fullLicenses, fullAddresses, primaryAddresses, fullContacts] forMode:kDDSFDownstreamSyncModeFull];
    
    
    ////////////////////////////////////////////// Incremental sync ////////////////////////////////////////
    DDSFSyncStep * incremental = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        NSString *distantPastString = @"utctimestamp=2000-01-01 00:00:01";
        NSString *nonDeltaString = @"&isdeltaload=0";
        NSString *deltaTimestampString = distantPastString;
        NSString *isDeltaString = nonDeltaString;
        
        if (_self.syncManager.utcCurrentSyncLastTimestamp) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
            deltaTimestampString = [NSString stringWithFormat:@"utctimestamp=%@", [df stringFromDate:_self.syncManager.utcCurrentSyncLastTimestamp]];
            isDeltaString = @"&isdeltaload=1";
        }
        
        NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/OfflineSync?%@&syncgroup=hcp%@"], deltaTimestampString, isDeltaString];
        return [DDSFRequest getRequestForPath:urlString];
    }];

    incremental.name = @"delta-accounts";
    incremental.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        log4Info(@"==> accounts group processing");

        if (_self.mode == kDDSFDownstreamSyncModeIncremental) {
            [_self updateEntities:json[@"Accounts"] withName:@"AGNAccount" whereIdWithKey:@"Id" notIn:_self.addedHCPIds];
            [_self updateEntities:json[@"Licenses"] withName:@"AGNLicense" whereIdWithKey:@"HCP__c" notIn:_self.addedHCPIds];
            [_self updateEntities:json[@"Contacts"] withName:@"AGNContact" whereIdWithKey:@"AccountId" notIn:_self.addedHCPIds];
            [_self updateEntities:json[@"Addresses"] withName:@"AGNAddress" whereIdWithKey:@"HCA_HCP__c" notIn:_self.addedHCPIds];
        }
        else {
            [_self addEntities:json[@"Accounts"] withName:@"AGNAccount"];
            [_self addEntities:json[@"Licenses"] withName:@"AGNLicense"];
            [_self addEntities:json[@"Contacts"] withName:@"AGNContact"];
            [_self addEntities:json[@"Addresses"] withName:@"AGNAddress"];
        }
    };
        
    [group setSteps:@[incremental] forMode:kDDSFDownstreamSyncModeIncremental];
    
    group.postProcess = ^(DDSFDownstreamSync *sync) {
        [_self deleteOrphanedAddressSuppressions];
        [_self saveContext];
    };
    
    return group;
}


@end
