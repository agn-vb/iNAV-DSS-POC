//
//  AGNDownstreamSync+SalesRepGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+SalesRepGroup.h"

@implementation AGNDownstreamSync (SalesRepGroup)

- (DDSFSyncItem*)salesRepGroup {
    __weak AGNDownstreamSync * _self = self;
    
    DDSFSyncStep * step = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/OfflinebulkSync?syncobject=User&BU=%@"], _self.loggedInSalesRep.businessUnit];
        return [DDSFRequest getRequestForPath:urlString];
    }];
    step.name = @"sales-reps";
    
    step.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        log4Info(@"==> sales rep group processing");

        [_self addEntities:json[@"responsepayload"] withName:@"AGNSalesRep"];
    };
    
    step.postProcess = ^(DDSFDownstreamSync * sync) {
        [_self buildSalesRepRelationships];
    };
    
    return step;
}

- (void)buildSalesRepRelationships {
    for (AGNSampleInventoryLine * line in [self allEntities:@"AGNSampleInventoryLine"])
        line.salesRep = [self salesRepBySFDCID:line.salesRepSalesForceId];
}

@end
