//
//  AGNPopoverTableViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNTableView.h"
#import "TypeDef.h"

typedef void(^objectSelectedBlock)(int selectedIndex);

@interface AGNPopoverTableViewController : UIPopoverController <UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) NSArray *objectArray;
@property (strong, nonatomic, readonly) UIViewController *viewController;
@property (strong, nonatomic, readonly) AGNTableView *tableView;
@property (copy, nonatomic) cellForRowAtIndexPathBlock cellBlock;
@property (copy, nonatomic) objectSelectedBlock onSelectBlock;
@property BOOL includeSearchBar;
@property (strong, nonatomic) UISearchBar *searchBar;
@property (strong, nonatomic) id<UISearchBarDelegate> searchBarDelegate;
@property (strong, nonatomic) UIView *headerView;
@property CGFloat rowHeight;
@property (nonatomic, strong, readwrite) NSNumber *maxWidthPercentage;


-(id)initWithDelegate:(id)delegate andTitle:(NSString *)title;


@end
