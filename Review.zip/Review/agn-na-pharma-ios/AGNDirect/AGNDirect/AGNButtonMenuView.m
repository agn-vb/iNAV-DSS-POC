//
//  AGNButtonMenuView.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNButtonMenuView.h"
#import "AGNSingleLineCell.h"
#import "AGNTableView.h"

@interface AGNButtonMenuItem : NSObject

@property (nonatomic, strong) AGNButtonTextBlock  buttonLabel;
@property (nonatomic, strong) AGNActionTitleBlock actionTitle;
@property (nonatomic, copy) AGNCheckBlock visible;
@property (nonatomic, copy) AGNCheckBlock enabled;
@property (nonatomic, copy) AGNActionBlock action;

@property (nonatomic, readonly) BOOL isVisible;
@property (nonatomic, readonly) BOOL isEnabled;
@property BOOL shouldDisplayUnderForms;

@property (nonatomic, strong) UIButton * button;

@end

@implementation AGNButtonMenuItem

- (BOOL)isVisible {
    if (self.visible)
        return self.visible();
    else
        return YES;
}

- (BOOL)isEnabled {
    if (self.enabled)
        return self.enabled();
    else
        return YES;
}

- (void)click:(id)sender {
    if (self.action)
        self.action(self.button);
}

@end

@interface AGNButtonMenuView ()

@property (nonatomic, strong) NSMutableArray * allItems;
@property (nonatomic, strong) NSMutableArray * currentItems;
@property (nonatomic, strong) NSMutableArray * popoverItems;

@property (nonatomic, assign) int numberOfButtons; // Number of menu buttons, excluding the more button

@property (nonatomic, strong) UIButton * moreButton;
@property (nonatomic, strong) AGNSimplePopoverTableViewController * morePopover;

@property (nonatomic, assign) CGRect lastFrame;

@end

@implementation AGNButtonMenuView

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.allItems = [NSMutableArray array];
        self.currentItems = [NSMutableArray array];
        self.popoverItems = [NSMutableArray array];
    }
    return self;
}

- (id)init {
    if ((self = [super init])) {
        self.allItems = [NSMutableArray array];
        self.currentItems = [NSMutableArray array];
        self.popoverItems = [NSMutableArray array];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    if ((self = [super initWithCoder:aDecoder])) {
        self.allItems = [NSMutableArray array];
        self.currentItems = [NSMutableArray array];        
        self.popoverItems = [NSMutableArray array];
    }
    return self;
}

- (void)addItemWithLabel:(AGNButtonTextBlock)label title:(AGNActionTitleBlock)title visible:(AGNCheckBlock)visibleBlock enabled:(AGNCheckBlock)enabledBlock action:(AGNActionBlock)actionBlock displayUnderForms:(BOOL)displayUnderForms {
    AGNButtonMenuItem * item = [[AGNButtonMenuItem alloc] init];
    item.actionTitle = title;
    item.buttonLabel = label;
    item.visible = visibleBlock;
    item.enabled = enabledBlock;
    item.action = actionBlock;
    item.shouldDisplayUnderForms = displayUnderForms;
    
    [self.allItems addObject:item];
    [self setNeedsLayout];
}

- (UIButton*)buttonWithTitle:(NSString*)title {
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont AGNHelveticaNeueBold16];
    [button setBackgroundImage:[[UIImage imageNamed:@"btn-bigblue"] stretchableImageWithLeftCapWidth:3 topCapHeight:0]forState:UIControlStateNormal];
    [button setBackgroundImage:[[UIImage imageNamed:@"btn-bigblue-hi"] stretchableImageWithLeftCapWidth:3 topCapHeight:0]forState:UIControlStateHighlighted];
    [self addSubview:button];
    return button;
}

- (void)layoutSubviews {
    // First recalc the current items array
    [self.currentItems removeAllObjects];
    for (AGNButtonMenuItem * item in self.allItems) {
        if (item.isVisible)
            [self.currentItems addObject:item];
        else {
            // Make sure the button doesn't stick around
            if (item.button) {
                [item.button removeFromSuperview];
                item.button = nil;
            }
        }
    }

    BOOL showFormsButton = self.showFormsButtonBlock();
    self.numberOfButtons = self.numberButtonsBlock();
    
    if(showFormsButton){
        if (!self.moreButton) {
            self.moreButton = [self buttonWithTitle:self.moreLabel];
            [self.moreButton addTarget:self action:@selector(more:) forControlEvents:UIControlEventTouchUpInside];
        }
    }else{
        if (self.moreButton) {
            [self.moreButton removeFromSuperview];
            self.moreButton = nil;
        }
    }


    // Create missing button for menu items / remove unneeded ones
    [self.popoverItems removeAllObjects];
    for (int pos = 0; pos < self.currentItems.count; pos++) {
        AGNButtonMenuItem * item = self.currentItems[pos];
        if (!(item.shouldDisplayUnderForms && showFormsButton)) {
            if (!item.button) {
                item.button = [self buttonWithTitle:item.buttonLabel()];
                [item.button addTarget:item action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
            }else{
                [item.button setTitle:item.buttonLabel() forState:UIControlStateNormal];
            }
            if (item.isEnabled) {
                item.button.enabled = YES;
                item.button.alpha = 1.0f;
            }
            else {
                item.button.enabled = NO;
                item.button.alpha = 0.5f;
            }
        }
        else {
            // Need to kill the buttons if they are there
            if (item.button) {
                [item.button removeFromSuperview];
                item.button = nil;
            }
            [self.popoverItems addObject:item];
        }
    }
    
    // Layout buttons
    CGSize size = self.frame.size;
    if (self.moreButton) {
        CGFloat x = 0.0f;
        CGFloat buttonWidth = size.width / (self.numberOfButtons);
        CGRect frame = CGRectMake(0.0f, 0.0f, 0.0f, size.height);
        
        frame.size.width = buttonWidth;
        x += frame.size.width;
        self.moreButton.frame = frame;

        for (int i = 1; i >=0; i--) {
            AGNButtonMenuItem * item = (AGNButtonMenuItem *)self.currentItems[i];
            if(showFormsButton && item.shouldDisplayUnderForms)
                continue;
            // we're reusing previous values for frame
            UIButton * button = ((AGNButtonMenuItem*)self.currentItems[i]).button;
            frame.origin.x = frame.origin.x + frame.size.width;
            if (i == 0)
                frame.size.width = size.width - frame.origin.x;
            else {
                x += buttonWidth;
                frame.size.width = roundf(x - frame.origin.x);
            }
            button.frame = frame;
        }
    }
    else {
        // We have 1, 2, or 3 buttons
        CGFloat buttonWidth = size.width / self.numberOfButtons;
        CGFloat x = 0.0f;
        CGRect frame = CGRectMake(0.0f, 0.0f, 0.0f, size.height); // Initial values

        // create the buttons that aren't the forms button
        for (int i = self.numberOfButtons - 1; i >=0; i--) {
            AGNButtonMenuItem * item = (AGNButtonMenuItem *)self.currentItems[i];
            if(showFormsButton && item.shouldDisplayUnderForms)
                continue;
            // we're reusing previous values for frame
            UIButton * button = ((AGNButtonMenuItem*)self.currentItems[i]).button;
            frame.origin.x = frame.origin.x + frame.size.width;
            if (i == 0)
                frame.size.width = size.width - frame.origin.x;
            else {
                x += buttonWidth;
                frame.size.width = roundf(x - frame.origin.x);
            }
            button.frame = frame;
        }
   }

    // If we have more popover displayed
    if (self.morePopover) {
        // If the frame changed (e.g. the device has been rotated), the dismiss the popover and present it again
        if (self.frame.size.width != self.lastFrame.size.width || 
            self.frame.size.height != self.lastFrame.size.height) {

            // Git rid of the popover
            [self.morePopover dismissPopoverAnimated:YES];
            // Present it again
            [self more:nil];
        }
        // Or, if there are no longer enough items to vouch a popover, just dismiss it
        else if (!self.moreButton) {
            [self.morePopover dismissPopoverAnimated:YES];
            self.morePopover = nil;
        }
        else {
            // Need to reload it
            self.morePopover.objectArray = self.popoverItems;
            [self.morePopover.tableView reloadData];
        }
    }
    
    self.lastFrame = self.frame;
}

- (void)more:(id)sender {
    
    __weak AGNButtonMenuView * _self = self;
    
    self.morePopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:self.moreTitle];
    self.morePopover.objectArray = self.popoverItems;
    self.morePopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        
        static NSString *CellIdentifier = @"CellIdentifier";
        
        AGNSingleLineCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }

        AGNButtonMenuItem * menuItem = (AGNButtonMenuItem*)_self.popoverItems[indexPath.row];
        cell.mainLabel.text = menuItem.actionTitle();
        return cell;
    };
    
    CGRect rect = self.moreButton.frame;
    rect = [self.superview convertRect:rect fromView:self];
    [self.morePopover presentPopoverFromRect:rect
                                      inView:self.superview
                    permittedArrowDirections:UIPopoverArrowDirectionDown    
                                    animated:YES];

    
    // The code below is for testing that layout refreshes correctly when settings change.
    // Keeping it here just in case we need it again
    /*
    double delayInSeconds = 5.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        NSLog(@"Tick 0");
        [self setNeedsLayout];
        
        double delayInSeconds = 5.0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            NSLog(@"Tick 1");
            [AGNAppDelegate sharedDelegate].canCreateCalls = NO;
            [self setNeedsLayout];
            
            double delayInSeconds = 5.0;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                NSLog(@"Tick 2");
                [AGNAppDelegate sharedDelegate].canCreateCalls = YES;
                [AGNAppDelegate sharedDelegate].canCreateForms = NO;
                [self setNeedsLayout];
                
                double delayInSeconds = 5.0;
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    NSLog(@"Tick 3");
                    [AGNAppDelegate sharedDelegate].canCreateForms = YES;
                    [self setNeedsLayout];
                });
            });
        });        
    });
    */
}

- (void)objectSelected:(NSInteger)selected {
    AGNButtonMenuItem * item = self.popoverItems[selected];

    if (item.action)
        item.action(nil);

    self.morePopover.delegate=self;
    [self.morePopover dismissPopoverAnimated:YES];
    self.morePopover=nil;
}


- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController{

    if (self.morePopover == popoverController)
        self.morePopover = nil;
}


@end
