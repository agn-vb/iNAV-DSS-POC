//
//  AGNDownstreamSync+NewAccountsAndCallsGroup.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync.h"

@interface AGNDownstreamSync (NewAccountsAndCallsGroup)

- (DDSFSyncItem*)addedAccountsAndCallsGroup;

@end
