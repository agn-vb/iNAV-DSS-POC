//
//  DDSFSyncGroup.m
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFSyncGroup.h"
#import "DDSFDownstreamSync.h"

@interface DDSFDownstreamSync ()
- (void)notify:(NSString*)notificationName;
@end

@interface DDSFSyncGroup ()

@property (nonatomic, strong) NSMutableDictionary * stepsByMode;

@end

@implementation DDSFSyncGroup {
    int _currentStepIndex;
    int _processingBlocksCompleted;
}

- (id)init {
    if ((self = [super init])) {
        self.stepsByMode = [NSMutableDictionary dictionaryWithCapacity:5];
    }
    return self;
}

- (void)setSync:(DDSFDownstreamSync *)sync {
    [super setSync:sync];
    
    // Also propagate the value to all children
    for (id key in [self.stepsByMode allKeys]) {
        NSArray * steps = [self.stepsByMode objectForKey:key];
        for (DDSFSyncItem * item in steps) {
            item.sync = sync;
        }
    }
}

- (void)setProcessingQueue:(NSOperationQueue *)processingQueue {
    [super setProcessingQueue:processingQueue];

    // Also propagate the value to all children
    for (id key in [self.stepsByMode allKeys]) {
        NSArray * steps = [self.stepsByMode objectForKey:key];
        for (DDSFSyncItem * item in steps) {
            item.processingQueue = processingQueue;
        }
    }
}

- (void)setSteps:(NSArray*)steps forMode:(DDSFDownstreamSyncMode)type {
    // Set self as the delegate for the items
    for (DDSFSyncItem * item in steps)
        item.delegate = self;
    
    if (steps == nil)
        [self.stepsByMode removeObjectForKey:[NSNumber numberWithInt:type]];
    else
        [self.stepsByMode setObject:steps forKey:[NSNumber numberWithInt:type]];
}

- (NSArray*)stepsForSelectedType {
    return [self.stepsByMode objectForKey:[NSNumber numberWithInt:self.sync.mode]];
}

- (DDSFSyncItem *)currentStep {
    NSArray * steps = [self stepsForSelectedType];
    
    DDSFSyncItem * step = nil;
    if (_currentStepIndex < steps.count) {
        step = [steps objectAtIndex:_currentStepIndex];
    }
    
    return step;
}

// When in this method, we expect to be on the processing queue
- (void)executeNextStep {
    if (self.sync.aborted)
        return;
    
    DDSFSyncItem * step = [self currentStep];
    
    if (step)
        [step execute];
    
    else {
        // We're almost done
        if (self.sync.stage == kDDSFDownstreamSyncStageFetch && self.postFetch) {
            [self.processingQueue addOperationWithBlock:^{
                if (self.sync.aborted)
                    return;

                self.postFetch(self.sync);
                [self.delegate syncItemCompleted:self];
            }];
        }
        else if (self.sync.stage == kDDSFDownstreamSyncStageProcess && self.postProcess) {
            [self.processingQueue addOperationWithBlock:^{
                if (self.sync.aborted)
                    return;
                
                self.postProcess(self.sync);
                _processingBlocksCompleted++;
                [self.sync notify:kDDSFNotificationSyncProgressUpdated];
                [self.delegate syncItemCompleted:self];
            }];
        }
        else
            [self.delegate syncItemCompleted:self];
    }
}

// When in this method we can be on any queue/thread
- (void)execute {
    if (self.sync.aborted)
        return;
    
    _currentStepIndex = 0;
    
    if (self.sync.stage == kDDSFDownstreamSyncStageFetch && self.preFetch) {
        [self.processingQueue addOperationWithBlock:^{
            self.preFetch(self.sync);
            [self executeNextStep];
        }];
    }
    else if (self.sync.stage == kDDSFDownstreamSyncStageProcess && self.preProcess) {
        [self.processingQueue addOperationWithBlock:^{
            self.preProcess(self.sync);
            _processingBlocksCompleted++;
            [self.sync notify:kDDSFNotificationSyncProgressUpdated];
            [self executeNextStep];
        }];
    }
    else {
        [self.processingQueue addOperationWithBlock:^{
            [self executeNextStep];
        }];
    }
}

- (void)cancel {
    log4Info(@"%s", __PRETTY_FUNCTION__);
    [[self currentStep] cancel];
    self.stepsByMode = nil;
}

- (int)numberOfFetchTasks {
    NSArray * steps = [self stepsForSelectedType];
    int count = 0;
    
    for (DDSFSyncItem * item in steps)
        count += item.numberOfFetchTasks;
    
    return count;
}

- (int)numberOfFetchTasksCompleted {
    NSArray * steps = [self stepsForSelectedType];
    int count = 0;
    
    for (DDSFSyncItem * item in steps)
        count += item.numberOfFetchTasksCompleted;
    
    return count;
}

- (int)numberOfProcessTasks {
    NSArray * steps = [self stepsForSelectedType];
    int count = 0;
    
    for (DDSFSyncItem * item in steps)
        count += item.numberOfProcessTasks;
    
    if (self.preProcess)
        count++;
    
    if (self.postProcess)
        count++;
    
    return count;
}

- (int)numberOfProcessTasksCompleted {
    NSArray * steps = [self stepsForSelectedType];
    int count = 0;
    
    for (DDSFSyncItem * item in steps)
        count += item.numberOfProcessTasksCompleted;
    
    return count + _processingBlocksCompleted;
}

#pragma mark -
#pragma mark DDSFSyncItemDelegate

- (void)syncItemCompleted:(DDSFSyncItem*)item {
    _currentStepIndex++; // Move onto the next one

    // Need to update the progress
    [self.sync notify:kDDSFNotificationSyncProgressUpdated];
    
    // Make sure we do the next step on the right queue
    [self.processingQueue addOperationWithBlock:^{
        [self executeNextStep];
    }];
}

- (void)syncItem:(DDSFSyncItem *)step failedWithError:(NSError *)error {
    [self.delegate syncItem:step failedWithError:error];
}


@end
