//
//  AGNCallDetailDetailsViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/18/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNEligibilityHelper.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNViewController.h"

static NSString * const AGNCheckCloseButtonNotification = @"AGNCheckCloseButtonNotification";


@interface AGNCallDetailDetailsViewController : AGNViewController <AGNPopoverDelegate, UITableViewDataSource, UITableViewDelegate, UIPopoverControllerDelegate>


@property (strong, nonatomic) AGNCall * call;
@property (strong, nonatomic) NSArray *detailPositions;
@property (strong, nonatomic) NSArray *sampleInventoryLines;
@property (strong, nonatomic) NSSet *sampleProducts;
//@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

-(void)reloadData;


@end
