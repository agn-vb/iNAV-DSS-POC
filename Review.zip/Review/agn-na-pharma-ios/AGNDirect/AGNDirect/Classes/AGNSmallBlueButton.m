//
//  AGNSmallBlueButton.m
//  AGNDirect
//
//  Created by Adam McLain on 10/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSmallBlueButton.h"

@implementation AGNSmallBlueButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self styleButton];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)styleButton {
    UIImage *defalut = [[UIImage imageNamed:@"btn-smblue"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 4.0f, 2.0f)];
    UIImage *highlighted = [[UIImage imageNamed:@"btn-smblue-hi"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 3.0f, 2.0f)];
    [self setBackgroundImage:defalut forState:UIControlStateNormal];
    [self setBackgroundImage:highlighted forState:UIControlStateHighlighted];
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.titleLabel.font = [UIFont AGNHelveticaNeueBold16];
}

@end
