//
//  AGNUpdateTransactionValueHolder.h
//  AGNDirect
//
//  Created by Mark Wells on 9/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    AGNApexWrapperManageCall = 0,
    AGNApexWrapperManageInventory,
    AGNApexWrapperUpdateAccount,
    AGNApexWrapperUpsertSignature,
    AGNApexWrapperUpsertContact,
    AGNApexWrapperInsertAddress,
    AGNApexWrapperUpdateAddress,
    AGNApexWrapperUpsertSyncRecord,
    AGNApexWrapperUpsertRequestForm,
    AGNApexWrapperUpsertReprint

    //TODO: More to be added
} AGNApexWrapperType;

/**
 * The purpose if this class is simply to provide a non-persistent container for
 * the values needed to create an AGNUpdateTransaction in CoreData. This value-
 * holder can be created transiently, then passed to the AGNUpdateQueueManager
 * that either updates an existing transaction in the queue based on these values
 * or creates a new persistent transaction (an instance of NSManagedObject sub-
 * class AGNUpdateTransaction.
 */

@interface AGNUpdateTransactionValueHolder : NSObject

// GUID of the primary object being updated
@property (nonatomic, retain) NSString * guid;

// SFDC ID of the primary object being updated
@property (nonatomic, retain) NSString * salesForceId;

// undo (before image) state of the object graph being updated
@property (nonatomic, retain) NSString * undoJSONRepresentation;

// current state of the object graph being updated
@property (nonatomic, retain) NSString * currentJSONRepresentation;

// class name of the object being updated
@property (nonatomic, retain) NSString * modelClassName;

// enum value for the ID of the APEX wrapper service that should eb used to update this object
@property (nonatomic, retain) NSNumber * apexWrapperServiceId;

// timestamp when this updateTransaction was first created
@property (nonatomic, retain) NSDate * createTimestamp;

// indicator that this is an insert, rather than an update - on revert the object must be deleted
@property (nonatomic, retain) NSNumber * deleteModelObjectOnRevert;

// indicator that this transaction has to succeed
@property (nonatomic, retain) NSNumber * mustSucceed;

- (BOOL)isValid;

@end
