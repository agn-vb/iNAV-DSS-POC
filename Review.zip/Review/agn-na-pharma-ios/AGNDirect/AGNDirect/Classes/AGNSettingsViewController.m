//
//  AGNSettingsViewController.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//



#import "AGNSettingsViewController.h"
#import "SFRestAPI.h"
#import "SFOAuthCoordinator.h"
#import "AGNSyncStatusViewController.h"
#import "AGNRootViewController.h"
#import "AGNUpdateQueueManager.h"
#import "AGNAppDelegate.h"
#import "UIApplication+UberFoundationExtensions.h"
#import "ZipArchive.h"
#import <KSCrash/KSCrash.h>
#import <KSCrash/KSCrashAdvanced.h>
#import <KSCrash/KSCrashReportFilterAppleFmt.h>



//typedef enum {
//    kForceSyncSetting = 0,
//    kEmailDebugLog,
//    kSignOut,
//    kNumberSettings
//} AGNSettingsSection;

@interface AGNSettingsViewController ()

@property (nonatomic, strong) AGNSyncManager *syncManager;
@property (nonatomic, strong) UIAlertView * cannotSyncAlert;
@property (weak, nonatomic) IBOutlet UILabel *appVersionLabel;
@property (weak, nonatomic) IBOutlet UILabel *appBuildDateLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topSpaceHeaderImageViewConstaraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *deltaSyncButtonConstaraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderHeightConstaraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *settingsLabelContraint;


@end

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Constants
//------------------------------------------------------------------------------

static const int kNumberSections=1;
static const int kSettingsSection=0;
static const int kTableViewPadding=30;
static const int kToolbarWidth=130;
static const int kTableViewHeight=200;
static const int kHeadingHeight=40;
static const int kRowHeight=40;
static const int kHeaderPadding=10;

@implementation AGNSettingsViewController

//@synthesize tableView = _tableView;
@synthesize syncManager = _syncManager;
@synthesize topSpaceHeaderImageViewConstaraint;
@synthesize deltaSyncButtonConstaraint;
@synthesize topHeaderHeightConstaraint;
@synthesize settingsLabelContraint;
//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//        self.tableView.delegate = self;
//        self.tableView.dataSource = self;
//        
    }
    return self;
}

- (void)viewDidLoad {
    self.appVersionLabel.text = [NSString stringWithFormat:@"Version - %@", [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
    self.appBuildDateLabel.text = [NSString stringWithFormat:@"Build Date - %s", __DATE__];
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topSpaceHeaderImageViewConstaraint.constant=0.0f;
        self.deltaSyncButtonConstaraint.constant=102.0f;
        self.topHeaderHeightConstaraint.constant=54.0f;
        self.settingsLabelContraint.constant=12.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topSpaceHeaderImageViewConstaraint.constant=20.0f;
        self.deltaSyncButtonConstaraint.constant=122.0f;
        self.topHeaderHeightConstaraint.constant=74.0f;
        self.settingsLabelContraint.constant=32.0f;
    }
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    log4Info(@"Opening settings screen");
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleLoginSucceeded:) name:AGNUserLoginSucceededNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleLoginFailed:) name:AGNUserLoginFailedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleLogoutSucceeded:) name:AGNUserLogoutSucceededNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleLogoutFailed:) name:AGNUserLogoutFailedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:RKReachabilityDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleDownSync:) name:kDDSFNotificationSyncStarted object:nil];
    
    [self updateButtonEnablement];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)reachabilityChanged:(NSNotification*)notification {
    [self updateButtonEnablement];
}

-(void)updateButtonEnablement{
    if ([AGNSyncManager isReplayingMockData]) {
        self.forceFullSyncButton.enabled=YES;
        self.forceFullSyncButton.alpha=1.0;
        self.performDeltaSyncButton.enabled=NO;
        self.performDeltaSyncButton.alpha=.5;
        self.signOutButton.enabled = NO;
        self.signOutButton.alpha = 0.5f;
    }
    else if ([AGNAppDelegate sharedDelegate].reachabilityObserver.networkStatus < RKReachabilityReachableViaWiFi) {
        self.forceFullSyncButton.enabled=NO;
        self.forceFullSyncButton.alpha=.5;
        self.performDeltaSyncButton.enabled=NO;
        self.performDeltaSyncButton.alpha=.5;
    }
    else{
        self.forceFullSyncButton.enabled=YES;
        self.forceFullSyncButton.alpha=1.0;
        self.performDeltaSyncButton.enabled=YES;
        self.performDeltaSyncButton.alpha=1.0;
    }

}

- (void)doSignOut {
    if ([AGNSyncManager isReplayingMockData])
        return; // We don't actually do anything

    
    [[AGNAppDelegate sharedDelegate].rootViewController lowerCurtain:YES completion:^{
        [[AGNAppDelegate sharedDelegate].rootViewController navigateToCallsTab];
    }];
    [[AGNAppDelegate sharedDelegate] logout:YES];
}

- (void)signOut {
    // Check if we have any items pending for up-sync
    if ([[AGNUpdateQueueManager defaultManager] pendingUpdateCount] > 0) {
        // Do the alert
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Warning", @"Warning")
                                                         message:NSLocalizedString(@"You have unsynced changes. If you sign out, those changes will be lost", @"Unsynced changes on sign-out")
                                                        delegate:self
                                               cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel")
                                               otherButtonTitles:NSLocalizedString(@"Continue", @"Continue"), nil];
        [alert show];
    }
    else
        [self doSignOut];
}


//------------------------------------------------------------------------------
// MARK: - force sync
//------------------------------------------------------------------------------
- (void)performDeltaSyncPressed:(id)sender {
    log4Info(@"Delta sync requested");
    [self forceSync:NO];
}

- (void)forceFullSyncPressed:(id)sender {
    log4Info(@"Forced full sync requested");
    [self forceSync:YES];
}

- (void)forceSync:(BOOL)isFullSync {
    if (![AGNSyncManager isReplayingMockData] &&
        [AGNAppDelegate sharedDelegate].reachabilityObserver.networkStatus < RKReachabilityReachableViaWiFi) {
        
        // Just ignore the click
    }
    else {
        if ([[AGNAppDelegate sharedDelegate] canSyncNow]) {
            self.syncManager = [AGNAppDelegate sharedDelegate].syncManager;
            [self.syncManager performSync:isFullSync];
        }
        else {
            // Display an alert
            NSDateFormatter * df = [[NSDateFormatter alloc] init];
            [df setTimeZone:[NSTimeZone localTimeZone]];
            [df setTimeStyle:kCFDateFormatterShortStyle];
            [df setDateStyle:kCFDateFormatterNoStyle];
            NSString * time = [df stringFromDate:[AGNAppDelegate sharedDelegate].batchWindowEndDate];
            NSString * message = nil;
            if([AGNAppDelegate sharedDelegate].databaseUnavailable ){
                message = @"Database could not be opened, unable to sync.";
            }
            else{
                message = [NSString stringWithFormat:
                                       NSLocalizedString(@"The server is currently updating. Please try again after %@.",@"Batches running, try again later"),
                                       time];
            }

            log4Info(@"Unable to sync: %@", message);
            self.cannotSyncAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Unable to sync", @"Title for unable to sync")
                                                              message:message
                                                             delegate:self
                                                    cancelButtonTitle:NSLocalizedString(@"Dismiss", @"Dismiss")
                                                    otherButtonTitles:nil];
            [self.cannotSyncAlert show];
        }
    }
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Email Log File
//------------------------------------------------------------------------------

-(NSString*) generateConcatenatedLogFileName{
    NSString *firstName = [AGNAppDelegate sharedDelegate].loggedInSalesRep?[AGNAppDelegate sharedDelegate].loggedInSalesRep.firstName:@"UNKNOWN";
    NSString *lastName = [AGNAppDelegate sharedDelegate].loggedInSalesRep?[AGNAppDelegate sharedDelegate].loggedInSalesRep.lastName:@"UNKNOWN";

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyyMMdd_HHmm"];
    NSString *dateString = [dateFormatter stringFromDate:[NSDate date]];
    
    NSString * fileName = [NSString stringWithFormat:@"%@_%@_%@",lastName,firstName,dateString];
    return fileName;
}

-(NSString *)generateEmailSubject{
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *versionString = version!=nil?[NSString stringWithFormat:@"v%@",version]:@"";
    NSString * productName = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleNameKey];
    if(!productName)
        productName = @"iNAV Mobile";
    NSString *firstName = [AGNAppDelegate sharedDelegate].loggedInSalesRep?[AGNAppDelegate sharedDelegate].loggedInSalesRep.firstName:@"UNKNOWN";
    NSString *lastName = [AGNAppDelegate sharedDelegate].loggedInSalesRep?[AGNAppDelegate sharedDelegate].loggedInSalesRep.lastName:@"UNKNOWN";
    NSString *subject = [NSString stringWithFormat:@"%@ %@ Log: %@, %@, %@", productName, versionString,lastName,firstName,[[NSDate date] agnFormattedTimestampString] ];
    return subject;

}

- (NSString*)stringForUserDefaultsDump {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    NSString * result =  [[defaults dictionaryRepresentation] description];
    return [result stringByReplacingOccurrencesOfString:@"\n" withString:@"\r\n"];
}


-(void)emailLogFile{
    log4Info(@"Log file requested by email.");
    
    if([MFMailComposeViewController canSendMail]){
        MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
        mailController.mailComposeDelegate = self;
        NSString *subject = [self generateEmailSubject];
        [mailController setSubject:subject];
        NSString *emailBody = subject;
        [mailController setMessageBody:emailBody isHTML:NO];

        //**** Set up file for concatenating the logs to in the temp dir *******/
        BOOL usingConcatenatedLogs = YES;

        NSString *tempPath = [UIApplication uber_temporaryDirectoryPath];
        NSURL *tempDirectory = nil;
        NSString *baseConcatenatedName = [self generateConcatenatedLogFileName];
        NSString * concatFileName = [NSString stringWithFormat:@"%@.txt",baseConcatenatedName];
        if (tempPath) {
            tempDirectory = [NSURL fileURLWithPath:tempPath isDirectory:YES];
            log4Debug(@"Created tempdir at %@", tempDirectory);
        }
        if (!tempDirectory) {
            usingConcatenatedLogs=NO;
            log4Warn(@"Unable to create temp directory");
        }
        NSDictionary *dictionary = @{ NSFileProtectionKey : NSFileProtectionComplete };
        NSURL * concatFilePath = [tempDirectory URLByAppendingPathComponent:concatFileName];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        // if the we cannot create the file, raise a FileNotFoundException
        if (![fileManager createFileAtPath:[concatFilePath path] contents:nil attributes:dictionary]) {
            log4Error(@"Couldn't create a file at %@", [concatFilePath path] );
            concatFilePath = nil;
            usingConcatenatedLogs=NO;
        }

        NSFileHandle *outputHandle = nil;
        if(usingConcatenatedLogs)
            outputHandle = [NSFileHandle fileHandleForWritingAtPath:[concatFilePath path]];
        if(!outputHandle)
            usingConcatenatedLogs=NO;
        else{
            log4Info(@"Writing concatenated logs to file : %@",concatFilePath);
        }


        NSString *zipFileName = [NSString stringWithFormat:@"%@.zip",baseConcatenatedName];
        NSString *zipPath  = [tempPath stringByAppendingPathComponent:zipFileName];
        ZipArchive* zip = [[ZipArchive alloc] init];
        BOOL zipOutput = [zip CreateZipFile2:zipPath];


        // ********* done with output file setup  **//

        NSArray * allReports = [[KSCrash instance]allReports];
        KSCrashReportFilterAppleFmt * filter = [KSCrashReportFilterAppleFmt filterWithReportStyle:KSAppleReportStyleSymbolicated];
        NSMutableArray *crashFilePaths = [[NSMutableArray alloc]init];
        [filter filterReports:allReports onCompletion:^(NSArray *filteredReports, BOOL completed, NSError *error) {
            int i=1;
            for(NSString * report in filteredReports){
                NSString * filename = [NSString stringWithFormat:@"%@-%d-log.txt", @"crash_report", i];
                i++;
                NSData * reportData = [report dataUsingEncoding:NSUTF8StringEncoding];
                NSString* filePath = [tempPath stringByAppendingPathComponent:filename];
                [reportData writeToFile:filePath atomically:NO];

                [crashFilePaths addObject:filePath];

                if(zipOutput){
                    [zip addFileToZip:filePath newname:filename];
                }else{
                     [mailController addAttachmentData:[report dataUsingEncoding:NSUTF8StringEncoding] mimeType:@"text/plain" fileName:filename];
                }

            }
        }];

        // Now user defaults dump
        NSString * defaultsFilename = [NSString stringWithFormat:@"%@-defaults.txt", baseConcatenatedName];
        NSString * content = [self stringForUserDefaultsDump];
        BOOL addedToZip=NO;
        if(zipOutput){
            NSError *error;
            NSString* defaultsPath = [tempPath stringByAppendingPathComponent:defaultsFilename];
            if([content writeToFile:defaultsPath atomically:NO encoding:NSUTF8StringEncoding error:&error]){
                [zip addFileToZip:defaultsPath newname:defaultsFilename];
                addedToZip=YES;
            }
        }
        if(!addedToZip){
            [mailController addAttachmentData:[content dataUsingEncoding:NSUTF8StringEncoding] mimeType:@"text/plain" fileName:defaultsFilename];
        }


        int readLength = 10*1024;
        NSString *logsDirectory = [AGNLoggingHelper logsDirectory];
        NSDirectoryEnumerator *directoryEnumerator = [[NSFileManager defaultManager] enumeratorAtPath:logsDirectory];
        [directoryEnumerator skipDescendants];


        NSMutableDictionary *fileList = [[NSMutableDictionary alloc] init];
        for (NSString *path in directoryEnumerator) {
            NSDictionary *attributes = [directoryEnumerator fileAttributes];
            NSDate *lastModificationDate = [attributes objectForKey:NSFileModificationDate];
            [fileList setObject:lastModificationDate    forKey:path];
        }
        // sort them so least recent is first
        NSEnumerator *enumerator = [[fileList keysSortedByValueUsingSelector:@selector(compare:)] objectEnumerator];


        // get a list of files in the logs directory
        for (NSString *path in enumerator) {
            NSString *filePath = [logsDirectory stringByAppendingPathComponent:path];
            if(usingConcatenatedLogs){
                log4Info(@"Adding %@ to concatenated log file ",filePath);
                NSFileHandle *inputHandle = [NSFileHandle fileHandleForReadingAtPath:filePath];
                int i=0;
                NSData *data = [inputHandle readDataOfLength:readLength];
                while(data.length>0){
                    i++;
                    //NSLog(@"Writing chunk %d of %@",i,filePath);
                    [outputHandle writeData:data];
                    data = [inputHandle readDataOfLength:readLength];
                }
                [inputHandle closeFile];
                [outputHandle writeData:data];
            }else{
                if(zipOutput){
                    [zip addFileToZip:filePath newname:path];
                }else{
                    NSData *fileData = [NSData dataWithContentsOfFile:filePath];
                    [mailController addAttachmentData:fileData mimeType:@"text/plain" fileName:path];
                }
            }
        }

        if(usingConcatenatedLogs ){
            [outputHandle closeFile];
            if(zipOutput){
                [zip addFileToZip:[concatFilePath path] newname:concatFileName];
            }
        }
        if(zipOutput){
            [zip CloseZipFile2];
            NSData *zipFile = [NSData dataWithContentsOfFile:zipPath];
            [mailController addAttachmentData:zipFile mimeType:@"application/zip" fileName:zipFileName];

        }else if(usingConcatenatedLogs){
            NSData *concatData = [NSData dataWithContentsOfFile:[concatFilePath path]];
            [mailController addAttachmentData:concatData mimeType:@"text/plain" fileName:concatFileName];
        }


        NSString * supportEmailAddresses = [[NSUserDefaults standardUserDefaults] valueForKey:AGNSupportEmailAddresses];
        NSMutableArray * finalArray = [[NSMutableArray alloc]init];
        if(supportEmailAddresses){
            NSArray * addresses = [supportEmailAddresses componentsSeparatedByString:@","];
            for(NSString * address in addresses){
                NSString * email = [address agnTrim];
                if([email AGNIsValidEmail]){
                    [finalArray addObject:email];
                }else{
                    log4Warn(@"%@ doesn't look like a valid email address, not adding it");
                }
                
            }
        }
        if(finalArray.count>0)
            [mailController setToRecipients:finalArray];


//        // Set up recipients
//        NSArray *toRecipients = [NSArray arrayWithObject:@"first@example.com"];
//        NSArray *ccRecipients = [NSArray arrayWithObjects:@"second@example.com", @"third@example.com", nil];
//        [mailController setToRecipients:toRecipients];
//        [mailController setCcRecipients:ccRecipients];

        [mailController setModalPresentationStyle:UIModalPresentationFormSheet];
        [self presentViewController:mailController animated:YES completion:nil];
    }
    else{
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
                                                            message:NSLocalizedString(@"Sorry, this device is unable to send email.", @"Message to show when a user requests email on a device that doesn't support it")
                                                           delegate:self
                                                  cancelButtonTitle:NSLocalizedString(@"OK", @"OK")
                                                  otherButtonTitles:nil];
        [alertView show];
                                  
    }
}


// Dismisses the email composition interface when users tap Cancel or Send.
// Proceeds to update the message field with the result of the operation.
- (void)mailComposeController:(MFMailComposeViewController *)controller
          didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    NSString *message = nil;
    switch (result)
	{
		case MFMailComposeResultCancelled:
			message = @"cancelled";
			break;
		case MFMailComposeResultSaved:
            [[KSCrash instance]deleteAllReports];
            log4Info(@"Email saved, deleting existing crash reports");
			message = @"saved";
			break;
		case MFMailComposeResultSent:
            [[KSCrash instance]deleteAllReports];
            log4Info(@"Email sent, deleting existing crash reports");
			message = @"sent";
			break;
		case MFMailComposeResultFailed:
			message = @"failed";
			break;
		default:
			message = @"not sent";
			break;
	}
    if(error)
        log4Error(@"MailComposer had error %@, result %@", error, result);
    else
        log4Info(@"MailComposer dismissed, message %@", message);
 	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)handleLoginSucceeded:(NSNotification *)notification {
    log4Debug(@"login succeeded");
}


- (void)handleLoginFailed:(NSNotification *)notification {
    log4Debug(@"login failed");
}

- (void)handleLogoutSucceeded:(NSNotification *)notification {
    log4Debug(@"logout succeeded");
}

- (void)handleLogoutFailed:(NSNotification *)notification {
    log4Debug(@"logout failed");
}

- (void)handleDownSync:(NSNotification*)notification {
    [self.cannotSyncAlert dismissWithClickedButtonIndex:0 animated:YES];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UIAlertViewDelegate
//------------------------------------------------------------------------------

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (self.cannotSyncAlert == alertView) {
        self.cannotSyncAlert = nil;
    }
    else if (buttonIndex == 1) {
        [self doSignOut];
    }
}


- (IBAction)sendDebugPressed:(id)sender {
    [self emailLogFile];
}

- (IBAction)signoutPressed:(id)sender {
    log4Info(@"User signed out manually.");

    [self signOut];
}
@end
