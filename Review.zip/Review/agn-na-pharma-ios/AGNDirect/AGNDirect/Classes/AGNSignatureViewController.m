//
//  AGNSignatureViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/18/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  THIS IS THE RIGHT SIDE OF THE CALL VIEW (SIGNATURE / RECEIPT)

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNSignatureViewController.h"
#import "AGNCallProductSampleCell.h"
#import "AGNGetSignatureFooterCell.h"
#import "AGNSignatureImageTableViewCell.h"
#import "AGNCallNameAddressLicenseCell.h"
#import "AGNCategoryHeaders.h"
#import "AG_SignatureCaptureView.h"
#import "AGNAppDelegate.h"
#import "AGNReceiptSelectionCell.h"
#import "AGNTableView.h"
#import "AGNSampleInventoryLine.h"
#import "AGNCaptureSignatureViewController.h"
#import "AGNTableViewHeader.h"
#import "AGNCallDetailViewController.h"

static const int  kAGNMemoryBufferSize=7*1024*1024;

@interface AGNSignatureViewController ()
@property (weak, nonatomic) IBOutlet AGNTableView *signatureDetailsTableView;

@property (weak, nonatomic) IBOutlet AGNTableView *callDetailTableView;


@property (strong, nonatomic) IBOutlet UIView *signatureView;
@property (weak, nonatomic) AGNTableViewHeader *signatureFooter;
@property (strong,nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) AGNSignatureImageTableViewCell *signatureImageCell;
@property (strong, nonatomic) AGNReceiptSelectionCell *receiptSelectionCell;

@property int* memoryBuffer;
@end

@implementation AGNSignatureViewController

enum SignatureCells {
//    kSignatureHeaderCell = 0,
//    kLegalAgreementCell,
//    kSampleHeaderCell,
//    kSampleDetailCells,
    kNameAddressCell = 0,
    kReceiptSelectionCell,
    kSignatureImageCell,
    TotalSignatureCells
};

@synthesize call=_call;
@synthesize requestForm=_requestForm;
@synthesize signatureImageCell=_signatureImageCell;
@synthesize managedObjectContext=_managedObjectContext;
@synthesize receiptSelectionCell=_receiptSelectionCell;

-(AGNAddress*)address{
    if(self.call)
        return self.call.address;
    if(self.requestForm)
        return self.requestForm.address;
    return nil;
}


-(AGNAccount*)account{
    if(self.call)
        return self.call.account;
    if(self.requestForm)
        return self.requestForm.account;
    return nil;
}

-(void)setRequestForm:(AGNRequestForm *)requestForm{
    _requestForm=requestForm;
    [self.signatureDetailsTableView reloadData];
    [self setSignatureButtonEnablement];
    [self.signatureImageCell setNeedsDisplay];
}

-(void)setCall:(AGNCall *)call{
    _call=call;
    [self.signatureDetailsTableView reloadData];
    [self setSignatureButtonEnablement];
    [self.signatureImageCell setNeedsDisplay];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sampleQuantityChanged:) name:AGNSampleCellQuantityChangedNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(signatureCaptured:) name:AGNSignatureCapturedNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(switchedHCP:) name:AGNSwitchHCPNotificationKey object:nil];
    self.signatureDetailsTableView.scrollEnabled=YES;
    self.callDetailTableView.scrollEnabled=YES;
    [self setSignatureButtonEnablement];
    [self.callDetailTableView reloadData];
    [self.signatureImageCell setNeedsDisplay];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNSampleCellQuantityChangedNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNSignatureCapturedNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNSwitchHCPNotificationKey object:nil];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	self.signatureDetailsTableView.tableFooterView = [[UIView alloc] init];
    self.signatureDetailsTableView.scrollEnabled = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

    if([segue.identifier isEqualToString:@"GetSignature"]){
        AGNCaptureSignatureViewController *signatureViewController = (AGNCaptureSignatureViewController *)segue.destinationViewController;
        signatureViewController.memoryBuffer=self.memoryBuffer;
        self.memoryBuffer=nil;
        signatureViewController.call = self.call;
        signatureViewController.requestForm = self.requestForm;
    }
}

//------------------------------------------------------------------------------
// MARK: - Table View Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
//    if(tableView==self.signatureDetailsTableView)
      return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    if(tableView==self.signatureDetailsTableView)
        return [self numSamples];
    return 3;
}

- (int)numSamples
{
    return [self filteredSampleDrops].count ;
}

- (NSOrderedSet *)filteredSampleDrops
{
    //filter out any sample drops that have expired lines from being displayed
    NSIndexSet *indexSet = [self.call.liveSampleDrops indexesOfObjectsPassingTest:^BOOL(AGNSampleDrop *drop, NSUInteger idx, BOOL *stop) {
        if (self.call.isClosed || !drop.sampleInventoryLine.isExpired) {
            // anything expired will show validation error on left side, don't display on right side.
            // unless call is already closed, then expired is meaningless
            return YES;
        }
        return NO;
    }];
    
    NSOrderedSet *filteredDrops = [[NSOrderedSet alloc] initWithArray:[self.call.liveSampleDrops objectsAtIndexes:indexSet]];
    
    return filteredDrops;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = nil;
    int row = indexPath.row;
    
    

    if(aTableView==self.signatureDetailsTableView){
    
        cell = [aTableView dequeueReusableCellWithIdentifier:@"SampleDetailCell"];
        AGNSampleDrop *drop = [[self filteredSampleDrops] objectAtIndex:(row)];
        
        ((UILabel *)[cell viewWithTag:1]).text = drop.productDescription ? drop.productDescription : drop.sampleInventoryLine.product.productDescription;
        ((UILabel *)[cell viewWithTag:2]).text = drop.lotNumber ? drop.lotNumber : drop.sampleInventoryLine.lotNumber;
        ((UILabel *)[cell viewWithTag:3]).text = drop.quantity.stringValue;
        return cell;
    }
    
//    UIImage *bgImage = [[UIImage imageNamed:@"subhead-grey"] resizableImageWithCapInsets:UIEdgeInsetsMake(1.0f, 0.0f, 4.0f, 0.0f)];
//    UIImageView *headerBackground = [[UIImageView alloc] initWithImage:bgImage];
//    [headerBackground setTranslatesAutoresizingMaskIntoConstraints:NO];

//    void (^setCellBackground)(UITableViewCell *) = ^(UITableViewCell *aCell){
//        UIView *contentView = aCell.contentView;
//        [contentView addSubview:headerBackground];
//        [contentView sendSubviewToBack:headerBackground];
//        
//        NSDictionary *views = NSDictionaryOfVariableBindings(headerBackground);
//        [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[headerBackground]|" options:0 metrics:nil views:views]];
//        [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[headerBackground]" options:0 metrics:nil views:views]];
//        [contentView addConstraint:[NSLayoutConstraint constraintWithItem:headerBackground attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:contentView attribute:NSLayoutAttributeHeight multiplier:1.0 constant:1.0]];
//    };
    
    

//    if (row==kSignatureHeaderCell) {
//        cell = [aTableView dequeueReusableCellWithIdentifier:@"SignatureHeaderCell"];
//        setCellBackground(cell);
//    }
//    else if (row==kLegalAgreementCell) {
//        cell = [aTableView dequeueReusableCellWithIdentifier:@"LegalAgreementCell"];
//    }
//    else if (row==kSampleHeaderCell) {
//        cell = [aTableView dequeueReusableCellWithIdentifier:@"SampleHeaderCell"];
//        setCellBackground(cell);
//    }
//    else if (row>= kSampleDetailCells && row<=kSampleDetailCells+numberOfSamples) {
//        cell = [aTableView dequeueReusableCellWithIdentifier:@"SampleDetailCell"];
//        AGNSampleDrop *drop = [[self filteredSampleDrops] objectAtIndex:(row - 3)];
//
//        ((UILabel *)[cell viewWithTag:1]).text = drop.sampleInventoryLine.product.productDescription;
//        ((UILabel *)[cell viewWithTag:2]).text = drop.sampleInventoryLine.lotNumber;
//        ((UILabel *)[cell viewWithTag:3]).text = drop.quantity.stringValue;
//    }
    if (row==kNameAddressCell) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"NameAddressCell"];
        ((AGNCallNameAddressLicenseCell *)cell).label.attributedText = [self nameAddressLabel];
        ((AGNCallNameAddressLicenseCell *)cell).label.numberOfLines = 0;
        ((AGNCallNameAddressLicenseCell *)cell).licenseLabel.attributedText = [self licenseLabel];

    }
    else if (row==kReceiptSelectionCell) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"ReceiptSelectionCell"];
        self.receiptSelectionCell=((AGNReceiptSelectionCell *)cell);
        self.receiptSelectionCell.call = self.call;
        self.receiptSelectionCell.view = self.view;
    }
    else if (row==kSignatureImageCell) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"SignatureImageCell"];
        self.signatureImageCell = (AGNSignatureImageTableViewCell *)cell;

        if(self.call){
            if([self.call isClosed]){
                if([self.call signatureCaptureDate])
                    [self.signatureImageCell setClosedCallSignatureAcceptedMode:[self.call.signatureCaptureDate agnFormattedTimestampString]];
                else
                    [self.signatureImageCell setClosedCallNoSignatureMode];
            }
            else {
                if([self.call signatureCaptureDate])
                    [self.signatureImageCell setSignatureAcceptedMode:self.call.signatureImage];
                else
                    [self.signatureImageCell setSignaturePendingMode];
            }
        }
        else if(self.requestForm){
            if(self.requestForm.signatureImage){
                [self.signatureImageCell setSignatureAcceptedMode:self.requestForm.signatureImage];
            }else{
                [self.signatureImageCell setSignaturePendingMode];
            }
        }

        
    }
    
    if (!cell) {
        log4Debug(@"oops...no cell for row %d", row);
    }
    //useful for finding constraint violations
    log4Trace(@"\nCell: %@, Reuse id %@\n",cell,cell.reuseIdentifier);
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
        return 28.0f;
}


- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    int row = indexPath.row;
    if(aTableView==self.signatureDetailsTableView)
        return 28.0;
//    if (row==kLegalAgreementCell) {
//        return 123.0;
//    }
    if (row==kNameAddressCell) {
        return 108.0;
    }
    else if (row==kReceiptSelectionCell) {
        return 98;
    }
    else if (row==kSignatureImageCell) {
        return 163;
    }
    return 28.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    if(tableView==self.signatureDetailsTableView){
        return nil;
    }
    
    if (!self.signatureFooter) {
        AGNTableViewHeader *footer = [[AGNTableViewHeader alloc] init];
        [footer setButtonLabelText:NSLocalizedString(@"GET SIGNATURE", @"")];
        [footer.button addTarget:self action:@selector(presentSignatureCaptureViewController) forControlEvents:UIControlEventTouchUpInside];
        self.signatureFooter = footer;
    }
    
    [self setSignatureButtonEnablement];
    return self.signatureFooter;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
   if(tableView==self.signatureDetailsTableView ){
       if(self.call)
           return [self sampleCellHeaderView];
       else if(self.requestForm){
           AGNTableViewHeader *headerView = [[AGNTableViewHeader alloc] init];
           headerView.leftLabel.text = self.requestForm.type;
           return headerView;
       }
    }
    AGNTableViewHeader *headerView = [[AGNTableViewHeader alloc] init];
    return headerView;
}

- (UILabel *)formattedLabel{
    UILabel *mainLabel = [[UILabel alloc] init];
    [mainLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
    mainLabel.font = [UIFont AGNAvenirBlackFontWithSize:16.0f];
    mainLabel.textColor = [UIColor AGNEleventhHour];
    mainLabel.shadowOffset = CGSizeMake(0.0f, 0.5f);
    mainLabel.shadowColor = [UIColor AGNDropShadow];
    mainLabel.backgroundColor = [UIColor clearColor];
    return mainLabel;
}

- (UIView *)sampleCellHeaderView{
    
    AGNTableViewHeader *headerView = [[AGNTableViewHeader alloc] init];
    UILabel *sampleLabel = [self formattedLabel];
    sampleLabel.text = NSLocalizedString(@"SAMPLE", @"Sample Name Column header - sample details signature pane");
    UILabel *lotLabel = [self formattedLabel];
    lotLabel.text = NSLocalizedString(@"LOT #", @"Lot Column header - sample details signature pane");
    UILabel *quantityLabel = [self formattedLabel];
    quantityLabel.text = NSLocalizedString(@"QTY", @"Quanity Column header - sample details signature pane");
    
    [headerView addSubview:sampleLabel];
    [headerView addSubview:lotLabel];
    [headerView addSubview:quantityLabel];
    
    NSDictionary *views = NSDictionaryOfVariableBindings(sampleLabel, lotLabel,quantityLabel);
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[sampleLabel]-8-[lotLabel]-8-[quantityLabel]-22-|" options:0 metrics:nil views:views]];
    
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[sampleLabel(>=88)]" options:0 metrics:nil views:views]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[lotLabel(==90)]" options:0 metrics:nil views:views]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[quantityLabel(==45)]" options:0 metrics:nil views:views]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[sampleLabel]|" options:0 metrics:nil views:views]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[lotLabel]|" options:0 metrics:nil views:views]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[quantityLabel]|" options:0 metrics:nil views:views]];
    
    return headerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if(tableView==self.signatureDetailsTableView){
        return 0.0f;
    }
    //return kAGNTableViewHeaderHeight;
    return 34.0f;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleNone;
}

-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation{
    if(self.receiptSelectionCell){
        [self.receiptSelectionCell interfaceRotated];
    }
    
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.signatureDetailsTableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.signatureDetailsTableView.contentSize = newContentSize;
    
    newContentSize = self.callDetailTableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.callDetailTableView.contentSize = newContentSize;
}

//------------------------------------------------------------------------------
// MARK: - Utility Methods
//------------------------------------------------------------------------------

-(BOOL)hasValidAddress{
    if(!self.address){
        UIAlertView *shouldntHappenAlert = [[UIAlertView alloc] initWithTitle:@"Address is missing" message:@"The call is no longer associated with an address; address may have been deleted. Please use Switch HCP to select a new address, or create a new call." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [shouldntHappenAlert show];
        return NO;
    }
    return YES;
}

- (void)presentSignatureCaptureViewController {
    if([self hasValidAddress]){
        // allocate some memory to be sure we have 'room' for the signature.  we'll free it just before processing the signature image
        log4Info(@"About to launch signature capture, allocating memory");
       self.memoryBuffer = malloc(kAGNMemoryBufferSize);
       if(!self.memoryBuffer){
           log4Error(@"Unable to allocate memory for signature capture!!  Showing alert.");
           UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Low Memory Detected" message:@"You seem to be running low on memory - please close some other applications before proceeding. If the problem persists, restart your device." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alertView show];

            return ;
        }
        [self performSegueWithIdentifier:@"GetSignature" sender:self];
    }
}

- (void)sampleQuantityChanged:(NSNotification *)notification {
    // When the quantity text field value in an AGNCallProductSampleCell is changed, we need
    //  to recheck whether or not to enable the 'Get Signature' button on the Footer of the
    //  signatureDetailsTableView.
    [self setSignatureButtonEnablement];
    
    // Now make sure to adjust the number of samples in the samples section of the signature table
//    NSMutableArray *indexPaths = [NSMutableArray array];
//    for (int i=0; i<[self numSamples]; i++) {
//        [indexPaths addObject:[NSIndexPath indexPathForRow:i+kSampleDetailCells inSection:0]];
//    }
    // TODO fix the reloadRows
    [self.signatureDetailsTableView reloadData];
    //[self.signatureDetailsTableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:NO];
    
}


-(void)signatureCaptured:(NSNotification *)notification {
    
//    UIImage *image = (UIImage *)notification.object;
    [self setSignatureButtonEnablement];
    [self.signatureDetailsTableView reloadData];
    [self.signatureImageCell setNeedsDisplay];
}

-(void)switchedHCP:(NSNotification *)notification {
    AGNCall * newCall = (AGNCall *)notification.object;
    self.call = newCall;
    [self.signatureDetailsTableView reloadData];
    [self.callDetailTableView reloadData];
}


- (void)setSignatureButtonEnablement {
    // Cell has a 'Get Signature' button that depends on the state of the call
    //  to determine whether it should be enabled or disabled. The call must have
    //  at least one sample and a quantity in order for the button to be active.

    self.signatureFooter.button.hidden = NO;
    BOOL enableButton = NO;

    if(self.call){
        enableButton = [self.call canGetSignature];
        if([self numSamples]==0){
            if(![self.call isClosed]){ // don't bother modifying call if already closed & no samples
                if([self.call.emailReceiptRequested boolValue])
                    self.call.emailReceiptRequested=[NSNumber numberWithBool:NO];
                if([self.call.mailReceiptRequested boolValue])
                    self.call.mailReceiptRequested = [NSNumber numberWithBool:NO];
            }
            [self.receiptSelectionCell.mailReceiptSwitch setOn:NO];
            [self.receiptSelectionCell.emailReceiptSwitch setOn:NO];
            self.receiptSelectionCell.mailReceiptSwitch.enabled=NO;
            self.receiptSelectionCell.emailReceiptSwitch.enabled=NO;
            self.receiptSelectionCell.emailAddress.hidden=YES;
        }else{
            self.receiptSelectionCell.mailReceiptSwitch.enabled=YES;
            self.receiptSelectionCell.emailReceiptSwitch.enabled=YES;
            if([self.call.emailReceiptRequested boolValue])
                self.receiptSelectionCell.emailAddress.hidden=NO;
        }
    }

    if(self.requestForm){
        enableButton = NO;
        if([self.requestForm.status isEqualToString:kAGNRequestFormStatusNew] && !self.requestForm.signatureImage){
            enableButton = YES;
        }
    }

    self.signatureFooter.button.enabled = enableButton;
    self.signatureFooter.button.titleLabel.alpha = enableButton ? 1.0 : 0.5;

}


- (NSAttributedString *)nameAddressLicenseLabel {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightObliqueFont = [UIFont fontWithName:@"Avenir-LightOblique" size:16];
    UIFont *lightFont = [UIFont fontWithName:@"Avenir-Light" size:16];
    UIFont *mediumFont = [UIFont fontWithName:@"Avenir-Medium" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightObliqueAttributes = @{ NSFontAttributeName : lightObliqueFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightAttributes = @{ NSFontAttributeName : lightFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *mediumAttributes = @{ NSFontAttributeName : mediumFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:[self.account formattedName] attributes:boldAttributes];
    if (self.account.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)", self.account.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:lightObliqueAttributes]];
    }
    NSString *addressString = [NSString stringWithFormat:@"\n%@",self.address.doubleLineFormattedString];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:addressString attributes:mediumAttributes]];
    if ([self.account.licenses count] > 0) {
        AGNLicense *license = [self.account samplingLicenseForAddress:self.address];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\nLICENSE:" attributes:lightAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:license.licenseNumber attributes:boldAttributes]];
        NSDate *licenseExpDate = license.expirationDate;
        if (licenseExpDate) {
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"  EXPIRES:" attributes:lightAttributes]];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[licenseExpDate agnFormattedDateString] attributes:boldAttributes]];
        }
    }
    
    return formattedString;
}

- (NSAttributedString *)nameAddressLabel {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightObliqueFont = [UIFont fontWithName:@"Avenir-LightOblique" size:16];
    UIFont *mediumFont = [UIFont fontWithName:@"Avenir-Medium" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightObliqueAttributes = @{ NSFontAttributeName : lightObliqueFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *mediumAttributes = @{ NSFontAttributeName : mediumFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:[self.account formattedName] attributes:boldAttributes];
    if (self.account.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)", self.account.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:lightObliqueAttributes]];
    }
    NSString *addressString = [NSString stringWithFormat:@"\n%@",self.address.singleLineStreetString];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:addressString attributes:mediumAttributes]];
    NSString *cityStateZipString = [NSString stringWithFormat:@"\n%@",self.address.cityStateZipFormattedString];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:cityStateZipString attributes:mediumAttributes]];
    return formattedString;
}

- (NSAttributedString *)licenseLabel {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightFont = [UIFont fontWithName:@"Avenir-Light" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightAttributes = @{ NSFontAttributeName : lightFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    AGNLicense *license = [self.account samplingLicenseForAddress:self.address];
    if (license) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"LICENSE:" attributes:lightAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:license.licenseNumber attributes:boldAttributes]];
        NSDate *licenseExpDate = license.expirationDate;
        if (licenseExpDate) {
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"  EXPIRES:" attributes:lightAttributes]];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[licenseExpDate agnFormattedDateString] attributes:boldAttributes]];
        }
    }
    return formattedString;
}

@end
