//
//  AGNBigGreyButton.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/7/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNBigGreyButton : UIButton

@end
