//
//  AGNFindViewController.h
//  AGNDirect
//
//  Created by Mark Wells on 8/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNViewController.h"

static NSString * const AGNHCPFilterCanceledKey = @"AGNHCPFilterCanceled";

@interface AGNHCPFilterViewController : AGNViewController <UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate>

@property (strong,nonatomic) NSString *searchText;

@end
