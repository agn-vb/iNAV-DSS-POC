//
//  AGNEligibilityHelper.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


@interface AGNEligibilityHelper : NSObject

@property (strong,nonatomic) AGNCall *call;

@property (strong,nonatomic) AGNDataManager *dataManager;

@property (strong,nonatomic,readonly) NSSet *blacklistProductIds;
-(NSArray *) eligibleDetailPositions;
-(NSArray *) eligibleSampleInventoryLines;
-(BOOL) hasSamplingSection;
-(BOOL) hasSignaturePane;

// delete objects locally only
-(void) removeIneligibleDrops;
- (void)removeIneligibleDetails;
// send delete request to the server
-(void) deleteIneligibleDrops;
-(void) deleteIneligibleDetails;
- (id)initWithCall:(AGNCall *)call ;
+ (void)filterTransferEligibleReps:(NSMutableArray *)reps;
+(NSArray *) filteredDetailsForHCP:(AGNAccount *)hcp fromDetails:(NSOrderedSet *)details;
+(NSArray *) filteredSamplesForHCP:(AGNAccount *)hcp fromSamples:(NSOrderedSet *)samples atAddress:(AGNAddress *)address;
-(BOOL)isValidForUpsert;

-(void)clearCurrentCallInfo;
-(void)persistCurrentCallInfo;
-(BOOL)hasValidAddress;
-(BOOL)hasValidSalesRep;
-(BOOL) hasValidSignature;
@end
