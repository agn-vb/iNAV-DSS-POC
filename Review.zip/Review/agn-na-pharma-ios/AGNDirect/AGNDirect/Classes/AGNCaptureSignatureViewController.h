//
//  AGNCaptureSignatureViewController.h
//  AGNDirect
//
//  Created by Adam McLain on 10/11/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNViewController.h"
#import "AG_SignatureCaptureView.h"
#import "AGNRequestForm.h"
#import <QuickLook/QuickLook.h>

@interface AGNCaptureSignatureViewController : AGNViewController <UITableViewDataSource, UITableViewDelegate, AG_SignatureCaptureViewDelegate, UIAlertViewDelegate ,QLPreviewControllerDataSource>{
    
    QLPreviewController * preview;
}

@property (strong, nonatomic) AGNCall *call;
@property (strong, nonatomic) AGNRequestForm *requestForm;


@property int* memoryBuffer;
@property (weak, nonatomic) IBOutlet UILabel *legaleseLabel;

@property  (nonatomic, strong) QLPreviewController * preview;

@end
