//
//  AG_SignatureCaptureView.h
//
//  Created by Ben Gottlieb on 10/11/10.
//

#import <UIKit/UIKit.h>
@class AG_SignatureCaptureView;

@protocol AG_SignatureCaptureViewDelegate <NSObject>
- (void) signatureCaptureViewHasValidSignature: (BOOL) valid;
@optional
- (void) signatureCaptureViewTouchesEnded: (AG_SignatureCaptureView *)captureView;
@end


@interface AG_SignatureCaptureView : UIControl {

}

@property (nonatomic, strong) NSMutableArray *points;
@property (nonatomic, strong) NSMutableArray *lines;

@property (nonatomic, strong) UIButton *clearButton;
@property (nonatomic, weak) IBOutlet id <AG_SignatureCaptureViewDelegate> delegate;
@property (nonatomic, strong) UIImage *existingSignatureImage;  

- (void) clear;
- (UIImage *) signatureImage;
- (void)resetValidation;
@end
