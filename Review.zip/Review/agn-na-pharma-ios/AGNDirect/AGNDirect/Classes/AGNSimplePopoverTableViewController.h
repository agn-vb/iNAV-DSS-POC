//
//  AGNViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNCategoryHeaders.h"
#import "TypeDef.h"

@class AGNTableView;
@class AGNSimplePopoverTableViewController;

typedef NSInteger(^numberRowsBlock)(UITableView *, NSInteger);

@protocol AGNPopoverDelegate <NSObject>
@optional
// take action when item is selected
- (void)objectSelected:(NSInteger)selected;
- (void)popoverBackButtonPressed:(AGNSimplePopoverTableViewController *)popover;

@end

@interface AGNSimplePopoverTableViewController : UIPopoverController <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) id<AGNPopoverDelegate> popOverDelegate;
@property (strong, nonatomic) NSArray *objectArray;
@property (strong, nonatomic, readonly) UIViewController *viewController;
@property (strong, nonatomic, readonly) AGNTableView *tableView;
@property (strong, nonatomic) cellForRowAtIndexPathBlock cellBlock;
@property (strong, nonatomic) numberRowsBlock numberRowsBlock;
@property BOOL includeSearchBar;
@property (strong, nonatomic) UISearchBar *searchBar;
@property (strong, nonatomic) id<UISearchBarDelegate> searchBarDelegate;
@property (strong, nonatomic) UIView *headerView;
@property CGFloat rowHeight;
@property (nonatomic, strong, readwrite) NSNumber *maxWidthPercentage;


-(id)initWithDelegate:(id<AGNPopoverDelegate>)delegate andTitle:(NSString *)title;
-(void)addBackButton;

@end
