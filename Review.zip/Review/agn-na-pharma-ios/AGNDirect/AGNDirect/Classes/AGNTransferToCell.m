//
//  AGNTransferToCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTransferToCell.h"
#import "AGNTableView.h"
#import "AGNEligibilityHelper.h"
#import "NSString+AGNString.h"
#import "AGNInventoryTransactionLineCell.h"
#import "UITextField+NSIndexPath.h"

@implementation AGNTransferToCell
@synthesize filteredReps=_filteredReps;
@synthesize transaction=_transaction;

-(NSMutableArray *)filteredReps{
    if(!_filteredReps) {
        _filteredReps = [[NSMutableArray alloc]init];
    }
    return _filteredReps;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setTransaction:(AGNSampleInventoryTransaction *)transaction{
    _transaction=transaction;
    
    if([_transaction isReturn]){
        self.transferNumberLabel.text = NSLocalizedString(@"Authorization #:", @"Label for return auth number on returns screen");
        self.toNameTextField.hidden=YES;
    }else{
        self.transferNumberLabel.text = NSLocalizedString(@"Authorization #:", @"Label for transfer number on transfers screen");
        if([_transaction isOpen]){
            self.toNameTextField.hidden=NO;
            self.transferToNameLabel.hidden=YES;
            if(_transaction.to)
                self.toNameTextField.text = [_transaction toRepDisplayString];
        }else{
            self.toNameTextField.hidden=YES;
            self.transferToNameLabel.hidden=NO;
            if(_transaction.to)
                self.transferToNameLabel.text = [_transaction toRepDisplayString];
        }

   }
    
    
    if(_transaction.transferAuthorizationNumber)
        self.transferNumberTextField.text = _transaction.transferAuthorizationNumber;
    
    [self updateValidationState];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if(textField==self.transferNumberTextField){
        if(!textField.text || textField.text.length < 1){
            self.transaction.transferAuthorizationNumber=nil;
        }else{
            self.transaction.transferAuthorizationNumber = textField.text;
        }
        [self updateValidationState];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferToSelectedNotificationKey object:self];
    }
}

- (IBAction)valueChanged:(id)sender {
    if (sender == self.transferNumberTextField) {
        self.transferNumberTextField.text = [self.transferNumberTextField.text uppercaseString];
    }
}

-(void)updateValidationState{
    
    if (self.transaction.transferAuthorizationNumber && ![self.transaction.transferAuthorizationNumber AGNIsValidTransferNumber]) {
        self.transferNumberTextField.backgroundColor = [UIColor AGNWarny];
        self.transferNumberTextField.textColor = [UIColor whiteColor];
    }
    else {
        self.transferNumberTextField.backgroundColor = [UIColor whiteColor];
        self.transferNumberTextField.textColor = [UIColor blackColor];
    }
    
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    if(textField==self.transferNumberTextField) {
        self.transferNumberTextField.backgroundColor=[UIColor whiteColor];
        self.transferNumberTextField.textColor = [UIColor blackColor];
    }
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferCellDidBeginEditing object:textField];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)objectSelected:(NSInteger)selected{
    AGNSalesRep *toRep = self.filteredReps[selected];
    [self.transaction setTo:toRep];
    [self.transaction setToSalesForceId:toRep.salesForceId];
    //self.transferToNameLabel.text = [self.transaction toRepDisplayString];
    self.toNameTextField.text = [self.transaction toRepDisplayString];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferToSelectedNotificationKey object:toRep];

}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark SearchBar Delegate
//------------------------------------------------------------------------------

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)aSearchText {
    NSArray *searchResults = [[AGNDataManager defaultInstance]getRepsForFilterString:aSearchText];
    [self.filteredReps removeAllObjects];
    [self.filteredReps addObjectsFromArray:searchResults];
    [AGNEligibilityHelper filterTransferEligibleReps:self.filteredReps];
    [self.popover.tableView reloadData];
    [self.popover.searchBar becomeFirstResponder];
}


@end
