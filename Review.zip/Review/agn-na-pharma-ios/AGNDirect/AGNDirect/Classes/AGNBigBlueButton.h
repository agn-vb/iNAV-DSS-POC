//
//  AGNBigBlueButton.h
//  AGNDirect
//
//  Created by Adam McLain on 10/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNBigBlueButton : UIButton

@end
