//
//  AGNAvailabilityGrid.h
//  AGNDirect
//
//  Created by Adam McLain on 10/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNHCPAvailabilityManager.h"
#import "AGNHCPDayAvailability.h"

@interface AGNAvailabilityGrid : UIView
@property (strong, nonatomic) AGNHCPAvailabilityManager *availabilityManager;
@end
