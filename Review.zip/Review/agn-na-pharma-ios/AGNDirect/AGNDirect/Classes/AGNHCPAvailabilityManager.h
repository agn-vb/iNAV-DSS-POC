//
//  AGNHCPAvailabilityManager.h
//  TestApp
//
//  Created by Adam McLain on 10/19/12.
//  Copyright (c) 2012 AdamMcLain. All rights reserved.
//

#import <Foundation/Foundation.h>
@class AGNAddress;
@class AGNHCPDayAvailability;

typedef enum {
    kAGNWeekdayMonday = 1,
    kAGNWeekdayTuesday,
    kAGNWeekdayWednesday,
    kAGNWeekdayThursday,
    kAGNWeekdayFriday
} kAGNWeekday;

@interface AGNHCPAvailabilityManager : NSObject
@property (strong, nonatomic, readonly) AGNHCPDayAvailability *monday;
@property (strong, nonatomic, readonly) AGNHCPDayAvailability *tuesday;
@property (strong, nonatomic, readonly) AGNHCPDayAvailability *wednesday;
@property (strong, nonatomic, readonly) AGNHCPDayAvailability *thursday;
@property (strong, nonatomic, readonly) AGNHCPDayAvailability *friday;

- (id)initWithAddress:(AGNAddress *)anAddress;
- (AGNHCPDayAvailability *)dayAvailabiliyForWeekday:(int)weekday;

@end
