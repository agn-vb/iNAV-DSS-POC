//
//  AGNDualSlider.m
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNDualSlider.h"
#import "CGGeometry+UberUIKitExtensions.h"
#import "AGNCategoryHeaders.h"

#define kThumbLabelSpace 20
#define kThumbShadowSize 2
#define kThumbToOutsideTrackDelta 5

@interface AGNDualSlider ()

@property (nonatomic, assign) CGFloat lastPosition;

@property (nonatomic, strong) UILabel* minLabel;
@property (nonatomic, strong) UILabel* maxLabel;

@property (nonatomic, strong) UIImageView* minThumb;
@property (nonatomic, strong) UIImageView* maxThumb;

@property (nonatomic, strong) UIImageView* insideTrack;
@property (nonatomic, strong) UIImageView* outsideTrack;

@end

@implementation AGNDualSlider

@synthesize minLabel;
@synthesize maxLabel;
@synthesize minThumb;
@synthesize maxThumb;
@synthesize insideTrack;
@synthesize outsideTrack;
@synthesize lastPosition;
@synthesize minimumValue;
@synthesize maximumValue;
@synthesize selectedMinimumValue;
@synthesize selectedMaximumValue;
@synthesize minimumLabelText;
@synthesize maximumLabelText;
@synthesize indexPath;

#pragma mark -

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
	if (self) 
	{
        maximumValue = selectedMaximumValue = 1.0;
		
		[self addSubview:outsideTrack = 
		 [[UIImageView alloc] initWithImage:
		   [UIImage imageNamed:@"slider.png"]]];
		
		[self addSubview:insideTrack = 
		 [[UIImageView alloc] initWithImage:
		   [UIImage imageNamed:@"sliderFill.png"]]];
		
		// make the track images stretchy (and interactable)
		for (UIImageView* track in [NSArray arrayWithObjects:
									insideTrack, outsideTrack, nil])
		{
			CGFloat imageWidth = track.image.size.width;
			track.image = [track.image resizableImageWithCapInsets:
							   UIEdgeInsetsMake(0, (imageWidth-1)/2, 
												0, (imageWidth-1)/2)];
		}
		
		// create the two thumbs w/in the insideTrack
		[insideTrack addSubview:minThumb = 
		 [[UIImageView alloc] initWithImage:
		   [UIImage imageNamed:@"sliderHandle.png"]]];
		
		[insideTrack addSubview:maxThumb = 
		 [[UIImageView alloc] initWithImage:
		   [UIImage imageNamed:@"sliderHandle.png"]]];
		
		// add a label to each thumb
		[minThumb addSubview:minLabel = 
		 [[UILabel alloc] initWithFrame:CGRectZero]];
		
		[maxThumb addSubview:maxLabel = 
		 [[UILabel alloc] initWithFrame:CGRectZero]];
    
		// configure the thumbs and their labels
		for (UIImageView* thumb in [NSArray arrayWithObjects:
									minThumb, maxThumb, nil])
		{
			UILabel* label = thumb.subviews.lastObject;
			
			thumb.contentMode = UIViewContentModeBottom;
			label.font = [UIFont AGNAvenirRomanFontWithSize:12];
            label.textColor = [UIColor AGNSecondGrayd];
            label.backgroundColor = [UIColor clearColor];

			thumb.frame = CGRectInset(thumb.frame, kThumbShadowSize, 0);
			thumb.frame = CGRectOffset(thumb.frame, 0, kThumbLabelSpace);
			label.frame = CGRectOffset(label.frame, 0, -kThumbLabelSpace);
		}
		
		// minThumb is left aligned, maxThumb is right aligned
		
		maxThumb.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		minThumb.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    
		maxThumb.frame = CGRectOffset(maxThumb.frame, 
									  CGRectGetMaxX(insideTrack.bounds) - 
									  CGRectGetWidth(maxThumb.frame), 0);
	
		// vertically align everything
		// - move outsideTrack down to align with thumbs
		// - vertically center insideTrack w/in outsideTrack
		
		outsideTrack.frame = CGRectOffset(outsideTrack.frame, 
										  0, kThumbLabelSpace + 
										  kThumbToOutsideTrackDelta);
		insideTrack.frame = UberCGRectVerticallyCenteredInRect(insideTrack.frame, 
														   outsideTrack.frame);
		
		// inset insideTrack by outsideTrack's border, 
		const CGFloat edge = (CGRectGetHeight(outsideTrack.frame) - 
							  CGRectGetHeight(insideTrack.frame))/2;
		insideTrack.frame = CGRectInset(insideTrack.frame, edge, 0);
    
		// horizontally stretch the two tracks to fill the frame
		insideTrack.frame = UberCGRectGrow(insideTrack.frame,
									   CGRectGetWidth(frame) - 2*edge - 
									   CGRectGetWidth(insideTrack.frame), CGRectMaxXEdge);
		
		outsideTrack.frame = UberCGRectGrow(outsideTrack.frame, CGRectGetWidth(frame) - 
										CGRectGetWidth(outsideTrack.frame), CGRectMaxXEdge);
		
		// resize self.frame to encompass everything and configure autoresizing masks for tracks
		frame = CGRectUnion(outsideTrack.frame, 
							CGRectUnion(insideTrack.frame, minThumb.bounds));
		
		self.frame = CGRectOffset(frame, CGRectGetMinX(self.frame), CGRectGetMinY(self.frame));
		
		insideTrack.autoresizingMask = outsideTrack.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		
		// add a gestureRecognizer to track the thumbs
		[self addGestureRecognizer:
		 [[UIPanGestureRecognizer alloc] initWithTarget:self 
												  action:@selector(moveThumb:)]];
		
		[self addGestureRecognizer:
		 [[UILongPressGestureRecognizer alloc] initWithTarget:self 
														action:@selector(moveThumb:)]];
		
		((UILongPressGestureRecognizer*)self.gestureRecognizers.lastObject).minimumPressDuration = 0;
		
		// move minThumb to leftMost edge of outsideTrack
		minThumb.frame = CGRectOffset(minThumb.frame, 
									  CGRectGetMinX(outsideTrack.frame) - CGRectGetMinX(minThumb.frame) - 
									  CGRectGetMinX(insideTrack.frame), -CGRectGetMinY(insideTrack.frame));
		
		// move maxThumb to rightMost edge of outsideTrack
		maxThumb.frame = CGRectOffset(maxThumb.frame, 
									  CGRectGetMaxX(outsideTrack.frame) - CGRectGetMaxX(maxThumb.frame) - 
									  CGRectGetMinX(insideTrack.frame), -CGRectGetMinY(insideTrack.frame));
	}
    return self;
}

- (void)moveThumb:(UIGestureRecognizer*)gesture
{
	UIView* thumb = self.insideTrack.subviews.lastObject;
	const CGPoint location = [gesture locationInView:self];
	log4Trace(@"insideTrack: %@", NSStringFromCGRect(self.insideTrack.frame));
	if (gesture.state == UIGestureRecognizerStateBegan)
	{
		CGRect thumbFrame[] = 
		{
			CGRectZero, // placeholder, initially
			
			[self convertRect:self.minThumb.frame
					 fromView:self.insideTrack], 
			
			[self convertRect:self.maxThumb.frame
					 fromView:self.insideTrack], 
		};
		
		if (location.x <=	// left of midPt is min
			CGRectGetMidX(CGRectUnion(thumbFrame[1], 
									  thumbFrame[2])))
		{
			thumb = self.minThumb;
			thumbFrame[0] = thumbFrame[1];
		}
		else				// right of midPt is max
		{
			thumb = self.maxThumb;
			thumbFrame[0] = thumbFrame[2];
		}
			
		[self.insideTrack bringSubviewToFront:thumb];
		
		if (CGRectContainsPoint(thumbFrame[0], location))
		{
			thumb = nil; // we're done, skip block below
		}
		else
		{	// fake an initial lastPosition to move thumb
			self.lastPosition = CGRectGetMidX(thumbFrame[0]);
		}
	}
	
	if (thumb)
	{
		signed multiplier = 0;
		CGRectEdge limitEdge, movementEdge;
        void(^primaryBlock)(void)= nil;
        void(^secondaryBlock)(void)= nil;
        
		CGFloat delta = (location.x - self.lastPosition);
		
		if (thumb == self.minThumb)
		{
			multiplier = -1;
			limitEdge = CGRectMaxXEdge;
			movementEdge = CGRectMinXEdge;
			
			primaryBlock = ^{ [self updateMinLabel]; };
			secondaryBlock = ^{ [self updateMaxLabel]; };
		}
		else//if (thumb == self.maxThumb)
        {
			multiplier = 1;
			limitEdge = CGRectMinXEdge;
			movementEdge = CGRectMaxXEdge;
			
			primaryBlock = ^{ [self updateMaxLabel]; };
			secondaryBlock = ^{ [self updateMinLabel]; };
		}
		
		const CGRect thumbFrame = [self convertRect:thumb.frame 
										   fromView:self.insideTrack];
        
		const CGFloat thumbWidth = CGRectGetWidth(thumbFrame);
		const CGRect range = UberCGRectGrow(self.outsideTrack.frame, 
										-thumbWidth, limitEdge);
		
		if (delta < 0)
		{	// moving to the left
			delta = MAX(delta, CGRectGetMinX(range) - CGRectGetMinX(thumbFrame));
		}
		else
		{	// moving to the right
			delta = MIN(delta, CGRectGetMaxX(range) - CGRectGetMaxX(thumbFrame));
		}
		
		self.insideTrack.frame = CGRectIntegral(UberCGRectGrow(self.insideTrack.frame,
											delta*multiplier, movementEdge));
		log4Trace(@"insideTrack: %@", NSStringFromCGRect(self.insideTrack.frame));
		// if the thumbs are touching, the moving one pushes the other
		const CGFloat doubleThumbWidth = (2*thumbWidth);
		const CGFloat thumbSpan = (CGRectGetMaxX(self.maxThumb.frame) - 
								   CGRectGetMinX(self.minThumb.frame));
		
		if (thumbSpan <= doubleThumbWidth)
		{
			delta = (doubleThumbWidth - thumbSpan);
			
			self.insideTrack.frame = CGRectIntegral(UberCGRectGrow(self.insideTrack.frame, delta, limitEdge));
            log4Trace(@"insideTrack: %@", NSStringFromCGRect(self.insideTrack.frame));
			
			secondaryBlock();
		}
		
		primaryBlock();
		[self sendActionsForControlEvents:UIControlEventValueChanged];
		
		if ((delta > -0.01) && (delta < 0.01)) return;
	}
	
	self.lastPosition = location.x;
}

- (void)updateMinLabel
{
	const BOOL wasHidden = self.minLabel.hidden;
    
	self.minLabel.hidden = (!self.maxLabel.isHidden &&
							[self.minLabel.text
							 isEqualToString:self.maxLabel.text]);
	
	if (!self.minLabel.isHidden)
	{
		[self.minLabel sizeToFit];
		
		if (wasHidden ||
			self.maxLabel.isHidden)
		{
			[self updateMaxLabel];
		}
		
		CGRect labelFrame = CGRectOffset(self.minLabel.frame,
										 CGRectGetMaxX(self.minThumb.bounds) -
										 CGRectGetWidth(self.minLabel.frame) -
										 CGRectGetMinX(self.minLabel.frame), 0);
		
		CGFloat delta = (CGRectGetMinX(self.outsideTrack.frame) -
						 CGRectGetMinX([self convertRect:labelFrame
												fromView:self.minThumb]));
		if (delta > 0)
		{
			labelFrame = CGRectOffset(labelFrame, delta, 0);
		}
		
		self.minLabel.frame = labelFrame;
	}
	else
	{
		CGRect parentRect = CGRectOffset(CGRectUnion(self.minThumb.frame,
													 self.maxThumb.frame),
										 -CGRectGetMinX(self.minThumb.frame),
										 -CGRectGetMinY(self.minThumb.frame));
		self.maxLabel.frame = UberCGRectHorizontallyCenteredInRect(self.maxLabel.frame, parentRect);
	}
}

- (void)updateMaxLabel
{
	const BOOL wasHidden = self.maxLabel.hidden;
    
	self.maxLabel.hidden = (!self.minLabel.isHidden &&
							[self.minLabel.text
							 isEqualToString:self.maxLabel.text]);
	
	if (!self.maxLabel.isHidden)
	{
		[self.maxLabel sizeToFit];
		
		if (wasHidden ||
			self.minLabel.isHidden)
		{
			[self updateMinLabel];
		}
		
		CGRect labelFrame = CGRectOffset(self.maxLabel.frame,
										 -CGRectGetMinX(self.maxLabel.frame), 0);
		
		CGFloat delta = (CGRectGetMaxX(self.outsideTrack.frame) -
						 CGRectGetMaxX([self convertRect:labelFrame
												fromView:self.maxThumb]));
        
		if (delta < 0)
		{
			labelFrame = CGRectOffset(labelFrame, delta, 0);
		}
		
		self.maxLabel.frame = labelFrame;
	}
	else
	{
		CGRect parentRect = CGRectOffset(CGRectUnion(self.minThumb.frame,
													 self.maxThumb.frame),
										 -CGRectGetMinX(self.minThumb.frame),
										 -CGRectGetMinY(self.minThumb.frame));
		self.minLabel.frame = UberCGRectHorizontallyCenteredInRect(self.minLabel.frame, parentRect);
	}
}

#pragma mark -

- (CGFloat)valueRange
{
	return (self.maximumValue - self.minimumValue);
}

- (CGFloat)visualRange
{
	return (self.maxPosition - self.minPosition);
}

- (CGFloat)minPosition
{
	return (CGRectGetMinX(self.outsideTrack.frame) + CGRectGetWidth(self.minThumb.frame));
}

- (CGFloat)maxPosition
{
	return (CGRectGetMaxX(self.outsideTrack.frame) - CGRectGetWidth(self.maxThumb.frame));
}

- (CGFloat)selectedMinimumValue
{
	CGFloat curPosition = CGRectGetMaxX([self convertRect:self.minThumb.frame 
												 fromView:self.insideTrack]);
	
	return (self.minimumValue +
			self.valueRange * ((curPosition - self.minPosition) / self.visualRange));
}

- (CGFloat)selectedMaximumValue
{
	CGFloat curPosition = CGRectGetMinX([self convertRect:self.maxThumb.frame 
												 fromView:self.insideTrack]);
	
	return (self.maximumValue - 
			self.valueRange * ((self.maxPosition - curPosition) / self.visualRange));
}

- (void)setSelectedMinimumValue:(float)value
{
	CGFloat curPosition = CGRectGetMaxX([self convertRect:self.minThumb.frame
												 fromView:self.insideTrack]);
	
	CGFloat newPosition = (((value - self.minimumValue) * 
							self.visualRange) / self.valueRange) + self.minPosition;
	
	self.insideTrack.frame = CGRectIntegral(UberCGRectGrow(self.insideTrack.frame,
										curPosition - newPosition, CGRectMinXEdge));
	
	[self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)setSelectedMaximumValue:(float)value
{
	CGFloat curPosition = CGRectGetMinX([self convertRect:self.maxThumb.frame 
												 fromView:self.insideTrack]);
	
	CGFloat newPosition = (self.maxPosition - 
						   (((self.maximumValue - value) * 
							self.visualRange) / self.valueRange));
	
	self.insideTrack.frame = CGRectIntegral(UberCGRectGrow(self.insideTrack.frame,
										newPosition - curPosition, CGRectMaxXEdge));
	
	[self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)setMinimumValue:(float)value
{
	minimumValue = value;
	
	[self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)setMaximumValue:(float)value
{
	maximumValue = value;
	
	[self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (NSString *)minLabelText {
    return self.minLabel.text;
}

- (void)setMinimumLabelText:(NSString *)text {
    self.minLabel.text = text;
    [self updateMinLabel];
}

- (NSString *)maximumLabelText {
    return self.maxLabel.text;
}

- (void)setMaximumLabelText:(NSString *)text {
    self.maxLabel.text = text;
    [self updateMaxLabel];
}

- (void)setEnabled:(BOOL)enabled {
    [super setEnabled:enabled];

    self.minThumb.hidden = !enabled;
    self.maxThumb.hidden = !enabled;
    self.insideTrack.hidden = !enabled;
}

@end



