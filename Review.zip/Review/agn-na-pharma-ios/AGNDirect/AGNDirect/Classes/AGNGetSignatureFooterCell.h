//
//  AGNGetSignatureFooterCell.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/30/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNGetSignatureFooterCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIButton *getSignatureButton;
@property (weak, nonatomic) IBOutlet UIButton *acceptSignatureButton;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;

@end
