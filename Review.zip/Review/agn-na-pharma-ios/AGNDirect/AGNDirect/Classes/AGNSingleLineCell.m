//
//  AGNSingleLineCell.m
//  AGNDirect
//
//  Created by Adam McLain on 9/10/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSingleLineCell.h"

@implementation AGNSingleLineCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self agnSetStyledSelectedBackground];
        
        UILabel *label = [[UILabel alloc] init];
        [label setTranslatesAutoresizingMaskIntoConstraints:NO];
        label.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
        label.textColor = [UIColor AGNGreyMatter];
        label.highlightedTextColor = [UIColor whiteColor];
        label.backgroundColor = [UIColor clearColor];
        label.tag = 618;
        
        [self.contentView addSubview:label];
        NSDictionary *views = NSDictionaryOfVariableBindings(label);
        
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[label]|" options:0 metrics:nil views:views]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[label]|" options:0 metrics:nil views:views]];
        
        self.mainLabel = label;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
