//
//  AGNTextFieldCell.m
//  AGNDirect
//
//  Created by Adam McLain on 10/7/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTextFieldCell.h"
#import "AGNCategoryHeaders.h"

@interface AGNTextFieldCell ()
@property (nonatomic, strong, readwrite) UILabel *label;
@property (nonatomic, strong, readwrite) UITextField *textField;
@end

@implementation AGNTextFieldCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UILabel *label = [[UILabel alloc] init];
        UITextField *textField = [[UITextField alloc] init];
        [label setTranslatesAutoresizingMaskIntoConstraints:NO];
        [textField setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.label = label;
        self.label.font = [UIFont AGNAvenirHeavy16];
        self.label.textColor = [UIColor AGNGreyMatter];
        self.textField = textField;
        self.textField.font = [UIFont AGNAvenirRoman16];
        self.textField.textColor = [UIColor AGNSecondGrayd];
        [self.contentView addSubview:textField];
        [self.contentView addSubview:label];
        self.label.backgroundColor = [UIColor clearColor];
        self.textField.textAlignment = NSTextAlignmentRight;
        self.textField.backgroundColor =[UIColor clearColor];
        self.textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        
        NSDictionary *views = NSDictionaryOfVariableBindings(label, textField);
        UIView *parentView = self.contentView;
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[label]|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[textField(==20)]" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[textField]-22-|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[label]-22-|" options:0 metrics:nil views:views]];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)prepareForReuse{
    [super prepareForReuse];
    self.label.text=@"";
    self.textField.text=@"";
    self.textField.placeholder=@"";
    self.textField.delegate=nil;
}

@end
