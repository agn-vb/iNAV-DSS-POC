//
//  AGNAppDelegate.m
//  AGNDirect
//
//  Created by Mark Wells on 7/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAppDelegate.h"
#import "AGNRootViewController.h"
#import "SFAuthorizingViewController.h"
#import "SFRestAPI.h"
#import "SFNativeRootViewController.h"
#import "AGNCallDetailViewController.h"
#import "AGNUpdateQueueManager.h"
#import "AGNRequestForm.h"
#import <KSCrash/KSCrash.h>
#import <KSCrash/KSCrashAdvanced.h>


#define RETRY_PERIOD    (5*60)

//------------------------------------------------------------------------------
// MARK: - Constants
//------------------------------------------------------------------------------

NSString * const kAGNUserDefaultsKeyAllowedNumberOfQuestions = @"kAGNUserDefaultsKeyAllowedNumberOfQuestions";

NSString * const kAGNDefaultsSyncCallsKey = @"kAGNDefaultsSyncCallsKey";
NSString * const kAGNDefaultsCreateCallsKey = @"kAGNDefaultsCreateCallsKey";
NSString * const kAGNDefaultsSyncFormsKey = @"kAGNDefaultsSyncFormsKey";
NSString * const kAGNDefaultsCreateFormsKey = @"kAGNDefaultsCreateFormsKey";
NSString * const kAGNDefaultsSyncReprintsKey = @"kAGNDefaultsSyncReprintsKey";
NSString * const kAGNDefaultsCreateReprintsKey = @"kAGNDefaultsCreateReprintsKey";


static NSString *const RemoteAccessConsumerKey = @"3MVG982oBBDdwyHhnxd3O0VPz0xB1cmIbI3Q6rT9Ft6v3yQDEjM7_3jRSMnUHD2050_bs_k5mpKSR307T.DYR";
static NSString *const OAuthRedirectURI = @"testsfdc://localhost:8443/RestTest/oauth/_callback";
static NSString *const OAuthLoginDomain = @"test.salesforce.com";


//static NSString *const RemoteAccessConsumerKey = @"3MVG982oBBDdwyHglMYlRGJIClzw5OGDtzLvcD08lemEv0hEVvwYA7uHd7R9r.fEcaQ5DTrn5Vf6xPhGFpynR";
//static NSString *const OAuthRedirectURI = @"testsfdc://localhost:8443/RestTest/oauth/_callback";
//static NSString *const OAuthLoginDomain = @"dev-na3--Dev.cs13.my.salesforce.com";

static NSString *const AGNLastLoggedInUserSalesForceIdKey = @"AGNLastLoggedInUserSalesForceId";
static NSString *const AGNIsLoggedInKey = @"AGNIsLoggedInKey";

//static NSString *const RemoteAccessConsumerKey = @"3MVG9y6x0357Hlefc0.j3PhgpixxYFRnXe.bpXE3JgjSnfeTB8GFXT9HbCIEwoyTwJVa6SE.utql89RYfE86i";
//static NSString *const OAuthRedirectURI = @"testsfdc:///mobilesdk/detect/oauth/done";
//static NSString *const OAuthLoginDomain = @"jimmyliu-dev-ed.my.salesforce.com";

//@"jimmyliu-dev-ed.my.salesforce.com"
//@"jimmliu@agntest.com"
//@"Oktagon1";
//@"3MVG9y6x0357Hlefc0.j3PhgpixxYFRnXe.bpXE3JgjSnfeTB8GFXT9HbCIEwoyTwJVa6SE.utql89RYfE86i"

//------------------------------------------------------------------------------
// MARK: - Private Interface
//------------------------------------------------------------------------------

@interface AGNAppDelegate ()

@property (nonatomic, strong) AGNRootViewController *rootViewController;
@property (nonatomic, strong) AGNCall *callToRestore;
@property (nonatomic, strong) AGNRequestForm  *formToRestore;


@property (nonatomic) int environment;
@property (nonatomic, strong) NSString * key;
@property (nonatomic, strong) NSString * domain;
@property (nonatomic, strong) NSString * baseServiceUrl;

@property (nonatomic, strong) NSArray * configurations;
@property (nonatomic) BOOL logoutOnLaunch;
@property (nonatomic) BOOL needsOfflineAlert;
@property (nonatomic) BOOL retryLogin;
@property (nonatomic) BOOL cannotLoginWithAnotherUser;

@property (nonatomic, strong) UIAlertView * offlineAlert;
@property (nonatomic, strong) UIAlertView * signoffAlert;

@property (nonatomic, strong) NSTimer * nextSyncTimer;
@property (nonatomic, strong) NSDate * nextSyncRetryTime;
@property (nonatomic, strong) NSTimer * nextSyncRetryTimer;

@property (nonatomic, strong) NSMutableDictionary * settings;

@property (nonatomic, strong) UIAlertView * batchIsRunningAlert;

@property (nonatomic, strong) UIAlertView * databaseUnavailableAlert;

- (void)configureLoggedInSalesRep;
- (void)wipeDatabase;

@end


//------------------------------------------------------------------------------
// MARK: - Implementation
//------------------------------------------------------------------------------

@implementation AGNAppDelegate

@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;
@synthesize dataManager = _dataManager;
@synthesize lastLoggedInUserSFDCID = _lastLoggedInUserSFDCID;
@synthesize syncManager = _syncManager;
@synthesize loggedInSalesRep = _loggedInSalesRep;
@synthesize callToRestore;
@synthesize settings=_settings;
@synthesize databaseUnavailable=_databaseUnavailable;
@synthesize databaseUnavailableAlert=_databaseUnavailableAlert;

+ (AGNAppDelegate *)sharedDelegate {
    return (AGNAppDelegate *)[UIApplication sharedApplication].delegate;
}

+ (NSString*)serviceUrlForPath:(NSString*)servicePath {
    NSString * baseUrl = [AGNAppDelegate sharedDelegate].baseServiceUrl;
    return [baseUrl stringByAppendingString:servicePath];
}

- (NSString*)homeUrl {
    return [_baseServiceUrl stringByAppendingString:@"/home/home.jsp"];
}

-(NSInteger)monthsCallHistory{
    NSInteger numMonthsOfCallHistoryToRetrieve = [[NSUserDefaults standardUserDefaults] integerForKey:@"months_call_history"];
    if(numMonthsOfCallHistoryToRetrieve>0 && numMonthsOfCallHistoryToRetrieve<6)
        return numMonthsOfCallHistoryToRetrieve;
    else return 6;
}

- (void)loadConfig {
    if (!self.configurations) {
        [AGNLoggingHelper setUpLogging];
        [AGNAppDelegate synchronizeWithSettingsBundle];

        // Read all configurations
        int i = 10;
        printf("size of int is  %zu bytes \n",sizeof(int)) ;
        printf("size of pointer to int is %zu bytes \n",sizeof(int *)) ;
        
        NSError * error = nil;
        NSData * confData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"environments" ofType:@"json"]];
        self.configurations = (NSArray*)[NSJSONSerialization JSONObjectWithData:confData options:0 error:&error];
        NSAssert1(error == nil, @"Error parsing environments.json - %@", error);

        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        self.environment = [[defaults objectForKey:@"environment"] intValue];
        
        NSDictionary * config = [self.configurations objectAtIndex:self.environment];
        log4Info(@"Selected environment %@", [config objectForKey:@"name"]);
        self.key = [config objectForKey:@"key"];
        self.domain = [config objectForKey:@"domain"];
        
        NSNumber * oldEnv = [defaults objectForKey:@"previouslySelectedEnvironment"];
        if (oldEnv) {
            if ([oldEnv intValue] != self.environment) {
                [self wipeDatabase];
                self.logoutOnLaunch = YES;
                [defaults setInteger:self.environment forKey:@"previouslySelectedEnvironment"];
            }
        }
        else {
            [defaults setInteger:self.environment forKey:@"previouslySelectedEnvironment"];
        }
        [defaults synchronize];
    }
}

- (void)printOutBatchDates {
    log4Info(@">>>>>>>>>>>  Batch window: %@ to %@", [self.batchWindowStartDate agnLocalTimeString],[self.batchWindowEndDate agnLocalTimeString]);
}

- (void)retrySync {
    log4Info(@"Retrying Sync");
    [self resetSyncDeferral];
    [self.nextSyncTimer invalidate];
    self.nextSyncTimer = nil;
    [[AGNUpdateQueueManager defaultManager] processQueue]; // Trigger the update manager
    [self checkNextSync]; // Trigger automatic down sync if needed
}

- (void)retryDownstreamSync {
    if ([self shouldSyncNow])
        [self retrySync];
}

- (void)deferSync {
    self.nextSyncRetryTimer = [NSTimer scheduledTimerWithTimeInterval:RETRY_PERIOD+1 target:self selector:@selector(retrySync) userInfo:nil repeats:NO]; // Adding an extra second to make sure that the timer fires after we're past the time.
    self.nextSyncRetryTime = [NSDate dateWithTimeIntervalSinceNow:RETRY_PERIOD];
    log4Info(@"Deferring sync - next retry time: %@", [self.nextSyncRetryTime agnLocalTimeString]);
}

- (void)resetSyncDeferral {
    [self.nextSyncRetryTimer invalidate];
    self.nextSyncRetryTimer = nil;
    self.nextSyncRetryTime = nil;
}

- (BOOL)canSyncNow {
    if(self.databaseUnavailable)
        return NO;
    NSDate * now = [NSDate date];
    if ([now timeIntervalSinceDate:self.batchWindowStartDate] < 0) // Now is earlier than batch start time
        return YES;
    
    if ([now timeIntervalSinceDate:self.batchWindowEndDate] >= 0) // Now is later than batch end time
        return YES;
    
    return NO;
}

- (BOOL)shouldSyncNow {
    if (![self canSyncNow]){
        return NO;
    }
    
    if (!self.nextSyncRetryTime)
        return YES;
    
    if ([self.nextSyncRetryTime timeIntervalSinceNow] >= 0) // Next retry is later than now
    {
        if([self syncInterrupted])
            return YES;
        return NO;
    }

    return YES;
}



// This method will either trigger next sync, or set up a timer
// Returns YES if sync was triggered, NO if it was scheduled
- (BOOL)checkNextSync {

    // Calculate midnight today
    NSDate * now = [NSDate date];
    NSDate * midnightToday = [now agnMidnightEastCoast];

    // Get the batch window start time
    NSInteger minutesSinceMidnight = 0;
    NSNumber * minutesSinceMidnightValue = [[NSUserDefaults standardUserDefaults] objectForKey:AGNBatchWindowStartTimeKey];
    if (minutesSinceMidnightValue)
        minutesSinceMidnight = [minutesSinceMidnightValue integerValue];
    
    self.batchWindowStartDate = [midnightToday dateByAddingTimeInterval:60.0f*minutesSinceMidnight];;
    
    // Get the force sync threshold
    minutesSinceMidnight = 360;
    minutesSinceMidnightValue = [[NSUserDefaults standardUserDefaults] objectForKey:AGNBatchWindowEndTimeKey];
    if (minutesSinceMidnightValue)
        minutesSinceMidnight = [minutesSinceMidnightValue integerValue];
    
    self.batchWindowEndDate = [midnightToday dateByAddingTimeInterval:60.0f*minutesSinceMidnight];
    [self printOutBatchDates];


    if([self syncInterrupted]){
        if(![self canSyncNow]){
            log4Warn(@"Last Sync was interrupted, but can't sync now.  Warning user, will sync when able.");
            [self.rootViewController showSyncInterruptedAlert];
        }else{
            log4Warn(@"Last Sync was interrupted, syncing now!");
            return [self.rootViewController triggerDownstreamSync];
        }
    }
    else{
        if ([self.batchWindowEndDate timeIntervalSinceDate:now] < 0) {
            // We are already past the threshold - need to check if we have synced
            
            if ((!self.syncManager.localLastSyncStartedTimestamp && [self canSyncNow]) ||
                ([self.syncManager.localLastSyncStartedTimestamp timeIntervalSinceDate:self.batchWindowEndDate] < 0 && [self shouldSyncNow])) {
                
                // No, the last sync time was before the threshold and we can/should sync now (not within the batch window or deferred).
                // We need to sync now
                // We are not going to setup the timer, since it will be reset after the sync completes or fails.
                log4Info(@"It is time to sync, triggering downstream sync, last sync %@",self.syncManager.localLastSyncStartedTimestamp);
                [self printOutBatchDates];
                return [self.rootViewController triggerDownstreamSync];            
            }
            else if (self.syncManager.localLastSyncStartedTimestamp && [self.syncManager.localLastSyncStartedTimestamp timeIntervalSinceDate:self.batchWindowEndDate] >= 0) { // Only do this if we have synced today.
                // We have already synced today.  Next time - tomorrow
                log4Info(@"have already synced today, last sync %@", self.syncManager.localLastSyncStartedTimestamp);
                NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateComponents *components = [[NSDateComponents alloc] init];
                components.day = 1;
                
                while ([self.batchWindowEndDate timeIntervalSinceNow] < 0) { // Do this as a loop to make sure we're in the future
                    self.batchWindowEndDate = [gregorian dateByAddingComponents:components toDate:self.batchWindowEndDate options:0];
                    self.batchWindowStartDate = [gregorian dateByAddingComponents:components toDate:self.batchWindowStartDate options:0];
                }
                // If the batchWindowStartDate is later than end date, we need to decrease it back
                if ([self.batchWindowStartDate timeIntervalSinceDate:self.batchWindowEndDate] > 0) {
                    components.day = -1;
                    self.batchWindowStartDate = [gregorian dateByAddingComponents:components toDate:self.batchWindowStartDate options:0];
                }
                
            }
            // else - we need the sync but could not sync because of deferral.  We will sync on the deferral timer
        }
        else if ([self.batchWindowStartDate timeIntervalSinceDate:now] > 0) {
            // The sync date is in the future, but we are before the batch window. E.g. batches start at 1am, and it's now 12:30am.
            if ((!self.syncManager.localLastSyncStartedTimestamp && [self canSyncNow]) ||
                ([self.syncManager.localLastSyncStartedTimestamp timeIntervalSinceNow] < - 24 * 60 * 60 && [self shouldSyncNow])) { // last sync is older than 24 hours (local time)
                log4Info(@"triggering sync, last sync %@", self.syncManager.localLastSyncStartedTimestamp);

                // We haven't synced for more than 24 hours. We need to sync now
                [self printOutBatchDates];
                return [self.rootViewController triggerDownstreamSync];
            }
        }
    }

    if (self.nextSyncTimer)  // Cancel the old timer
        [self.nextSyncTimer invalidate];
    
    self.nextSyncTimer = [NSTimer scheduledTimerWithTimeInterval:[self.batchWindowEndDate timeIntervalSinceNow] target:self selector:@selector(retryDownstreamSync) userInfo:nil repeats:NO];
    log4Info(@"Set up next sync timer");
    return NO;
}

-(NSObject *)configSettingForKey:(NSString *)key{
    return self.settings[key];
}

-(void)setConfigSetting:(NSObject *)value forKey:(NSString * )key{
    self.settings[key]=value;
}

-(NSMutableDictionary *)settings{
    if(!_settings){
        _settings = [[NSMutableDictionary alloc]init];
    }
    return _settings;
}

//------------------------------------------------------------------------------
// MARK: - Application life-cycle
//------------------------------------------------------------------------------

-(void) setupCrashLogs{
    [KSCrash installWithCrashReportSink:nil];

    NSArray * allReports = [[KSCrash instance]allReports];
    for(NSDictionary * dict in allReports){
        NSDictionary *report = dict[@"report"];
        log4Warn(@"FOUND CRASH LOG %@ from %@",report[@"id"], report[@"timestamp"]);
    }
    
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application{
    log4Warn(@"Application received a low memory warning!");
}

-(void)logTimeZone{
    [NSTimeZone resetSystemTimeZone];
    log4Info(@"System Time Zone : %@",[NSTimeZone systemTimeZone]);
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
#if TRAINING
    // We want to go into replay mode
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:@"replay:training" forKey:kDDSFDownstreamSyncMockModeDefaultsKey];
    [defaults synchronize];

    // Also set base service URL. It doesn't mean anything, but should be a valid URL
     self.baseServiceUrl = @"https://training.nowhere.com";
#endif
    
    
    // this should be just about the first thing we do
    [self loadConfig];
    [self setApplicationGUID];
    [self setupCrashLogs];

    [self logTimeZone];


    
    // Set up a reachability observer on the SFDC login host
    self.reachabilityObserver = [RKReachabilityObserver reachabilityObserverForInternet];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reachabilityChanged:)
                                                 name:RKReachabilityDidChangeNotification
                                               object:nil];
    
    
    // Pick up the intialViewController instantiated from the storyboard
    self.rootViewController = (AGNRootViewController *)self.window.rootViewController;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(mergeChanges:)
                                                 name:NSManagedObjectContextDidSaveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(downstreamSyncBegan:)
                                                 name:kDDSFNotificationSyncStarted
                                               object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(downstreamSyncCompleted:)
                                                 name:kDDSFNotificationSyncEnded
                                               object:nil];

    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(timezoneChanged:)
                                                 name:NSSystemTimeZoneDidChangeNotification
                                               object:nil];

    if (self.logoutOnLaunch)
        [self logout:YES];
    
    [self configureLoggedInSalesRep];
    
    AGNUpdateQueueManager * queueMgr = [AGNUpdateQueueManager defaultManager]; //Initialize the update queue manager
    log4Info(@"Application version %@ (GUID: %@) launched with %d items in the update queue.",[self applicationVersion],[self applicationGUID], [queueMgr pendingUpdateCount]);
    
    return YES;
    
    // Now that we are using storyboards, do NOT call super
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Stop downsync timer
    [self.nextSyncTimer invalidate];
    self.nextSyncTimer = nil;
    log4Info(@"Application about to enter inactive state");
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // this is now done in calldetailviewcontroller
  //  [self persistCurrentCallInfo];
    
    // Stop the deferral timer
    [self.nextSyncRetryTimer invalidate];
    self.nextSyncRetryTimer = nil;
    
    // Let's set up our next sync call - DEBUG ONLY
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    // First, let's set up our last sync date to be really old
    if (self.syncManager.utcLastCompleteSyncTimestamp && [defaults boolForKey:@"reset_last_sync_date"])
        self.syncManager.utcLastCompleteSyncTimestamp = [self.syncManager.utcLastCompleteSyncTimestamp dateByAddingTimeInterval:-48*60*60]; // Two days in the past
    
    // Now set the theshold so that it is two minutes from now
    if ([defaults boolForKey:@"simulate_time_to_sync"]) {
        NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDate * now = [NSDate date];
        NSDateComponents * components = [gregorian components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit|NSMinuteCalendarUnit|NSTimeZoneCalendarUnit) fromDate:now];
        NSInteger minutes = components.hour * 60 + components.minute;
        
        // Now also need to correct for timezone
        NSTimeZone * eastCoast = nil;
        if (components.timeZone.isDaylightSavingTime)
            eastCoast = [NSTimeZone timeZoneWithAbbreviation:@"EDT"];
        else
            eastCoast = [NSTimeZone timeZoneWithAbbreviation:@"EST"];
        
        int timezoneMinutes = (eastCoast.secondsFromGMT - components.timeZone.secondsFromGMT)/60;
        
        
        [defaults setObject:[NSNumber numberWithInteger:minutes + 16 + timezoneMinutes] forKey:AGNForcedSyncTimeKey];
        [defaults setObject:[NSNumber numberWithInteger:minutes + 16 + timezoneMinutes - 180] forKey:AGNBatchWindowStartTimeKey];
        [defaults synchronize];
        
        NSDate * midnightToday = [now agnMidnightEastCoast];
        log4Info(@"===============  SETUP DOWNSTREAM TRIGGER FOR %@ ================", [[midnightToday dateByAddingTimeInterval:(minutes + 16 + timezoneMinutes)*60] agnLocalTimeString]);
    }
    log4Info(@"Application moving to background.");

    [super applicationDidEnterBackground:application];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Let's check environment
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];

    [self logTimeZone];
    
    NSNumber * newEnvironment = [defaults objectForKey:@"environment"];
    if ([newEnvironment intValue] != self.environment) {
        log4Info(@"Entering foreground.  New environment selected: %d (was %d), clearing upsync queue",newEnvironment,self.environment);
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Environment Changed" message:@"You have selected a different environment. Please quit the app and restart. All unsynced changes have been lost." delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil];
        [alert show];
        [[AGNUpdateQueueManager defaultManager] clearQueue];
        return;
    }

    AGNUpdateQueueManager * queueMgr = [AGNUpdateQueueManager defaultManager]; //Initialize the update queue manager
    log4Info(@"Application entering foreground with %d items in the update queue.", [queueMgr pendingUpdateCount]);
    [self navigateToCallIfShouldRestore];
    [self navigateToFormIfShouldRestore];

    if ([self syncInterrupted]) {
        [self retrySync];
    }
    // Restore deferral timer
    if (self.nextSyncRetryTime) {
        if ([self.nextSyncRetryTime timeIntervalSinceNow] <= 0) // Is it already time to retry?
            [self retrySync];
        else
            self.nextSyncRetryTimer = [NSTimer scheduledTimerWithTimeInterval:[self.nextSyncRetryTime timeIntervalSinceNow] target:self selector:@selector(retrySync) userInfo:nil repeats:NO]; // Schedule a timer
    }
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    log4Info(@"Application became active.");
    [self navigateToCallIfShouldRestore];
    [self navigateToFormIfShouldRestore];
    [self checkNextSync];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    log4Info(@"Application terminating.");
    [super applicationWillTerminate:application];
}


//------------------------------------------------------------------------------
// MARK: - Remote Access / OAuth configuration
//------------------------------------------------------------------------------

- (NSString*)remoteAccessConsumerKey {
    [self loadConfig];
    return self.key;
}

- (NSString*)oauthRedirectURI {
    return OAuthRedirectURI;
}

- (NSString *)oauthLoginDomain {
    [self loadConfig];
    return self.domain;
}

- (void)logout:(BOOL)clearUser {
    self.isAuthenticated = NO;
    if (clearUser) {
        self.isLoggedIn = NO;
        self.syncManager.utcLastCompleteSyncTimestamp = nil;
        self.syncManager.localLastSyncStartedTimestamp = nil;
        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        [defaults removeObjectForKey:AGNLastSyncTimestampKey];
        [defaults removeObjectForKey:AGNLastSyncLocalTimestampKey];
        [defaults setBool:NO forKey:AGNIsLoggedInKey]; // Not logged in any more
        [defaults synchronize];
        
        // Kill Okta cookies
        NSHTTPCookieStorage * storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
        for (NSHTTPCookie * cookie in [storage cookies]) {
            if ([cookie.domain hasSuffix:@".okta.com"])
                [storage deleteCookie:cookie];
        }
    }
    [super logout];
    [[SFRestAPI sharedInstance].coordinator revokeAuthentication];
}

//- (void)identityCoordinatorRetrievedData:(SFIdentityCoordinator *)coordinator {
//    [super identityCoordinatorRetrievedData:coordinator];
//    [self.authViewController dismissViewControllerAnimated:YES completion:nil];
//}
//
//- (void)identityCoordinator:(SFIdentityCoordinator *)coordinator didFailWithError:(NSError *)error {
//    [super identityCoordinator:coordinator didFailWithError:error];
//    [self.authViewController dismissViewControllerAnimated:YES completion:nil];
//}

- (UIViewController *)newRootViewController {
    return self.rootViewController;
}

- (void)configureLoggedInSalesRep {
    
    self.lastLoggedInUserSFDCID = [[NSUserDefaults standardUserDefaults] valueForKey:AGNLastLoggedInUserSalesForceIdKey];
    self.isLoggedIn = [[NSUserDefaults standardUserDefaults] boolForKey:AGNIsLoggedInKey];
    
#if TRAINING
    log4Debug(@"Last Logged in is %@",self.lastLoggedInUserSFDCID);
    if(!self.lastLoggedInUserSFDCID && [AGNSyncManager isReplayingMockData]) {
        // Need to read the ID from the file
        NSString * path = [[NSBundle mainBundle] pathForResource:@"user-0" ofType:@"json" inDirectory:@"training"];
        NSData * data = [NSData dataWithContentsOfFile:path];
        NSDictionary * json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSDictionary * userData = json[@"userData"];
        self.lastLoggedInUserSFDCID = userData[@"Id"];
        self.isLoggedIn = YES;
    }
#endif
    
    // If offline and logged in - retrieve the sales rep
    if ((self.reachabilityObserver.networkStatus < RKReachabilityReachableViaWiFi && self.isLoggedIn) || [AGNSyncManager isReplayingMockData]) {
        self.loggedInSalesRep = self.lastLoggedInUserSFDCID ? [[AGNDataManager defaultInstance] getRepForId:self.lastLoggedInUserSFDCID] : nil;
    }
}


//------------------------------------------------------------------------------
// MARK: - Actions
//------------------------------------------------------------------------------

- (BOOL)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
            return NO;
        }
    }
    return YES;
}

//------------------------------------------------------------------------------
// MARK: - Core Data stack
//------------------------------------------------------------------------------

-(AGNSyncManager *)syncManager{
    if(_syncManager){
        return _syncManager;
    }
    _syncManager = [[AGNSyncManager alloc]init];
    return _syncManager;
}

-(AGNDataManager *)dataManager{
    if(_dataManager != nil){
        return _dataManager;
    }
    
    _dataManager = [[AGNDataManager alloc] initWithManagedObjectContext:self.managedObjectContext];
    return _dataManager;
}

- (NSManagedObjectContext*)temporaryMOC {
    NSManagedObjectContext * moc = nil;
    
    NSPersistentStoreCoordinator * coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        moc = [[NSManagedObjectContext alloc] init];
        [moc setPersistentStoreCoordinator:coordinator];
        [moc setUndoManager:nil];
    }
    return moc;
  
}

// Returns the managed object context for the application.
// If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
- (NSManagedObjectContext *)managedObjectContext
{
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(contextDidSave:)
                                                     name:NSManagedObjectContextDidSaveNotification
                                                   object:nil];
    }
    return _managedObjectContext;
}

- (void)contextDidSave:(NSNotification *)notification {
    
    SEL selector = @selector(mergeChangesFromContextDidSaveNotification:);
    [_managedObjectContext performSelectorOnMainThread:selector withObject:notification waitUntilDone:YES];
    
}

// Returns the managed object model for the application.
// If the model doesn't already exist, it is created from the application's model.
- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Model" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

-(BOOL) shouldPerformLightweightMigrationFromVersion:(NSString*)oldVersion toVersion:(NSString*)newVersion {
    return YES;
}

- (void)setupPersistentStore {
    NSError *error = nil;
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"Model.sqlite"];
    NSManagedObjectModel * model = _persistentStoreCoordinator.managedObjectModel;
    NSDictionary *sourceMetadata = [NSPersistentStoreCoordinator metadataForPersistentStoreOfType:NSSQLiteStoreType
                                                                                              URL:storeURL
                                                                                            error:&error];

    if (sourceMetadata) {
        // We found a store. Need to check versions

        NSManagedObjectModel *sourceModel = [NSManagedObjectModel mergedModelFromBundles:nil
                                                                        forStoreMetadata:sourceMetadata];
        NSString * oldVersion = [sourceModel.versionIdentifiers anyObject];
        NSString * newVersion = [model.versionIdentifiers anyObject];

        if (![model isConfiguration:nil compatibleWithStoreMetadata:sourceMetadata]) {
            // Migration is required
            log4Info(@"Converting data model version - old : %@  new: %@",oldVersion,newVersion);

            log4Info(@"Setting full sync required flag to YES");
            [self.syncManager setNeedFullSync:YES];

            // Let's check if lightweight migration is possible
            // Get the old model
            NSManagedObjectModel *sourceModel = [NSManagedObjectModel mergedModelFromBundles:nil
                                                                            forStoreMetadata:sourceMetadata];

            error = nil;
            NSMappingModel * mappingModel = sourceModel?[NSMappingModel inferredMappingModelForSourceModel:sourceModel destinationModel:model error:&error]:nil;

            if (mappingModel && !error) {


                // Can perform lightweight migration - ask the delegate if we should
                BOOL shouldPerformLightweightMigration = YES;
                shouldPerformLightweightMigration = [self shouldPerformLightweightMigrationFromVersion:oldVersion toVersion:newVersion];

                

                if (shouldPerformLightweightMigration) {
                    log4Info(@"About to attempt a lightweight migration from %@ to %@ ",oldVersion,newVersion);
                    NSDictionary * options = @{
                                               NSPersistentStoreFileProtectionKey: NSFileProtectionComplete,
                                               NSMigratePersistentStoresAutomaticallyOption: @YES,
                                               NSInferMappingModelAutomaticallyOption:@YES
                                               };

                    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:options error:&error]) {
                        /*
                         Replace this implementation with code to handle the error appropriately.

                         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.

                         Typical reasons for an error here include:
                         * The persistent store is not accessible;
                         * The schema for the persistent store is incompatible with current managed object model.
                         Check the error message to determine what the actual problem was.


                         If the persistent store is not accessible, there is typically something wrong with the file path. Often, a file URL is pointing into the application's resources directory instead of a writeable directory.

                         If you encounter schema incompatibility errors during development, you can reduce their frequency by:
                         * Simply deleting the existing store:
                         [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil]

                         * Performing automatic lightweight migration by passing the following dictionary as the options parameter:
                         @{NSMigratePersistentStoresAutomaticallyOption:@YES, NSInferMappingModelAutomaticallyOption:@YES}

                         Lightweight migration will only work for a limited set of schema changes; consult "Core Data Model Versioning and Data Migration Programming Guide" for details.

                         }

                         */
                       // NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
                        log4Error(@"Unresolved error opening database  %@, %@", error, [error userInfo]);
                        [self warnDatabaseUnavailable:error];
                        return;

                    }

                    log4Info(@"Successfully performed lightweight migration from version %@ to %@",[sourceModel.versionIdentifiers anyObject],[model.versionIdentifiers anyObject]);

                    return;
                }
            }
            else {
                // Cannot perform lightweight migration

                // TODO: let the delegate perform the migration
                log4Error(@"Unresolved error opening database  %@, %@", error, [error userInfo]);
                [self warnDatabaseUnavailable:error];
                return;
            }
        }
        else{
            log4Info(@"Model is compatible with store, leaving it alone.");
        }

    }else{
        log4Info(@"Store Metadata null, this may be a new installation.  Proceeding to create persistent store.");
    }



    NSMutableDictionary *options = [NSMutableDictionary dictionary];
    [options setValue:NSFileProtectionComplete forKey:NSPersistentStoreFileProtectionKey];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:options error:&error]) {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
         
         Typical reasons for an error here include:
         * The persistent store is not accessible;
         * The schema for the persistent store is incompatible with current managed object model.
         Check the error message to determine what the actual problem was.
         
         
         If the persistent store is not accessible, there is typically something wrong with the file path. Often, a file URL is pointing into the application's resources directory instead of a writeable directory.
         
         If you encounter schema incompatibility errors during development, you can reduce their frequency by:
         * Simply deleting the existing store:
         [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil]
         
         * Performing automatic lightweight migration by passing the following dictionary as the options parameter:
         @{NSMigratePersistentStoresAutomaticallyOption:@YES, NSInferMappingModelAutomaticallyOption:@YES}
         
         Lightweight migration will only work for a limited set of schema changes; consult "Core Data Model Versioning and Data Migration Programming Guide" for details.
         
         */
        log4Error(@"Unresolved error opening database  %@, %@", error, [error userInfo]);
        [self warnDatabaseUnavailable:error];
    }
}

-(void) warnDatabaseUnavailable:(NSError*) error{
    self.databaseUnavailable=YES;
    self.databaseUnavailableAlert = [[UIAlertView alloc]initWithTitle:@"Unable To Restore Database" message:[NSString stringWithFormat:@"Could not open database due to unexpected error; please contact support for further instruction.  " ] delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
    [self.databaseUnavailableAlert show];
}

- (void)wipeDatabase {
    NSPersistentStoreCoordinator * persistentStoreCoordinator = self.persistentStoreCoordinator; // We have to create one even if one has not been initialized yet to know the paths
    
    NSArray *stores = [persistentStoreCoordinator persistentStores];
    for(NSPersistentStore *store in stores) { // There should only be one, but this is safer
        [persistentStoreCoordinator removePersistentStore:store error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:store.URL.path error:nil];
    }

    // Need to add the persistent store back
    [self setupPersistentStore];
}

// Returns the persistent store coordinator for the application.
// If the coordinator doesn't already exist, it is created and the application's store added to it.
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    if (_persistentStoreCoordinator == nil) {
        _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
        [self setupPersistentStore];
    }
    return _persistentStoreCoordinator;
}

- (void)mergeChanges:(NSNotification *)notification {
    if (![NSThread isMainThread]) {
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self.managedObjectContext mergeChangesFromContextDidSaveNotification:notification];
            log4Debug(@">>>>>>> Merged changes");
            log4Debug(@"Current Thread is: %@\n", [NSThread currentThread]);
        });
    }
    else {
        [self.managedObjectContext mergeChangesFromContextDidSaveNotification:notification];
        log4Debug(@">>>>>>> Merged changes");
        log4Debug(@"Changes happening on the main thread]\n");
    }
}

- (void) setLoggedInSalesRep:(AGNSalesRep *)loggedInSalesRep{
    if(loggedInSalesRep && loggedInSalesRep.salesForceId &&  self.managedObjectContext!=[loggedInSalesRep managedObjectContext]){
        //  logged in rep being set from another MOC, reinflate into the main one
        loggedInSalesRep = (AGNSalesRep *)[self.managedObjectContext objectWithID:[loggedInSalesRep objectID]];
    }
    _loggedInSalesRep =  loggedInSalesRep;
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:loggedInSalesRep.salesForceId forKey:AGNLastLoggedInUserSalesForceIdKey];
    [defaults setBool:YES forKey:AGNIsLoggedInKey];
    [defaults synchronize];
    self.isLoggedIn = YES;

    [[NSNotificationCenter defaultCenter] postNotificationName:AGNLoggedInUserSetNotificationKey object:self.loggedInSalesRep];

}

-(void)setApplicationGUID{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    if(![defaults stringForKey:kAGNApplicationGUIDKey]){
        NSString * newGuid = [[NSUUID UUID] UUIDString];
        [defaults setValue:newGuid forKey:kAGNApplicationGUIDKey];
        log4Warn(@"Setting new Application GUID, %@ ",newGuid);
    }
}

-(NSString *)applicationGUID{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    return [defaults stringForKey:kAGNApplicationGUIDKey];
}

-(NSString *)applicationVersion{
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    return version;
}

//------------------------------------------------------------------------------
// MARK: - Application's Documents directory
//------------------------------------------------------------------------------

// Returns the URL to the application's Documents directory.
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

- (void)oauthCoordinator:(SFOAuthCoordinator *)coordinator willBeginAuthenticationWithView:(UIWebView *)view {
    AGNRootViewController *rootViewController =  (AGNRootViewController *)self.window.rootViewController;
    __block BOOL syncing = [rootViewController isSyncing];
    if (syncing) {
        [rootViewController syncingStopped:^{
            [rootViewController lowerCurtain:YES];
            syncing = NO;
        }];
    }
    for (int i=0; i<5; i++) {
        if (!syncing) {
            break;
        }
        [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.1f]];
    }
    if (syncing) {
        rootViewController.syncViewVisible = NO;
        [rootViewController lowerCurtain:YES];
    }
}

- (void)oauthCoordinator:(SFOAuthCoordinator *)coordinator didBeginAuthenticationWithView:(UIWebView *)view {
    self.loginTriggered = YES;
    [super oauthCoordinator:coordinator didBeginAuthenticationWithView:view];
}

- (void)displayOfflineAlert {
    if (!self.offlineAlert) {
        self.offlineAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Offline", @"Offline Title")
                                                       message:NSLocalizedString(@"You need to be online in order to authenticate.", @"Need to be online to authenticate")
                                                      delegate:self cancelButtonTitle:@"Retry"
                                             otherButtonTitles:nil];
        [self.offlineAlert show];
    }
}

- (void)displayUnreachableAlertWithDescription:(NSString*)description {
    if (!self.offlineAlert) {
        self.offlineAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Failed to Authenticate", @"Offline Title")
                                                       message:description
                                                      delegate:self cancelButtonTitle:@"Retry"
                                             otherButtonTitles:nil];
        [self.offlineAlert show];
    }
}



// This method is a necessary hack to address the fact that SFDC iOS SDK API does not have callback on when the login screen was dismissed.
// Therefore we have to catch moments when viewDidAppear happens on the root controller, and trigger what we need to do based on a flag.
- (void)rootViewControllerDidAppear {
    log4Trace(@"==============> ROOT VIEW CONTROLLER DID APPEAR");
    if (self.cannotLoginWithAnotherUser) {
        self.cannotLoginWithAnotherUser = NO;
        self.signoffAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Error", @"Error")
                                                      message:NSLocalizedString(@"There are pending changes created by the previous user. The user has to sign in and upload them to the server first before another user can sign-in.", @"Cant sign in as another user message")
                                                     delegate:self
                                            cancelButtonTitle:@"Sign Out"
                                            otherButtonTitles:nil];
        
        [self.signoffAlert show];
    }
    else if (self.initiateSyncAfterAuthScreenIsDissmissed) {
        log4Info(@"Initiate sync after auth screen dismissed");
        [self.rootViewController triggerDownstreamSync];
        self.initiateSyncAfterAuthScreenIsDissmissed = NO;
    }
    else if (self.needsOfflineAlert) {
        [self displayOfflineAlert];
        self.needsOfflineAlert = NO;
    }
    else if (self.retryLogin) {
        self.retryLogin = NO;
        [self login];
    }
}

- (void)oauthCoordinatorDidAuthenticate:(SFOAuthCoordinator *)coordinator {
    log4Info(@"Authenticate completed")
    [super oauthCoordinatorDidAuthenticate:coordinator];
    [SFRestAPI sharedInstance].coordinator = coordinator; // This line seems to fix a lot of problems
    
    NSString * identity = [coordinator.credentials.identityUrl relativePath];
    NSString * userId = [identity substringFromIndex:identity.length - 18];

    if(self.databaseUnavailable){
        log4Warn(@"Database is unavailable, skipping sync tasks");
        return;
    }

    log4Info(@"MSWDidAuthenticate ");
    
    // Detect change of user
    if (self.lastLoggedInUserSFDCID && ![self.lastLoggedInUserSFDCID isEqualToString:userId]) {
        // The user has changed.
        log4Info(@"User has changed, was %@, is %@",self.lastLoggedInUserSFDCID,userId);
        
        if ([AGNUpdateQueueManager defaultManager].pendingUpdateCount > 0) {
            log4Info(@"New user and there are pending updates - can't sign in");
            // We have pending changes - we can't sign-in.
            self.cannotLoginWithAnotherUser = YES;
            return;
        }
        else {
            log4Info(@"Signed in as new user, wiping database");
            // We're good, but need to wipe database and force full sync
            self.syncManager.utcLastCompleteSyncTimestamp = nil;
            [self wipeDatabase];
        }
    }
    
    self.baseServiceUrl = coordinator.credentials.instanceUrl.absoluteString;
    
    self.isAuthenticated = YES;
    
    NSNotification *notification = [NSNotification notificationWithName:AGNUserLoginSucceededNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    

    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSDate * utcLastCompleteSyncTimestamp = [defaults objectForKey:AGNLastSyncTimestampKey];
    if (!utcLastCompleteSyncTimestamp || self.shouldSyncAfterLogin) { // Never synced or full sync was previously triggered
        self.shouldSyncAfterLogin = NO;  // We are about to sync, so reset the flag
        if (self.loginTriggered) {
            self.initiateSyncAfterAuthScreenIsDissmissed = YES;
            self.loginTriggered = NO;
            log4Info(@"Setting initiateSyncAfterAuthScreenIsDissmissed flag to yes"  );

        }
        else {
            
            log4Info(@"Performing Sync - utcLastCompleteSyncTimestamp is %@, should sync after login is %@",utcLastCompleteSyncTimestamp,self.shouldSyncAfterLogin?@"true":@"false" );
            self.isLoggedIn = YES;
            [self.rootViewController triggerDownstreamSync];
        }
    }
    else if (![self checkNextSync]) { // We checked next time to sync and ended up just setting up a timer or flagging the root controller for fugure sync
      
        log4Info(@"Not time to sync, just updating logged in user");
        [self.syncManager syncLoggedInUser];
        [self.rootViewController raiseCurtain:YES];
    }
    
}

- (void)oauthCoordinator:(SFOAuthCoordinator *)coordinator didFailWithError:(NSError *)error {
    // Check for offline
    if (self.reachabilityObserver.networkStatus < RKReachabilityReachableViaWiFi) {
        // Ignore the error, since it's got to be the network error
        log4Info(@"Offline, couldn't auth");
        
        if (self.loginTriggered) {
            // We were already authenticating
            [coordinator stopAuthentication];
            [self.rootViewController dismissViewControllerAnimated:YES completion:nil];
            self.needsOfflineAlert = YES;
            self.loginTriggered = NO;
        }
        else if (self.isLoggedIn)
            [self.rootViewController raiseCurtain:YES]; // Generally shoudln't be here, but just in case
        else
            [self displayOfflineAlert];
    }
    else if ([NSURLErrorDomain isEqualToString:error.domain]) {
        log4Warn(@"=============> Network error: %@", [error localizedDescription]);
        [self displayUnreachableAlertWithDescription:[error localizedDescription]];
    }
    else {
        NSString * errorString = [error.userInfo objectForKey:@"error"];
        log4Warn(@"=============> Auth error: %@", errorString);
        
        NSNotification *notification = [NSNotification notificationWithName:AGNUserLoginFailedNotificationKey object:nil];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
        
        [coordinator stopAuthentication];
        [self.syncManager cleanUpAfterPartialSync];
        
        AGNRootViewController *rootViewController =  (AGNRootViewController *)self.window.rootViewController;
        if ([rootViewController isSyncing]) {
            [rootViewController syncingStopped:^{
                [rootViewController lowerCurtain:YES];
                [self logout:NO]; // We need to logout after the sync view is dismissed.
            }];
        }
        else {                
            [rootViewController lowerCurtain:YES];
            [self logout:NO]; // We are not syncing, so we can just logout now
        }
    }
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Handle Sync Notifications
//------------------------------------------------------------------------------

-(void)setInterruptedSyncKey{
    log4Info(@"Setting sync in progress persistent key");

    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults setBool:YES forKey:kAGNInterruptedSyncKey];
}

-(void)clearInterruptedSyncKey{
    log4Info(@"Clearing  sync in progress persistent key");
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:kAGNInterruptedSyncKey];
}

-(BOOL) syncInterrupted{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    if([standardUserDefaults boolForKey:kAGNInterruptedSyncKey])
        return YES;
    return NO;
}


- (void)downstreamSyncBegan:(NSNotification *)notification {
    if (self.batchIsRunningAlert) {
        [self.batchIsRunningAlert dismissWithClickedButtonIndex:0 animated:YES];
        self.batchIsRunningAlert = nil;
    }
    
    AGNRootViewController *rootViewController =  (AGNRootViewController *)self.window.rootViewController;
    [rootViewController lowerCurtain:YES];
    [rootViewController syncingStarted];
    
    // We are already syncing, need to kill the next sync timer
    [self.nextSyncTimer invalidate];
    self.nextSyncTimer = nil;
}

- (void)downstreamSyncCompleted:(NSNotification *)notification {
    AGNRootViewController *rootViewController =  (AGNRootViewController *)self.window.rootViewController;
    [rootViewController syncingStopped];
    [rootViewController raiseCurtain:YES];
    [self.syncManager cleanUpAfterPartialSync];
    log4Info(@"Downstream Sync Completed per notification %@, schedule next sync",notification);
    [self checkNextSync]; // Schedule the next sync
}

- (void)timezoneChanged:(NSNotification *)notification {
    log4Info(@"Timezone changed %@",notification);
    [self logTimeZone];
}


- (void)clearDataModel
{
    // Overriding this method in SFNativeRootViewController because it clears the rootviewcontroller and
    // tries to re-create it by instantiating a new SFNativeRootViewController instance. Our rootViewController
    // is an AGNRootViewController instance and it is instantiated on startup from the Storyboard.
    
    // In my unit testing I have not found any ill effects from commenting out this method, but there could
    // potentially be issues if logging in as a different user. If this is the case, we may need to bring the
    // SF SDK into the project as source and modify it there.
}

+(void)synchronizeWithSettingsBundle{
    [self synchronizeSettingWithSettingsBundle:@"environment"];
    [self setVersion];
}

+ (void) setVersion
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [defaults setObject:version forKey:@"version"];
}

+ (NSString*)synchronizeSettingWithSettingsBundle:(NSString*)key
{
	NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
	NSString *val = nil;
    
	if (standardUserDefaults)
		val = [standardUserDefaults objectForKey:key];
    
	// TODO: / apparent Apple bug: if user hasn't opened Settings for this app yet (as if?!), then
	// the defaults haven't been copied in yet.  So do so here.  Adds another null check
	// for every retrieve, but should only trip the first time
	if (val == nil) {
		log4Debug(@"user defaults may not have been loaded from Settings.bundle ... doing that now ...");
		//Get the bundle path
		NSString *bPath = [[NSBundle mainBundle] bundlePath];
		NSString *settingsPath = [bPath stringByAppendingPathComponent:@"Settings.bundle"];
		NSString *plistFile = [settingsPath stringByAppendingPathComponent:@"Root.plist"];
        
		//Get the Preferences Array from the dictionary
		NSDictionary *settingsDictionary = [NSDictionary dictionaryWithContentsOfFile:plistFile];
		NSArray *preferencesArray = [settingsDictionary objectForKey:@"PreferenceSpecifiers"];
        
		//Loop through the array
		NSDictionary *item;
		for(item in preferencesArray)
		{
			//Get the key of the item.
			NSString *keyValue = [item objectForKey:@"Key"];
            
			//Get the default value specified in the plist file.
			id defaultValue = [item objectForKey:@"DefaultValue"];
            
			if (keyValue && defaultValue) {
				[standardUserDefaults setObject:defaultValue forKey:keyValue];
				if ([keyValue compare:key] == NSOrderedSame)
					val = defaultValue;
			}
		}
		[standardUserDefaults synchronize];
	}
	return val;
}

-(BOOL)currentVersionValid {
    NSString *message = [[NSUserDefaults standardUserDefaults] objectForKey:kAGNKillSwitchMessage];
    if(message)return NO;
    return YES;
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Reachability
//------------------------------------------------------------------------------

- (void)reachabilityChanged:(NSNotification *)notification {
    
    NSString * reachabilityNetworkStatus = @"";

    switch (self.reachabilityObserver.networkStatus) {
        case RKReachabilityIndeterminate:
            return; // Do nothing
            
        case RKReachabilityReachableViaWiFi:
        case RKReachabilityReachableViaWWAN:
            // Online
            
            if (![AGNSyncManager isReplayingMockData]) {
                reachabilityNetworkStatus = @"- Connected via WiFi";
                if(self.reachabilityObserver.networkStatus==RKReachabilityReachableViaWWAN){
                    reachabilityNetworkStatus = @"- Connected via a cell data connection";
                }
                if (self.offlineAlert != nil)
                    [self.offlineAlert dismissWithClickedButtonIndex:0 animated:YES]; // This will trigger reauthentication when dismissed
                else if (!self.isAuthenticated && !self.loginTriggered)
                    [self login];
                
                break;
            }
            // If we're in mock mode, then we just continue as if we were offline
            
        case RKReachabilityNotReachable:
            // Offline
            if (self.isLoggedIn){
                if([self currentVersionValid]){
                    if([self syncInterrupted]){
                        [self.rootViewController showSyncInterruptedAlert];
                    }else{
                        [self.rootViewController raiseCurtain:YES]; // Let the user use the app in offline mode
                    }
                }else{
                    [self.rootViewController showAppVersionForcedUpgradeNotice];
                }
            }
            else
                [self displayOfflineAlert]; // Nope, they need to authenticate first, and that can only be done online
            
            break;

    }
    
    log4Info(@"Connectivity status changed to: %@ %@", self.reachabilityObserver.networkStatus >= RKReachabilityReachableViaWiFi ? @"ONLINE" : @"OFFLINE", reachabilityNetworkStatus);
    
}


//  attempted iOS application state saving / restoration
//  had trouble integrating it w/ our root view controller
//  also does not persist under some circumstances and we need to force it - user can not leave call screen if sig captured

//-(BOOL)application:(UIApplication *)application shouldRestoreApplicationState:(NSCoder *)coder
//{
//    return YES;
//}
//
//-(BOOL)application:(UIApplication *)application shouldSaveApplicationState:(NSCoder *)coder
//{
//    return YES;
//}
//
//-(void)application:(UIApplication *)application willEncodeRestorableStateWithCoder:(NSCoder *)coder{
//    AGNRootViewController *rootViewController =  self.rootViewController;
//    UIViewController * vc = rootViewController.currentViewController;
//    if ([vc isKindOfClass:[UINavigationController class]]) {
//        UINavigationController *navController = (UINavigationController*)vc;
//        UIViewController *topViewController = [navController topViewController];
//        if([topViewController isKindOfClass:[AGNCallDetailViewController class]]){
//            log4Debug(@"Need to save the current call");
//            AGNCall *currentCall = ((AGNCallDetailViewController*)topViewController).call;
//            NSString *objectId = currentCall.salesForceId;
//            
//            [coder encodeObject:objectId forKey:kCurrentCallRestoreStateKey];
//        }
//    }
//}
//
//-(void)application:(UIApplication *)application didDecodeRestorableStateWithCoder:(NSCoder *)coder{
//    if([coder containsValueForKey:kCurrentCallRestoreStateKey]){
//        NSString *callId = [coder decodeObjectForKey:kCurrentCallRestoreStateKey];
//        AGNDataManager *dm = [AGNDataManager defaultInstance];
//        self.callToRestore = (AGNCall*)[dm objectOfType:@"AGNCall" forId:callId];
//        log4Debug(@"Navigate to call %@",callToRestore);
//    }
//}


-(void)navigateToCallIfShouldRestore{
    NSString *callId = [[NSUserDefaults standardUserDefaults] objectForKey:kCurrentCallRestoreStateKey];
    if(callId){
        AGNDataManager *dm = [AGNDataManager defaultInstance];
        self.callToRestore = (AGNCall*)[dm undeletedObjectOfType:@"AGNCall" forId:callId];
        if(!self.callToRestore)
            self.callToRestore = (AGNCall*)[dm undeletedObjectOfType:@"AGNCall" forGuid:callId];
    }

    if(self.callToRestore){
        log4Info(@"Restoring application to open call %@", self.callToRestore.guid);
        //back button
        UIViewController * vc = self.rootViewController.currentViewController;
        if ([vc isKindOfClass:[UINavigationController class]]) {
            UINavigationController *navController = (UINavigationController*)vc;
            UIViewController *topViewController = navController.topViewController;
            if([topViewController respondsToSelector:@selector(navigateToCall:)]){
                AGNCallsViewController *callsVC = (AGNCallsViewController*)topViewController;
                [callsVC navigateToCall:self.callToRestore];
            }

            [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
        }
    }
    self.callToRestore=nil;
}

-(void)navigateToFormIfShouldRestore{
    NSString *formId = [[NSUserDefaults standardUserDefaults] objectForKey:kCurrentFormRestoreStateKey];
    if(formId){
        AGNDataManager *dm = [AGNDataManager defaultInstance];
        self.formToRestore = (AGNRequestForm*)[dm undeletedObjectOfType:@"AGNRequestForm" forGuid:formId];
        log4Info(@"Got form id to restore %@, form is: %@",formId,self.formToRestore);
    }

    if(self.formToRestore){
        log4Info(@"Restoring application to open form %@", self.formToRestore.guid);
        //back button
        UIViewController * vc = self.rootViewController.currentViewController;
        if ([vc isKindOfClass:[UINavigationController class]]) {
            UINavigationController *navController = (UINavigationController*)vc;
            UIViewController *topViewController = navController.topViewController;
            if([topViewController respondsToSelector:@selector(navigateToForm:)]){
                AGNCallsViewController *callsVC = (AGNCallsViewController*)topViewController;
                [callsVC navigateToForm:self.formToRestore];
            }else{
                log4Warn(@"Wanted to restore to a form but VC %@ does not support it.",topViewController);
            }

            [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
        }
    }
    self.formToRestore=nil;
}


- (void)presentBatchIsRunningAlert {
    log4Info(@"About to display batchIsRunning Alertview");
    if (!self.batchIsRunningAlert) {
        self.batchIsRunningAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Unable to sync", @"Title for unable to sync")
                                                              message: NSLocalizedString(@"The server is currently updating. Please try again in a few minutes.", @"Message for batch is running error")
                                                             delegate:self
                                                    cancelButtonTitle:NSLocalizedString(@"Dismiss", @"Dismiss")
                                                    otherButtonTitles:nil];
        [self.batchIsRunningAlert show];
    }
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UIAlertViewDelegate
//------------------------------------------------------------------------------

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (alertView == self.batchIsRunningAlert) {
        self.batchIsRunningAlert = nil;
    }
    else if (alertView == self.offlineAlert) {
        self.offlineAlert = nil;
        if (self.reachabilityObserver.networkStatus >= RKReachabilityReachableViaWiFi) {
            if (!self.loginTriggered)
                [self login];
        }
        else
            [self displayOfflineAlert]; // Keep displaying until we're online
    }
    else if (self.signoffAlert == alertView) {
        self.signoffAlert = nil;
        [self logout:YES];
    }else if(self.databaseUnavailableAlert ==alertView){
        [self.rootViewController raiseCurtain:YES];
    }
    else { // The built-in retry alert
//        [super alertView:alertView didDismissWithButtonIndex:buttonIndex];
        self.loginTriggered = NO;
        self.retryLogin = YES;
    }
}

#pragma mark -
#pragma mark Sync/Create options

- (BOOL)defaultsValueForKey:(NSString*)key defaultValue:(BOOL)defaultValue {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    id value = [defaults objectForKey:key];
    if (value)
        return [value boolValue];
    else
        return defaultValue;
}

- (void)setDefaultsValue:(BOOL)value forKey:(NSString*)key {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:value forKey:key];
    [defaults synchronize];    
}

- (BOOL)shouldSyncCalls {
    return [self defaultsValueForKey:kAGNDefaultsSyncCallsKey defaultValue:YES];
}

- (void)setShouldSyncCalls:(BOOL)shouldSyncCalls {
    [self setDefaultsValue:shouldSyncCalls forKey:kAGNDefaultsSyncCallsKey];
}

- (BOOL)canCreateCalls {
    return [self defaultsValueForKey:kAGNDefaultsCreateCallsKey defaultValue:YES];
}

- (void)setCanCreateCalls:(BOOL)canCreateCalls {
    [self setDefaultsValue:canCreateCalls forKey:kAGNDefaultsCreateCallsKey];
}

- (BOOL)shouldSyncForms {
    return [self defaultsValueForKey:kAGNDefaultsSyncFormsKey defaultValue:YES];
}

- (void)setShouldSyncForms:(BOOL)shouldSyncForms {
    [self setDefaultsValue:shouldSyncForms forKey:kAGNDefaultsSyncFormsKey];
}

- (BOOL)canCreateForms {
    return [self defaultsValueForKey:kAGNDefaultsCreateFormsKey defaultValue:YES];
}

- (void)setCanCreateForms:(BOOL)canCreateForms {
    [self setDefaultsValue:canCreateForms forKey:kAGNDefaultsCreateFormsKey];
}

- (BOOL)shouldSyncReprints{
    return [self defaultsValueForKey:kAGNDefaultsSyncReprintsKey defaultValue:YES];
}

-(void)setShouldSyncReprints:(BOOL)shouldSyncReprints{
    [self setDefaultsValue:shouldSyncReprints forKey:kAGNDefaultsSyncReprintsKey];
}

- (BOOL)canCreateReprints {
    return [self defaultsValueForKey:kAGNDefaultsCreateReprintsKey defaultValue:YES];
}

- (void)setCanCreateReprints:(BOOL)canCreateReprints {
    [self setDefaultsValue:canCreateReprints forKey:kAGNDefaultsCreateReprintsKey];
}
@end
