//
//  AGNAppDelegate.h
//  AGNDirect
//
//  Created by Mark Wells on 7/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SFNativeRestAppDelegate.h"
#import "AGNSyncManager.h"
#import "AGNUpdateQueueManager.h"
#import "AGNDataManager.h"
#import "AGNSalesRep.h"
#import "RestKit.h"

@class AGNRootViewController;

static NSString *const kCurrentCallRestoreStateKey = @"CurrentCallRestoreStateKey";
static NSString *const kCurrentFormRestoreStateKey = @"CurrentFormRestoreStateKey";
static NSString *const kAGNKillSwitchMessage = @"KillSwitchMessage";
static NSString *const kAGNInterruptedSyncKey = @"InterruptedSyncKey";
static NSString *const kAGNApplicationGUIDKey = @"ApplicationGUID";

extern NSString * const kAGNDefaultsSyncCallsKey;
extern NSString * const kAGNDefaultsCreateCallsKey;
extern NSString * const kAGNDefaultsSyncFormsKey;
extern NSString * const kAGNDefaultsCreateFormsKey;


static NSString *AGNUserLoginSucceededNotificationKey = @"AGNUserLoginSucceededNotification";
static NSString *AGNUserLoginFailedNotificationKey = @"AGNUserLoginFailedNotification";
static NSString *AGNUserLogoutSucceededNotificationKey = @"AGNUserLogoutSucceededNotification";
static NSString *AGNUserLogoutFailedNotificationKey = @"AGNUserLogoutFailedNotification";

static NSString *AGNLoggedInUserSetNotificationKey = @"AGNLoggedInUserSetNotification";

static NSString *AGNViewControllerPushedNotificationKey = @"AGNViewControllerPushedNotification";
static NSString *AGNViewControllerPoppedNotificationKey = @"AGNViewControllerPoppedNotification";

static NSString *AGNCancelNavigationRequestNotificationKey = @"AGNCancelNavigationRequestNotificationKey";

static NSString *AGNLastSyncTimestampKey = @"AGNLastSyncTimestampKey";
static NSString *AGNLastSyncLocalTimestampKey = @"AGNLastSyncLocalTimestampKey";

static NSString *AGNBackButtonPressedKey = @"AGNBackButtonPressed";

static NSString * AGNForcedSyncTimeKey = @"AGNForcedSyncTimeKey"; // Time is expresses as minutes since midnight
static NSString * AGNBatchWindowStartTimeKey = @"AGNBatchWindowStartTimeKey"; // Time is expresses as minutes since midnight
static NSString * AGNBatchWindowEndTimeKey = @"AGNBatchWindowEndTimeKey"; // Time is expresses as minutes since midnight

static NSString *AGNIncrementalSyncMaxDaysSinceLastSyncKey = @"AGNIncrementalSyncMaxDaysSinceLastSync";
static NSString *AGNIncrementalSyncMaxNewAccountsKey = @"AGNIncrementalSyncMaxNewAccountsKey";

// comma delimited list of email address to receive log files
static NSString *AGNSupportEmailAddresses = @"AGNSupportEmailAddresses";


static NSString *AGNFilterToMyClosedCalls = @"AGNFilterToMyClosedCalls";
static NSString *AGNFilterToMyPlannedCalls = @"AGNFilterToMyPlannedCalls";
static NSString *AGNFilterToMyForms = @"AGNFilterToMyForms";
static NSString *AGNPlaceholderText = @"No data to display";


extern NSString * const kAGNUserDefaultsKeyAllowedNumberOfQuestions;


@interface AGNAppDelegate : SFNativeRestAppDelegate <UIApplicationDelegate>

@property (readonly, strong, nonatomic) AGNRootViewController *rootViewController;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@property (nonatomic, strong, readonly) AGNSyncManager *syncManager;
@property (readonly, strong, nonatomic) AGNDataManager *dataManager;

@property (strong, nonatomic) AGNSalesRep *loggedInSalesRep;
@property (strong, nonatomic) NSString *lastLoggedInUserSFDCID;
@property (nonatomic) BOOL isLoggedIn; // Doesn't mean authenticated, just that we have previously logged in successfully some time in the past. To be used for offline.
@property (nonatomic) BOOL isAuthenticated; // For online - means that we have been online and have a session.
@property (nonatomic) BOOL shouldSyncAfterLogin; // Set to true to force a sync after a login
@property (nonatomic) BOOL databaseUnavailable;  // We were not able to open the store on launch


@property (strong, nonatomic) RKReachabilityObserver *reachabilityObserver;

@property (nonatomic, readonly) NSString * homeUrl;

@property (nonatomic, strong) NSDate * batchWindowStartDate; // No syncing will happen after this time until the batch window ends
@property (nonatomic, strong) NSDate * batchWindowEndDate; // No syncing will happen before this date, and it will be forced when the app is launched after this date

// Properties for sync/vs login management
@property (nonatomic) BOOL initiateSyncAfterAuthScreenIsDissmissed;
@property (nonatomic) BOOL loginTriggered; // YES if we got an event telling us that a login screen has been presented (we can't sync until it's gone)


- (BOOL)saveContext;
- (NSURL *)applicationDocumentsDirectory;

+ (AGNAppDelegate *)sharedDelegate;
+ (NSString*)serviceUrlForPath:(NSString*)servicePath;

- (void)rootViewControllerDidAppear;
- (BOOL)checkNextSync;

- (void)deferSync; // Defers any automatic syncing by 5 minutes from now. (To support unfinished batch processing)
- (void)resetSyncDeferral; // Resets the above deferral
- (BOOL)canSyncNow; // Returns YES if we're not inside the batch window. (For force-sync)
- (BOOL)shouldSyncNow; // Return YES if we're not inside the batch window and not deferred. (For automatic sync).

- (void)logout:(BOOL)clearUser;
- (NSObject *)configSettingForKey:(NSString *)key;
- (void)setConfigSetting:(NSObject *)value forKey:(NSString * )key;

- (void)presentBatchIsRunningAlert;

-(void)setInterruptedSyncKey;
-(void)clearInterruptedSyncKey;
-(BOOL) syncInterrupted;
-(NSString *)applicationGUID;
-(NSString *)applicationVersion;

- (NSManagedObjectContext*)temporaryMOC;

@property (nonatomic, assign) BOOL shouldSyncCalls;
@property (nonatomic, assign) BOOL canCreateCalls;
@property (nonatomic, assign) BOOL shouldSyncForms;
@property (nonatomic, assign) BOOL canCreateForms;
@property (nonatomic, assign) BOOL shouldSyncReprints;
@property (nonatomic, assign) BOOL canCreateReprints;

@property (readonly) NSInteger monthsCallHistory;

@end
