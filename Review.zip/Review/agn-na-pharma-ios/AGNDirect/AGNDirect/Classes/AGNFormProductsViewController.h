//
//  AGNFormProductsViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/29/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNViewController.h"
#import "AGNTableView.h"
@interface AGNFormProductsViewController : AGNViewController <UITableViewDataSource, UITableViewDelegate>

@property (strong,nonatomic) AGNTableView *tableView;

@end
