//
//  AGNTransferViewController.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGNSampleInventoryTransaction.h"
#import "AGNShipmentItemCell.h"
#import "AGNViewController.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNTableView.h"

@interface AGNTransferViewController : AGNViewController <AGNPopoverDelegate, UITableViewDataSource, UITableViewDelegate, UIPopoverControllerDelegate, UITextFieldDelegate>

@property (strong, nonatomic) AGNSampleInventoryTransaction * transaction;
@property (strong, nonatomic) NSString * targetType; // Only used for new objects - return or outgoing transfer
@property (weak, nonatomic) IBOutlet UIButton * submitButton;
@property (weak, nonatomic) IBOutlet AGNTableView * tableView;

- (IBAction)submit:(id)sender;
- (IBAction)toggleEditMode:(id)sender;
- (BOOL) isDuplicateAuthID ;
@property (weak, nonatomic) IBOutlet UILabel *transferToLabel;
@property (weak, nonatomic) IBOutlet UITextField *transferNumberTextField;

@end
