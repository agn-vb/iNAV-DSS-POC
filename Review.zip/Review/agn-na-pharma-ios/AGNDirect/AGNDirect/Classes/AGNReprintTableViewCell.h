//
//  AGNReprintTableViewCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/12/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNAPC.h"
static NSString *AGNReprintQuantityChangedNotificationKey = @"AGNReprintQuantityChangedNotificationKey";

typedef void (^textFieldActiveCell)(UITextField *);


@interface AGNReprintTableViewCell : UITableViewCell  <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UILabel *jobName;
@property (weak, nonatomic) IBOutlet UILabel *apcCode;
@property (weak, nonatomic) IBOutlet UILabel *product;
@property (weak, nonatomic) IBOutlet UITextField *quantity;
@property (weak, nonatomic) IBOutlet UILabel *qtyReadOnly;

@property (strong, nonatomic)  NSMutableDictionary *quantities;
@property (strong, nonatomic)  AGNAPC *apc;
@property (strong, nonatomic)  AGNMarketingCollateral *content;

@property (strong, nonatomic) textFieldActiveCell textFieldActiveBlock;


@end
