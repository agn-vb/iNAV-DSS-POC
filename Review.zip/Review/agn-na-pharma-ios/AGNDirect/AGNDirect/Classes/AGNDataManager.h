//
//  AGNDataManager.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/14/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGNAddress.h"
#import "AGNCall.h"
#import "AGNAccount.h"
#import "AGNProductBrand.h"
#import "AGNProductSKU.h"
#import "AGNSampleInventoryLine.h"

@interface AGNDataManager : NSObject

@property (strong) NSManagedObjectContext *managedObjectContext;

+(AGNDataManager *) defaultInstance;
-(id) initWithManagedObjectContext:(NSManagedObjectContext *)context;

// account sync group
-(NSArray *) getAllHCPs;
-(NSArray *) getAllHCPsWithSortDescriptors:(NSArray *)sortDescriptors;
-(AGNAccount *) getHCPForId:(NSString *)salesForceId;
-(NSArray *) getHCPSForFilterString:(NSString *)filterString;
-(NSArray *) getHCPSForFilterString:(NSString *)filterString withSortDescriptors:(NSArray *)sortDescriptors;
-(NSArray *) getHCPSWithNameMatching:(NSString *)filterString ;
-(NSArray *) getContactRoles;
-(NSArray *) getAllRecordsOfEntity:(NSString *)entityName withProperties:(NSArray *)properties;

// user sync group
-(NSArray *) getAllReps;
-(NSArray *) getRepsValidForOutboundTransfer;
-(AGNSalesRep *) getRepForId:(NSString *)repId;
-(NSArray *) getRepsForFilterString:(NSString *)filterString;

// calls
-(NSArray *) getAllCalls;
-(NSArray *) getCallsForRep:(AGNSalesRep *)salesRep;
-(NSArray *) getClosedCallsForRep:(AGNSalesRep *)salesRep;
-(NSArray *) getSavedDraftsForRep:(AGNSalesRep *)salesRep;
// for single date
-(NSArray *) getAllCallsForDateComponents:(NSDateComponents *)dateComponents andRep:(AGNSalesRep *)salesRep;
// for date range - start/end date can be null
-(NSArray *) getAllCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep;
-(NSArray *) getClosedCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep;
-(NSArray *) getPlannedCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep;
-(NSArray *) getPlannedCallsForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser;
-(NSArray *) getClosedCallsForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser;
-(NSArray *) getClosedCallsForHCP:(AGNAccount *)hcp andAddress:(AGNAddress *)address restrictToCurrentUser:(BOOL) restrictToCurrentUser;
-(NSArray *) getPlannedCallsForHCP:(AGNAccount *)hcp andAddress:(AGNAddress *)address restrictToCurrentUser:(BOOL) restrictToCurrentUser;
-(NSArray *) getAllDetailPositions;
-(NSArray *) getCurrentDetailPositions;
-(NSArray *) getClosedCallsForCurrentRepWithinMonth:(NSDateComponents *)dateComponents;
- (AGNScheduleEntry *)firstScheduleEntryForDate:(NSDate *)date;
-(NSArray *)callDatesFrom:(NSDate *)fromDate to:(NSDate *)toDate;
-(NSArray *)callsFrom:(NSDate *)fromDate to:(NSDate *)toDate;
-(NSArray *) getClosedCallDatesForRep:(AGNSalesRep *)salesRep;
- (NSArray *)submittedFormDatesForRep:(AGNSalesRep *)salesRep;
-(NSArray *) getFormsForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser;
- (NSArray *)submittedFormsForCurrentRepWithinMonth:(NSDateComponents *)dateComponents;
- (NSArray *) getMCDForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser;
- (NSArray *)submittedMCDDatesForRep:(AGNSalesRep *)salesRep ;
- (NSFetchedResultsController *)scheduleViewFetchedResultsController:(BOOL)callsOnly;
- (NSArray *)submittedMCDsForCurrentRepWithinMonth:(NSDateComponents *)dateComponents;



// inventory
-(NSArray *) getAllProductSKUs;
-(AGNProductSKU *) getProductSKUForSku:(NSString *)sku;
-(AGNProductSKU *) getProductSKUForId:(NSString *)sfdcId;
-(AGNProductBrand *) getProductBrandForId:(NSString *)sfdcId;
-(NSArray *) getSampleInventoryLines;
-(NSArray *)getSampleInventoryLinesWithSortDescriptors:(NSArray *)sortDescriptors;
-(AGNSampleInventoryLine *)getSampleInventoryLineForProductSKU:(AGNProductSKU *)productSKU andLotNumber:(NSString *)lotNumber;
-(NSArray *) getSampleInventoryTransactionLinesForProduct:(AGNProductSKU *)product;
-(NSArray *) getAllSampleInventoryTransactions;

-(NSArray *) getOutgoingProductForLoggedInUser;
-(NSArray *) getIncomingProductForLoggedInUser;

-(AGNSampleInventoryTransaction *)getMonthlyReconciliationDraft;

-(NSArray *)calendarEntriesFrom:(NSDate *)fromDate to:(NSDate *)toDate;

//utility
- (NSManagedObject *)undeletedObjectOfType:(NSString *)entityName forId:(NSString *)sfdcId;
- (NSManagedObject *)undeletedObjectOfType:(NSString *)entityName forGuid:(NSString *)guid;
- (NSManagedObject *)objectOfType:(NSString *)entityName forId:(NSString *)sfdcId;
- (NSManagedObject *)objectOfType:(NSString *)entityName forGuid:(NSString *)guid;
- (NSArray *) getAllObjectsOfType:(NSString *)entityName withSortDescriptors:(NSArray *)sortDescriptors;

// zip code
-(NSArray *)zipCodeRecordForZip:(NSString *)zip andState:(NSString *)state;
-(NSArray *)getStates;


-(NSArray *) getTOT;
-(NSFetchedResultsController *) getScheduleEntriesController;
-(NSArray *) getScheduleEntries;

@end
