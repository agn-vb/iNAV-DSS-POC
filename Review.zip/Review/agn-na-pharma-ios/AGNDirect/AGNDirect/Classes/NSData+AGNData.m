//
//  NSData+AGNData.m
//  AGNDirect
//
//  Created by Mark Wells on 10/19/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "NSData+AGNData.h"

@implementation NSData (AGNData)

- (NSString *)agnBase64EncodedString;
{
	size_t outputLength;
	char *outputBuffer =
    NewBase64Encode([self bytes], [self length], false, &outputLength);
	
	NSString *result =
    [[NSString alloc]
      initWithBytes:outputBuffer
      length:outputLength
      encoding:NSASCIIStringEncoding];
	free(outputBuffer);
	return result;
}

@end
