//
//  AGNFormProductsViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/29/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNFormProductsViewController.h"
#import "AGNSingleLineCell.h"
@interface AGNFormProductsViewController ()

@end

@implementation AGNFormProductsViewController

@synthesize tableView=_tableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.view=self.tableView;
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
}

- (AGNTableView *)tableView{
    if(!_tableView) {
        _tableView = [[AGNTableView alloc]init];
    }
    return _tableView;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    static NSString *ClosedCallCellIdentifier = @"AGNClosedCallCell";

    AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:CellIdentifier];
    }
        cell.mainLabel.text = AGNPlaceholderText;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    
    return cell;
}

@end
