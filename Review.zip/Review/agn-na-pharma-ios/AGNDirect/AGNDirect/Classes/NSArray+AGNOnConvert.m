//
//  NSArray+AGNOnConvert.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/13/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "NSArray+AGNOnConvert.h"

@implementation NSArray (AGNOnConvert)

-(NSDictionary *)AGNconvertResponseToDictionaryWithKey:(NSString *)key{
    if(self.count==1 && [self.firstObject isKindOfClass:NSDictionary.class])
        return self.firstObject;
    NSMutableDictionary * dictionary = [[NSMutableDictionary alloc]init];
    dictionary[key]=self;
    return dictionary;
}

@end
