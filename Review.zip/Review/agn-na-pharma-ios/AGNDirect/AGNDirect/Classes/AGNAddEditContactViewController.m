//
//  AGNAddEditContactViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/17/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAddEditContactViewController.h"
#import "AGNTableView.h"
#import "AGNTextFieldCell.h"
#import "AGNTableViewHeader.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNContactRole.h"
#import "UITextField+NSIndexPath.h"

@interface AGNAddEditContactViewController ()

@property (nonatomic, strong, readwrite) AGNTableView *tableView;
@property (nonatomic, strong) NSMutableArray *values;
@property (nonatomic, strong) NSMutableArray *textFields;
@property (nonatomic, strong) UITextField *lastActiveTextField;
@property (nonatomic, strong) UITextField *roleTextField;
@property (nonatomic, strong) UIButton *deleteButton;
@property (nonatomic, strong) NSArray *contactTypes;
//@property (nonatomic, strong) AGNContactRole *selectedRole;

@property (nonatomic, strong) AGNSimplePopoverTableViewController *contactTypePopover;


@end

@implementation AGNAddEditContactViewController
static NSArray *headerNames;
@synthesize values=_values;
@synthesize textFields=_textFields;
@synthesize contact=_contact;
@synthesize deleteButton=_deleteButton;

enum EditSections {
    FirstNameSection = 0,
    //MiddleNameSection,
    LastNameSection,
    //PhoneSection,
    //EmailSection,
    RoleSection,
    TotalSections
};


+(void)initialize{
    //headerNames = @[@"First Name",@"Middle Name",@"Last Name",@"Phone",@"Email",@"Role"];
    headerNames = @[@"First Name",@"Last Name",@"Professional Role"];
}

- (NSMutableArray *)values{
    if(!_values){
        _values=  [[NSMutableArray alloc]initWithCapacity:TotalSections];
        for(int i=0; i < TotalSections; i ++){
            _values[i]=[NSNull null];
        }
    }
    return _values;
}

- (NSMutableArray *)textFields{
    if(!_textFields){
        _textFields=  [[NSMutableArray alloc]initWithCapacity:TotalSections];
        for(int i=0; i < TotalSections; i ++){
            _textFields[i]=[NSNull null];
        }
    }
    return _textFields;
}

- (id)init;
{
    AGNTableView *table = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    //table.tableFooterView = [[UIView alloc] init];
    self = [super init];
    if (self) {
        self.view = table;
        self.title=NSLocalizedString(@"Add Office Staff", @"Add/Edit contacts title for add");

        table.delegate = self;
        table.dataSource = self;
        self.tableView = table;
        UIImage *normal = [[UIImage imageNamed:@"btn-smblue"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 4.0f, 2.0f)];
        UIImage *highlighted = [[UIImage imageNamed:@"btn-smblue-hi"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 3.0f, 2.0f)];
        
        UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(done:)];
        [done setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        [done setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
        
        UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancel:)];
        [cancel setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        [cancel setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
        
        [self.navigationItem setLeftBarButtonItem:cancel];
        [self.navigationItem setRightBarButtonItem:done];
        self.tableView.scrollEnabled = YES;
    }
    return self;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.contactTypes = [[AGNDataManager defaultInstance]getContactRoles];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.textFields[0] becomeFirstResponder];
}

- (BOOL)validateValue:(id)value named:(NSString*)name required:(BOOL)required maxLen:(int)maxLen {
    if (value == [NSNull null]) {
        if (!required) {
            return YES;
        }
        else {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Missing Required Fields" message:[NSString stringWithFormat:@"%@ is Required", name] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
    }
    else {
        NSString * text = value;
        if (required && text.length == 0) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Missing Required Fields" message:[NSString stringWithFormat:@"%@ is Required", name] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
        else if (maxLen > 0 && text.length > maxLen) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Value Too Long" message:[NSString stringWithFormat:@"%@ may not exceed 128 characters", name] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
    }
    return YES;
}

//------------------------------------------------------------------------------
// MARK: - Bar Button Item Mehtods
//------------------------------------------------------------------------------
- (void)done:(id)sender {

    // Copy the latest values from controls
    for (int i = 0; i < self.textFields.count; i++) {
        NSString * value = ((UITextField*)self.textFields[i]).text;
        self.values[i] = value ? [value agnTrim] : [NSNull null];
    }
    
    if (![self validateValue:self.values[LastNameSection] named:@"Last Name" required:YES maxLen:80]) {
        [self.textFields[LastNameSection] becomeFirstResponder];
        return;
    }

    if (![self validateValue:self.values[FirstNameSection] named:@"First Name" required:NO maxLen:40]) {
        [self.textFields[FirstNameSection] becomeFirstResponder];
        return;
    }
    
    if (![self validateValue:self.values[RoleSection] named:@"Professional Role" required:YES maxLen:0]) {
        [self.textFields[RoleSection] becomeFirstResponder];
        return;
    }
    
    [self saveContact];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)cancel:(id)sender {
    log4Info(@"Cancelled Contact edits");
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setContact:(AGNContact *)contact{
    _contact=contact;
    self.title=NSLocalizedString(@"Edit Office Staff", @"Add/Edit contacts title for edit");
    self.values[FirstNameSection]=[self convertNull:self.contact.firstName];
//    self.values[MiddleNameSection]=[self convertNull:self.contact.middleName];
    self.values[LastNameSection]=[self convertNull:self.contact.lastName];
//    self.values[PhoneSection]=[self convertNull:self.contact.phone];
//    self.values[EmailSection]=[self convertNull:self.contact.email];
    self.values[RoleSection]=[self convertNull:self.contact.contactRole];
    self.deleteButton.hidden=NO;
    self.deleteButton.enabled=YES;
}

//------------------------------------------------------------------------------
// MARK: - TableView Data Source
//------------------------------------------------------------------------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return TotalSections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *SingleFilterCellIdentifier = @"AGNTextFieldCell";
    
    AGNTextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:SingleFilterCellIdentifier];
    if (cell == nil) {
        cell = [[AGNTextFieldCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:SingleFilterCellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textField.delegate = self;
    cell.textField.keyboardType = UIKeyboardTypeDefault;
    cell.textField.indexPath= indexPath;
    
    if(indexPath.section==TotalSections-1){
        cell.textField.returnKeyType = UIReturnKeyDone;
    }else{
        cell.textField.returnKeyType = UIReturnKeyNext;
    }
    cell.textField.clearButtonMode = UITextFieldViewModeNever;
    cell.textField.text = [self convertNull:self.values[indexPath.section]];
    self.textFields[indexPath.section]=cell.textField;
    if(indexPath.section==RoleSection){
        self.roleTextField=cell.textField;
    }

    return cell;
}



-(void)saveContact{
    AGNContact *contact = self.contact;
    if(!contact){
        NSManagedObjectContext *moc = [AGNAppDelegate sharedDelegate].managedObjectContext;
        contact = (AGNContact *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNContact" inManagedObjectContext:moc];
        contact.guid = [[NSUUID UUID] UUIDString];
        contact.hcp = self.account;
        contact.salesForceAccountId = self.account.salesForceId;
        [self.account addContactsObject:contact];
    }

    contact.firstName = [self convertNull:self.values[FirstNameSection]];
    contact.lastName = [self convertNull:self.values[LastNameSection]];
    contact.contactRole = [self convertNull:self.values[RoleSection]];
//    if (self.selectedRole) {
//        contact.contactRole = self.selectedRole.roleName;
//    }

    log4Info(@"Saved changes to contact %@",contact);
}

-(id)convertNull:id{
    if(id==[NSNull null])
        return nil;
    if(id==nil)
        return [NSNull null];
    else return id;
}

//-------------------------------------n-----------------------------------------
// MARK: - text field delegate
//------------------------------------------------------------------------------

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    self.lastActiveTextField = textField;
    self.lastActiveTextField.indexPath = textField.indexPath;

    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    if(indexPath.section==RoleSection){
        [self.lastActiveTextField resignFirstResponder];
        [self showContactTypePopover];
        return NO;
    }
      
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    // so you can catch the contents on done without leaving the field
    self.lastActiveTextField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    NSString *text = textField.text;
    self.values[indexPath.section]=text;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if(textField==self.roleTextField)
        return NO;
    return YES;
}

//-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
//    return YES;
//}

-(BOOL)textFieldShouldReturn:(UITextField*)textField;
{
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    int section = indexPath.section;
    if(section>=TotalSections-1){
        [textField resignFirstResponder];
        [self done:nil];
        return YES;
    }else{
        UITextField *nextTextField = self.textFields[section+1];
        [nextTextField becomeFirstResponder];
        [textField resignFirstResponder];
    }
    return YES;
}


//------------------------------------------------------------------------------
// MARK: - Contact Type Popover
//------------------------------------------------------------------------------

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    if (self.contactTypePopover.popoverVisible) {
        [self.contactTypePopover dismissPopoverAnimated:NO];
        [self showContactTypePopover];
    }
}

-(void)objectSelected:(NSInteger)selected {
    AGNContactRole * role = [self.contactTypes objectAtIndex:selected];
    self.roleTextField.text = role.roleName;
    self.values[RoleSection] = role.roleName;
    [self.contactTypePopover dismissPopoverAnimated:YES];
    [self.roleTextField resignFirstResponder];
}

- (void)showContactTypePopover {
    if (!self.contactTypePopover) {
        self.contactTypePopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:@"Professional Role"];
        self.contactTypePopover.viewController.modalInPopover = NO;
        self.contactTypePopover.viewController.modalPresentationStyle = UIModalPresentationCurrentContext;
      
        __weak typeof(self) weakSelf = self;

        self.contactTypePopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"CellIdentifier";
            
            UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            [cell agnSetStyledSelectedBackground];
            
            AGNContactRole *role = [weakSelf.contactTypes objectAtIndex:indexPath.row];
            UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
            NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
            NSAttributedString * attributedRole = [[NSAttributedString alloc] initWithString:role.roleName attributes:heavyAttributes];

            cell.textLabel.attributedText = attributedRole;
            return cell;
        };
        
    }
    
    if ([self.contactTypes count] > 0) {
        self.contactTypePopover.objectArray = self.contactTypes;
        
        CGRect presentingRect = [self.tableView rectForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:RoleSection]];
        presentingRect.origin.y -= presentingRect.size.height / 2;
        [self.contactTypePopover presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    }
}
//------------------------------------------------------------------------------
// MARK: - TableView Delegate
//------------------------------------------------------------------------------
//- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
//    [self.textFields[indexPath.section] becomeFirstResponder];
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.textFields[indexPath.section] becomeFirstResponder];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    AGNTableViewHeader *header = [[AGNTableViewHeader alloc] init];
    header.leftLabel.text = [headerNames[section] uppercaseString];
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kAGNTableViewHeaderHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if(section==TotalSections-1)
        return 80.0f;
    else
        return 0.0f;
}

-(UIButton *)deleteButton{
    if(!_deleteButton){
        UIButton *newButton = [[UIButton alloc]init];
        [newButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [newButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateNormal];
        [newButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey-hi"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateHighlighted];
        [newButton setContentEdgeInsets:UIEdgeInsetsMake(0, 22, 0, 22)];
        newButton.hidden = YES;
        newButton.opaque=YES;
        newButton.enabled=NO;
        _deleteButton=newButton;
    }
    return _deleteButton;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    if( section==TotalSections-1){
        UIView *view = [[UIView alloc]init];
        UIButton *deleteButton = [self deleteButton];
        [view addSubview:deleteButton];
        [deleteButton addTarget:self action:@selector(deleteTapped) forControlEvents:UIControlEventTouchUpInside];
        NSDictionary *dict1 = NSDictionaryOfVariableBindings(view,deleteButton);
        [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(>=10)-[deleteButton]-(>=10)-|" options:0 metrics:nil views:dict1]];
        [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[deleteButton(>=250)]" options:0 metrics:nil views:dict1]];
        [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[deleteButton(==35)]" options:0 metrics:nil views:dict1]];
        [view addConstraint:[NSLayoutConstraint constraintWithItem:deleteButton attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [view addConstraint:[NSLayoutConstraint constraintWithItem:deleteButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];
        [deleteButton setTitle:NSLocalizedString(@"DELETE CONTACT", @"Delete button text on edit profile screen") forState:UIControlStateNormal];
        
        
        return view;
    }
    
    return [[UIView alloc]init];
}

-(void)deleteTapped{
    log4Debug(@"Delete Tapped");
    self.contact.toBeDeletedFlag=@1;
    [self.navigationController popViewControllerAnimated:YES];
}

@end
