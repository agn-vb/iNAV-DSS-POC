//
//  AGNHCPFilterViewController.m
//  AGNDirect
//
//  Created by Mark Wells on 8/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  HCP LIST - CAN BE FILTERED, SORTED.  

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNHCPFilterViewController.h"
#import "AGNCallsViewController.h"
#import "AGNSegmentedSortControl.h"
#import "AGNDataManager.h"
#import "AGNFilterCell.h"
#import "AGNSingleLineCell.h"
#import "AGNCategoryHeaders.h"
#import "AGNCallHistoryViewController.h"
#import "AGNTableView.h"

const int kAlphabeticalSortIndex = 0;

@interface AGNHCPFilterViewController ()

@property (strong, nonatomic) UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelButton;
@property (weak, nonatomic) IBOutlet AGNTableView *tableView;
@property (weak, nonatomic) IBOutlet AGNSegmentedSortControl *segmentedControl;
//@property (strong, nonatomic) NSSortDescriptor *currentSortDescriptor;
@property (strong, nonatomic) NSIndexPath *currentlySelectedIndexPath;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;

@property (strong, nonatomic) NSArray *filteredHcps;


@property (nonatomic, retain) NSArray *sectionsArray;
@property (nonatomic, retain) NSArray *indexTitles;
@property (nonatomic, retain) NSArray *sectionTitles;
- (void)configureSections;
@property BOOL showPlaceholder;
@property (nonatomic, strong) NSArray * sortDescriptors;


@end

@implementation AGNHCPFilterViewController

@synthesize searchBar;
@synthesize cancelButton;
@synthesize tableView;
@synthesize segmentedControl;
//@synthesize currentSortDescriptor;
@synthesize filteredHcps=_filteredHcps;
@synthesize searchText;
@synthesize sectionsArray=_sectionsArray;
@synthesize topHeaderViewConstraint;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    if ([[UIDevice currentDevice].systemVersion floatValue] > 6.1) {
        // separator causes selection to look janky in ios7
        self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    }
    
    [self.segmentedControl addTarget:self
                              action:@selector(sort)
                    forControlEvents:UIControlEventValueChanged];
    NSDictionary *segmentSortMapping = @{
    [NSNumber numberWithInt:0]:[NSSortDescriptor sortDescriptorWithKey:@"lastName" ascending:YES selector:@selector(caseInsensitiveCompare:)],
    [NSNumber numberWithInt:1]:[NSSortDescriptor sortDescriptorWithKey:@"sort_rating" ascending:YES],
    [NSNumber numberWithInt:2]:[NSSortDescriptor sortDescriptorWithKey:@"sort_frequency" ascending:YES]
    };
    
    [self.segmentedControl setupMapping:[segmentSortMapping mutableCopy] andSortOrder:@[@0,@1,@2]];
    UIImage *leftDividerSelected = [UIImage imageNamed:@"SegmentedControl-divider-LeftSelectedRightUnselected"];
    UIImage *rightDividerSelected = [UIImage imageNamed:@"SegmentedControl-divider-LeftUnselectedRightSelected"];
    UIImage *noDividerSelected = [UIImage imageNamed:@"SegmentedControl-divider-LeftUnselectedRightUnselected"];
    UIImage *unselected = [[UIImage imageNamed:@"SegmentedControl-StretchUnselected"] resizableImageWithCapInsets:UIEdgeInsetsMake(15.0f, 0.0f, 15.0f, 0.0f)];
    UIImage *selected = [[UIImage imageNamed:@"SegmentedControl-StretchSelected"] resizableImageWithCapInsets:UIEdgeInsetsMake(15.0f, 0.0f, 15.0f, 0.0f)];
    [self.segmentedControl setDividerImage:leftDividerSelected forLeftSegmentState:UIControlStateSelected rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.segmentedControl setDividerImage:rightDividerSelected forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    [self.segmentedControl setDividerImage:noDividerSelected forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.segmentedControl setBackgroundImage:unselected forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.segmentedControl setBackgroundImage:selected forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    
    self.searchBar=[[UISearchBar alloc]init];
    self.searchBar.translatesAutoresizingMaskIntoConstraints = NO;
    self.searchBar.delegate = self;
    [self.view addSubview:self.searchBar];
    
    NSDictionary *viewsDict = @{ @"searchBar" : self.searchBar };
    NSArray *horizontalConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|-90-[searchBar]|" options:0 metrics:nil views:viewsDict];
    [self.view addConstraints:horizontalConstraints];
    NSArray *constraints =nil;
    NSDictionary *attributes;
    
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(-2)-[searchBar(==44)]" options:0 metrics:nil views:viewsDict];
        self.topHeaderViewConstraint.constant=0.0f;
        
       attributes = @{ UITextAttributeTextShadowOffset: [NSValue valueWithUIOffset:UIOffsetMake(0, -1)], UITextAttributeTextColor : [UIColor whiteColor], UITextAttributeTextShadowColor : [UIColor blackColor]};
        
    } else {
        // Load resources for iOS 7 or later
        [NSLayoutConstraint constraintsWithVisualFormat:@"|-82-[searchBar]|" options:0 metrics:nil views:viewsDict];
        constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(20)-[searchBar(==44)]" options:0 metrics:nil views:viewsDict];
        self.topHeaderViewConstraint.constant=20.0f;
        
        NSShadow * shadow  = [[NSShadow alloc]init];
        shadow.shadowColor = [UIColor blackColor];
        [shadow setShadowOffset:CGSizeMake(0, -1)];
        
        UIFontDescriptor *fontDescriptor=[UIFontDescriptor preferredFontDescriptorWithTextStyle:UIFontTextStyleSubheadline];
        UIFontDescriptor *boldFontDescriptor=[fontDescriptor fontDescriptorWithSymbolicTraits:UIFontDescriptorTraitBold];
        UIFont *boldFont=[UIFont fontWithDescriptor:boldFontDescriptor size:0.0];
        
         attributes= [NSDictionary dictionaryWithObjectsAndKeys:
                                    [UIColor whiteColor], NSForegroundColorAttributeName,
                                    shadow, NSShadowAttributeName,boldFont,NSFontAttributeName,
                                    nil];
    }
    
    [self.view addConstraints:constraints];
      //  self.searchBar.backgroundImage = [UIImage imageNamed:@"bar-bigblue"];
    
    // why self.searchbar.backgroundColor = clear color doesn't work is beyond me, but it doesn't
    [self hideSearchBarBackground:self.searchBar];
 
    [self.segmentedControl setTitleTextAttributes:attributes
                                         forState:UIControlStateNormal];
    [self.segmentedControl setTitleTextAttributes:attributes
                                         forState:UIControlStateSelected];
    
    
    self.currentlySelectedIndexPath = [NSIndexPath indexPathForRow:-1 inSection:-1];
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    [self setSearchBarReturnKeyType];
}

-(void)hideSearchBarBackground:(UIView *)view{

    if ([NSStringFromClass([view class]) isEqualToString:@"UISearchBarBackground"]) {
        view.alpha=0;
        return;
    }

    for(UIView * subview in view.subviews)
        [self hideSearchBarBackground:subview];


}
-(void)setSearchBarReturnKeyType{
    for (UIView *searchBarSubview in [self.searchBar subviews]) {
        
        if ([searchBarSubview conformsToProtocol:@protocol(UITextInputTraits)]) {
            
            @try {
                
                [(UITextField *)searchBarSubview setReturnKeyType:UIReturnKeyDone];
                [(UITextField *)searchBarSubview setKeyboardAppearance:UIKeyboardAppearanceAlert];
            }
            @catch (NSException * e) {
                
                // ignore exception
            }
        }
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    log4Info(@"Opened filter view");
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(resetSearchBar:)
                                                 name:AGNLoggedInUserSetNotificationKey
                                               object:nil];

    
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        self.tableView.rowHeight = 44.0f;
    } else {
        self.tableView.rowHeight = 56.0f;
    }
    [self reloadContent];
  }

- (void)reloadContent {
    NSIndexPath *selectedRow = self.currentlySelectedIndexPath;
    if(self.sortDescriptors && self.sortDescriptors.count>0){
        self.filteredHcps = self.searchBar.text.length > 0 ? [[AGNDataManager defaultInstance] getHCPSForFilterString:self.searchText withSortDescriptors:self.sortDescriptors ] : [[AGNDataManager defaultInstance] getAllHCPsWithSortDescriptors:self.sortDescriptors];

    }else{
        self.filteredHcps = self.searchBar.text.length > 0 ? [[AGNDataManager defaultInstance] getHCPSForFilterString:self.searchBar.text] : [[AGNDataManager defaultInstance] getAllHCPs];

    }
    [self configureSections];
    [self.tableView reloadData];
    if (selectedRow && !self.showPlaceholder)
    {
        AGNAccount *account = [self accountAtIndexPath:selectedRow];
        if(account){
            [self.tableView selectRowAtIndexPath:selectedRow animated:NO scrollPosition:UITableViewScrollPositionMiddle];
            [self populateDetailViewForIndexPath:selectedRow];
        }
        return;
    }
}

-(void)resetSearchBar:(NSNotification *)notification{
    self.searchBar.text=nil;
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [self.searchBar resignFirstResponder];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:AGNLoggedInUserSetNotificationKey object:nil];
    [super viewWillDisappear:animated];

}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {
        self.tableView.rowHeight = 44.0f;
    } else {
        self.tableView.rowHeight = 56.0f;
    }

}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.tableView.contentSize = newContentSize;

    [self reloadContent];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Actions
//------------------------------------------------------------------------------

- (IBAction)cancelFilterClicked:(UIBarButtonItem *)sender {
    [self.searchBar resignFirstResponder];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNHCPFilterCanceledKey object:self];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.showPlaceholder){
        return 1;
    }
    return [self.sectionTitles count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.showPlaceholder){
        return 1;
    }
    NSArray *hcps = [self.sectionsArray objectAtIndex:section];
	
    return [hcps count];
}

- (AGNAccount *)accountAtIndexPath:(NSIndexPath *)indexPath{
    if([self.sectionsArray count]<=indexPath.section)
        return nil;
    NSArray *hcps = [self.sectionsArray objectAtIndex:indexPath.section];
    if(hcps.count <=indexPath.row)
        return nil;
   return hcps[indexPath.row];
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *FilterCellIdentifier = @"AGNFilterCell";
    static NSString *SingleFilterCellIdentifier = @"AGNSingleCell";
    
    if(self.showPlaceholder){
        AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:SingleFilterCellIdentifier];
        if (cell == nil) {
            cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:SingleFilterCellIdentifier];
        }
        
        cell.mainLabel.text = AGNPlaceholderText;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    
    AGNAccount *account = [self accountAtIndexPath:indexPath];
    
    //only display address in landscape
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
        AGNFilterCell *cell = [tableView dequeueReusableCellWithIdentifier:FilterCellIdentifier];
        if (cell == nil) {
            cell = [[AGNFilterCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:FilterCellIdentifier];
        }
        
        cell.nameLabel.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
        cell.nameLabel.textColor = [UIColor AGNGreyMatter];
        cell.addressLabel.font = [UIFont AGNAvenirRomanFontWithSize:16.0f];
        cell.addressLabel.textColor = [UIColor AGNSecondGrayd];
        cell.addressLabel.highlightedTextColor = [UIColor AGNSilberLining];
        
        NSString *addressString = @"";
        AGNAddress *address = account.primaryAddress;
        if(!address){
            if([account.addresses count]>0)
                address = [account.addresses allObjects][0];
        }
        if(address){
            if (address.line1) {
                addressString = [addressString stringByAppendingString:[address.line1 uppercaseString]];
            }
            if (address.line2) {
                addressString = [addressString stringByAppendingFormat:@", %@", [address.line2 uppercaseString]];
            }
            if (address.line3) {
                addressString = [addressString stringByAppendingFormat:@", %@", [address.line3 uppercaseString]];
            }
            if (address.city) {
                addressString = [addressString stringByAppendingFormat:@", %@", [address.city uppercaseString]];
            }
            if (address.usState) {
                addressString = [addressString stringByAppendingFormat:@", %@", [address.usState uppercaseString]];
            }
            if (address.zip) {
                addressString = [addressString stringByAppendingFormat:@" %@", [address.zip uppercaseString]];
            }
        }
        
        
        //cell.nameLabel.text = [account doctorNameAndDesignation];
        cell.nameLabel.attributedText = [account attributedDoctorNameDesignationAndSpecialty];
        cell.addressLabel.text = NSLocalizedString(addressString, @"The string for addresses");
        
        return cell;
    }
    
    
    AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:SingleFilterCellIdentifier];
    if (cell == nil) {
        cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:SingleFilterCellIdentifier];
    }
    
    //    cell.mainLabel.text = [account doctorNameAndDesignation];
    cell.mainLabel.attributedText = [account attributedDoctorNameAndDesignation];
    
    
    
    return cell;
}


//------------------------------------------------------------------------------
// MARK: -  Section-related methods

//------------------------------------------------------------------------------


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if(self.showPlaceholder){
        return @"";
    }
    return [self.sectionTitles objectAtIndex:section];
}


- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    if(self.showPlaceholder){
        return [[NSArray alloc]init];
    }
    return self.indexTitles;
}


- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    if(self.showPlaceholder){
        return 0;
    }
    return [self.indexTitles indexOfObject:title];
}

- (void)configureSections {
    
    BOOL ascending = YES;
    NSArray *sortDescriptors = [self.segmentedControl getCurrentSortDescriptors];
    NSSortDescriptor *firstSort = sortDescriptors[0];
    NSString * key = [firstSort key];
    ascending = [firstSort ascending];
	
    NSMutableArray *indexTitles = [[NSMutableArray alloc]init];
    NSMutableArray *sectionTitles = [[NSMutableArray alloc]init];
    NSMutableArray *objectsInSections  = [[NSMutableArray alloc]init];
	for (AGNAccount *hcp in self.filteredHcps) {
        NSObject *sortAttribute = [hcp valueForKey:key];
        NSString *sectionString = @"";
        NSString *indexString =@"";
        if(sortAttribute){
            sectionString = [sortAttribute description];
            if([key isEqualToString:@"lastName"]){
                sectionString = [sectionString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                sectionString = [sectionString.uppercaseString substringToIndex:1];
            }
            indexString = sectionString;

        }else{
           //sectionString = @"UNKNOWN";
            if([key isEqualToString:@"lastName"]){
                sectionString = @"UNKNOWN";
            }else if ([key isEqualToString:@"sort_rating"]){
                sectionString = @"No Rating";
            }else if ([key isEqualToString:@"sort_frequency"]){
                sectionString = @"No Frequency";
            }
            indexString = @"_";
        }
       
        NSUInteger index = [sectionTitles indexOfObject:sectionString];
        if(index==NSNotFound){
            [sectionTitles addObject:sectionString];
            
            //ONLY SHOW INDEX IF WE ARE NOT FILTERING AND SORTED BY NAME
            if([key isEqualToString:@"lastName"]){
                if(self.searchText && [self.searchText agnTrim].length>0){
                    // don't populate index if we're filtering
                }
                else{
                    [indexTitles addObject:indexString];

                }
            }
            
            NSMutableArray *objectArray = [[NSMutableArray alloc]init];
            [objectArray addObject:hcp];
            [objectsInSections addObject:objectArray];
            
        }else{
            NSMutableArray *objectArray = [objectsInSections objectAtIndex:index];
            [objectArray addObject:hcp];
        }
	}

    self.indexTitles = indexTitles;
	self.sectionTitles = sectionTitles;
    self.sectionsArray = objectsInSections;
}



//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Delegate
//------------------------------------------------------------------------------


- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.showPlaceholder)
        return;
    if ([self.currentlySelectedIndexPath compare:indexPath] == NSOrderedSame) {
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNCallHistorySelectedKey object:nil userInfo:nil];
        self.currentlySelectedIndexPath = [NSIndexPath indexPathForRow:-1 inSection:-1];
    }else{
        self.currentlySelectedIndexPath = indexPath;
        [self populateDetailViewForIndexPath:indexPath];
    }
    [self.searchBar resignFirstResponder];
    
}

-(void) populateDetailViewForIndexPath:(NSIndexPath *)indexPath{
    AGNAccount *acct = [self accountAtIndexPath:indexPath];

    NSDictionary *userInfo = @{ @"account" : acct };
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNHCPDetailViewSelectedKey object:nil userInfo:userInfo];
    
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark HCP Sorting
//------------------------------------------------------------------------------

-(NSArray *)sortDescriptorsWithFirstName:(NSArray *)sortDescriptors{
    NSMutableArray *sortDescriptorsWithFirstName = [[NSMutableArray alloc]initWithCapacity:sortDescriptors.count +1];
    for(NSSortDescriptor *sortDescriptor in sortDescriptors){
        [sortDescriptorsWithFirstName addObject:sortDescriptor];
        if([sortDescriptor.key isEqualToString:@"lastName"]){
            NSSortDescriptor *firstNameDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"firstName" ascending:sortDescriptor.ascending selector:@selector(caseInsensitiveCompare:)];
            [sortDescriptorsWithFirstName addObject:firstNameDescriptor];
        }
    }
    return sortDescriptorsWithFirstName;
}

-(void) sort {
    int sortIndex = [self.segmentedControl selectedSegmentIndex];
    NSArray *segmentSortDescriptors = [self.segmentedControl getSortDescriptorsForSortIndex:[NSNumber numberWithInt:sortIndex]];
    self.sortDescriptors = [self sortDescriptorsWithFirstName:segmentSortDescriptors];
    log4Debug(@"resorting with descriptors %@",self.sortDescriptors);
    self.filteredHcps = self.searchText.length > 0 ? [[AGNDataManager defaultInstance] getHCPSForFilterString:self.searchText withSortDescriptors:self.sortDescriptors] : [[AGNDataManager defaultInstance] getAllHCPsWithSortDescriptors:self.sortDescriptors];
    [self configureSections];
    [self.tableView reloadData];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark SearchBar Delegate
//------------------------------------------------------------------------------

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)aSearchText {
    self.searchText = aSearchText;
    NSArray *segmentSortDescriptors = [self.segmentedControl getCurrentSortDescriptors];
    self.sortDescriptors = [self sortDescriptorsWithFirstName:segmentSortDescriptors];
    self.filteredHcps = self.searchText.length > 0 ? [[AGNDataManager defaultInstance] getHCPSForFilterString:self.searchText withSortDescriptors:self.sortDescriptors] : [[AGNDataManager defaultInstance] getAllHCPsWithSortDescriptors:self.sortDescriptors ];
    [self configureSections];
    [self.tableView reloadData];
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.searchBar resignFirstResponder];
}

-(void)setFilteredHcps:(NSArray *)filteredHcps{
    if([filteredHcps count]==0)
        self.showPlaceholder=YES;
    else{
        self.showPlaceholder=NO;
        _filteredHcps=filteredHcps;
    }
}

@end
