//
//  AGNHCPContactEditViewController.h
//  AGNDirect
//
//  Created by Adam McLain on 10/7/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNAccount.h"

typedef void(^SaveChangesBlock)(void);

@interface AGNHCPContactEditViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (nonatomic, strong) AGNAccount *account;
@property (nonatomic, strong) SaveChangesBlock saveBlock;
@end
