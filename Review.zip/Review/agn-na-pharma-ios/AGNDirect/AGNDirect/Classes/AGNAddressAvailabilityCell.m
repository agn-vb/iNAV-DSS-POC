//
//  AGNAddressAvailabilityCell.m
//  AGNDirect
//
//  Created by Adam McLain on 10/25/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAddressAvailabilityCell.h"

@implementation AGNAddressAvailabilityCell
@synthesize gridView = _gridView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.gridView = [[AGNAvailabilityGrid alloc] init];
        [self.contentView addSubview:self.gridView];
        [self.gridView setTranslatesAutoresizingMaskIntoConstraints:NO];
        NSDictionary *views = @{@"addressView" : self.addressView, @"gridView" : self.gridView};
        for (UIView *view in [views allValues]) {
            [view setTranslatesAutoresizingMaskIntoConstraints:NO];
        }
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[addressView][gridView]" options:0 metrics:nil views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[gridView]-22-|" options:0 metrics:nil views:views]];
    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.gridView.availabilityManager = nil;
}

- (void)setAddress:(AGNAddress *)address {
    [super setAddress:address];
    self.gridView.availabilityManager = address.availabilityManager;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
