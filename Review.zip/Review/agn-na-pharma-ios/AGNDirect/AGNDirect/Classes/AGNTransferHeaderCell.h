//
//  AGNTransferHeaderCell.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNTransferHeaderCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel * label;
@property (weak, nonatomic) IBOutlet UIButton * editButton;
@property (weak, nonatomic) IBOutlet UILabel * submittedLabel;

@end
