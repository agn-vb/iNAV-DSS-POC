//
//  AGNConstants.h
//  AGNDirect
//
//  Created by Mark Wells on 9/13/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kAGNSFDCAuthBaseURL @"http://login.salesforce.com"