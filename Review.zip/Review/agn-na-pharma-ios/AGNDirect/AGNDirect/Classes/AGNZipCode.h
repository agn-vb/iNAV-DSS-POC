//
//  AGNZipCode.h
//  AGNDirect
//
//  Created by Mark Wells on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface AGNZipCode : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * zipCode;
@property (nonatomic, retain) NSString * usState;

@end
