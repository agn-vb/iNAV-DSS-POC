//
//  AGNTransientStateWrapper.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/6/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTransientStateWrapper.h"

@implementation AGNTransientStateWrapper

@synthesize abbreviation;
@synthesize fullName;

@end
