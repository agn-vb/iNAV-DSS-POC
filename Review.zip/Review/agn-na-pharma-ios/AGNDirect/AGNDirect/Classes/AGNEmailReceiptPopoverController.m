//
//  AGNViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//   POPOVER FOR SELECTING / ADDING EMAIL ADDRESS FOR RECEIPT

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNEmailReceiptPopoverController.h"
#import "AGNTableView.h"

static const float kMaxHeightPercentage=.66;

@interface AGNEmailReceiptPopoverController ()
@property (nonatomic, strong) AGNTableView *tableView;
@property (nonatomic, strong) UINavigationController *navigationController;
@end

@implementation AGNEmailReceiptPopoverController

@synthesize addEmailTextField=_addEmailTextField;
@synthesize addButton=_addButton;

- (UITextField *) addEmailTextField{
    if(!_addEmailTextField){
        _addEmailTextField=[[UITextField alloc]init];
    }
    return _addEmailTextField;
}

- (UIButton * )addButton{
    if(!_addButton){
        _addButton = [[UIButton alloc]init];
    }
    return _addButton;
}

- (id)initWithDelegate:(id<AGNEmailPopoverDelegate>)delegate andTitle:(NSString *)title {
    AGNTableView *table = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view = table;
    vc.title = title;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    self = [super initWithContentViewController:nav];
    if (self) {
        table.delegate = self;
        table.dataSource = self;
        self.tableView = table;
        self.popOverDelegate = delegate;
        self.delegate = (id)delegate;
        self.navigationController = nav;
        self.addEmailTextField.delegate = self;
        self.addEmailTextField.borderStyle = UITextBorderStyleRoundedRect;
        self.addEmailTextField.font = [UIFont AGNAvenirHeavy16];
        self.addEmailTextField.textColor = [UIColor AGNGreyMatter];

    }
    return self;
}

- (void)presentPopoverFromRect:(CGRect)rect inView:(UIView *)view permittedArrowDirections:(UIPopoverArrowDirection)arrowDirections animated:(BOOL)animated {
    [self.tableView reloadData];
    [self.tableView layoutIfNeeded];
    CGSize size = [self.tableView contentSize];
    
    if(view){
        float height = size.height;
        float maxHeight =  view.frame.size.height *kMaxHeightPercentage;
        float width = view.frame.size.width;
        if(size.height > maxHeight)
            height = maxHeight;
        if (height <= self.tableView.contentSize.height) {
            self.tableView.scrollEnabled = NO;
        } else {
            self.tableView.scrollEnabled = YES;
        }
        height += self.navigationController.navigationBar.frame.size.height;
        size = CGSizeMake(width,height);
    }
    self.popoverContentSize = size;
    
    [super presentPopoverFromRect:rect inView:view permittedArrowDirections:arrowDirections animated:animated];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section==0)return 1;
    else
    return self.objectArray.count;
}

- (void)addButtonClicked{
    log4Debug([NSString stringWithFormat:@"Add Button clicked %@ ",self.addEmailTextField.text]);
    [self.popOverDelegate addNewEmail:self.addEmailTextField.text];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    log4Debug([NSString stringWithFormat:@"Text view did end editing %@ ",textField.text]);
    [self.popOverDelegate addNewEmail:textField.text];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        static NSString *CellIdentifier = @"AddNewCellIdentifier";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
            self.addEmailTextField.translatesAutoresizingMaskIntoConstraints=NO;
            self.addButton.translatesAutoresizingMaskIntoConstraints=NO;
            self.addEmailTextField.delegate = self;
            NSDictionary *constraintsViewsDictionary =
            @{
            @"superview" : cell.contentView ,
            @"textView" : self.addEmailTextField,
            @"addButton": self.addButton
            };
            
            cell.textLabel.hidden=YES;
            [cell.contentView addSubview:self.addEmailTextField];
            [cell.contentView addSubview:self.addButton];
            
            
            self.addEmailTextField.placeholder=@"Add New";
            self.addEmailTextField.keyboardType = UIKeyboardTypeEmailAddress;
            
            [self.addButton setTitle:@"+" forState:UIControlStateNormal];
            [self.addButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [self.addButton addTarget:self action:@selector(addButtonClicked) forControlEvents:UIControlEventTouchUpInside];

            [cell.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[textView(>=250)]" options:0 metrics:nil views:constraintsViewsDictionary]];
            [cell.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[addButton(==20)]" options:0 metrics:nil views:constraintsViewsDictionary]];

            [cell.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-8-[textView]-22-[addButton]-8-|" options:0 metrics:nil views:constraintsViewsDictionary]];
            
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.addEmailTextField attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:cell.contentView  attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.addButton attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:cell.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];

            
        }
        return cell;

        
    }
    else {
        static NSString *CellIdentifier = @"CellIdentifier";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        [cell agnSetStyledSelectedBackground];
        
        NSString* address = self.objectArray[indexPath.row];
        cell.textLabel.text = address;
        cell.textLabel.font = [UIFont AGNAvenirHeavy14];
        cell.textLabel.textColor = [UIColor AGNGreyMatter];
        int indexSelected = [self.popOverDelegate currentSelection];
        if(indexPath.row==indexSelected){
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        return cell;
    }
    
    return nil;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        [self.addEmailTextField becomeFirstResponder];
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        return;
    }
    if(self.popOverDelegate){
        [self.popOverDelegate objectSelected:indexPath.row];
    }
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
}

//------------------------------------------------------------------------------
// MARK: - UITextfieldDelegate
//------------------------------------------------------------------------------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    return (newLength > 80) ? NO : YES;
}

@end
