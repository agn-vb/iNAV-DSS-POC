//
//  AGNClosedCallCell.h
//  AGNDirect
//
//  Created by Adam McLain on 8/8/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNCallHistoryCell : UITableViewCell
@property (strong, nonatomic) UILabel *mainLabel;
@property (strong, nonatomic) UILabel *secondaryLabel;

+ (CGFloat)heightForAttributedString:(NSAttributedString *)anAttributedString withWidth:(CGFloat)width;

@end
