//
//  AGNCallDetailDetailsViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/18/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  THIS IS THE LEFT SIDE OF THE CALL VIEW (ADDING DETAILS/SAMPLES ETC.)

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



#import "AGNCallDetailViewController.h"
#import "AGNHCPDetailViewController.h"
#import "AGNCallNameAddressLicenseCell.h"
#import "AGNCallProductHeaderCell.h"
#import "AGNCallProductDetailCell.h"
#import "AGNCallProductSampleCell.h"
#import "AGNCall.h"
#import "AGNSampleInventoryLine.h"
#import "AGNDetailPosition.h"
#import "AGNCallDetail.h"
#import "AGNSignatureViewController.h"
#import "AGNGetSignatureFooterCell.h"
#import "AGNCallDetailDetailsViewController.h"
#import "AGNCategoryHeaders.h"
#import "AGNTableViewHeader.h"
#import "AGNCallContact.h"
#import "AGNTableView.h"


@interface AGNCallDetailDetailsViewController ()

@property (weak, nonatomic) IBOutlet AGNTableView *detailsTableView;
@property (assign, nonatomic) BOOL shouldDisplayExtraSampleCell;
@property (strong, nonatomic) AGNProductSKU *selectedSKU;
@property (strong, nonatomic) AGNSimplePopoverTableViewController *lotPickerPopover;
@property (strong, nonatomic) NSIndexPath *lotPickerSelectedCellIndexPath;
@property (strong, nonatomic) AGNEligibilityHelper *eligibilityHelper;
@property (strong, nonatomic) UITextField *activeField;
@property (strong, nonatomic) NSIndexPath *returnToIndexPath;

@property CGFloat keyboardHeight;


@property BOOL inEditMode;

@end

static const int kHeight=44;


@implementation AGNCallDetailDetailsViewController

@synthesize call=_call;
@synthesize eligibilityHelper=_eligibilityHelper;
@synthesize detailPositions=_detailPositions;
@synthesize selectedSKU=_selectedSKU;
@synthesize lotPickerPopover=_lotPickerPopover;
@synthesize lotPickerSelectedCellIndexPath=_lotPickerSelectedCellIndexPath;

BOOL showPlaceholder;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.detailsTableView.tableFooterView = [[UIView alloc] init];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    showPlaceholder=NO;
    [self.detailsTableView registerClass:[AGNCallProductDetailCell class] forCellReuseIdentifier:@"CallProductCodeCell"];
    [self.detailsTableView registerClass:[AGNCallProductSampleCell class] forCellReuseIdentifier:@"CallProductSampleCodeCell"];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(sampleCellBeganEditing:)
                                                 name:AGNSampleCellDidBeginEditing object:nil];

    

}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.detailsTableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.detailsTableView.contentSize = newContentSize;
}

-(void)setCall:(AGNCall *)call{
    _call=call;
    self.eligibilityHelper=[[AGNEligibilityHelper alloc]initWithCall:call];
    if(![self.call isClosed]){
        self.detailPositions = [self.eligibilityHelper eligibleDetailPositions];
        if(!self.call.signatureCaptureDate){
            self.sampleInventoryLines = [self.eligibilityHelper eligibleSampleInventoryLines];
            NSMutableSet *products = [[NSMutableSet alloc] init];
            for (AGNSampleInventoryLine *sampleLine in self.sampleInventoryLines) {
                [products addObject:sampleLine.product];
            }
        self.sampleProducts = products;
        }
    }
    [self reloadData];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableViewDataSource
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    int sections=0; //details
    if([self detailsSectionIndex]>=0)
        sections++;
    if([self availableDetailsSectionIndex]>=0)
        sections++; //available details
    if ([self.eligibilityHelper hasSamplingSection])
        sections++; // display samples in the call
    if([self.call canAddSamples])
        sections++; // display available samples
    if([self.call isClosed])
        sections++; //additional call info
    if(sections==0){
        showPlaceholder=YES;
        return 1;
    }
    return sections;
}

- (NSInteger)detailsSectionIndex{
    if([self.call.liveCallDetails count]>0 || [[self.eligibilityHelper eligibleDetailPositions] count]>0)
        return 0;
    return -1;
}

-(NSInteger)availableDetailsSectionIndex{
    if([self.call isClosed])
        return -1;
    if([self detailsSectionIndex]<0)
        return -1;
    if (self.call.isDSSCall == [NSNumber numberWithInt:1]) {
        return -1;
    }
    return [self detailsSectionIndex]+1;
}

-(NSInteger)selectedSamplesSectionIndex{
    if(![self.eligibilityHelper hasSamplingSection])
        return -1;
    if([self availableDetailsSectionIndex]>=0)
        return [self availableDetailsSectionIndex]+1;
    else if([self detailsSectionIndex]>=0)
        return [self detailsSectionIndex]+1;
    else return 0;
}

-(NSInteger)availableSamplesSectionIndex{
    if(![self.call canAddSamples])
        return -1;
    if (self.call.isDSSCall == [NSNumber numberWithInt:1]) {
        return -1;
    }
    else return [self selectedSamplesSectionIndex]+1;
}

-(NSInteger)additionalCallInfoSection{
    if(![self.call isClosed])
        return -1;
    if([self selectedSamplesSectionIndex]>-1)
        return [self selectedSamplesSectionIndex]+1;
    else return [self detailsSectionIndex]+1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(showPlaceholder)
        return 1;
    NSMutableOrderedSet *liveCallDetails = [self.call liveCallDetails];
    NSMutableOrderedSet *liveSampleDrops = [self.call liveSampleDrops];
    int callDetailsCount = [liveCallDetails count];
    int detailPositionsCount = [self.detailPositions count];
    if (section == [self detailsSectionIndex]) {
        if ([self.call isClosed]) {
            return [liveCallDetails count] > 0 ? callDetailsCount : 0;
        }
        return [liveCallDetails count] > 0 ? callDetailsCount : 1;
    } else if (section == [self availableDetailsSectionIndex]) {
        return [self.call.closed boolValue] ? 0 : [[self availableDetails] count];
    } else if (section == [self selectedSamplesSectionIndex]) {
        int sampleCount = 0;
        sampleCount += liveSampleDrops.count;
        if (self.shouldDisplayExtraSampleCell) {
            sampleCount++;
        }
        if ([self.call isClosed]) {
            return sampleCount;
        }
        return sampleCount > 0 ? sampleCount : 1;
    } else if (section == [self availableSamplesSectionIndex]) {
        int count = 0;
        count += [[self availableSamples] count];
        if(count==0)
            count=1; // will show a line indicating that there aren't any available samples
        return [self.call.closed boolValue] || self.call.signatureCaptureDate ? 0 : count;
    } else if (section == [self additionalCallInfoSection]){
        int numContacts = self.call.callContacts.count;
        if(!self.call.nonMDCall.boolValue)
            numContacts++;
        return 2+numContacts;
    }
    return 0;
}

- (int)numSamples {
    return [[self.call liveSampleDrops] count];
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = nil;
    if(showPlaceholder){
        cell = [aTableView dequeueReusableCellWithIdentifier:@"CallProductCodeCell"];
        ((AGNCallProductDetailCell *)cell).label.text = @"No product details eligible for this call.";
        return cell;
    }
    NSMutableOrderedSet *liveSampleDrops = [self.call liveSampleDrops];
    
    //Details
    if (indexPath.section == [self detailsSectionIndex]) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"CallProductCodeCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        AGNCallDetail *callDetail = nil;
        if ([[self.call liveCallDetails] count] > 0) {
            callDetail = [[self.call orderedCallDetails] objectAtIndex:indexPath.row];
        }
        ((AGNCallProductDetailCell *)cell).label.text = callDetail ? [callDetail displayString] : NSLocalizedString(@"Choose a Product from the list below", @"Message to show when call has no details");
        ((AGNCallProductDetailCell *)cell).model = callDetail;
    }
    
    //Available Details
    else if (indexPath.section == [self availableDetailsSectionIndex]) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"CallProductCodeCell"];
        ((AGNCallProductDetailCell *)cell).label.text = [((AGNDetailPosition *)[[self availableDetails] objectAtIndex:indexPath.row]) displayString];
    }
    
    //Samples
    else if (indexPath.section == [self selectedSamplesSectionIndex]) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"CallProductSampleCodeCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        AGNSampleDrop *sampleDrop = nil;
        if ([liveSampleDrops count] > 0 || self.shouldDisplayExtraSampleCell) {
            
            // requested cell is outside the bounds of the sampleDrop collection, display lot picker for empty cell
            if (indexPath.row == liveSampleDrops.count || liveSampleDrops.count == 0) {
                [self presentLotPickerForIndexPath:indexPath];
            } else {
                sampleDrop = (AGNSampleDrop *)[((NSOrderedSet *)liveSampleDrops) objectAtIndex:indexPath.row];
            }
            ((AGNCallProductSampleCell *)cell).label.text = @"";
            ((AGNCallProductSampleCell *)cell).sku = self.selectedSKU;
            ((AGNCallProductSampleCell *)cell).quantityTextField.enabled = !([self.call.closed boolValue] || self.call.signatureCaptureDate);
            if (self.call.isDSSCall == [NSNumber numberWithInt:1]) {
                ((AGNCallProductSampleCell *)cell).quantityTextField.enabled = false;
            }
            ((AGNCallProductSampleCell *)cell).model = sampleDrop;
            
            if( [indexPath compare:self.lotPickerSelectedCellIndexPath]==NSOrderedSame){
                //[((AGNCallProductSampleCell *)cell).quantityTextField becomeFirstResponder];
                self.activeField = ((AGNCallProductSampleCell *)cell).quantityTextField;
            }
        }
        else {
            ((AGNCallProductSampleCell *)cell).label.text = NSLocalizedString(@"Choose a Sample from the list below", @"Message to show when call has no samples");
            ((AGNCallProductSampleCell *)cell).quantityTextField.hidden = YES;
            ((AGNCallProductSampleCell *)cell).quantityLabel.hidden = YES;
        }
        
    }
    
    //Available Samples
    else if (indexPath.section == [self availableSamplesSectionIndex]) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"CallProductCodeCell"];
        if([[self availableSamples] count]==0){
            ((AGNCallProductDetailCell *)cell).label.text =  NSLocalizedString(@"No samples available", @"Message to show when rep has no eligible inventory");
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }else{
            AGNProductSKU * product = [[self availableSamples] objectAtIndex:indexPath.row];
            ((AGNCallProductDetailCell *)cell).label.text = product.productDescription;
        }
    }
    
    
    //Additional Call Info
    else if (indexPath.section == [self additionalCallInfoSection]){
        cell = [aTableView dequeueReusableCellWithIdentifier:@"CallProductCodeCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if(indexPath.row==0){
            NSString *closedDateText = [NSString stringWithFormat:@"CLOSED - %@", [self.call.callClosedTimestamp agnFormattedTimestampString]];
            ((AGNCallProductDetailCell *)cell).label.text =  closedDateText;
        }
        if(indexPath.row==1) {
            NSMutableString *labelString = [NSMutableString stringWithString:@"CONTACTED : "];
            ((AGNCallProductDetailCell *)cell).label.text = labelString;
        }
        
        UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:14.0f];
        NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
        

        
        int offset = self.call.nonMDCall.boolValue?2:3;
        if (indexPath.row>1 && indexPath.row < offset) {
              ((AGNCallProductDetailCell *)cell).label.attributedText = [[NSAttributedString alloc]initWithString:[NSString stringWithFormat:@"\t %@",self.call.account.doctorNameAndDesignation] attributes:romanAttributes];
        }
        if(indexPath.row >=offset){
            AGNCallContact *contact = self.call.callContacts.allObjects[indexPath.row-offset];
            ((AGNCallProductDetailCell *)cell).label.attributedText = [[NSAttributedString alloc]initWithString:[NSString stringWithFormat:@"\t %@",[contact formattedStampedNameAndRole]]attributes:romanAttributes];
        }
        
    }
    
    [cell agnSetStyledSelectedBackground];
    
    return cell ? cell : [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Delegate
//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(showPlaceholder)
        return;
    NSMutableOrderedSet *liveSampleDrops = [self.call liveSampleDrops];
    if (tableView.editing) {
        return; //don't allow any selection while editing
    }
    //Available Details
    if (indexPath.section == [self availableDetailsSectionIndex]) {
        //only add details if the call is still open
        if([self.call canAddDetails]){
            AGNDetailPosition * dp = (AGNDetailPosition *)[[self availableDetails] objectAtIndex:indexPath.row];
            AGNCallDetail *cd = (AGNCallDetail *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNCallDetail" inManagedObjectContext: [self.call managedObjectContext]];
            cd.detailPosition = dp;
            cd.guid = [[NSUUID UUID] UUIDString];
            [self.call addDetail:cd];
            log4Info(@"Adding detail %@ to call %@",cd.displayString,self.call);
            //remove selected detail from self.call.callDetails and the tableView
            //self.call.callDetails
            //[self.callProductsTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];
            NSRange range = NSMakeRange(0, 2);
            NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
            [self.detailsTableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
    //Added Samples
    if (indexPath.section == [self selectedSamplesSectionIndex] && [liveSampleDrops count]>0) {
        if (self.call.signatureCaptureDate) {
            return;
        }
        AGNProductSKU *sku = [[liveSampleDrops[indexPath.row] sampleInventoryLine] product];
        self.selectedSKU = sku;
        self.shouldDisplayExtraSampleCell = NO;
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNSampleCellQuantityChangedNotification object:self];
        [self presentLotPickerForIndexPath:indexPath];
        [self.detailsTableView deselectRowAtIndexPath:indexPath animated:NO];
        
    }
    
    //Available Samples
    if (indexPath.section == [self availableSamplesSectionIndex] && [[self availableSamples] count] > 0) {
        //only add samples if the call has not accepted a signature
        if ([self.call canAddSamples]) {
            self.selectedSKU = [self availableSamples][indexPath.row];
            
            self.shouldDisplayExtraSampleCell = YES;
            [self.detailsTableView reloadData];
        }
    }
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 33.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    if (section==[self detailsSectionIndex] && [self.call isClosed] && [[self.call liveCallDetails] count] == 0) {
        return 0.0f;
    }
    
    if (section==[self selectedSamplesSectionIndex] && [self.call isClosed] && [self.call liveSampleDrops].count == 0) {
        return 0.0f;
    }
    
    if (section==[self availableDetailsSectionIndex] && [[self availableDetails] count] == 0) {
        return 0.0f;
    }
    
    return 28.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    AGNTableViewHeader *header = [[AGNTableViewHeader alloc] init];
    if(showPlaceholder){
        header.leftLabel.text = NSLocalizedString(@"No Data To Display", @"Empty call detail view");
        return header;
    }
    
    if(section==[self detailsSectionIndex]){
        header.leftLabel.text = NSLocalizedString(@"DETAILS",@"Table header for details section of call");
        BOOL editMode = tableView.editing;
        [header setButtonLabelText:(editMode ? @"DONE" : @"EDIT")];
        [header setNeedsDisplay];
        [header.button addTarget:self action:@selector(toggleEditMode:) forControlEvents:UIControlEventTouchUpInside];
        //if call has no editable fields, disable button until they are present
        if ([[self.call liveCallDetails] count] == 0 && [[self.call liveSampleDrops] count] == 0 && !tableView.editing) {
            header.button.enabled = NO;
            header.button.titleLabel.alpha = 0.5f;
        }
        //if call is closed, disable and dim button
        if (self.call.closed == [NSNumber numberWithInt:1]) {
            header.button.enabled = NO;
            header.button.hidden=YES;
        }
        //barathan
        NSLog(@"Test Call info %@ :",self.call);
        if (self.call.isDSSCall == [NSNumber numberWithInt:1]) {
            header.button.enabled = NO;
            header.button.hidden=YES;
            tableView.editing=NO;
        }
        // AL-735 - nothing to edit so hide the button
        if(self.call.signatureCaptureDate && [[self.call liveCallDetails]count]==0){
            header.button.enabled = NO;
            header.button.hidden=YES;
            tableView.editing=NO;
        }
       
    }
    else if (section==[self availableDetailsSectionIndex]){
      header.leftLabel.text = NSLocalizedString(@"AVAILABLE DETAILS",@"Table header for available details section of call");
    }
    else if(section ==[self selectedSamplesSectionIndex]){
        header.leftLabel.text = @"SAMPLES";
    }
    else if(section==[self availableSamplesSectionIndex]){
        header.leftLabel.text = @"AVAILABLE SAMPLES";
    }
    else if(section==[self additionalCallInfoSection]){
        header.leftLabel.text = @"ADDITIONAL CALL INFO";
    }
    return header;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.call.closed || (indexPath.section != 0 && indexPath.section != 2) ||
        ((indexPath.section ==  [self selectedSamplesSectionIndex] && self.call.signatureCaptureDate))) {
        return NO;
    }
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (((indexPath.section == [self detailsSectionIndex] && [[self.call liveCallDetails] count] > 0)) || (indexPath.section == [self selectedSamplesSectionIndex] && [[self.call liveSampleDrops] count] > 0)) {
        //Details - return none if call is closed
        if (indexPath.section == 0 && self.call.closed == [NSNumber numberWithInt:1]) {
            return UITableViewCellEditingStyleNone;
        }
        
        //Samples - return none if there is already a signature captured and if the call is closed
        if ((indexPath.section ==  [self selectedSamplesSectionIndex] && self.call.signatureCaptureDate)
            || self.call.closed == [NSNumber numberWithInt:1]){
            return UITableViewCellEditingStyleNone;
        }
        if (self.call.isDSSCall == [NSNumber numberWithInt:1]) {
            return UITableViewCellEditingStyleNone;
        }
        return UITableViewCellEditingStyleDelete;
    }
    return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == [self detailsSectionIndex]) {
        [tableView beginUpdates];
        AGNCallDetail *detailToDelete = [self.call orderedCallDetails][indexPath.row];
        log4Debug(@"hasChanges %d, isInserted %d, isDeleted %d, isUpdate %d", detailToDelete.hasChanges, detailToDelete.isInserted, detailToDelete.isDeleted, detailToDelete.isUpdated);
        log4Info(@"Deleting detail %@ from call %@",detailToDelete.displayString, self.call);
        if ([detailToDelete isInserted]) {
            detailToDelete.call = nil;
            [[self.call managedObjectContext] deleteObject:detailToDelete];
        } else {
            detailToDelete.toBeDeletedFlag = @YES;
        }
        if (indexPath.row > 1) { //account for the dummy row with the help text
            [self.detailsTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
        }

        NSRange range = NSMakeRange(0, 2);
        NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
        [self.detailsTableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];
        [tableView endUpdates];

    }
    if (indexPath.section == [self selectedSamplesSectionIndex]) {
        [tableView beginUpdates];


        NSMutableOrderedSet *mos = [self.call liveSampleDrops];
        AGNSampleDrop *dropToDelete = [mos objectAtIndex:indexPath.row];
        log4Info(@"Deleting sample %@ from call %@",dropToDelete.sampleInventoryLine.product.productDescription, self.call);

        log4Debug(@"hasChanges %d, isInserted %d, isDeleted %d, isUpdate %d", dropToDelete.hasChanges, dropToDelete.isInserted, dropToDelete.isDeleted, dropToDelete.isUpdated);
        if (dropToDelete.isInserted) {
            dropToDelete.call = nil;
            [[self.call managedObjectContext]deleteObject:dropToDelete];
        } else {
            dropToDelete.toBeDeletedFlag = @YES;
        }
//        if (indexPath.row > 1) { //account for the dummy row with the help text
//            [self.detailsTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
//        }
        NSRange range = NSMakeRange(indexPath.section, indexPath.section);
        NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
        [self.detailsTableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNSampleCellQuantityChangedNotification object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];
        [tableView endUpdates];

    }
    
    // toggle editing off if there are no details or samples
    if ([[self.call liveCallDetails] count] == 0 && [[self.call liveSampleDrops] count] == 0) {
        tableView.editing = NO;
        self.inEditMode = NO;
    }
    
    if(!self.inEditMode){
        // leave edit mode if this was swipe to delete
        // otherwise if edit button pressed stay in edit mode
        tableView.editing = NO;
   }
    
    
    NSRange range = NSMakeRange(0, 1);
    NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
    [self.detailsTableView reloadSections:section withRowAnimation:UITableViewRowAnimationNone];


}


//------------------------------------------------------------------------------
// MARK: - Reordering
//------------------------------------------------------------------------------

-(BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==[self detailsSectionIndex] && [[self.call liveCallDetails] count] > 1)
        return YES;
    return NO;
}

- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath {
    NSMutableOrderedSet *liveCallDetails = [self.call liveCallDetails];

    NSIndexPath *target = proposedDestinationIndexPath;
    NSUInteger proposedSection = proposedDestinationIndexPath.section;
    
    if(proposedSection!=[self detailsSectionIndex]){ // prevent attempt to move outside the section
        return sourceIndexPath;
    }
    
    if (proposedSection == [self detailsSectionIndex] && [liveCallDetails count] > 0) {
        NSUInteger lastIndex = [liveCallDetails count] - 1;
        if (proposedDestinationIndexPath.row > lastIndex) {
            target = [NSIndexPath indexPathForRow:lastIndex inSection:0];
        }
    }
    return target;

}

-(void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{
    log4Debug(@"Moved detail position from index %d to index %d",sourceIndexPath.row,destinationIndexPath.row);
    [self.call moveDetailAtIndex:sourceIndexPath.row toIndex:destinationIndexPath.row];
    [self.call printDetailPositions];
    
}

//------------------------------------------------------------------------------
// MARK: - Utility Methods
//------------------------------------------------------------------------------
- (NSArray *)availableSamples {
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (AGNProductSKU *sku in self.sampleProducts) {
        NSLog(@"SKU Desc : %@ ", sku.dssOnlySku);
        NSLog(@"Call Type : %@ ", self.call.isDSSCall);
        if ((self.call.isDSSCall == nil || self.call.isDSSCall == [NSNumber numberWithInt:0] ) && (sku.dssOnlySku == [NSNumber numberWithInt:1]) ) {
             NSLog(@"SKU Desc : %@ - %@ ", sku.dssOnlySku, sku.fullDescription);
        }
        else  if ([[self availableSampleInventoryLinesForSKU:sku] count] > 0) {
            [array addObject:sku];
        }
    }

    return [array sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"productDescription" ascending:YES]]];
}

- (NSArray *)availableDetails {
    NSMutableArray *array = [self.detailPositions mutableCopy];
    for (AGNCallDetail *detail in [self.call orderedCallDetails]) {
        if ([self.detailPositions containsObject:detail.detailPosition]) {
            [array removeObject:detail.detailPosition];
        }
    }
    return array;
}


//------------------------------------------------------------------------------
// MARK: - <#text#>
//------------------------------------------------------------------------------

-(void)sampleCellBeganEditing:(NSNotification *)notification{
    self.activeField=((AGNCallProductSampleCell *)notification.object).quantityTextField;
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    
    UITableViewCell *cell = (UITableViewCell *)[[self.activeField superview] superview];
    NSIndexPath *indexPath = [self.detailsTableView indexPathForCell:cell];
    
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        if(!info){
            keyboardHeight = self.keyboardHeight;
        }
        else{
            keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
            self.keyboardHeight=keyboardHeight;
        }
    }
    else {
        if(!info){
            keyboardHeight = self.keyboardHeight;
        }
        else{
            keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
            self.keyboardHeight=keyboardHeight;
        }
    }
    
    
    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardHeight-kHeight, 0.0);
    self.detailsTableView.contentInset = contentInsets;
    self.detailsTableView.scrollIndicatorInsets = contentInsets;
    
    
    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.detailsTableView.frame;
    aRect.size.height -= (keyboardHeight+kHeight);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        self.returnToIndexPath=[self firstVisibleRow];
        [self.detailsTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

-(NSIndexPath *)firstVisibleRow{
    NSArray* indexPaths = [self.detailsTableView indexPathsForVisibleRows];
    NSArray* sortedIndexPaths = [indexPaths sortedArrayUsingSelector:@selector(compare:)];
    return (NSIndexPath*)[sortedIndexPaths objectAtIndex:0];
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    self.activeField = nil;
    self.keyboardHeight=0.0;

    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:[animationTime doubleValue] animations:^{
        UIEdgeInsets contentInsets = UIEdgeInsetsZero;
        self.detailsTableView.contentInset = contentInsets;
        self.detailsTableView.scrollIndicatorInsets = contentInsets;
    }];
    if(self.returnToIndexPath){
        [self.detailsTableView scrollToRowAtIndexPath:self.returnToIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
        self.returnToIndexPath=nil;
    }

}


//------------------------------------------------------------------------------
// MARK: - Lot Picker Popover
//------------------------------------------------------------------------------
- (void)presentLotPickerForIndexPath:(NSIndexPath *)indexPath {
    self.lotPickerSelectedCellIndexPath = indexPath;
    
    AGNProductSKU *sku = nil;
    AGNSampleDrop *sd = nil;
    
    // Get related SKU for related tableViewCell
    if (self.shouldDisplayExtraSampleCell) {
        sku = self.selectedSKU;
    } else {
        sd = [[self.call liveSampleDrops] objectAtIndex:indexPath.row];
        sku = sd.sampleInventoryLine.product;
    }
    
    NSMutableArray *sampleInventoryProducts = [self availableSampleInventoryLinesForSKU:sku];
    if (indexPath.section == [self selectedSamplesSectionIndex]) {
        if (sd.sampleInventoryLine) {
            [sampleInventoryProducts addObject:sd.sampleInventoryLine];
        }
    }
    
    if (sampleInventoryProducts.count == 0) {
        return;
    }
    
    if (self.call.isDSSCall == [NSNumber numberWithInt:1]) {
        return;
    }

    // per Jeff, show the lot picker even if there's only one choice
    // there's extra info in the lot picker that they need to see
    
//    if (sampleInventoryProducts.count == 1){
//        [self createSampleDropWithSIL:sampleInventoryProducts[0]];
//        [self samplesChanged];
//        return;
//    }
    
    // sort the array by dates
    [sampleInventoryProducts sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        AGNSampleInventoryLine *sil1 = obj1;
        AGNSampleInventoryLine *sil2 = obj2;
        return [sil1.expiration compare:sil2.expiration];
    }];
    
    // create popover
    if (!self.lotPickerPopover) {
        self.lotPickerPopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Available Lots", @"lot picker title")];
    }
    
    // set properites on popover to display the sampleInventoryLines array
    self.lotPickerPopover.objectArray = sampleInventoryProducts;
    self.lotPickerPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        static NSString *CellIdentifier = @"CellIdentifier";
        
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        [cell agnSetStyledSelectedBackground];
        
        AGNSampleInventoryLine *sampleInventoryLine = [sampleInventoryProducts objectAtIndex:indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ (%@)", sampleInventoryLine.lotNumber, sampleInventoryLine.product.productDescription];
        cell.textLabel.font = [UIFont AGNAvenirHeavy16];
        cell.textLabel.textColor = [UIColor AGNGreyMatter];
        cell.textLabel.highlightedTextColor = [UIColor whiteColor];
        NSString *expiration = sampleInventoryLine.expiration ? [sampleInventoryLine.expiration agnFormattedDateString] : @"";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"EXP: %@     QTY: %@",  expiration, sampleInventoryLine.quantity];
        return cell;
    };
    
    // display the popover
    CGRect presentingRect = [self.detailsTableView rectForRowAtIndexPath:indexPath];
    presentingRect.origin.y -= presentingRect.size.height / 2;
    [self.lotPickerPopover presentPopoverFromRect:presentingRect inView:self.detailsTableView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
    self.shouldDisplayExtraSampleCell = NO;
//    NSRange range = NSMakeRange(2, 2);
//    NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
//    [self.detailsTableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.detailsTableView reloadData];
    return YES;
}

- (void)objectSelected:(NSInteger)selected {
    if (self.shouldDisplayExtraSampleCell == NO) {
        AGNSampleInventoryLine *sil = (AGNSampleInventoryLine *)[self.lotPickerPopover.objectArray objectAtIndex:selected];
        AGNSampleDrop *sd = [[self.call liveSampleDrops] objectAtIndex:self.lotPickerSelectedCellIndexPath.row];
        sd.sampleInventoryLine = sil;
        [self.detailsTableView reloadRowsAtIndexPaths:@[self.lotPickerSelectedCellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    } else {
        AGNSampleInventoryLine *sil = (AGNSampleInventoryLine *)[self.lotPickerPopover.objectArray objectAtIndex:selected];
        [self createSampleDropWithSIL:sil];
  }
    
    [self samplesChanged];
}

-(void)samplesChanged{
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];
    self.shouldDisplayExtraSampleCell = NO;
    [self.detailsTableView reloadData];
    [self.lotPickerPopover dismissPopoverAnimated:YES];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNSampleCellQuantityChangedNotification object:self];
    AGNCallProductSampleCell *cell = (AGNCallProductSampleCell *)[self.detailsTableView cellForRowAtIndexPath:self.lotPickerSelectedCellIndexPath];
    [cell.quantityTextField becomeFirstResponder];
}

-(void)createSampleDropWithSIL:(AGNSampleInventoryLine *)sil{
    AGNSampleInventoryTransactionLine *sitl = (AGNSampleInventoryTransactionLine *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryTransactionLine" inManagedObjectContext:[self.call managedObjectContext]];
    sitl.sampleInventoryLine = sil;
    AGNSampleDrop *sd = (AGNSampleDrop *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleDrop" inManagedObjectContext:[self.call managedObjectContext]];
    sd.call = self.call;
    sd.guid = [[NSUUID UUID] UUIDString];
    sd.quantity = 0;
    sd.sampleInventoryLine = sil;
    log4Info(@"Adding sample %@ to call %@",sil.product.productDescription,self.call);

}

- (void)toggleEditMode:(id)sender {
    //don't allow editing if the call is closed
    if (self.call.closed == [NSNumber numberWithInt:0]) {
        [self.detailsTableView setEditing:!self.detailsTableView.editing];
        self.inEditMode=!self.inEditMode;
        
        // Force reload of first header view to display correct button title
        NSRange range = NSMakeRange(0, 1);
        NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
        [self.detailsTableView reloadSections:section withRowAnimation:UITableViewRowAnimationNone];
    }
}




//------------------------------------------------------------------------------
// MARK: - TableViewDelegate helpers
//------------------------------------------------------------------------------


// create array of sampleInventoryLines related to SKU. Items must have a quantity
// and not expired or have a lot number already sampled
- (NSMutableArray *)availableSampleInventoryLinesForSKU:(AGNProductSKU *)sku {
    NSMutableArray *sampleInventoryProducts = [[NSMutableArray alloc] init];
    for (AGNSampleInventoryLine *sample in self.sampleInventoryLines) {
        if (sample.product == sku && sample.quantity > 0) {
            BOOL skip = NO;
            for (AGNSampleDrop *sd in [self.call liveSampleDrops]) {
                if (sd.sampleInventoryLine.lotNumber == sample.lotNumber) {
                    skip = YES;
                }
            }
            if (skip || sample.isExpired) continue;
            
            [sampleInventoryProducts addObject:sample];
        }
    }
    return sampleInventoryProducts;
}


-(void)reloadData{
    [self.detailsTableView reloadData];
}

@end
