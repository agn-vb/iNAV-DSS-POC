//
//  AGNTableViewHeader.m
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

///////////////////////////////////////////////////////////////////////////

// Used throughout the application - common functionality need in the header views

#import "AGNTableViewHeader.h"
#import "AGNCategoryHeaders.h"

@interface AGNTableViewHeader ()
@property (nonatomic, strong, readwrite) UILabel *rightLabel;
@property (nonatomic, strong, readwrite) UILabel *leftLabel;
@property (nonatomic, strong, readwrite) UIButton *button;
@property (nonatomic, strong) NSArray *buttonWidthConstraints;
@end

@implementation AGNTableViewHeader

@synthesize rightLabel;
@synthesize leftLabel;
@synthesize button;
@synthesize buttonWidthConstraints;
@synthesize secondaryButton;
@synthesize data;

- (id)init {
    self = [super init];
     if (self) {
         [self styleView];
     }
     
     return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self styleView];
    }
    
    return self;
}
     
 - (void)styleView {
     UIImage *bgImage = [[UIImage imageNamed:@"subhead-grey"] resizableImageWithCapInsets:UIEdgeInsetsMake(1.0f, 0.0f, 4.0f, 0.0f)];
     UIImageView *imageView = [[UIImageView alloc] initWithImage:bgImage];
     [imageView setTranslatesAutoresizingMaskIntoConstraints:NO];
     [self addSubview:imageView];
     
     UILabel *mainLabel = [[UILabel alloc] init];
     [mainLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
     mainLabel.font = [UIFont AGNAvenirBlackFontWithSize:16.0f];
     mainLabel.textColor = [UIColor AGNEleventhHour];
     mainLabel.shadowOffset = CGSizeMake(0.0f, 0.5f);
     mainLabel.shadowColor = [UIColor AGNDropShadow];
     mainLabel.backgroundColor = [UIColor clearColor];
     self.leftLabel = mainLabel;
     [self addSubview:mainLabel];
     
     UILabel *secondaryLabel = [[UILabel alloc] init];
     [secondaryLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
     secondaryLabel.font = [UIFont AGNAvenirBlackFontWithSize:16.0f];
     secondaryLabel.textColor = [UIColor AGNEleventhHour];
     secondaryLabel.textAlignment = NSTextAlignmentRight;
     secondaryLabel.shadowOffset = CGSizeMake(0.0f, 0.5f);
     secondaryLabel.shadowColor = [UIColor AGNDropShadow];
     secondaryLabel.backgroundColor = [UIColor clearColor];
     self.rightLabel = secondaryLabel;
     [self addSubview:secondaryLabel];
     
     UIButton *mainButton = [UIButton buttonWithType:UIButtonTypeCustom];
     [mainButton setTranslatesAutoresizingMaskIntoConstraints:NO];
     [mainButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateNormal];
     [mainButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey-hi"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateHighlighted];
     [mainButton setContentEdgeInsets:UIEdgeInsetsMake(0, 22, 0, 22)];
     self.button = mainButton;
     [self addSubview:mainButton];
     mainButton.alpha=0.0;
     
     NSDictionary *views = NSDictionaryOfVariableBindings(mainLabel, secondaryLabel, mainButton, imageView, self);
     
     [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[imageView]|" options:0 metrics:nil views:views]];
     [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[imageView]" options:0 metrics:nil views:views]];
     [self addConstraint:[NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self attribute:NSLayoutAttributeHeight multiplier:1.0 constant:1.0]];
     
     [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[mainLabel]-[secondaryLabel]-22-|" options:0 metrics:nil views:views]];
     [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[mainLabel]|" options:0 metrics:nil views:views]];
     [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[secondaryLabel]|" options:0 metrics:nil views:views]];
     
     self.buttonWidthConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"[mainButton]|" options:0 metrics:nil views:views];
     [self addConstraints:self.buttonWidthConstraints];
     [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[mainButton]" options:0 metrics:nil views:views]];
     [self addConstraint:[NSLayoutConstraint constraintWithItem:mainButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self attribute:NSLayoutAttributeHeight multiplier:1.0 constant:1.0]];
}

// support for the Edit Button in Draft Calls (Call History)
- (void) addSecondaryButton:(UIButton *)newButton withTitle:(NSString *)title{
    [newButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [newButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateNormal];
    [newButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey-hi"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateHighlighted];
    [newButton setContentEdgeInsets:UIEdgeInsetsMake(0, 22, 0, 22)];
    self.secondaryButton = newButton;
    [self addSubview:self.secondaryButton];
    
    NSDictionary *views =    @{
        @"mainButton" : self.button ,
        @"secondaryButton" : newButton
        };
    
    for(NSLayoutConstraint * constraint in self.buttonWidthConstraints){
        [self removeConstraint:constraint];
    }
    
    self.buttonWidthConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"[secondaryButton][mainButton]|" options:0 metrics:nil views:views];
    [self addConstraints:self.buttonWidthConstraints];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[secondaryButton]" options:0 metrics:nil views:views]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:secondaryButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self attribute:NSLayoutAttributeHeight multiplier:1.0 constant:1.0]];

    [self setSecondaryButtonLabelText:title];
}

// If the Edit Button is displayed but too few calls to display the Show More/Show Less button, then the Edit button needs to move over
-(void)moveSecondaryToEdge{
    if(!self.secondaryButton)
        return;
    NSDictionary *views =    @{
    @"secondaryButton" : self.secondaryButton
    };
    for(NSLayoutConstraint * constraint in self.buttonWidthConstraints){
        [self removeConstraint:constraint];
    }
    [self.button removeFromSuperview];
    [self.button setHidden:YES];
    self.buttonWidthConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"[secondaryButton]|" options:0 metrics:nil views:views];
    [self addConstraints:self.buttonWidthConstraints];
    [self setNeedsDisplay    ];
}



- (void)layoutSubviews {
    [super layoutSubviews];
    if ([self.button attributedTitleForState:UIControlStateNormal] == nil) {
        self.button.hidden = YES;
    }
}

- (void)setButtonLabelText:(NSString *)text {
    if (text.length == 0) {
        return;
    }
        NSAttributedString *buttonString = [[NSAttributedString alloc] initWithString:text attributes:[UIButton agnAttributedStringAttributes]];
    [self.button setAttributedTitle:buttonString forState:UIControlStateNormal];
    self.button.hidden = NO;
    self.button.alpha = 1.0;
}

- (void)setSecondaryButtonLabelText:(NSString *)text {
    if (text.length == 0) {
        return;
    }
    NSAttributedString *buttonString = [[NSAttributedString alloc] initWithString:text attributes:[UIButton agnAttributedStringAttributes]];
    [self.secondaryButton setAttributedTitle:buttonString forState:UIControlStateNormal];
    self.secondaryButton.hidden = NO;
}
@end
