//
//  AGNDataManager.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/14/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  SINGLE CLASS FOR QUERIES USED THROUGHOUT THE APPLICATION

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNDataManager.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNContactRole.h"
#import "AGNTransientStateWrapper.h"

#define MAX_DAYS_SCHEDULE_VIEW 45

@interface AGNDataManager()

@property (strong,nonatomic) NSDictionary *stateNameLookup;

@end

@implementation AGNDataManager


@synthesize managedObjectContext=_managedObjectContext;
@synthesize stateNameLookup=_stateNameLookup;

//------------------------------------------------------------------------------
// MARK: - Get manager
//------------------------------------------------------------------------------

-(id)initWithManagedObjectContext:(NSManagedObjectContext *)context
{
    if ((self = [super init]))
    {
        self.managedObjectContext = context;
    }
    return self;
}

+(AGNDataManager *)defaultInstance{
    AGNAppDelegate *appDelegate = (AGNAppDelegate *)[[UIApplication sharedApplication]delegate];
    return appDelegate.dataManager;
}


//------------------------------------------------------------------------------
// MARK: - State long name lookup
//------------------------------------------------------------------------------

-(NSDictionary *)stateNameLookup{
    
    if(!_stateNameLookup){
        NSMutableDictionary *values = [[NSMutableDictionary alloc]init];
        NSString *file = [[NSBundle mainBundle]  pathForResource:@"us-states" ofType:@"json"];
        NSData * data =  [NSData dataWithContentsOfFile:file];
        NSError * error = nil;
        NSArray * json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        for(NSDictionary *dict in json){
            NSString * abbreviation = dict[@"abbr"];
            NSString * fullName = dict [@"name"];
            values[abbreviation]=fullName;
        }
        _stateNameLookup = values;
    }
    return _stateNameLookup;
}


//------------------------------------------------------------------------------
// MARK: - Account Queries
//------------------------------------------------------------------------------

-(NSArray *)getContactRoles{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNContactRole" inManagedObjectContext:context];
    NSSortDescriptor *roleName = [[NSSortDescriptor alloc]
                                  initWithKey:@"roleName" ascending:YES selector:@selector(caseInsensitiveCompare:)];

    [request setEntity:entity];
    [request setSortDescriptors:[NSArray arrayWithObject:roleName]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching contact roles : %@ ",error);
    return objects;
}

// default sort - last name ascending

-(NSArray *) getAllHCPs{
    return [self getAllHCPsWithSortDescriptors:[self defaultHCPSortDescriptors]];
}

// Fetch records with salesForceIds only
-(NSArray *) getAllRecordsOfEntity:(NSString *)entityName withProperties:(NSArray *)properties{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    [request setEntity:entity];
    [request setPropertiesToFetch:properties];
    [request setResultType:NSDictionaryResultType];

    NSError *error = nil;
    NSArray *objects =[context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching AGNAccount Ids %@",error);
    if(objects && [objects count]>0)
        return objects;
    return nil;
}

// Sort descriptors is an array of NSSortDescriptor
// example :   NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
//                                                initWithKey:@"lastName" ascending:YES];

-(NSArray *) getAllHCPsWithSortDescriptors:(NSArray *)sortDescriptors{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNAccount" inManagedObjectContext:context];
    [request setEntity:entity];
    [request setSortDescriptors:sortDescriptors];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all HCPs : %@ ",error);
    return objects;

}

-(AGNAccount *) getHCPForId:(NSString *)salesForceId{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNAccount" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"salesForceId = %@", salesForceId];
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching AGNAccount for salesForceId %@ %@",salesForceId,error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;
}

//  Currently doing a case insensitive search for first name, last name, prinary specialty, city, zip
//  Currently relying on caller to include wildcard tokens in the filterString - e.g filterString = @"*jo*"

-(NSArray *) getHCPSForFilterString:(NSString *)filterString withSortDescriptors:(NSArray *)sortDescriptors {
    NSString *wildCardFilterString = [NSString stringWithFormat:@"*%@*", filterString];
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNAccount" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *firstNamePredicate = [NSPredicate predicateWithFormat:@"firstName like[c] %@ ",  wildCardFilterString];
    NSPredicate *lastNamePredicate = [NSPredicate predicateWithFormat:@"lastName like[c] %@ ",  wildCardFilterString];
    NSPredicate *specialtyPredicate = [NSPredicate predicateWithFormat:@"primarySpecialty like[c] %@ ",  wildCardFilterString];
    NSPredicate *cityPredicate = [NSPredicate predicateWithFormat:@"ANY addresses.city like[c] %@", wildCardFilterString];
    NSPredicate *zipPredicate = [NSPredicate predicateWithFormat:@"ANY addresses.zip like[c] %@", wildCardFilterString];
    NSPredicate *line1Predicate = [NSPredicate predicateWithFormat:@"ANY addresses.line1 like[c] %@", wildCardFilterString];
//    NSPredicate *line2Predicate = [NSPredicate predicateWithFormat:@"ANY addresses.line2 like[c] %@", wildCardFilterString];
//    NSPredicate *line3Predicate = [NSPredicate predicateWithFormat:@"ANY addresses.line3 like[c] %@", wildCardFilterString];

    [request setPredicate:[NSCompoundPredicate orPredicateWithSubpredicates:@[firstNamePredicate,lastNamePredicate,specialtyPredicate,cityPredicate,zipPredicate,line1Predicate]]];
    [request setSortDescriptors:sortDescriptors];

    NSError *error = nil;
    NSDate * start = [NSDate date];
    NSArray *objects = [context executeFetchRequest:request error:&error];
    NSDate * end = [NSDate date];

    NSTimeInterval t = [end timeIntervalSinceDate:start];
    log4Debug (@"elapsed time %f",t);

    if(error)
        log4Error(@"Error fetching HCPs matching %@ - %@",filterString,error);
    return objects;
}

-(NSArray *) getHCPSWithNameMatching:(NSString *)filterString withSortDescriptors:(NSArray *)sortDescriptors {
    NSString *wildCardFilterString = [NSString stringWithFormat:@"*%@*", filterString];
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNAccount" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *firstNamePredicate = [NSPredicate predicateWithFormat:@"firstName like[c] %@ ",  wildCardFilterString];
    NSPredicate *lastNamePredicate = [NSPredicate predicateWithFormat:@"lastName like[c] %@ ",  wildCardFilterString];
    
    [request setPredicate:[NSCompoundPredicate orPredicateWithSubpredicates:@[firstNamePredicate,lastNamePredicate]]];
    [request setSortDescriptors:sortDescriptors];
    
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching HCPs matching %@ - %@",filterString,error);
    return objects;
}

-(NSArray *) getHCPSWithNameMatching:(NSString *)filterString {
    return [self getHCPSWithNameMatching:filterString withSortDescriptors:[self defaultHCPSortDescriptors]];
}


// using default sort - last name ascending, first name ascending

-(NSArray *) defaultHCPSortDescriptors{
    
    NSSortDescriptor *lastName = [[NSSortDescriptor alloc]
                                  initWithKey:@"lastName" ascending:YES selector:@selector(caseInsensitiveCompare:)];
    NSSortDescriptor *firstName = [[NSSortDescriptor alloc]
                                   initWithKey:@"firstName" ascending:YES selector:@selector(caseInsensitiveCompare:)];
    return @[lastName,firstName];
}

-(NSArray *) getHCPSForFilterString:(NSString *)filterString {
    return [self getHCPSForFilterString:filterString withSortDescriptors:[self defaultHCPSortDescriptors]];
}





//------------------------------------------------------------------------------
// MARK: - Call Queries
//------------------------------------------------------------------------------

-(NSArray *)callDatesFrom:(NSDate *)fromDate to:(NSDate *)toDate{
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"AGNCall"];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:self.managedObjectContext];
    
    fetchRequest.resultType = NSDictionaryResultType;
    fetchRequest.propertiesToFetch = [NSArray arrayWithObject:[[entity propertiesByName] objectForKey:@"startDate"]];
    fetchRequest.returnsDistinctResults = YES;
    
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    
    
    
    NSPredicate *startDatePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@  AND startDate <= %@",fromDate,toDate ];
    
    fetchRequest.predicate = [NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:notDeletedPredicate,startDatePredicate, nil]];
    
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    if(error)
        log4Error(@"Error fetching first call for today %@", error);
    return objects;
}

-(NSArray *) getClosedCallDatesForRep:(AGNSalesRep *)salesRep{
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@",[NSNumber numberWithBool:YES]];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,closedPredicate,notDeletedPredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
 
    request.resultType = NSDictionaryResultType;
    request.propertiesToFetch = [NSArray arrayWithObject:[[entity propertiesByName] objectForKey:@"startDate"]];
    request.returnsDistinctResults = YES;
    
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching closed calls for rep %@ - %@",salesRep, error);
    return objects;
    
}

- (NSArray *)submittedFormDatesForRep:(AGNSalesRep *)salesRep {
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];
    
    NSFetchRequest * request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNRequestForm" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate]]];
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    request.resultType = NSDictionaryResultType;
    request.propertiesToFetch = [NSArray arrayWithObject:[[entity propertiesByName] objectForKey:@"startDate"]];
    request.returnsDistinctResults = YES;
    
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching submited form dates for rep %@ - %@",salesRep, error);
    return objects;
}

- (NSArray *)submittedMCDDatesForRep:(AGNSalesRep *)salesRep {
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];

    NSFetchRequest * request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNMarketingDisbursement" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate]]];

    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];

    request.resultType = NSDictionaryResultType;
    request.propertiesToFetch = [NSArray arrayWithObject:[[entity propertiesByName] objectForKey:@"startDate"]];
    request.returnsDistinctResults = YES;

    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching submited MCD dates for rep %@ - %@",salesRep, error);
    return objects;
}


-(NSArray *)calendarEntriesFrom:(NSDate *)fromDate to:(NSDate *)toDate{
    
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"AGNHCPActivity"];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *salesRepPreciate = [NSPredicate predicateWithFormat:@"salesForceRepId = %@", [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId];

    fromDate = [fromDate laterDate:[self earliestScheduleDay]];

    NSPredicate *startDatePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@  AND startDate <= %@",fromDate,toDate ];
    [fetchRequest setIncludesSubentities:YES];
    fetchRequest.predicate = [NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:notDeletedPredicate,startDatePredicate,salesRepPreciate, nil]];

    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    if(error)
        log4Error(@"Error fetching first call for today %@", error);
    return objects;
}

-(NSArray *)callsFrom:(NSDate *)fromDate to:(NSDate *)toDate{
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"AGNCall"];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *salesRepPreciate = [NSPredicate predicateWithFormat:@"salesForceRepId = %@", [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId];
    
    NSPredicate *startDatePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@  AND startDate <= %@",fromDate,toDate ];
    
    fetchRequest.predicate = [NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:notDeletedPredicate,startDatePredicate,salesRepPreciate, nil]];
    
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    if(error)
        log4Error(@"Error fetching first call for today %@", error);
    return objects;
}

-(NSArray *)sortDescriptorsForCalls{
    // make sure calls always in same order
    NSSortDescriptor *sortDescriptorDate = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    NSSortDescriptor *sortDescriptorGUID = [[NSSortDescriptor alloc]
                                        initWithKey:@"salesForceId" ascending:YES];
    return [NSArray arrayWithObjects:sortDescriptorDate,sortDescriptorGUID, nil];
}

- (AGNScheduleEntry *)firstScheduleEntryForDate:(NSDate *)date{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNScheduleEntry" inManagedObjectContext:context];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *salesRepPreciate = [NSPredicate predicateWithFormat:@"salesForceRepId = %@", [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId];
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDateComponents * components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit
                             fromDate:date];
    
    NSDate *startDate = [calendar dateFromComponents:components];

    
    NSPredicate *startDatePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@",startDate];
    [fetchRequest setEntity:entity];
    [fetchRequest setSortDescriptors:[self sortDescriptorsForCalls]];
    
	[fetchRequest setFetchBatchSize:1];
    [fetchRequest setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:startDatePredicate,notDeletedPredicate,salesRepPreciate, nil]]];
    
    
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    if(error)
        log4Error(@"Error fetching first call for today %@", error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;
}

-(NSDate *)earliestScheduleDay{
    NSDateComponents *subtractDays = [[NSDateComponents alloc]init];
    [subtractDays setDay:(-MAX_DAYS_SCHEDULE_VIEW)];
    NSDate *now = [NSDate date];
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDate *dateLimit = [calendar dateByAddingComponents:subtractDays toDate:now options:0];
    return dateLimit;
}

- (NSFetchedResultsController *)scheduleViewFetchedResultsController:(BOOL)callsOnly {
    
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    
    NSDate *dateLimit = [self earliestScheduleDay];

    NSString * entityName = callsOnly?@"AGNCall":@"AGNScheduleEntry";
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    NSPredicate *salesRepPreciate = [NSPredicate predicateWithFormat:@"salesForceRepId = %@", loggedInUser.salesForceId];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *datePreciate = [NSPredicate predicateWithFormat:@"startDate >= %@ ",dateLimit];
    
    [fetchRequest setEntity:entity];
    [fetchRequest setIncludesSubentities:YES];
    [fetchRequest setSortDescriptors:[self sortDescriptorsForCalls]];
    
	// Set the batch size to a suitable number.
	[fetchRequest setFetchBatchSize:20];
	
    [fetchRequest setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:notDeletedPredicate,salesRepPreciate,datePreciate, nil]]];
    
    // Use the sectionIdentifier property to group into sections.
	NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:context sectionNameKeyPath:@"startDay" cacheName:@"Root"];

  
	return aFetchedResultsController;
    
}

-(NSArray *) getTOT{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNTimeOffTerritory" inManagedObjectContext:context];
    [request setEntity:entity];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all calls %@",error);
    return objects;
}

-(NSArray *) getScheduleEntries{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;

    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNScheduleEntry" inManagedObjectContext:context];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *salesRepPreciate = [NSPredicate predicateWithFormat:@"salesForceRepId = %@", loggedInUser.salesForceId];

    [request setEntity:entity];
    [request setIncludesSubentities:YES];
    [request setSortDescriptors:[self sortDescriptorsForCalls]];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:notDeletedPredicate,salesRepPreciate, nil]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all calls %@",error);
    return objects;
}


-(NSFetchedResultsController *) getScheduleEntriesController{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    [fetchRequest setIncludesSubentities:YES];
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;

    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNScheduleEntry" inManagedObjectContext:context];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *salesRepPreciate = [NSPredicate predicateWithFormat:@"salesForceRepId = %@", loggedInUser.salesForceId];

    
    [fetchRequest setEntity:entity];
    [fetchRequest setSortDescriptors:[self sortDescriptorsForCalls]];
    
	// Set the batch size to a suitable number.
	[fetchRequest setFetchBatchSize:20];
	
    [fetchRequest setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:notDeletedPredicate,salesRepPreciate, nil]]];
    
    // Use the sectionIdentifier property to group into sections.
	NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:context sectionNameKeyPath:@"startDay" cacheName:@"Root"];
    
    
	return aFetchedResultsController;
}

-(NSArray *) getAllCalls{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:context];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];

    [request setEntity:entity];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    [request setPredicate:notDeletedPredicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all calls %@",error);
    return objects;
}

-(NSArray *) getCallsForRep:(AGNSalesRep *) salesRep{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];

    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:context];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[predicate,notDeletedPredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all calls for rep %@ - %@",salesRep,error);
    return objects;
}


-(NSArray *) getClosedCallsForRep:(AGNSalesRep *)salesRep{
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@",[NSNumber numberWithBool:YES]];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];

    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,closedPredicate,notDeletedPredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"endDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching closed calls for rep %@ - %@",salesRep, error);
    return objects;

}

// calls that are not marked complete yet

-(NSArray *) getSavedDraftsForRep:(AGNSalesRep *)salesRep{
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];
//    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"NOT closed == %@ ",[NSNumber numberWithBool:YES]];
//    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"NOT toBeDeletedFlag == %@ ",[NSNumber numberWithBool:YES]];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@ OR closed = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,closedPredicate,notDeletedPredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching saved drafts for rep %@ - %@",salesRep, error);
    return objects;
}

//  idea is to get all calls for the day independent of time, will probably have timezone issues
//  to work out once we see what the data coming in will look like

-(NSArray *) getAllCallsForDateComponents:(NSDateComponents *)dateComponents andRep:(AGNSalesRep *)salesRep{
    
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", salesRep];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];

    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDate *startDate = [calendar dateFromComponents:dateComponents];
    NSDateComponents *addDayComponent = [[NSDateComponents alloc]init];
    [addDayComponent setDay:1];
    NSDate *endDate = [calendar dateByAddingComponents:addDayComponent toDate:startDate options:0];
    NSPredicate *datePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@ and startDate <=%@",
                                  startDate, endDate];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,datePredicate,notDeletedPredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching  calls for date components and rep %@ %@ - %@",dateComponents, salesRep, error);
    return objects;

    
}

//  idea is to get all calls for the day independent of time, will probably have timezone issues
//  to work out once we see what the data coming in will look like

-(NSArray *) getClosedCallsForCurrentRepWithinMonth:(NSDateComponents *)dateComponents{
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", loggedInUser];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@ ",[NSNumber numberWithBool:YES]];
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
//    NSDateComponents *comps = [[NSDateComponents alloc] init];
//    [comps setDay:1];
//    [comps setMonth:month];
//    [comps setYear:year];
    
    NSDate *startDate = [calendar dateFromComponents:dateComponents];

    NSDateComponents *addMonthComponent = [[NSDateComponents alloc]init];
    [addMonthComponent setMonth:1];
    NSDate *endDate = [calendar dateByAddingComponents:addMonthComponent toDate:startDate options:0];
    NSPredicate *datePredicate = [NSPredicate predicateWithFormat:@"endDate >= %@ and endDate <%@",
                                  startDate, endDate];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,datePredicate,notDeletedPredicate,closedPredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"endDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching  calls for date components %@ %@",dateComponents,error);
    return objects;
    
    
}

- (NSArray *)submittedFormsForCurrentRepWithinMonth:(NSDateComponents *)dateComponents {
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", loggedInUser];
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDate *startDate = [calendar dateFromComponents:dateComponents];
    
    NSDateComponents *addMonthComponent = [[NSDateComponents alloc]init];
    [addMonthComponent setMonth:1];
    NSDate *endDate = [calendar dateByAddingComponents:addMonthComponent toDate:startDate options:0];
    NSPredicate *datePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@ and startDate <%@",
                                  startDate, endDate];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNRequestForm" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,datePredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching  calls for date components %@ %@",dateComponents,error);
    return objects;
    
    
}

- (NSArray *)submittedMCDsForCurrentRepWithinMonth:(NSDateComponents *)dateComponents {
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    NSPredicate *salesRepPredicate = [NSPredicate predicateWithFormat:@"salesRep = %@", loggedInUser];

    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDate *startDate = [calendar dateFromComponents:dateComponents];

    NSDateComponents *addMonthComponent = [[NSDateComponents alloc]init];
    [addMonthComponent setMonth:1];
    NSDate *endDate = [calendar dateByAddingComponents:addMonthComponent toDate:startDate options:0];
    NSPredicate *datePredicate = [NSPredicate predicateWithFormat:@"startDate >= %@ and startDate <%@",
                                  startDate, endDate];

    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNMarketingDisbursement" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[salesRepPredicate,datePredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching  calls for date components %@ %@",dateComponents,error);
    return objects;


}

//  calls for HCP not marked closed

-(NSArray *) getPlannedCallsForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser{
    NSPredicate *accountPredicate = [NSPredicate predicateWithFormat:@"account = %@", hcp];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@ OR closed = nil",[NSNumber numberWithBool:NO]];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    if(restrictToCurrentUser){
        NSPredicate *onlyMePredicate = [NSPredicate predicateWithFormat:@"salesRep = %@ ",[AGNAppDelegate sharedDelegate].loggedInSalesRep];
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,notDeletedPredicate,closedPredicate,onlyMePredicate]]];

    }else{
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,notDeletedPredicate,closedPredicate]]];
    }
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all planned calls for hcp %@ - %@",hcp, error);
    return objects;

}

-(NSArray *) getPlannedCallsForHCP:(AGNAccount *)hcp andAddress:(AGNAddress *)address restrictToCurrentUser:(BOOL) restrictToCurrentUser{
    NSPredicate *accountPredicate = [NSPredicate predicateWithFormat:@"account = %@", hcp];
    NSPredicate *addressPredicate = [NSPredicate predicateWithFormat:@"address = %@", address];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@ OR closed = nil",[NSNumber numberWithBool:NO]];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    if(restrictToCurrentUser){
        NSPredicate *onlyMePredicate = [NSPredicate predicateWithFormat:@"salesRep = %@ ",[AGNAppDelegate sharedDelegate].loggedInSalesRep];
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,addressPredicate, notDeletedPredicate,closedPredicate,onlyMePredicate  ]]];
        
    }else{

        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,addressPredicate, notDeletedPredicate,closedPredicate]]];
    }
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all planned calls for hcp %@ - %@",hcp, error);
    return objects;
    
}


-(NSArray *) getClosedCallsForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser{
    NSPredicate *accountPredicate = [NSPredicate predicateWithFormat:@"account = %@", hcp];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@",[NSNumber numberWithBool:YES]];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];

    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    if(restrictToCurrentUser){
        NSPredicate *onlyMePredicate = [NSPredicate predicateWithFormat:@"salesRep = %@ ",[AGNAppDelegate sharedDelegate].loggedInSalesRep];
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,closedPredicate,notDeletedPredicate,onlyMePredicate]]];
    }else{
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,closedPredicate,notDeletedPredicate]]];
    }
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"endDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching closed calls for hcp %@ -  %@",hcp, error);
    return objects;

}


-(NSArray *) getClosedCallsForHCP:(AGNAccount *)hcp andAddress:(AGNAddress *)address restrictToCurrentUser:(BOOL) restrictToCurrentUser{
    NSPredicate *accountPredicate = [NSPredicate predicateWithFormat:@"account = %@", hcp];
    NSPredicate *addressPredicate = [NSPredicate predicateWithFormat:@"address = %@", address];
    NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@",[NSNumber numberWithBool:YES]];
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    if(restrictToCurrentUser){
        NSPredicate *onlyMePredicate = [NSPredicate predicateWithFormat:@"salesRep = %@ ",[AGNAppDelegate sharedDelegate].loggedInSalesRep];
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,addressPredicate, closedPredicate,notDeletedPredicate,onlyMePredicate  ]]];
    }else{
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,addressPredicate, closedPredicate,notDeletedPredicate]]];
    }
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"endDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching closed calls for hcp %@ -  %@",hcp, error);
    return objects;
    
}

-(NSArray *) getFormsForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser{
    NSPredicate *accountPredicate = [NSPredicate predicateWithFormat:@"account = %@", hcp];
   // NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@",[NSNumber numberWithBool:YES]];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNRequestForm" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    if(restrictToCurrentUser){
        NSPredicate *onlyMePredicate = [NSPredicate predicateWithFormat:@"salesRep = %@ ",[AGNAppDelegate sharedDelegate].loggedInSalesRep];
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,onlyMePredicate  ]]];
    }else{
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate]]];
    }
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching closed calls for hcp %@ -  %@",hcp, error);
    return objects;
}


-(NSArray *) getMCDForHCP:(AGNAccount *)hcp restrictToCurrentUser:(BOOL) restrictToCurrentUser{
    NSPredicate *accountPredicate = [NSPredicate predicateWithFormat:@"account = %@", hcp];
    // NSPredicate *closedPredicate = [NSPredicate predicateWithFormat:@"closed = %@",[NSNumber numberWithBool:YES]];

    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNMarketingDisbursement" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    if(restrictToCurrentUser){
        NSPredicate *onlyMePredicate = [NSPredicate predicateWithFormat:@"salesRep = %@ ",[AGNAppDelegate sharedDelegate].loggedInSalesRep];
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate,onlyMePredicate  ]]];
    }else{
        [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[accountPredicate]]];
    }
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching closed calls for hcp %@ -  %@",hcp, error);
    return objects;
}

// private method
-(NSArray *) getCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep andAccount:(AGNAccount *)account andClosedFlag:(NSNumber *)closed{
    NSMutableArray *predicates = [[NSMutableArray alloc]init];
    if(salesRep != nil)
        [predicates addObject:[NSPredicate predicateWithFormat:@"salesRep = %@",salesRep]];
    if(startDate != nil)
        [predicates addObject:[NSPredicate predicateWithFormat:@"startDate >= %@",startDate]];
    if(endDate != nil)
        [predicates addObject:[NSPredicate predicateWithFormat:@"startDate <= %@", endDate]];
    if(account !=nil)
        [predicates addObject:[NSPredicate predicateWithFormat:@"account = %@",account]];

    if(closed !=nil ){
        if([closed boolValue])
            [predicates addObject:[NSPredicate predicateWithFormat:@"closed = %@",closed]];
        else{
            [predicates addObject:[NSPredicate predicateWithFormat:@"closed = %@ OR closed = nil",closed]];
        }
    }
    NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
    [predicates addObject:notDeletedPredicate];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNCall" inManagedObjectContext:[self managedObjectContext]];
    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:predicates]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"startDate" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *objects = [[self managedObjectContext] executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching  calls  -  %@", error);
    return objects;
}

-(NSArray *) getAllCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep{
    return [self getCallsForDateStart:startDate dateEnd:endDate andRep:salesRep andAccount:nil andClosedFlag:nil];
}
-(NSArray *) getClosedCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep{
    return [self getCallsForDateStart:startDate dateEnd:endDate andRep:salesRep andAccount:nil andClosedFlag:[NSNumber numberWithBool:YES]];
}
-(NSArray *) getPlannedCallsForDateStart:(NSDate *)startDate dateEnd:(NSDate *)endDate andRep:(AGNSalesRep *)salesRep{
    return [self getCallsForDateStart:startDate dateEnd:endDate andRep:salesRep andAccount:nil andClosedFlag:[NSNumber numberWithBool:NO]];
}
-(NSArray *) getPlannedCallsForHCP:(AGNAccount *)hcp andRep:(AGNSalesRep *)salesRep{
    return [self getCallsForDateStart:nil dateEnd:nil andRep:salesRep andAccount:hcp andClosedFlag:[NSNumber numberWithBool:NO]];
}

//------------------------------------------------------------------------------
// MARK: - Sales Reps
//------------------------------------------------------------------------------


-(NSArray *)getAllReps{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSalesRep" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:entity];
    NSSortDescriptor *sortDescriptorLastName = [[NSSortDescriptor alloc]
                                        initWithKey:@"lastName" ascending:YES];
    NSSortDescriptor *sortDescriptorFirstName = [[NSSortDescriptor alloc]
                                        initWithKey:@"firstName" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObjects:sortDescriptorLastName,sortDescriptorFirstName, nil]];
    NSError *error = nil;
    NSArray *objects = [self.managedObjectContext executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all reps %@",error);
    return objects;
}

- (NSArray *)getRepsValidForOutboundTransfer {
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSalesRep" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:entity];
    NSString *businessUnit = [AGNAppDelegate sharedDelegate].loggedInSalesRep.businessUnit;
    if (businessUnit) {
        NSPredicate *businessUnitPredicate = [NSPredicate predicateWithFormat:@"businessUnit = %@ ",  businessUnit];
        [request setPredicate:businessUnitPredicate];
        NSSortDescriptor *sortDescriptorLastName = [[NSSortDescriptor alloc]
                                                    initWithKey:@"lastName" ascending:YES];
        NSSortDescriptor *sortDescriptorFirstName = [[NSSortDescriptor alloc]
                                                     initWithKey:@"firstName" ascending:YES];
        [request setSortDescriptors:[NSArray arrayWithObjects:sortDescriptorLastName,sortDescriptorFirstName, nil]];
        NSError *error = nil;
        NSArray *objects = [self.managedObjectContext executeFetchRequest:request error:&error];
        if(error)
            log4Error(@"Error fetching all reps valid for outbound transfer:%@",error);
        return objects;
    };
    return [NSArray array];
}

-(AGNSalesRep *)getRepForId:(NSString *)repId{
    return (AGNSalesRep *)[self undeletedObjectOfType:@"AGNSalesRep" forId:repId];
}

-(NSArray *) getRepsForFilterString:(NSString *)filterString  {
    NSSortDescriptor *sortDescriptorLastName = [[NSSortDescriptor alloc]
                                                initWithKey:@"lastName" ascending:YES];
    NSSortDescriptor *sortDescriptorFirstName = [[NSSortDescriptor alloc]
                                                 initWithKey:@"firstName" ascending:YES];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:sortDescriptorLastName,sortDescriptorFirstName, nil];
    return [self getRepsForFilterString:filterString withSortDescriptors:sortDescriptors];
}


-(NSArray *) getRepsForFilterString:(NSString *)filterString withSortDescriptors:(NSArray *)sortDescriptors {
    NSString *wildCardFilterString = [NSString stringWithFormat:@"*%@*", filterString];
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSalesRep" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *firstNamePredicate = [NSPredicate predicateWithFormat:@"firstName like[c] %@ ",  wildCardFilterString];
    NSPredicate *lastNamePredicate = [NSPredicate predicateWithFormat:@"lastName like[c] %@ ",  wildCardFilterString];
    
    [request setPredicate:[NSCompoundPredicate orPredicateWithSubpredicates:@[firstNamePredicate,lastNamePredicate]]];
    [request setSortDescriptors:sortDescriptors];
    
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching HCPs matching %@ - %@",filterString,error);
    return objects;
}

//------------------------------------------------------------------------------
// MARK: - Details positions
//------------------------------------------------------------------------------



-(NSArray *)getAllDetailPositions{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNDetailPosition" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:entity];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"position" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSError *error = nil;
    NSArray *objects = [self.managedObjectContext executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all detail positions %@",error);
    return objects;

}

// detail positions that are eligible today (effective date <= today, end date >= today)

-(NSArray *)getCurrentDetailPositions{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNDetailPosition" inManagedObjectContext:self.managedObjectContext];
    
    NSDate *today = [NSDate date];
    NSPredicate *effectiveDatePredicate = [NSPredicate predicateWithFormat:@"effectiveDate <= %@", today];
    NSPredicate *endDatePredicate = [NSPredicate predicateWithFormat:@"endDate >= %@", today];

    [request setEntity:entity];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[effectiveDatePredicate,endDatePredicate]]];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"position" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSError *error = nil;
    NSArray *objects = [self.managedObjectContext executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching current detail positions %@",error);
    return objects;
    
}


//------------------------------------------------------------------------------
// MARK: - Inventory
//------------------------------------------------------------------------------

-(AGNSampleInventoryTransaction *)getMonthlyReconciliationDraft {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:entity];
    
        
    NSPredicate *typeReconciliation = [NSPredicate predicateWithFormat:@"transactionType= %@", kInventoryCountType];
    NSPredicate *statusPredicate = [NSPredicate predicateWithFormat:@"status= %@", kOpenStatusType];
    
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[typeReconciliation,statusPredicate]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory transactions %@ ",error);
    if([objects count]>1){
        log4Error(@"Have %d open reconciliations, should only have one",[objects count]);
    }
    if((int)[objects count]>=1)
        return objects[0];
    return nil;
}


- (NSPredicate *)receivedOrCompleteStatusPredicate {
    //    NSPredicate *fromPredicate = [NSPredicate predicateWithFormat:@"from = %@",loggedInUser];
    NSPredicate *receivedStatusPredicate = [NSPredicate predicateWithFormat:@"status= %@", kReceivedStatusType];
    NSPredicate *completeStatusPredicate = [NSPredicate predicateWithFormat:@"status= %@", kCompleteStatusType];
    NSPredicate *statusPredicate = [NSCompoundPredicate orPredicateWithSubpredicates:@[receivedStatusPredicate, completeStatusPredicate]];
    return statusPredicate;
}


-(NSArray *) getOutgoingDraftTransfersAndReturnsForLoggedInUser{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    //AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    // get accepted outbound shipments (returns)
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:context];
    [request setEntity:entity];
    
    NSPredicate *typeReturn = [NSPredicate predicateWithFormat:@"transactionType= %@", kReturnType];
    NSPredicate *typeTransfer = [NSPredicate predicateWithFormat:@"transactionType= %@", kOutboundTransferType];
    NSPredicate *typePredicate = [NSCompoundPredicate orPredicateWithSubpredicates:@[typeReturn,typeTransfer]];
//    NSPredicate *fromPredicate = [NSPredicate predicateWithFormat:@"from = %@",loggedInUser];
    NSPredicate *statusPredicate = [NSPredicate predicateWithFormat:@"status= %@", kOpenStatusType];
    
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[typePredicate, statusPredicate]]];
    [request setSortDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"sfdcCreatedDate" ascending:NO]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory transactions %@ ",error);
    return objects;
 
}



-(NSArray *) getOutgoingSubmittedTransfersAndReturnsForLoggedInUser{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    //AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    // get accepted outbound shipments (returns)
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:context];
    [request setEntity:entity];
    
    NSPredicate *typeReturn = [NSPredicate predicateWithFormat:@"transactionType= %@", kReturnType];
    NSPredicate *typeTransfer = [NSPredicate predicateWithFormat:@"transactionType= %@", kOutboundTransferType];
    NSPredicate *typePredicate = [NSCompoundPredicate orPredicateWithSubpredicates:@[typeReturn,typeTransfer]];
    NSPredicate *statusPredicate = [self receivedOrCompleteStatusPredicate];
    
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[typePredicate, statusPredicate]]];
    [request setSortDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"sfdcCreatedDate" ascending:NO]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory transactions %@ ",error);
    return objects;
}


-(NSArray *) getOutgoingProductForLoggedInUser{
    NSMutableArray *result = [[NSMutableArray alloc]init];
    [result addObjectsFromArray:[self getOutgoingDraftTransfersAndReturnsForLoggedInUser]];
    [result addObjectsFromArray:[self getOutgoingSubmittedTransfersAndReturnsForLoggedInUser]];
    return result;
}

-(NSArray *) getIncomingProductForLoggedInUser{
    NSMutableArray *result = [[NSMutableArray alloc]init];
    [result addObjectsFromArray:[self getOpenIncomingProductForLoggedInUser]];
    [result addObjectsFromArray:[self getAcceptedIncomingProductForLoggedInUser]];
    return result;
}

-(NSArray *) getOpenIncomingProductForLoggedInUser{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    
    // first get upcoming (open) shipments adn transfers
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:context];
    [request setEntity:entity];
    
    NSPredicate *typeShipment = [NSPredicate predicateWithFormat:@"transactionType= %@", kShipmentType];
    NSPredicate *typeTransfer = [NSPredicate predicateWithFormat:@"transactionType= %@", kInboundTransferType];
    NSPredicate *typePredicate = [NSCompoundPredicate orPredicateWithSubpredicates:@[typeShipment,typeTransfer]];

    NSPredicate *statusOpen = [NSPredicate predicateWithFormat:@"status= %@", kOpenStatusType];
    NSPredicate *toPredicate = [NSPredicate predicateWithFormat:@"to = %@",loggedInUser];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[typePredicate,statusOpen,toPredicate]]];
    [request setSortDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"shipmentDate" ascending:NO]]];
    NSError *error = nil;
    NSArray *openShipments = [context executeFetchRequest:request error:&error];
    
    if(error)
        log4Error(@"Error fetching sample inventory transactions %@ ",error);
    return openShipments;
}

-(NSArray *) getAcceptedIncomingProductForLoggedInUser{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    
    // first get upcoming (open) shipments
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:context];
    [request setEntity:entity];
    
    NSPredicate *typeShipment = [NSPredicate predicateWithFormat:@"transactionType= %@", kShipmentType];
    NSPredicate *typeTransfer = [NSPredicate predicateWithFormat:@"transactionType= %@", kInboundTransferType];
    NSPredicate *typePredicate = [NSCompoundPredicate orPredicateWithSubpredicates:@[typeShipment,typeTransfer]];
    NSPredicate *statusPredicate = [self receivedOrCompleteStatusPredicate];
    NSPredicate *toPredicate = [NSPredicate predicateWithFormat:@"to = %@",loggedInUser];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[typePredicate,statusPredicate,toPredicate]]];
    [request setSortDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"actualReceivedDate" ascending:NO]]];
    NSError *error = nil;
    NSArray *shipments = [context executeFetchRequest:request error:&error];
    
    if(error)
        log4Error(@"Error fetching sample inventory transactions %@ ",error);
    return shipments;
}


-(NSArray *)getAllProductSKUs{
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"productCode" ascending:YES];
    return [self getAllObjectsOfType:@"AGNProductSKU" withSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
}

-(AGNProductSKU *) getProductSKUForSku:(NSString *)sku{

    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNProductSKU" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"productCode = %@", sku];
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching product for productCode %@ ",sku,error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;
}

-(AGNProductSKU *) getProductSKUForId:(NSString *)sfdcId{
    return (AGNProductSKU *)[self undeletedObjectOfType:@"AGNProductSKU" forId:sfdcId];
}

-(AGNProductBrand *) getProductBrandForId:(NSString *)sfdcId{
    return (AGNProductBrand *)[self undeletedObjectOfType:@"AGNProductBrand" forId:sfdcId];
}

//TODO: I don't think we need to do this per sales rep - we should only have our own in the database
-(NSArray *)getSampleInventoryLines {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryLine" inManagedObjectContext:context];
    [request setEntity:entity];
    NSMutableArray *sortDescriptors = [[NSMutableArray alloc]initWithCapacity:2];
    [sortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"product.productCode" ascending:YES]];
    [sortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"expiration" ascending:YES]];
    [request setSortDescriptors:sortDescriptors];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory lines - %@", error);
    return objects;
}

-(NSArray *)getSampleInventoryLinesWithSortDescriptors:(NSArray *)sortDescriptors {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryLine" inManagedObjectContext:context];
    [request setEntity:entity];
    [request setSortDescriptors:sortDescriptors];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory lines - %@", error);
    return objects;
}

-(AGNSampleInventoryLine *)getSampleInventoryLineForProductSKU:(AGNProductSKU *)productSKU andLotNumber:(NSString *)lotNumber {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryLine" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *productPredicate = [NSPredicate predicateWithFormat:@"product = %@", productSKU];
    NSPredicate *lotPredicate = [NSPredicate predicateWithFormat:@"lotNumber = %@", lotNumber];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[productPredicate,lotPredicate]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory  - %@", error);
    return [objects lastObject]; //should only be one
}



-(NSArray *) getSampleInventoryTransactionLinesForProduct:(AGNProductSKU *)product {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransactionLine" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product = %@", product];
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory transaction lines for product %@ - %@ ",product,error);
    return objects;
}

-(NSArray *) getAllSampleInventoryTransactions{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:context];
    [request setEntity:entity];
    [request setSortDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"shipmentDate" ascending:YES]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching sample inventory transactions %@ ",error);
    return objects;

}


//------------------------------------------------------------------------------
// MARK: - Zip Code
//------------------------------------------------------------------------------

-(NSArray *)zipCodeRecordForZip:(NSString *)zip andState:(NSString *)state{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNZipCode" inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *zipPredicate = [NSPredicate predicateWithFormat:@"zipCode = %@", zip];
    NSPredicate *statePredicate = [NSPredicate predicateWithFormat:@"usState = %@", state];
    [request setPredicate:[NSCompoundPredicate andPredicateWithSubpredicates:@[zipPredicate,statePredicate]]];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching zip codes  - %@", error);
    return objects;
}

-(NSArray *)getStates{
    NSMutableArray * results = [[NSMutableArray alloc]init];
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNZipCode" inManagedObjectContext:context];
    request.entity = entity;
    request.propertiesToFetch = [NSArray arrayWithObject:[[entity propertiesByName] objectForKey:@"usState"]];
    request.returnsDistinctResults = YES;
    request.resultType = NSDictionaryResultType;
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"usState" ascending:YES];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSError *error = nil;
    NSArray * dictArray =  [context executeFetchRequest:request error:&error];
    NSDictionary *nameMapping = self.stateNameLookup;
    for(NSDictionary * dict in dictArray){
        NSString * abbrev = dict[@"usState"];
        NSString *fullName = nameMapping[abbrev];
        if(!fullName)
            fullName = @"Unknown";
        AGNTransientStateWrapper *state = [[AGNTransientStateWrapper alloc]init];
        state.abbreviation=abbrev;
        state.fullName=fullName;
        [results addObject:state];
    }

    return [results sortedArrayUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"fullName" ascending:YES]]];
}

//------------------------------------------------------------------------------
// MARK: - Create / Update methods
//------------------------------------------------------------------------------

- (AGNCall *) createCall{
    return (AGNCall *) [self createObject:@"AGNCall"];
}

- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
        }
    }
}

// PRIVATE

- (id <AGNModelProtocol> ) createObject:(NSString *)entityName{
    return [NSEntityDescription insertNewObjectForEntityForName:entityName inManagedObjectContext:self.managedObjectContext];
}

//------------------------------------------------------------------------------
// MARK: - Utility Methods
//------------------------------------------------------------------------------

- (NSManagedObject *)undeletedObjectOfType:(NSString *) entityName forId:(NSString *) sfdcId {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *predicate = nil;

    if ([entity propertiesByName][@"toBeDeletedFlag"]) {
        NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
        NSPredicate *idPredicate = [NSPredicate predicateWithFormat:@"salesForceId = %@", sfdcId];
        predicate = [NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:idPredicate,notDeletedPredicate, nil]];
    }else{
        predicate = [NSPredicate predicateWithFormat:@"salesForceId = %@", sfdcId];
    }

    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching %@ ",entityName,error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;
    
}

- (NSManagedObject *)undeletedObjectOfType:(NSString *)entityName forGuid:(NSString *) guid {
    //TODO: put checks in here to make sure we are calling this on an entity that has a guid field
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    [request setEntity:entity];

    NSPredicate *predicate = nil;

    if ([entity propertiesByName][@"toBeDeletedFlag"]) {
        NSPredicate *notDeletedPredicate = [NSPredicate predicateWithFormat:@"toBeDeletedFlag = %@ OR toBeDeletedFlag = nil",[NSNumber numberWithBool:NO]];
        NSPredicate *idPredicate = [NSPredicate predicateWithFormat:@"guid = %@", guid];
        predicate = [NSCompoundPredicate andPredicateWithSubpredicates:[NSArray arrayWithObjects:idPredicate,notDeletedPredicate, nil]];
    }else{
        predicate = [NSPredicate predicateWithFormat:@"guid = %@", guid];
    }

    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching %@ ",entityName,error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;
    
}

- (NSManagedObject *)objectOfType:(NSString *) entityName forId:(NSString *) sfdcId {
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"salesForceId = %@", sfdcId];
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching %@ ",entityName,error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;

}

- (NSManagedObject *)objectOfType:(NSString *)entityName forGuid:(NSString *) guid {
    //TODO: put checks in here to make sure we are calling this on an entity that has a guid field
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"guid = %@", guid];
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching %@ ",entityName,error);
    if(objects && [objects count]>0)
        return objects[0];
    return nil;

}

-(NSArray *) getAllObjectsOfType:(NSString *)entityName withSortDescriptors:(NSArray *)sortDescriptors{
    NSManagedObjectContext* context = [self managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    [request setEntity:entity];
    if (sortDescriptors) {
        [request setSortDescriptors:sortDescriptors];
    }
    NSError *error = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching all %@ objects : %@ ",entityName, error);
    return objects;
    
}


@end
