//
//  AGNShipmentItemCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/14/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNShipmentItemCell.h"
#import "AGNInventoryTransactionLineCell.h"

@implementation AGNShipmentItemCell
@synthesize delegate=_delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setLine:(AGNSampleInventoryTransactionLine *)line {
    _line = line;
  
    self.receivedQuantity.delegate=self;
    
    self.sampleName.text = [NSString stringWithFormat:@"%@ - %@", line.product.productDescription, line.lotNumber];
//    self.sampleName.text = line.productDescription;
    [self setExpirationLabelForLine:line];
    self.lotNumber.text = line.lotNumber;
    self.shippedQuantity.text = line.expectedQuantity?[line.expectedQuantity stringValue]:@"";
    
    if([line.sampleInventoryTransaction isOpen]){
        self.receivedQuantity.text = line.actualQuantity? line.actualQuantity.stringValue:@"";
        self.receivedQtyLabel.hidden=YES;
        self.receivedQuantity.hidden=NO;
    }
    else {
        self.receivedQtyLabel.text = line.actualQuantity? line.actualQuantity.stringValue:@"";
        self.receivedQtyLabel.hidden=NO;
        self.receivedQuantity.hidden=YES;
    }
}

- (void)setExpirationLabelForLine:(AGNSampleInventoryTransactionLine *)line
{
    //only mess with showing the date vs "Expired" if the shipment hasn't been accepted yet
    if (self.accepted) {
        self.expiration.text = line.expirationDate?[line.expirationDate agnFormattedDateString]:@"";
    }
    else {
        //comparing just the day, so that products that expire on today's date don't show as expired
        unsigned int flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
        NSCalendar *calendar = [NSCalendar currentCalendar];
        
        NSDateComponents *expirationDateComponents = [calendar components:flags fromDate:line.expirationDate];
        NSDateComponents *currentDateComponents = [calendar components:flags fromDate:[NSDate date]];
        
        NSDate *expiredDay = [calendar dateFromComponents:expirationDateComponents];
        NSDate *todayDay = [calendar dateFromComponents:currentDateComponents];
        
        self.expiration.text = line.expirationDate?[line.expirationDate agnFormattedDateString]:@"";
        NSComparisonResult result = [expiredDay compare:todayDay];
        if (result == NSOrderedAscending) {
            //expired
            self.expiration.textColor = [UIColor AGNWarny];
        }
        else {
            //not expired yet
            self.expiration.textColor = [UIColor AGNGreyMatter];
        }
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if([textField.text length]>0){
        NSNumberFormatter *nf = [[NSNumberFormatter alloc]init];
        self.line.actualQuantity = [nf numberFromString:textField.text];
        self.receivedQuantity.text = self.line.actualQuantity? self.line.actualQuantity.stringValue:@"";

    }else{
        self.line.actualQuantity = nil;
    }
    [self updateValidationState];
    [self.delegate quantitySelected];
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferCellDidBeginEditing object:textField];
}

- (BOOL)isValid {
    if ([self.line.actualQuantity intValue]<0)
        return NO;
    else
        return YES;
}


- (void)updateValidationState {
    
    if (self.isValid) {
        self.receivedQuantity.backgroundColor = [UIColor whiteColor];
        self.receivedQuantity.textColor = [UIColor blackColor];
    }
    else {
        self.receivedQuantity.backgroundColor = [UIColor AGNWarny];
        self.receivedQuantity.textColor = [UIColor whiteColor];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
