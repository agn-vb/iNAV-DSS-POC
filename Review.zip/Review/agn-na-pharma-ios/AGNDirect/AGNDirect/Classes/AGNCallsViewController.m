//
//  AGNCallsViewController.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  PARENT/CONTAINER VIEW CONTROLLER FOR CALL LANDING PAGE
//  Will display AGNScheduleViewController, AGNHCPFilterViewController, AGNHCPDetailViewController, and AGNCallHistoryViewController
//  according to user selection in its left and right panes.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//

#import "AGNCallsViewController.h"
#import "AGNHCPDetailViewController.h"
#import "AGNCallHistoryViewController.h"
#import "AGNScheduleViewController.h"
#import "AGNHCPFilterViewController.h"
#import "AGNAccount.h"
#import "AGNFormDetailViewController.h"

@interface AGNCallsViewController ()

@property (nonatomic, strong) IBOutlet UIView *leftPane;
@property (nonatomic, strong) IBOutlet UIView *rightPane;
@property (nonatomic, strong) UIViewController *rightViewController;
@property (nonatomic, strong) UIViewController *leftViewController;
@property (weak, nonatomic) IBOutlet UIImageView *centerBar;

@property (nonatomic, strong) AGNScheduleViewController *scheduleVC;
@property (nonatomic, strong) AGNHCPFilterViewController *hcpFilterVC;
@property (nonatomic, strong) AGNHCPDetailViewController *hcpDetailVC;
@property (nonatomic, strong) AGNCallHistoryViewController *callHistoryVC;

@end

@implementation AGNCallsViewController

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.accessibilityIdentifier = @"callsContainer";
	
    self.view.backgroundColor = [UIColor whiteColor];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(showHCPProfileViewController:)
                                                 name:AGNHCPDetailViewSelectedKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(showScheduleViewController:)
                                                 name:AGNHCPFilterCanceledKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(showHCPFilterViewController:)
                                                 name:AGNHCPFilterEnteredKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(showCallHistoryViewController:)
                                                 name:AGNCallHistorySelectedKey
                                               object:nil];
}

- (void)viewWillUnload {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNHCPDetailViewSelectedKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNHCPFilterCanceledKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNHCPFilterEnteredKey object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNCallHistorySelectedKey object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    if (!self.hcpFilterVC) {
        [self showHCPFilterViewController:nil];
        [self showCallHistoryViewController:nil];
    }
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Show Left Pane VCs
//------------------------------------------------------------------------------

- (void)showScheduleViewController:(NSNotification *)notification {
    if (!self.scheduleVC) {
        self.scheduleVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"ScheduleViewController"];
        [self replaceCurrentViewControllerWithViewController:self.scheduleVC  within:self.leftPane];
    }
    BOOL shouldAnimate = [notification.userInfo[@"animate"] boolValue];
    [self transitionToViewController:self.scheduleVC  within:self.leftPane animated:shouldAnimate];
    [self showCallHistoryViewController:notification];
}

- (void)showHCPFilterViewController:(NSNotification *)notification {
    if (!self.hcpFilterVC) {
        self.hcpFilterVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"HCPFilterViewController"];
        [self replaceCurrentViewControllerWithViewController:self.hcpFilterVC  within:self.leftPane];
    }
    [self transitionToViewController:self.hcpFilterVC  within:self.leftPane animated:YES];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Show Right Pane VCs
//------------------------------------------------------------------------------

- (void)showHCPProfileViewController:(NSNotification *)notification {
    
    AGNAccount *acct = notification.userInfo[@"account"];
    if (!self.hcpDetailVC) {
        self.hcpDetailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"HCPDetailViewController"];
        [self replaceCurrentViewControllerWithViewController:self.hcpDetailVC  within:self.rightPane];
    }
    self.hcpDetailVC.account = acct;
    [self transitionToViewController:self.hcpDetailVC  within:self.rightPane animated:YES];
}

- (void)showCallHistoryViewController:(NSNotification *)notification {
    if (!self.callHistoryVC) {
        self.callHistoryVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"CallHistoryViewController"];
        [self replaceCurrentViewControllerWithViewController:self.callHistoryVC  within:self.rightPane];
    }
    BOOL shouldAnimate = [notification.userInfo[@"animate"] boolValue];
    [self transitionToViewController:self.callHistoryVC  within:self.rightPane animated:shouldAnimate];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Manage VC Transitions
//------------------------------------------------------------------------------

- (void)replaceCurrentViewControllerWithViewController:(UIViewController *)newViewController within:(UIView *)aContainerView {
    BOOL isLeftPane = aContainerView == self.leftPane;
    [self addChildViewController:newViewController];
    if (isLeftPane && self.leftViewController) {
        [self.leftViewController.view removeFromSuperview];
    }
    else {
        if (self.rightViewController) {
            [self.rightViewController.view removeFromSuperview];
        }
    }
    [aContainerView addSubview:newViewController.view];
    [newViewController.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self setupBoundsConstraintsForView:newViewController.view within:aContainerView];
    if (isLeftPane) {
        self.leftViewController = newViewController;
    }
    else {
        self.rightViewController = newViewController;
    }
}

- (void)transitionToViewController:(UIViewController *)newVC within:(UIView *)containerView animated:(BOOL)animated {
    BOOL isLeftPane = containerView == self.leftPane;
    UIViewController *currentVC = (containerView == self.leftPane) ? self.leftViewController : self.rightViewController;
    if (currentVC && currentVC != newVC) {
        UIViewAnimationTransition transition = UIViewAnimationOptionTransitionNone;
        if (animated) {
            transition = UIViewAnimationOptionTransitionCrossDissolve;
        }
        [self transitionFromViewController:currentVC
                          toViewController:newVC
                                  duration:0.1 options:transition
                                animations:^{[self setupBoundsConstraintsForView:newVC.view within:containerView];}
                                completion:^(BOOL completion) {
                                    [newVC didMoveToParentViewController:self];
                                    if (isLeftPane) {
                                        self.leftViewController = newVC;
                                    }
                                    else {
                                        self.rightViewController = newVC;
                                    }
                                }];
    }
}

- (void)setupBoundsConstraintsForView:(UIView *)aContentView within: (UIView *)aContainerView {
    //Set up layout constraints
    NSDictionary *viewsDict = @{ @"view" : aContentView };
    NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[view]|" options:0 metrics:nil views:viewsDict];
    [aContainerView addConstraints:constraints];
    constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:viewsDict];
    [aContainerView addConstraints:constraints];
    
    [aContainerView setNeedsUpdateConstraints];
}


//------------------------------------------------------------------------------
// MARK: - Used to restore state
//------------------------------------------------------------------------------
-(void) navigateToCall:(AGNCall *)call {
    [self.callHistoryVC navigateToCall:call];
}

-(void)navigateToForm:(AGNRequestForm *)form{
    AGNFormDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNFormDetailViewController"];
    log4Info(@"Restoring view to form %@",form);

    detailVC.requestForm = form;
    [self.navigationController pushViewController:detailVC animated:YES];

    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}


@end
