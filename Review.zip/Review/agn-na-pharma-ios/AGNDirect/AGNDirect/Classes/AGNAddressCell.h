//
//  AGNAddressCell.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kAddressCellHeight 168.0f
#define kAddressCellLineHeight 24.0f


@interface AGNAddressCell : UITableViewCell

@property (strong, nonatomic) AGNAddress *address;
@property (assign, nonatomic) BOOL isSelected;
@property (strong, nonatomic) IBOutlet UIView *addressView;
@property (strong, nonatomic) IBOutlet UILabel *whichAddressLabel;
@property (strong, nonatomic) IBOutlet UILabel *addressLabel;
@property (strong, nonatomic) IBOutlet UIButton *directionsButton;
@property (strong, nonatomic) IBOutlet UILabel *eligibilityLabel;
@property (strong, nonatomic) IBOutlet UIImageView *eligibilityImageView;
@property (strong, nonatomic) IBOutlet UIView *officeHoursView;
@property (strong, nonatomic) IBOutlet UIView *officeHoursEditView;

@property BOOL editMode;

@end
