//
//  AGNGetSignatureFooterCell.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/30/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNGetSignatureFooterCell.h"

@implementation AGNGetSignatureFooterCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
