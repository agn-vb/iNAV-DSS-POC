//
//  AGNInventoryTransactionSummaryCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNInventoryTransactionSummaryCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel * leftLabel;
@property (strong, nonatomic) IBOutlet UILabel * rightLabel;

@end
