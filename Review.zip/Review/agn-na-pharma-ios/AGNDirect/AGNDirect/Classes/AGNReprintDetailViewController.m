//
//  AGNReprintDetailViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/10/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNReprintDetailViewController.h"
#import "AGNBigBlueButton.h"
#import "AGNSmallBlueButton.h"
#import "AGNTableView.h"
#import "NSManagedObjectContext+RequestFormExtensions.h"
#import "AGNAPC.h"
#import "AGNReprintTableViewCell.h"
#import "AGNMarketingCollateral.h"
#import "AGNMarketingDisbursement.h"
#import "AGNAccountAddressPopover.h"



@interface AGNReprintDetailViewController ()

@property (weak, nonatomic) IBOutlet AGNBigBlueButton *submitButton;
@property (weak, nonatomic) IBOutlet UILabel *hcpInfoLabel;
@property (weak, nonatomic) IBOutlet AGNTableView *tableView;
@property (nonatomic, assign) BOOL readonly;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) NSArray *sortedAPCs;
@property (strong, nonatomic) UIDatePicker *datePicker;
@property (strong, nonatomic) UIPopoverController *datePickerPopover;
@property (strong, nonatomic) NSMutableArray *currentSortDescriptors;

@property (weak, nonatomic) IBOutlet UILabel *jobNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *jobNameImage;
@property (weak, nonatomic) IBOutlet UILabel *apcLabel;
@property (weak, nonatomic) IBOutlet UIImageView *apcImage;
@property (weak, nonatomic) IBOutlet UILabel *productLabel;

@property (weak, nonatomic) IBOutlet UIImageView *productImage;

@property (strong, nonatomic) NSMutableDictionary *quantities;

@property (strong, nonatomic) AGNAccountAddressPopover * accountAddressPopover;

@property (weak, nonatomic) IBOutlet AGNSmallBlueButton *switchHCPButton;

@property (strong, nonatomic) UITextField *activeField;

@property (weak, nonatomic) IBOutlet UIView *footerView;

@property (strong, nonatomic) textFieldActiveCell textFieldActiveBlock;

@property (strong, nonatomic) NSArray * readOnlyContents;

@property (strong, nonatomic) NSDate * earliestDate;
@property (strong, nonatomic) NSDate * latestDate;

@property (strong, nonatomic) UIAlertView *canDismissAlertView;

@property (strong, nonatomic) NSString * salesForceId;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;


@end

@implementation AGNReprintDetailViewController

@synthesize topHeaderViewConstraint;
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.currentSortDescriptors=[[NSMutableArray alloc]initWithCapacity:3];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(quantityChanged)
                                                 name:AGNReprintQuantityChangedNotificationKey object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];
//
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(cellBeganEditing:)
//                                                 name:kAGNNotificationRequestFormBeganEditing object:nil];


    if(!self.marketingDisbursement){
        _readonly = NO;
        log4Info(@"Opened Reprint screen to new object")
    }
    else{
        _readonly = YES;
        self.salesForceId=self.marketingDisbursement.salesForceId;
        log4Info(@"Opened Reprint %@",self.marketingDisbursement.guid);
        self.hcp = self.marketingDisbursement.account;
        self.hcpAddress = self.marketingDisbursement.address;
        self.readOnlyContents = [[self.marketingDisbursement.marketingCollateral allObjects] sortedArrayUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"apcJobName" ascending:YES]]];

    }
    [self configureView];

}

-(void)configureSortGestures{

    UIGestureRecognizer * tapJob = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedJobName:)];
    self.jobNameLabel.userInteractionEnabled=YES;
    [self.jobNameLabel addGestureRecognizer:tapJob];

    UIGestureRecognizer * tapJob2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedJobName:)];
    self.jobNameImage.userInteractionEnabled=YES;
    [self.jobNameImage addGestureRecognizer:tapJob2];

    UIGestureRecognizer * tapAPC = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedAPC:)];
    self.apcLabel.userInteractionEnabled=YES;
    [self.apcLabel addGestureRecognizer:tapAPC];

    UIGestureRecognizer * tapAPC2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedAPC:)];
    self.apcImage.userInteractionEnabled=YES;
    [self.apcImage addGestureRecognizer:tapAPC2];


    UIGestureRecognizer * tapProduct = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedProduct:)];
    self.productLabel.userInteractionEnabled=YES;
    [self.productLabel addGestureRecognizer:tapProduct];

    UIGestureRecognizer * tapProduct2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedProduct:)];
    self.productImage.userInteractionEnabled=YES;
    [self.productImage addGestureRecognizer:tapProduct2];

  }


//------------------------------------------------------------------------------
// MARK: - switch hcp
//------------------------------------------------------------------------------

-(void) showSwitchHCPPopover {
    __weak AGNReprintDetailViewController * _self = self;

    self.accountAddressPopover = [[AGNAccountAddressPopover alloc] initWithTitle:NSLocalizedString(@"Switch HCP", @"Switch HCP Popover Title")
                                                                        onSelect:^(AGNAccount *account, AGNAddress *address) {
                                                                            _self.hcp =(AGNAccount*)[self.managedObjectContext objectWithID:account.objectID];
                                                                            _self.hcpAddress = (AGNAddress*) [self.managedObjectContext objectWithID:address.objectID];
                                                                            log4Info(@"switched HCP to %@ %@",account,address);
                                                                            [_self configureView];

                                                                            [_self.accountAddressPopover dismissPopoverAnimated:YES];
                                                                            _self.accountAddressPopover=nil;
                                                                        }];

    CGRect rect = self.switchHCPButton.frame;
    rect = [self.view convertRect:rect fromView:self.switchHCPButton.superview];
    [self.accountAddressPopover presentPopoverFromRect:rect
                                                inView:self.view
                              permittedArrowDirections:UIPopoverArrowDirectionAny
                                              animated:YES];
}


- (IBAction)switchHCPTapped:(id)sender {
    log4Info(@"Switch HCP Tapped");

    [self showSwitchHCPPopover];
}

-(NSMutableDictionary *)quantities{
    if(!_quantities){
        _quantities = [[NSMutableDictionary alloc]init];
    }
    return _quantities;
}

-(void)quantityChanged{
    [self setButtonEnablement];
}

-(void)setButtonEnablement{

    if(_readonly){
        self.submitButton.hidden=YES;
        self.switchHCPButton.hidden=YES;
    }else{

        if(self.quantities.allValues.count>0){
            self.submitButton.enabled=YES;
            self.submitButton.alpha=1;
        }else{
            self.submitButton.enabled=NO;
            self.submitButton.alpha=.5;
        }
    }
}

- (IBAction)submitButtonPressed:(id)sender {
    self.marketingDisbursement = [self createMarketingDisbursement];
    [self selectDropDate];
}

-(AGNMarketingDisbursement *)createMarketingDisbursement{
    AGNMarketingDisbursement * marketingDisbursement = (AGNMarketingDisbursement *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNMarketingDisbursement" inManagedObjectContext:self.managedObjectContext];
    marketingDisbursement.address =
    (AGNAddress*)[self.managedObjectContext objectWithID:self.hcpAddress.objectID];
    marketingDisbursement.account =
    (AGNAccount*)[self.managedObjectContext objectWithID:self.hcp.objectID];
    marketingDisbursement.salesForceAccountId=marketingDisbursement.account.salesForceId;
    marketingDisbursement.salesForceAddressId=marketingDisbursement.address.salesForceId;
    if ([AGNAppDelegate sharedDelegate].loggedInSalesRep) {
        marketingDisbursement.salesRep =  (AGNSalesRep*)[self.managedObjectContext objectWithID:[AGNAppDelegate sharedDelegate].loggedInSalesRep.objectID];
        marketingDisbursement.salesForceRepId = marketingDisbursement.salesRep.salesForceId;
    }
    marketingDisbursement.mobileCreateTimestamp = [NSDate date];
    marketingDisbursement.mobileLastUpdateTimestamp = [NSDate date];
    marketingDisbursement.startDate = [NSDate date];
    marketingDisbursement.guid = [[NSUUID UUID] UUIDString];
    marketingDisbursement.toBeDeletedFlag = NO;

    NSDate * earliestEffectiveDate = [NSDate date];
    NSDate * latestEndDate = [NSDate date];
    for(AGNAPC * apc in self.sortedAPCs){
        NSNumber * quantity = self.quantities[apc.salesForceId];
        if(quantity){
            [marketingDisbursement addMarketingCollateralObject:[self createMarketingContentForAPC:apc quantity:quantity disbursement:marketingDisbursement]];
            if([apc.effectiveDate compare:earliestEffectiveDate]==NSOrderedAscending){
                earliestEffectiveDate=apc.effectiveDate;
            }
            if([apc.endDate compare:latestEndDate]==NSOrderedDescending){
                latestEndDate  = apc.endDate;
            }
        }
    }
    self.earliestDate=earliestEffectiveDate;
    self.latestDate=latestEndDate;
    log4Info(@"Creating marketing disbursement object %@",marketingDisbursement.guid);
    return marketingDisbursement;
}

-(AGNMarketingCollateral *)createMarketingContentForAPC:(AGNAPC *)apc quantity:(NSNumber * )quantity disbursement:(AGNMarketingDisbursement *)disbursement{
     AGNMarketingCollateral * marketingContent = (AGNMarketingCollateral *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNMarketingCollateral" inManagedObjectContext:self.managedObjectContext];

    marketingContent.quantity=quantity;
    marketingContent.disbursement=disbursement;
    marketingContent.disbursementRemoteId=disbursement.salesForceId;
    marketingContent.apcCode=apc.apcCode;
    marketingContent.apcRemoteId=apc.salesForceId;
    marketingContent.apcJobName=apc.jobName;
    marketingContent.apcProductName=apc.productName;
    marketingContent.guid = [[NSUUID UUID] UUIDString];
    marketingContent.apcValue = apc.value;
    return marketingContent;
    
}


-(void)configureView{
    if(!_readonly){
        [self configureSortGestures];
    }
    [self configureHCPLabel];
    [self setButtonEnablement];
    [self initSort];
//    [self loadData];
}

-(void)configureHCPLabel{
    self.hcpInfoLabel.attributedText = [self attrStringHCPLabel];
}

-(NSAttributedString *)attrStringHCPLabel{

    UIFont *black21 = [UIFont AGNAvenirBlack21];
    UIFont *medium21 = [UIFont AGNAvenirMedium21];
    UIFont *medium16 = [UIFont AGNAvenirMedium16];

    NSDictionary *blackAttributes = @{ NSFontAttributeName : black21, NSForegroundColorAttributeName : [UIColor whiteColor] };
    NSDictionary *med21Attributes = @{ NSFontAttributeName : medium21, NSForegroundColorAttributeName : [UIColor whiteColor] };
    NSDictionary *med16Attributes = @{ NSFontAttributeName : medium16, NSForegroundColorAttributeName : [UIColor whiteColor] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    NSString *name = [NSString stringWithFormat:@"%@ %@ ", [self.hcp.firstName uppercaseString], [self.hcp.lastName uppercaseString]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:name attributes:blackAttributes]];
    NSString *profDesig = [NSString stringWithFormat:@" - %@   ",[self.hcp.professionalDesignation uppercaseString]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profDesig attributes:med21Attributes]];
    if (self.hcpAddress) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[self.hcpAddress singleLineFormattedString] attributes:med16Attributes]];
    }
    return formattedString;
}

-(void) reloadContent{
    [self loadData];

    if(_readonly && self.salesForceId){
        log4Info(@"reloading marketing disbursement");
        AGNMarketingDisbursement *refreshedDisbursement = nil;
        if(self.salesForceId){
            refreshedDisbursement = (AGNMarketingDisbursement *)[[AGNDataManager defaultInstance]undeletedObjectOfType:@"AGNMarketingDisbursement" forId:self.salesForceId];
        }
        if(!refreshedDisbursement){
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
        }
        else{
            self.hcp = self.marketingDisbursement.account;
            self.hcpAddress = self.marketingDisbursement.address;
            self.readOnlyContents = [[self.marketingDisbursement.marketingCollateral allObjects] sortedArrayUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"apcCode" ascending:YES]]];
        }
    }
}


-(void)loadData{
   // NSString * salesTeamId = [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceSalesTeamId;
    self.sortedAPCs = [self.managedObjectContext AGNValidAPCs:self.currentSortDescriptors];
    [self.tableView reloadData];
}


-(NSManagedObjectContext *)managedObjectContext{
    if(!_managedObjectContext){
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
        [_managedObjectContext setPersistentStoreCoordinator:[AGNAppDelegate sharedDelegate].persistentStoreCoordinator];

    }
    return _managedObjectContext;
}



//------------------------------------------------------------------------------
// MARK: - scrolling
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITextFieldDelegate methods
//------------------------------------------------------------------------------

-(void)scrollActiveToMiddle{
    if(self.activeField){
        AGNReprintTableViewCell *cell = (AGNReprintTableViewCell *)[[self.activeField superview] superview];
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];

    AGNReprintTableViewCell *cell = (AGNReprintTableViewCell *)[[self.activeField superview] superview];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];

    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
    }
    else {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
    }


    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardHeight-self.footerView.frame.size.height, 0.0);
    self.tableView.contentInset = contentInsets;
    self.tableView.scrollIndicatorInsets = contentInsets;


    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.tableView.frame;
    aRect.size.height -= (keyboardHeight+self.footerView.frame.size.height);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];

    [UIView animateWithDuration:[animationTime doubleValue] animations:^{
        UIEdgeInsets contentInsets = UIEdgeInsetsZero;
        self.tableView.contentInset = contentInsets;
        self.tableView.scrollIndicatorInsets = contentInsets;
    }];
}


//------------------------------------------------------------------------------
// MARK: - sorting
//------------------------------------------------------------------------------

-(void)initSort{
    if(_readonly){
        self.jobNameImage.hidden=YES;
        self.apcImage.hidden=YES;
        self.productImage.hidden=YES;
    }else{
        [self.currentSortDescriptors removeAllObjects];
        [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"jobName" ascending:YES]];
        [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"apcCode" ascending:YES]];
        [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"productName" ascending:YES]];

        self.jobNameImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
        self.apcImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
        self.productImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];

        [self loadData];
    }
    [self.tableView reloadData];
}

- (int)indexOfDescriptorForKey:(NSString *)key{
    for(int i=0; i < 3; i++ ){
        NSSortDescriptor *desc = self.currentSortDescriptors[i];
        if([desc.key isEqualToString:key])
            return i;
    }
    return -1;
}

- (void) updateToNewSort:(NSString *)sortKey{

    NSSortDescriptor *firstSort = self.currentSortDescriptors[0];

    if([firstSort.key isEqualToString:sortKey]){ // just switch sort order
        BOOL ascending=!firstSort.ascending;
        self.currentSortDescriptors[0]=[NSSortDescriptor sortDescriptorWithKey:sortKey ascending:ascending];

    }else{
        int index = [self indexOfDescriptorForKey:sortKey];
        NSSortDescriptor *existing = self.currentSortDescriptors[index];
        NSSortDescriptor *newDescriptor = [NSSortDescriptor sortDescriptorWithKey:sortKey ascending:!existing.ascending];
        for(int i=index-1; i >=0 ; i--){
            self.currentSortDescriptors[i+1]=self.currentSortDescriptors[i];
        }
        self.currentSortDescriptors[0]=newDescriptor;
    }

    [self updateImages];
    [self loadData];
    [self.tableView reloadData];

}

-(void) updateImages{
    self.jobNameImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.apcImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.productImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];

    for(int i=0; i < 3; i++){
        NSSortDescriptor *sort = self.currentSortDescriptors[i];
        if([sort.key isEqualToString:@"jobName"]){
            if(i==0)
                self.jobNameImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.jobNameImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.jobNameImage setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.jobNameImage setTransform:rotate];
            }
        }
        if([sort.key isEqualToString:@"apcCode"]){
            if(i==0)
                self.apcImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.apcImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.apcImage setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.apcImage setTransform:rotate];
            }
        }
        if([sort.key isEqualToString:@"productName"]){
            if(i==0)
                self.productImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.productImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.productImage setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.productImage setTransform:rotate];
            }

        }
    }


}

- (void)tappedJobName:(UITapGestureRecognizer *)sender {
    log4Info(@"Sort by job name");
    NSString *sortKey = @"jobName";
    [self updateToNewSort:sortKey];
}

- (void)tappedAPC:(UITapGestureRecognizer *)sender {
    log4Info(@"Sort by apc");
    NSString *sortKey = @"apcCode";
    [self updateToNewSort:sortKey];
}

- (void)tappedProduct:(UITapGestureRecognizer *)sender {
    log4Info(@"Sort by product name");
    NSString *sortKey = @"productName";
    [self updateToNewSort:sortKey];
}



//------------------------------------------------------------------------------
// MARK: - Dates
//------------------------------------------------------------------------------



-(void)dateSelected{

    [self.datePickerPopover dismissPopoverAnimated:NO];
    self.marketingDisbursement.startDate = self.datePicker.date;
    [self.marketingDisbursement populateStampedData];
    log4Info(@"Saving marketing disbursement %@",self.marketingDisbursement.guid);

    // we're on a new context, so need to explicitly save
    [self saveContext];

    NSArray *transactions = [self createManageUpdateTransactions];
    [self saveAndEnqueueTransactions:transactions];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];

}

// These are the update statements we'll send to SFDC
- (NSArray *)createManageUpdateTransactions {
    
    NSString *currentJSONRepresentation = [self.marketingDisbursement jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpsertReprint];
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.deleteModelObjectOnRevert = @YES;
    upTxn.guid = self.marketingDisbursement.guid;
    upTxn.modelClassName = @"AGNMarketingDisbursement";
    upTxn.salesForceId = self.marketingDisbursement.salesForceId;
    upTxn.mustSucceed = @YES;
    return @[upTxn];
}

- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
        }
    }
}


- (void)saveAndEnqueueTransactions:(NSArray *)updateTransactions {
    //Appending the transactions saves the context, including data model changes.
    //If it fails, it does a rollback - we need to inform user and refresh the interface.
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:updateTransactions]) {
        //TODO: notify user of fail and refresh interface
        log4Error(@"Failed to save call - either appendTransactions failed or MOC save failed");
    }
}

-(void)cancelDatePopover{
    log4Info(@"Cancel date selection");
    [self.datePickerPopover dismissPopoverAnimated:NO];
}


- (void)selectDropDate {
    if (!self.datePicker) {
        self.datePicker = [[UIDatePicker alloc] init];
        self.datePicker.datePickerMode = UIDatePickerModeDate;
        log4Info(@"Showing date picker with min date %@, max date %@",self.earliestDate,self.latestDate);
        self.datePicker.minimumDate = self.earliestDate;
        self.datePicker.maximumDate = self.latestDate;

        UIViewController *aVC = [[UIViewController alloc] init];
        [aVC.view addSubview:self.datePicker];
        if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
            // Load resources for iOS 6.1 or earlier
            aVC.contentSizeForViewInPopover = self.datePicker.frame.size;

        } else {
            // Load resources for iOS 7 or later
            aVC.preferredContentSize = self.datePicker.frame.size;
        }
        
        aVC.title = @"Disbursement Date";
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:aVC];
        UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(dateSelected)];
        [aVC.navigationItem setRightBarButtonItem:done];
        UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelDatePopover)];
        [aVC.navigationItem setLeftBarButtonItem:cancel];

        navController.modalInPopover = YES;
        navController.modalPresentationStyle = UIModalPresentationCurrentContext;

        self.datePickerPopover = [[UIPopoverController alloc] initWithContentViewController:navController];
        self.datePickerPopover.delegate = self;
    }

    self.datePicker.date = [NSDate date];

    CGRect presentingRect = [self.view convertRect:self.submitButton.frame fromView:self.submitButton.superview];
    log4Info(@"Submit reprint - launching date picker popover");
    [self.datePickerPopover presentPopoverFromRect:presentingRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(_readonly){
        return self.marketingDisbursement.marketingCollateral.count;
    }else{
        return [self.sortedAPCs count]>0?[self.sortedAPCs count]:1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"AGNReprintTableViewCell";

    AGNReprintTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[AGNReprintTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }

    if(_readonly){
        AGNMarketingCollateral * content = self.readOnlyContents[indexPath.row];
        cell.content = content;
        return cell;
    }

    if(self.sortedAPCs.count==0){
        cell.apc=nil;
        return cell;
    }

    AGNAPC *apc = self.sortedAPCs[indexPath.row];

    cell.quantities=self.quantities;
    cell.apc=apc;

    if(self.quantities[apc.salesForceId]){
        NSNumber * quantity = (NSNumber *)self.quantities[apc.salesForceId];
        cell.quantity.text = quantity.stringValue;
    }
    else{
        cell.quantity.text=nil;
    }

    cell.textFieldActiveBlock = ^(UITextField *textField){
        self.activeField = textField;
    };

    return cell;

}

-(BOOL)modificationsMade{
    if(!_readonly && [self.quantities allValues].count>0)
        return YES;
    return NO;
}

//------------------------------------------------------------------------------
// MARK: - Trigger Lock
//------------------------------------------------------------------------------

//  Called by the RootViewController in response to Back Button, other Navigation requests
//  If the call has not been modified, return Yes to allow the view to be dismissed.
//  If the call HAS been modified, prompt the user to save or discard changes.
-(BOOL)canDismiss{

    if(_readonly){
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
        return YES;
    }



    log4Info(@"Prompting user to save reprint ");

    self.canDismissAlertView = [[UIAlertView alloc]init];
    self.canDismissAlertView.delegate = self;
    self.canDismissAlertView.title = NSLocalizedString(@"Changes Made", @"Title on action sheet when dismissing form view controller without saving");
    self.canDismissAlertView.message = NSLocalizedString(@"Warning: If you continue, this form will not be saved.", @"Message on action sheet when dismissing form view controller without saving");
    [self.canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Continue", @"When dismissing form view, indicates changes won't be saved") ];
    [self.canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Cancel", @"When dismissing form view, indicates cancle will be dismissed so editing may continue")];
    [self.canDismissAlertView show ];

    // just refuse to dismiss, and we'll request dismissal in UIActionSheet delegate methods
    return NO;
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{

    if(alertView==self.canDismissAlertView){
        switch(buttonIndex){
            case 0: // discard changes - just pop the view controller
                log4Info(@"Discarding reprint@");
                [self.managedObjectContext rollback];

                [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];

                break;
            default:
                log4Info(@"Cancel - stay on the screen");
                // continue editing - cancel any outstanding navigation request
                [[NSNotificationCenter defaultCenter] postNotificationName:AGNCancelNavigationRequestNotificationKey object:nil];
                break;
        }
    }
}




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.dataSource=self;
    self.tableView.delegate = self;

    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
