//
//  UIApplication+UberFoundationExtensions.h
//  UberFoundation
//
//  Created by Justin Spahr-Summers on 2010-09-16.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * @defgroup UIApplicationExtensions UIApplication+UberFoundationExtensions
 * @ingroup UberFoundation
 * @{
 */

/**
 * Extensions to UIKit's \c UIApplication. These extensions are specifically
 * part of UberFoundation so that all components have easy access to standard
 * application folders and functionality that may not be GUI-related.
 */
@interface UIApplication (UberFoundationExtensions)
/**
 * Returns the path to the application's temporary folder on disk, attempting to
 * create one if it does not exist. Returns \c nil on error.
 */
+ (NSString *)uber_temporaryDirectoryPath;

/**
 * Returns the path to the application's Documents folder on disk, attempting to
 * create one if it does not exist. Returns \c nil on error.
 */
+ (NSString *)uber_documentsDirectoryPath;

/**
 * Returns the path to the application's Caches folder on disk, attempting to
 * create one if it does not exist. Returns \c nil on error.
 */
+ (NSString *)uber_cachesDirectoryPath;

/**
 * Returns the path to the application's Application Support folder on disk,
 * attempting to create one if it does not exist. Returns \c nil on error.
 */
+ (NSString *)uber_applicationSupportDirectoryPath;

/**
 * Returns the string value of the \c CFBundleVersion key from the application's
 * Info.plist file, or \c nil if the key is missing.
 */
+ (NSString *)uber_applicationVersion;
@end

/** @} */
