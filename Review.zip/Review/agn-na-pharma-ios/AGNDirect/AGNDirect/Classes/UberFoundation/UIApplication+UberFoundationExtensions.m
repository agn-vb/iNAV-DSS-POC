//
//  UIApplication+UberFoundationExtensions.m
//  UberFoundation
//
//  Created by Justin Spahr-Summers on 2010-09-16.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import "UIApplication+UberFoundationExtensions.h"

static NSString *uber_findDirectoryInPathsCreatingIfNecessary (NSArray *paths) {
	NSFileManager *manager = [[NSFileManager alloc] init];
	NSString *ret = nil;
	for (NSString *path in paths) {
		BOOL isDirectory;
		// if the file exists...
		if ([manager fileExistsAtPath:path isDirectory:&isDirectory]) {
			// and it's a directory...
			if (isDirectory) {
				ret = path;
				break;
			}
		} else {
			// otherwise, attempt to create the folder
			if ([manager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:NULL]) {
				ret = path;
				break;
			}
		}
	}
	
	[manager release];
	return ret;
}

@implementation UIApplication (UberFoundationExtensions)
+ (NSString *)uber_temporaryDirectoryPath {
	NSString *path = NSTemporaryDirectory();

	NSFileManager *manager = [[NSFileManager alloc] init];
	BOOL isDirectory;

	// if the folder doesn't exist...
	if (![manager fileExistsAtPath:path isDirectory:&isDirectory]) {
		// attempt to create the folder
		if (![manager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:NULL]) {
			// and return nil on error
			path = nil;
		}
	} else {
		// or it does exist, and isn't a directory...
		if (!isDirectory) {
			// return a nil path
			path = nil;
		}
	}

	[manager release];
	return path;
}

+ (NSString *)uber_documentsDirectoryPath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(
		NSDocumentDirectory,
		NSUserDomainMask,
		YES
	);
	
	return uber_findDirectoryInPathsCreatingIfNecessary(paths);
}

+ (NSString *)uber_cachesDirectoryPath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(
		NSCachesDirectory,
		NSUserDomainMask,
		YES
	);
	
	return uber_findDirectoryInPathsCreatingIfNecessary(paths);
}

+ (NSString *)uber_applicationSupportDirectoryPath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(
		NSApplicationSupportDirectory,
		NSUserDomainMask,
		YES
	);
	
	return uber_findDirectoryInPathsCreatingIfNecessary(paths);
}

+ (NSString *)uber_applicationVersion {
	return [[[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey] description];
}

@end
