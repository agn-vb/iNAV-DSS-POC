//
//  AGNFilterCell.m
//  AGNDirect
//
//  Created by Adam McLain on 9/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNFilterCell.h"

@implementation AGNFilterCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self agnSetStyledSelectedBackground];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self agnSetStyledSelectedBackground];
    }
    return self;
}

@end
