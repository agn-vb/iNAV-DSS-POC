//
//  AGNUpdateTransactionValueHolder.m
//  AGNDirect
//
//  Created by Mark Wells on 9/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNUpdateTransactionValueHolder.h"

@implementation AGNUpdateTransactionValueHolder

@synthesize guid;
@synthesize salesForceId;
@synthesize undoJSONRepresentation;
@synthesize currentJSONRepresentation;
@synthesize modelClassName;
@synthesize apexWrapperServiceId;
@synthesize createTimestamp;
@synthesize deleteModelObjectOnRevert;
@synthesize mustSucceed;

- (BOOL)isValid {
    if (!(self.apexWrapperServiceId && self.currentJSONRepresentation)) {
        return NO;
    }
    if (!(self.guid || self.salesForceId)) {
        return NO;
    }
    return YES;
}

@end
