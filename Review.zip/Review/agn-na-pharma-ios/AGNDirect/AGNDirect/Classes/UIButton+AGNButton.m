//
//  UIButton+AGNButton.m
//  AGNDirect
//
//  Created by Adam McLain on 9/8/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "UIButton+AGNButton.h"

@implementation UIButton (AGNButton)

+ (NSDictionary *)agnAttributedStringAttributes {
    UIFont *buttonFont = [UIFont AGNHelveticaNeueBoldFontWithSize:16.0f];
    NSShadow *shadow = [[NSShadow alloc] init];
    shadow.shadowColor = [UIColor blackColor];
    shadow.shadowOffset = CGSizeMake(0.0f, -1.0f);
    return @{ NSFontAttributeName : buttonFont, NSForegroundColorAttributeName : [UIColor whiteColor], NSShadowAttributeName : shadow };
}

@end
