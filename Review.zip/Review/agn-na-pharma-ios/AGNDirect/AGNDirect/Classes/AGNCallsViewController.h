//
//  AGNCallsViewController.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNViewController.h"
#import "AGNRequestForm.h"

static NSString * const AGNHCPDetailViewSelectedKey = @"AGNHCPDetailViewSelectedKey";

@interface AGNCallsViewController : AGNViewController

-(void) navigateToCall:(AGNCall *)call;
-(void) navigateToForm:(AGNRequestForm *)form;

@end
