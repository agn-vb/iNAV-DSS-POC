//
//  AGNAddressCell.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAddressCell.h"
#import "AGNCategoryHeaders.h"
#import "AGNSuppressedAddress.h"
#import <MapKit/MapKit.h>
#import <AddressBook/ABPerson.h>

@implementation AGNAddressCell

@synthesize address = _address;
@synthesize isSelected;
@synthesize addressView;
@synthesize whichAddressLabel;
@synthesize addressLabel;
@synthesize directionsButton;
@synthesize eligibilityLabel;
@synthesize eligibilityImageView;
@synthesize officeHoursView;
@synthesize officeHoursEditView;
@synthesize editMode=_editMode;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self agnSetStyledSelectedBackground];
        self.addressView = [[UIView alloc] init];
        [self.contentView addSubview:self.addressView];
        self.whichAddressLabel = [[UILabel alloc] init];
        self.whichAddressLabel.font = [UIFont AGNAvenirRoman16];
        self.whichAddressLabel.textColor = [UIColor AGNSecondGrayd];
        [self.whichAddressLabel setHighlightedTextColor:[UIColor AGNSilberLining]];
        self.whichAddressLabel.backgroundColor = [UIColor clearColor];
        [self.addressView addSubview:self.whichAddressLabel];
        self.addressLabel = [[UILabel alloc] init];
        self.addressLabel.font = [UIFont AGNAvenirHeavy16];
        self.addressLabel.textColor = [UIColor AGNGreyMatter];
        [self.addressLabel setHighlightedTextColor:[UIColor AGNHighliteWhite]];
        self.addressLabel.backgroundColor = [UIColor clearColor];
        self.addressLabel.numberOfLines = 0;
        [self.addressView addSubview:self.addressLabel];
        self.eligibilityLabel = [[UILabel alloc] init];
        self.eligibilityLabel.font = [UIFont AGNAvenirRoman16];
        self.eligibilityLabel.textColor = [UIColor AGNSecondGrayd];
        [self.eligibilityLabel setHighlightedTextColor:[UIColor AGNSilberLining]];
        self.eligibilityLabel.backgroundColor = [UIColor clearColor];
        self.eligibilityImageView = [[UIImageView alloc] init];
        [self.addressView addSubview:self.eligibilityImageView];
        [self.addressView addSubview:self.eligibilityLabel];
        self.directionsButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.directionsButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateNormal];
        [self.directionsButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey-hi"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateHighlighted];
        [directionsButton.titleLabel setFont:[UIFont AGNHelveticaNeueBold16]];
        [directionsButton setTitleColor:[UIColor AGNHighliteWhite] forState:UIControlStateNormal];
        directionsButton.titleLabel.shadowColor = [UIColor blackColor];
        directionsButton.titleLabel.shadowOffset = CGSizeMake(0,-1);
        [directionsButton setContentEdgeInsets:UIEdgeInsetsMake(0, 5, 0, 5)];
        [self.directionsButton setTitle:[NSLocalizedString(@"DIRECTIONS", @"Directions button title on HCP Address") uppercaseString] forState:UIControlStateNormal];
        self.directionsButton.hidden = YES;
        [self.contentView addSubview:self.directionsButton];
        
        [self.addressView setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.whichAddressLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.addressLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.eligibilityLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.eligibilityImageView setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.directionsButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        NSDictionary *views =
                @{
                @"addressView" : self.addressView ,
                @"whichAddressLabel" : self.whichAddressLabel ,
                @"addressLabel" : self.addressLabel ,
                @"eligibilityLabel" : self.eligibilityLabel ,
                @"eligibilityImageView" : self.eligibilityImageView ,
                @"directionsButton" : self.directionsButton
                };
        UIView *parentView = self.addressView;
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[addressView]-22-|" options:0 metrics:nil views:views]];
        NSString *constraint = [NSString stringWithFormat:@"V:|[addressView(==%f)]", kAddressCellHeight];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:constraint options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[whichAddressLabel]|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-7-[whichAddressLabel]" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[eligibilityImageView(==23)]-4-[eligibilityLabel]|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[eligibilityLabel]-8-|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[eligibilityImageView(==23)]" options:0 metrics:nil views:views]];
        [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.eligibilityLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.eligibilityImageView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0.0]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[addressLabel]|" options:0 metrics:nil views:views]];
        [self.addressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[whichAddressLabel]-(>=3)-[addressLabel]-3-[eligibilityLabel]" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[directionsButton]|" options:0 metrics:nil views:views]];
        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.directionsButton attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.eligibilityImageView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0.0]];

    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];

    self.address = nil;
    self.isSelected = NO;
    self.directionsButton.hidden = YES;
}

- (void)setAddress:(AGNAddress *)address {
    _address = address;
//    NSString *constraint = [NSString stringWithFormat:@"V:[addressView(==%f)]", kAddressCellHeight - ([address numberOfLinesMissingInMultiLineFormattedString] * kAddressCellLineHeight)];
    [[self constraints] enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL *stop) {
        NSLayoutConstraint *c = (NSLayoutConstraint *)obj;
        if (c.firstAttribute==NSLayoutAttributeHeight && c.firstItem==self.addressView && c.relation==NSLayoutRelationEqual) {
            [self removeConstraint:c];
            *stop = YES;
        }
    }];
    self.addressLabel.text = address.multiLineFormattedStringWithPhone;
    self.eligibilityLabel.text = address.canSample ? @"Eligible for Sampling" : @"Ineligible for Sampling";
    self.eligibilityImageView.image = address.canSample ? [UIImage imageNamed:@"thumb_up"] : [UIImage imageNamed:@"thumb_dn"];
    [self updateAddressLabel];
    [self updateButtonState];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    if(self.editMode){
        self.directionsButton.hidden=YES;
    }else{
        self.directionsButton.hidden = selected ? NO : YES;
    }
    if(directionsButton.highlighted){
        directionsButton.highlighted=NO;
    }
}

-(void)updateAddressLabel{
    NSString * label = self.address.primary.boolValue ? [NSLocalizedString(@"Primary Address", @"Primary address label on the HCP Profile") uppercaseString] : [NSLocalizedString(@"Secondary Address", @"Secondary address label on the HCP Profile") uppercaseString];
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)&&self.address.addressType) {
        self.whichAddressLabel.text = [[NSString stringWithFormat:@"%@ (%@)",label,self.address.addressType]uppercaseString];
    }
    else{
        self.whichAddressLabel.text = label;
    }
}

-(void)updateButtonState{
    if(self.editMode) {
        self.directionsButton.hidden=YES;
    }
    else{
        [self.directionsButton setTitle:[NSLocalizedString(@"DIRECTIONS", @"Directions button title on HCP Address") uppercaseString] forState:UIControlStateNormal];
        [self.directionsButton removeTarget:nil
                                     action:NULL
                           forControlEvents:UIControlEventAllEvents];
        [self.directionsButton addTarget:self action:@selector(launchMaps) forControlEvents:UIControlEventTouchUpInside];
    }
}

-(void)launchMaps{
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    NSMutableDictionary *addressDictionary = [[NSMutableDictionary alloc]init];
    addressDictionary[(NSString *)kABPersonAddressStreetKey]=[self.address singleLineStreetString];
    addressDictionary[(NSString *)kABPersonAddressCityKey]=self.address.city;
    addressDictionary[(NSString *)kABPersonAddressStateKey]=self.address.usState;
    addressDictionary[(NSString *)kABPersonAddressZIPKey]=self.address.zip;
    addressDictionary[(NSString *)kABPersonAddressCountryCodeKey]=@"US";
    
    [geocoder geocodeAddressString:[self.address singleLineFormattedString]
                 completionHandler:^(NSArray *placemarks, NSError *error) {
                     
                     if (error) {
                         UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"No results." message:@"Unable to locate address." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                         [alertView show];
                         self.directionsButton.highlighted=NO;
                         log4Warn(@"Unable to find maps data for address %@",self.address);
                         return;
                     }
                     
                     if(placemarks && placemarks.count > 0)
                     {
                         CLPlacemark *placemark = placemarks[0];
                         CLLocation *location = placemark.location;
                         CLLocationCoordinate2D coords = location.coordinate;
                         
                         log4Trace(@"Latitude = %f, Longitude = %f",
                               coords.latitude, coords.longitude);
                         MKPlacemark *place = [[MKPlacemark alloc]
                                     initWithCoordinate:coords addressDictionary:addressDictionary];
                         MKMapItem *destination = [[MKMapItem alloc]initWithPlacemark:place];
                         log4Info(@"Launching maps app to address %@",self.address);

                         [destination openInMapsWithLaunchOptions:@{MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving}];
                     }
                 }
     ];

}

- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated {
    [super setHighlighted:highlighted animated:animated];
    self.directionsButton.highlighted = NO;
}



@end
