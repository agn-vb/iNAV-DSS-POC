//
//  AGNHCPContactEditViewController.m
//  AGNDirect
//
//  Created by Adam McLain on 10/7/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

////////////////////////////////////////////////////////////////////

// This is the primary view for editing HCPs.  It is displayed when Edit is tapped from the HCP profile view.
// It will launch the views to add Contacts and Addresses.

////////////////////////////////////////////////////////////////////


#import "AGNHCPContactEditViewController.h"
#import "AGNTableView.h"
#import "AGNCategoryHeaders.h"
#import "AGNTableViewHeader.h"
#import "AGNTextFieldCell.h"
#import "AGNEditAddressCell.h"
#import "AGNSuppressedAddress.h"
#import "AGNAddEditContactViewController.h"
#import "AGNRootViewController.h"
#import "AGNHourSelectionCell.h"
#import "AGNCategoryHeaders.h"
#import "AGNAddAddressViewController.h"
#import "NSString+AGNString.h"
#import "UINavigationController+AGNKeyboardDismiss.h"
#import "UITextField+NSIndexPath.h"
#import "UISwitch+NSIndexPath.h"

@interface AGNHCPContactEditViewController()
@property (nonatomic, strong, readwrite) AGNTableView *tableView;
@property (nonatomic, strong) NSString *email1;
@property (nonatomic, strong) NSString *email2;
@property (nonatomic, strong) NSString *email3;
@property (nonatomic, strong) NSString *phone;
@property (nonatomic, strong) NSString *mobile;
@property (nonatomic, strong) NSString *fax;
@property (nonatomic, strong) UITextField *lastActiveTextField;

@property (nonatomic, assign) BOOL editingEmail;
@property (nonatomic, strong) NSArray *addresses;
@property (nonatomic, strong) NSArray *contacts;
@property (nonatomic, assign) BOOL hasEmailOrPhoneChanges; //indicates whether editing has been done to the account emails or phone numbers

// properties for hour slider
@property (strong, nonatomic) NSDate *startTime;
@property (strong, nonatomic) NSDate *endTime;
@property (assign, nonatomic) float segmentLength;

@property (strong, nonatomic) NSMutableDictionary *addressMap;

@end

@implementation AGNHCPContactEditViewController

@synthesize addressMap=_addressMap;

enum EditSections {
    PhoneSection = 0,
    EmailSection,
    ContactSection,
    AddressSection,
    TotalSections
};

const int PhoneRow=0;
const int MobileRow=1;
const int FaxRow=2;


-(void)viewDidLoad{
    AGNTableView *table = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    table.tableFooterView = [[UIView alloc] init];
    self.view = table;
    self.title = NSLocalizedString(@"EDIT CONTACT", @"Title for HCP Edit popover");
    table.delegate = self;
    table.dataSource = self;
    self.tableView = table;

    UIImage *normal = [[UIImage imageNamed:@"btn-smblue"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 4.0f, 2.0f)];
    UIImage *highlighted = [[UIImage imageNamed:@"btn-smblue-hi"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 3.0f, 2.0f)];

    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"DONE" style:UIBarButtonItemStyleBordered target:self action:@selector(done:)];
    [done setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [done setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];

    UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithTitle:@"CANCEL" style:UIBarButtonItemStyleBordered target:self action:@selector(cancel:)];
    [cancel setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [cancel setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];

    [self.navigationItem setLeftBarButtonItem:cancel];
    [self.navigationItem setRightBarButtonItem:done];


}


-(NSMutableDictionary *)addressMap{
    if(!_addressMap)
        _addressMap = [[NSMutableDictionary alloc]init];
    return _addressMap;
}

- (void)setAccount:(AGNAccount *)account {
    if (account != _account) {
        _account = account;

        self.email1 = account.email1;
        self.email2 = account.email2;
        self.email3 = account.email3;
        self.phone = account.phone;
        self.mobile = account.mobilePhone;
        self.fax = account.fax;
        
        self.addresses =  [[account.addresses allObjects] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"primary" ascending:NO]]];

        self.contacts = [[[account liveContacts] allObjects] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"firstName" ascending:YES]]];

        [self.account setUndoRepresentation];
        
    }
    log4Info(@"Opening edit screen for %@",[self.account description]);
} 

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];


    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];


    self.contacts   =  [[[self.account liveContacts] allObjects] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"firstName" ascending:YES]]];
    self.addresses =  [[self.account.addresses allObjects] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"primary" ascending:NO]]];

    
    NSUInteger startHour = 7;
    NSUInteger endHour = 19;
    NSCalendar *cal = [NSCalendar currentCalendar];
    cal.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    dateComponents.calendar = cal;
    [dateComponents setHour:startHour];
    NSDate *startDate = [cal dateFromComponents:dateComponents];
    self.startTime = startDate;
    [dateComponents setHour:endHour];
    NSDate *endDate = [dateComponents date];
    self.endTime = endDate;
    
    // a segment is 30 minutes
    NSInteger numberOfSegments = (endHour - startHour) * 2;
    
    // sliders selection range is between 0.0f and 1.0f
    self.segmentLength = 1.0f / numberOfSegments;
    
    [self.tableView reloadData];
    
}


//------------------------------------------------------------------------------
// MARK: - Bar Button Item Mehtods
//------------------------------------------------------------------------------
- (void)done:(id)sender {
    BOOL hasNewAddresses = NO;
    for (AGNAddress *address in self.addresses) {
        if(address.notSynced){
            hasNewAddresses = YES;
            break;
        }
    }
    
    if(hasNewAddresses){
        [self showNewAddressAlert];
    }else{
        [self persistChanges];
    }
    log4Info(@"Saving changes to HCP %@",self.account.description);
}

// Since you can't modify existing addresses, need to warn the user
-(void)showNewAddressAlert{
    UIAlertView *verifyAddressAlertView = [[UIAlertView alloc]init];
    verifyAddressAlertView.delegate = self;
    verifyAddressAlertView.message = NSLocalizedString(@"You are adding new addresses. Once saved, they can not be modified. Are you sure you're ready to save?", @"Message on alert view  to confirm adding new addresses");
    verifyAddressAlertView.title = NSLocalizedString(@"Adding New Addresses", @"Title on alert view  to confirm adding new addresses");
    [verifyAddressAlertView addButtonWithTitle:NSLocalizedString(@"Resume Editing",@"When adding addresses, indicates alertview  will be dismissed so editing may continue")];
    [verifyAddressAlertView addButtonWithTitle:NSLocalizedString(@"Save Changes",@"When adding addresses, indicates changes will be saved") ];
    [verifyAddressAlertView show ];
    
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    
    switch(buttonIndex){
        case 0: 
            break;
        case 1:
            [self persistChanges];
           break;
        default:
            break;
    }
}


-(void)persistChanges{
    [self.lastActiveTextField resignFirstResponder];
    self.account.phone = self.phone;
    self.account.mobilePhone = self.mobile;
    self.account.fax = self.fax;
    self.account.email1 = self.email1;
    self.account.email2 = self.email2;
    self.account.email3 = self.email3;
    
    for (AGNAddress *address in self.addresses) {
        [address saveAvailabilityManager];
        address.notSynced=NO;
    }

    log4Info(@"Saving changes to HCP %@",self.account);
    
    NSArray *transactions = [self createManageAccountUpdateTransactions];
    self.hasEmailOrPhoneChanges = NO;
    self.saveBlock();
    [self saveAndEnqueueTransactions:transactions];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNAddressModifiedNotificationKey object:self];
    [self dismissViewControllerAnimated:YES completion:nil];

}

- (void)cancel:(id)sender {
    [[AGNAppDelegate sharedDelegate].managedObjectContext rollback];
    log4Info(@"Cancelling changes to HCP %@",self.account);

    for(AGNAddress * address in self.addresses){
        [address resetAvailabilityManager];
    }

    [[NSNotificationCenter defaultCenter] postNotificationName:AGNAddressModifiedNotificationKey object:self];
    [self dismissViewControllerAnimated:YES completion:nil];
    log4Info(@"Cancelling changes to HCP %@",self.account.description);

}

//------------------------------------------------------------------------------
// MARK: - TableView Data Source
//------------------------------------------------------------------------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return TotalSections+[self.addresses count];
}

- (NSInteger)firstAddressSection{
    return AddressSection;
}

- (NSInteger)newAddressSection{
    return AddressSection+[self.addresses count];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(section == PhoneSection || section == EmailSection){
        return 3;
    }
    if (section == ContactSection){
        return [self.contacts count]+1;
    }
    else if (section >= [self firstAddressSection] && section < [self newAddressSection] ){
        return 6;
    }
    return 1;
}

-(void)configurePhoneCell:(AGNTextFieldCell *)cell atIndexPath:(NSIndexPath *)indexPath{
    cell.textField.placeholder = nil;
    cell.textField.text = nil;
    cell.label.text = nil;
    cell.textField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    cell.textField.returnKeyType = UIReturnKeyDone;

    switch(indexPath.row){
        case PhoneRow:
            if(self.phone && self.phone.length > 0){
                cell.label.attributedText = [self.account attributedPhone:self.phone withLabel:@"Main"];
            }else{
                cell.textField.placeholder = @"Add Main #";
            }
            break;
        case MobileRow:
            if(self.mobile && self.mobile.length > 0){
                cell.label.attributedText = [self.account attributedPhone:self.mobile withLabel:@"Mobile"];

            }else{
                cell.textField.placeholder = @"Add Mobile #";
            }
            break;
        case FaxRow:
            if(self.fax && self.fax.length > 0 ){
                cell.label.attributedText = [self.account attributedPhone:self.fax withLabel:@"FAX"];
            }else{
                cell.textField.placeholder = @"Add FAX #";
            }
            break;
        default:
            cell.textField.placeholder = @"Add #";
            break;
    }

}

-(void)configureEmailCell:(AGNTextFieldCell *)cell atIndexPath:(NSIndexPath *)indexPath{
    cell.textField.placeholder = nil;
    cell.textField.text = nil;
    cell.label.text = nil;
    cell.textField.keyboardType = UIKeyboardTypeEmailAddress;
    cell.textField.returnKeyType = UIReturnKeyDone;
    
    NSString *email = self.email1;
    if(indexPath.row == 1)
        email = self.email2;
    if(indexPath.row == 2)
        email = self.email3;
    if(email && email.length>0){
        cell.label.text = email;
    }else{
        cell.textField.placeholder = @"Add E-Mail";
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *SingleFilterCellIdentifier = @"AGNTextFieldCell";
    
    AGNTextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:SingleFilterCellIdentifier];
    if (cell == nil) {
        cell = [[AGNTextFieldCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:SingleFilterCellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textField.delegate = self;
    cell.textField.indexPath=indexPath;
    
    if (indexPath.section == PhoneSection) {
        [self configurePhoneCell:cell atIndexPath:indexPath];
    }
    
    if( indexPath.section == ContactSection){
        cell.textField.placeholder = @"Add Name, Title";
        
        if ([self.contacts count] > 0 && indexPath.row
            < [self.contacts count]) {
            AGNContact * contact = self.contacts[indexPath.row];
            cell.label.attributedText = [contact callClosureAttributedNameAndRole];
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
            cell.textField.placeholder = @"";

        }
        
        cell.textField.keyboardType = UIKeyboardTypeDefault;
        cell.textField.returnKeyType = UIReturnKeyDone;
        cell.textField.clearButtonMode = UITextFieldViewModeNever;
        
    }
    
    if (indexPath.section == EmailSection) {
        [self configureEmailCell:cell atIndexPath:indexPath];
    }
    
    static NSString *AddressCellIdentifier = @"AddressCodeCell";
    
    if(indexPath.section == [self newAddressSection]){
        cell.textField.placeholder = @"New Address";
        cell.textField.text=nil;
    }

    if (indexPath.section >= [self firstAddressSection] && indexPath.section < [self newAddressSection] ) {
        int row = indexPath.row;
        
        AGNAddress *address = self.addresses[indexPath.section-[self firstAddressSection]];
        if (row == 0)  {
            cell.textField.placeholder = @"Add new email";
            AGNEditAddressCell *addressCell = [tableView dequeueReusableCellWithIdentifier:AddressCellIdentifier];
            if (addressCell == nil) {
                addressCell = [[AGNEditAddressCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:AddressCellIdentifier];
            }
            addressCell.editMode=YES;
            addressCell.address=address;
            return addressCell;
        } else {
            static NSString *HourEditCellIdentifier = @"HouEditCell";
            
            AGNHourSelectionCell *hourCell = [tableView dequeueReusableCellWithIdentifier:HourEditCellIdentifier];
            if (hourCell == nil) {
                hourCell = [[AGNHourSelectionCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:HourEditCellIdentifier];
            }

            AGNHCPDayAvailability *availability = [address.availabilityManager dayAvailabiliyForWeekday:(row % 6)];
            hourCell.availability = availability;
            
            
            if (!hourCell.availability.isUnavailable) {
                hourCell.hourSlider.selectedMinimumValue = [self numberOfSegmentsForDate:availability.startTime] * self.segmentLength + (self.segmentLength / 12);
                hourCell.hourSlider.selectedMaximumValue = [self numberOfSegmentsForDate:availability.endTime] * self.segmentLength + (self.segmentLength / 2);
            }
            
            hourCell.hourSlider.indexPath=indexPath;
            hourCell.inOutSwitch.indexPath=indexPath;
            [hourCell.hourSlider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
            [hourCell.inOutSwitch addTarget:self action:@selector(inOutValueChanged:) forControlEvents:UIControlEventValueChanged];
            
            [self sliderChanged:hourCell.hourSlider];
            return hourCell;
        }
       }
    
    return cell;
}

-(AGNAddress *)addressForSection:(NSInteger)section{
    if(section>=AddressSection){
        return self.addresses[section-AddressSection];
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == PhoneSection || indexPath.section == EmailSection || indexPath.section == ContactSection || indexPath.section == [self newAddressSection]){
        AGNTextFieldCell *cell = (AGNTextFieldCell *)[tableView cellForRowAtIndexPath:indexPath];
        [cell.textField becomeFirstResponder];
    }
}

//------------------------------------------------------------------------------
// MARK: - TableView Delegate
//------------------------------------------------------------------------------

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    AGNTableViewHeader *header = [[AGNTableViewHeader alloc] init];
    if (section == PhoneSection) {
        header.leftLabel.text = NSLocalizedString(@"PHONE",@"Phone header HCP profile edit view");
    } else if (section == ContactSection){
        header.leftLabel.text = NSLocalizedString(@"OFFICE STAFF",@"Contacts header HCP profile edit view");
        
    }else if (section == EmailSection){
        header.leftLabel.text = NSLocalizedString(@"E-MAIL",@"Email header HCP profile edit view");
    } else if(section >= [self firstAddressSection] && section < [self newAddressSection]){
        AGNAddress * address = [self addressForSection:section];
        NSString * label = address.primary.boolValue ? [NSLocalizedString(@"Primary Address", @"Primary address label on the HCP Profile") uppercaseString] : [NSLocalizedString(@"Secondary Address", @"Secondary address label on the HCP Profile") uppercaseString];

        //if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation) && address.addressType) {
            // in the header/popover it fits in either orientation so lets leave it
        if (address.addressType) {
             header.leftLabel.text = [[NSString stringWithFormat:@"%@ (%@)",label,address.addressType]uppercaseString];
        }
        else{
             header.leftLabel.text = label;
        }
        if(![address.primary boolValue]){
            if([address isHidden]){
                [header setButtonLabelText:@"SHOW"];
                [header.button addTarget:self action:@selector(flipAddressState:) forControlEvents:UIControlEventTouchUpInside];
                header.data=address;
            }else if(address.salesForceId){ // if not synced to server don't allow hiding the address, too complex
                [header setButtonLabelText:@"HIDE"];
                [header.button addTarget:self action:@selector(flipAddressState:) forControlEvents:UIControlEventTouchUpInside];
                header.data=address;
            }else if(address.notSynced){
                [header setButtonLabelText:@"EDIT"];
                [header.button addTarget:self action:@selector(editAddress:) forControlEvents:UIControlEventTouchUpInside];
                header.data=address;
            }
        }
    }else if (section == [self newAddressSection]){
        header.leftLabel.text = NSLocalizedString(@"ADD ADDRESS", @"Address header (secondary) HCP profile edit view");
    }
    
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kAGNTableViewHeaderHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section >= [self firstAddressSection] && indexPath.section < [self newAddressSection]){
        int row = indexPath.row;
        if (row == 0 ) {
            return kEditAddressCellHeight;
        } else {
            return 60.0f;
        }
    }
    else
        return tableView.rowHeight;
}


//------------------------------------------------------------------------------
// MARK: - Address Suppression
//------------------------------------------------------------------------------


//  Sales rep has requested to hide this address locally.  Separate object since this data can't be stored on SFDC and sync would otherwise wipe it out.  

-(void) suppressAddress:(AGNAddress *)address{
    AGNSuppressedAddress * suppressionObject = (AGNSuppressedAddress *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSuppressedAddress" inManagedObjectContext:address.managedObjectContext];
    AGNSalesRep * currentRep = [[AGNAppDelegate sharedDelegate]loggedInSalesRep];
    suppressionObject.salesRep = currentRep;
    suppressionObject.salesForceSalesRepId = currentRep.salesForceId;
    suppressionObject.salesForceHCPId = address.account.salesForceId;
    suppressionObject.salesForceAddressId = address.salesForceId;
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNAddressModifiedNotificationKey object:self];
}

- (void)unsuppressAddress:(AGNAddress *)address{
    AGNSalesRep *me = [[AGNAppDelegate sharedDelegate]loggedInSalesRep];
    NSManagedObjectContext *moc = [address managedObjectContext];
    for (AGNSuppressedAddress *suppressionObject in me.suppressedAddresses){
        if([address.salesForceId isEqualToString:suppressionObject.salesForceAddressId]){
            AGNSalesRep * rep = suppressionObject.salesRep;
            NSSet * suppressedAddresses = rep.suppressedAddresses;
            NSMutableSet * newSuppressedAddresses = [NSMutableSet setWithSet:suppressedAddresses];
            [newSuppressedAddresses removeObject:suppressionObject];
            rep.suppressedAddresses=newSuppressedAddresses;
            suppressionObject.salesRep=nil;
            [moc deleteObject:suppressionObject];
        }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNAddressModifiedNotificationKey object:self];
}


-(void)flipAddressState:(id)sender{
    UIButton * button = (UIButton * )sender;
    AGNTableViewHeader * header = (AGNTableViewHeader *)button.superview;
    AGNAddress * address = (AGNAddress *)header.data;
    if([address isHidden]){
        [self unsuppressAddress:address];
        log4Info(@"Unsuppressing address %@",address);
        [header setButtonLabelText:@"HIDE"];
    }else{
        [self suppressAddress:address];
        log4Info(@"Suppressing address %@",address);
        [header setButtonLabelText:@"SHOW"];
    }
}

-(void)editAddress:(id)sender{
    AGNAddAddressViewController *vc = [[AGNAddAddressViewController alloc] init];
    UIButton * button = (UIButton * )sender;
    AGNTableViewHeader * header = (AGNTableViewHeader *)button.superview;
    AGNAddress * address = (AGNAddress *)header.data;

    vc.account = self.account;
    vc.address = address;
    [self.navigationController pushViewController:vc animated:YES];
}

//------------------------------------------------------------------------------
// MARK: - Add/Edit contacts
//------------------------------------------------------------------------------

- (void)launchAddEditContacts:(AGNContact *) contact {
    AGNAddEditContactViewController *vc = [[AGNAddEditContactViewController alloc] init];
    vc.account = self.account;
    if(contact){
        contact.undoJSONRepresentation=contact.jsonRepresentationForUndo;
        vc.contact = contact;
        log4Info(@"Editing contact %@",contact);
    }else{
        log4Info(@"Add office staff pressed");

    }
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)launchAddAddress {
    
    AGNAddAddressViewController *vc = [[AGNAddAddressViewController alloc] init];
    vc.account = self.account;
    log4Info(@"Add address pressed");

    [self.navigationController pushViewController:vc animated:YES];
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    NSIndexPath * indexPath = self.lastActiveTextField.indexPath;
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

//------------------------------------------------------------------------------
// MARK: - UITextField Delegate
//------------------------------------------------------------------------------
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.lastActiveTextField = (UITextField *)textField;
    self.lastActiveTextField.indexPath = textField.indexPath;
    
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    if (indexPath.section == PhoneSection) {
        AGNTextFieldCell *theCell = (AGNTextFieldCell *)cell;
        theCell.label.attributedText = nil;
        NSString *phone = self.phone;
        if(indexPath.row==MobileRow)
            phone = self.mobile;
        if(indexPath.row==FaxRow)
            phone = self.fax;
        theCell.textField.text = phone;
    }
    
    if(indexPath.section == EmailSection){
        AGNTextFieldCell *theCell = (AGNTextFieldCell *)cell;
        theCell.label.attributedText = nil;
        NSString *email = self.email1;
        if(indexPath.row==1)
            email = self.email2;
        if(indexPath.row==2)
            email = self.email3;
        theCell.textField.text = email;
    }
    
    if (indexPath.section == ContactSection) {
        AGNContact *contact = nil;
        if(indexPath.row < [self.contacts count]){
            contact = self.contacts[indexPath.row];
        }
        [textField resignFirstResponder];
        [self launchAddEditContacts:contact];
    }
    else if (indexPath.section == [self newAddressSection]){
            [textField resignFirstResponder];
            [self launchAddAddress];
    }

}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    if (indexPath.section == PhoneSection) {
        self.hasEmailOrPhoneChanges = YES;
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        newString = [self stripCharecters:newString];
        
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
        
        NSNumber *phoneNumber;
        
        range = NSMakeRange(0, newString.length);
        
        [numberFormatter getObjectValue:&phoneNumber forString:newString range:&range error:nil];
        
        if ((newString.length > 0) && (phoneNumber == nil || range.length < newString.length)) {
            return NO;
        }
        
        NSString *strippedPhoneString = [self formatNumber:newString];
        
        if ([self stripCharecters:textField.text].length == 10 && strippedPhoneString.length == 10) {
            return NO;
        }
        
        textField.text = [self formatPhoneNumber:strippedPhoneString];
        
        return NO;
    }
    if (indexPath.section == EmailSection) {
        self.hasEmailOrPhoneChanges = YES;
        int numberOfRows = [self tableView:self.tableView numberOfRowsInSection:indexPath.section];
        
        if ((indexPath.row +1) == numberOfRows && numberOfRows < 3 ) {
            self.editingEmail = YES;
            [self.tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:(indexPath.row +1) inSection:EmailSection]] withRowAnimation:UITableViewRowAnimationTop];
        }
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    self.editingEmail = NO;
    
    if (indexPath.section == PhoneSection) {
        log4Info(@"Add/Edit phone : %@", textField.text);
        if (indexPath.row == 0) {
            self.phone = textField.text;
        } else if (indexPath.row == 1) {
            self.mobile = textField.text;
        } else {
            self.fax = textField.text;
        }
        [self configurePhoneCell:(AGNTextFieldCell *)cell atIndexPath:indexPath];
    }
    
    if (indexPath.section == EmailSection) {
        log4Info(@"Add/Edit email : %@", textField.text);
        if (indexPath.row == 0) {
            self.email1 = textField.text;
        } else if (indexPath.row == 1) {
            self.email2 = textField.text;
        } else {
            self.email3 = textField.text;
        }
        [self configureEmailCell:(AGNTextFieldCell *)cell atIndexPath:indexPath];
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:textField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    if (indexPath.section == PhoneSection) {
        self.hasEmailOrPhoneChanges = YES;
    }
    if (indexPath.section == EmailSection) {
        self.hasEmailOrPhoneChanges = YES;
    }
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField*)textField
{
    [textField resignFirstResponder];
    
    return NO;
}

//------------------------------------------------------------------------------
#pragma mark - Phone Number Formatter
//------------------------------------------------------------------------------
-(NSString *)formatPhoneNumber:(NSString *)strippedPhoneString {
    
    int length = strippedPhoneString.length;
    
    NSMutableString *formattedString = [[NSMutableString alloc] init];
    
    if (length <= 3) {
        [formattedString appendFormat:@"%@", strippedPhoneString];
    }
    
    if(length > 3)
    {
        [formattedString appendFormat:@"(%@)",[strippedPhoneString  substringToIndex:3]];
    }
    
    if (length > 3 && length < 6) {
        NSRange newRange = NSMakeRange(3, strippedPhoneString.length - 3);
        [formattedString appendFormat:@" %@", [strippedPhoneString substringWithRange:newRange]];
    }
    
    if(length >= 6)
    {
        NSRange newRange = NSMakeRange(3, 3);
        [formattedString appendFormat:@" %@", [strippedPhoneString substringWithRange:newRange]];
    }
    
    
    if (length > 6 && length <= 10) {
        NSRange newRange = NSMakeRange(6, strippedPhoneString.length - 6);
        [formattedString appendFormat:@"-%@", [strippedPhoneString substringWithRange:newRange]];
    }
    
    return formattedString;
}

-(NSString*)formatNumber:(NSString*)mobileNumber
{
    mobileNumber = [self stripCharecters:mobileNumber];
    
    int length = [mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
    }
    
    return mobileNumber;
}

-(NSString *)stripCharecters:(NSString*)mobileNumber
{
    static NSArray *forbiddenCharecters;
    if (!forbiddenCharecters) {
        forbiddenCharecters = @[@"(", @")", @" ", @"-", @"+"];
    }
    
    for (NSString *letter in forbiddenCharecters) {
        mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:letter withString:@""];
    }
    
    return mobileNumber;
}


- (void)saveAndEnqueueTransactions:(NSArray *)updateTransactions {
    //Appending the transactions saves the context, including data model changes.
    //If it fails, it does a rollback - we need to inform user and refresh the interface.
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:updateTransactions]) {
        //TODO: notify user of fail and refresh interface
        log4Error(@"Failed to save account - either appendTransactions failed or MOC save failed");
    }
}

- (NSArray *)createManageAccountUpdateTransactions {
    NSMutableArray *transactions = [[NSMutableArray alloc]init];
    
    if (self.hasEmailOrPhoneChanges) {
        [transactions addObject:[self updateAccountTransaction]];
    }
    
    for(AGNContact * contact in self.account.contacts) {
        if ([contact.toBeDeletedFlag boolValue] || !contact.salesForceId || [contact hasChanges]) {
            [transactions addObject:[self upsertContactTransaction:contact]];
        }
    }
    for(AGNAddress * address in self.account.addresses) {
        if (!address.salesForceId || [[address changedValues] count] > 0) {
            [transactions addObject:[self upsertAddressTransaction:address]];
        }
    }
    return transactions;
}

- (AGNUpdateTransactionValueHolder *)updateAccountTransaction {
    NSString *currentJSONRepresentation = [self.account jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpdateAccount];
    upTxn.undoJSONRepresentation = self.account.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.deleteModelObjectOnRevert = [NSNumber numberWithBool:(self.account.undoJSONRepresentation == nil)];
    upTxn.modelClassName = @"AGNAccount";
    upTxn.salesForceId = self.account.salesForceId;
    return upTxn;
}

- (AGNUpdateTransactionValueHolder *)upsertContactTransaction:(AGNContact *)contact {
    NSString *currentJSONRepresentation = [contact jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpsertContact];
    upTxn.undoJSONRepresentation = contact.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.deleteModelObjectOnRevert = [NSNumber numberWithBool:contact.salesForceId==nil];
    upTxn.modelClassName = @"AGNContact";
    upTxn.salesForceId = contact.salesForceId;
    upTxn.guid = contact.guid;
    return upTxn;
}

- (AGNUpdateTransactionValueHolder *)upsertAddressTransaction:(AGNAddress *)address {
    NSString *currentJSONRepresentation = address.salesForceId ? [address jsonRepresentationForAvailabilityUpdate] : [address jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:(address.salesForceId ? AGNApexWrapperUpdateAddress : AGNApexWrapperInsertAddress)];
    upTxn.undoJSONRepresentation = address.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.deleteModelObjectOnRevert = [NSNumber numberWithBool:address.salesForceId==nil];
    upTxn.modelClassName = @"AGNAddress";
    upTxn.salesForceId = address.salesForceId;
    upTxn.guid = address.guid;
    return upTxn;
}


//------------------------------------------------------------------------------
#pragma mark - AGNSliderCellMethods
//------------------------------------------------------------------------------
- (void)sliderChanged:(AGNDualSlider *)slider {
    
    AGNHourSelectionCell *cell = (AGNHourSelectionCell *)[self.tableView cellForRowAtIndexPath:slider.indexPath];
    
    if ([cell.availability isUnavailable] &&
        slider.selectedMaximumValue == slider.maximumValue && slider.selectedMinimumValue == slider.minimumValue) {
        return;
    }
    
    NSDate *minDate = [self dateForSelectedValue:slider.selectedMinimumValue];
    NSDate *maxDate = [self dateForSelectedValue:slider.selectedMaximumValue];
    
    cell.availability.startTime = minDate;
    cell.availability.endTime = maxDate;
    
    slider.minimumLabelText = [minDate agnAvailabilityString];
    slider.maximumLabelText = [maxDate agnAvailabilityString];

}

- (NSDate *)dateForSelectedValue:(float)aFloat {
    int numberOfHalfHours = (aFloat / self.segmentLength) + (self.segmentLength / 2);
    NSCalendar *utcCalendar = [NSCalendar currentCalendar];
    utcCalendar.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    
    unsigned unitFlags = NSHourCalendarUnit | NSMinuteCalendarUnit;
    static NSDateComponents *startDateComponents;
    if (!startDateComponents) {
        startDateComponents = [utcCalendar components:unitFlags fromDate:self.startTime];
    }
    
//    static NSCalendar *calendar;
//    if (!calendar) {
//        calendar = utcCalendar;
//    }
    
    NSUInteger hour = [startDateComponents hour];
    NSUInteger minute = [startDateComponents minute];
    
    static NSDateComponents *dateComponents;
    if (!dateComponents) {
        dateComponents = [[NSDateComponents alloc] init];
        dateComponents.calendar = utcCalendar;
    }
    [dateComponents setHour:hour];
    [dateComponents setMinute:(numberOfHalfHours * 30) + minute];
    NSDate *date = [dateComponents date];
    
    return date;
}

- (int)numberOfSegmentsForDate:(NSDate *)date {
    NSCalendar *utcCalendar = [NSCalendar currentCalendar];
    utcCalendar.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];

    unsigned unitFlags = NSHourCalendarUnit | NSMinuteCalendarUnit;
    NSDateComponents *startDateComponents = [utcCalendar components:unitFlags fromDate:self.startTime];
    NSDateComponents *dateComponents = [utcCalendar components:unitFlags fromDate:date];
    
    NSUInteger hour = [dateComponents hour];
    NSUInteger minute = [dateComponents minute];
    
    hour -= startDateComponents.hour;
    minute -= startDateComponents.minute;
    
    int numberOfSegments = hour * 2;
    if (minute / 30 == 1) {
        numberOfSegments++;
    }
    
    return numberOfSegments;
}

- (void)inOutValueChanged:(UISwitch *)aSwitch {
    AGNHourSelectionCell *cell = (AGNHourSelectionCell *)[self.tableView cellForRowAtIndexPath:aSwitch.indexPath];

    cell.hourSlider.enabled = aSwitch.on;
    if (aSwitch.on) {
        cell.availability.startTime = self.startTime;
        cell.availability.endTime = self.endTime;
        [self sliderChanged:cell.hourSlider]; //hack to show label for new in/out
        log4Info(@"office hours toggled to IN");
    } else {
        [cell.availability setUnavailable];
        log4Info(@"office hours toggled to OUT");

    }
}
@end
