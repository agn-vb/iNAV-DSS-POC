//
//  AGNCallDetailViewController.h
//  AGNDirect
//
//  Created by Mark Wells on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNEligibilityHelper.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNViewController.h"
#import "AGNClosureModalViewController.h"
#import "AGNSmallBlueButton.h"

static NSString * const AGNSwitchHCPNotificationKey = @"AGNSwitchHCPNotification";

@interface AGNCallDetailViewController : AGNViewController <UIPopoverControllerDelegate, UIAlertViewDelegate, CallDetailDelegate, AGNPopoverDelegate, UISearchBarDelegate>

@property (strong, nonatomic) AGNCall *call;
@property (strong, nonatomic) AGNAccount *hcp;
@property (strong, nonatomic) AGNAddress *hcpAddress;
@property (strong, nonatomic) IBOutlet UIButton *closeCallButton;

@property (weak, nonatomic) IBOutlet UIView *leftView;
@property (weak, nonatomic) IBOutlet UIView *rightView;
@property (weak, nonatomic) IBOutlet UIView *footerView;

- (BOOL) canDismiss;
@property (weak, nonatomic) IBOutlet AGNSmallBlueButton *switchHCPButton;
- (IBAction)switchHCPTapped:(id)sender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *equalWidthsConstraint;
@end
