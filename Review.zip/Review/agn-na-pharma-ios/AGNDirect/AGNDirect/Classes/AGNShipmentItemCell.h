//
//  AGNShipmentItemCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/14/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSampleInventoryTransactionLine.h"

@protocol AGNShipmentItemCellDelegate;

@interface AGNShipmentItemCell : UITableViewCell <UITextFieldDelegate>



@property (weak, nonatomic) IBOutlet UILabel *sampleName;
@property (weak, nonatomic) IBOutlet UILabel *lotNumber;
@property (weak, nonatomic) IBOutlet UILabel *shippedQuantity;
@property (weak, nonatomic) IBOutlet UILabel *expiration;
@property (weak, nonatomic) IBOutlet UITextField *receivedQuantity;

@property (strong, nonatomic) AGNSampleInventoryTransactionLine *line;
@property BOOL accepted;

@property (weak, nonatomic) IBOutlet UILabel *receivedQtyLabel;

@property (weak, nonatomic) id<AGNShipmentItemCellDelegate> delegate;

@end

@protocol AGNShipmentItemCellDelegate <NSObject>

// take action when item is selected
- (void)quantitySelected;

@end

