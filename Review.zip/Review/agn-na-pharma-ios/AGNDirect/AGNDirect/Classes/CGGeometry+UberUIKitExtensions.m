/*
 *  CGGeometry+UberUIKitExtensions.c
 *  UberUIKit
 *
 *  Created by Bryan Hansen on 2/12/10.
 *  Copyright 2010 Übermind, Inc. All rights reserved.
 *
 */

#import "CGGeometry+UberUIKitExtensions.h"

CGRect UberCGRectGrow(CGRect rect, CGFloat value, CGRectEdge edge) {
	switch (edge) {
	case CGRectMinXEdge: return CGRectMake(rect.origin.x - value, rect.origin.y        , rect.size.width + value, rect.size.height        );
	case CGRectMaxXEdge: return CGRectMake(rect.origin.x        , rect.origin.y        , rect.size.width + value, rect.size.height        );
	case CGRectMinYEdge: return CGRectMake(rect.origin.x        , rect.origin.y - value, rect.size.width        , rect.size.height + value);
	case CGRectMaxYEdge: return CGRectMake(rect.origin.x        , rect.origin.y        , rect.size.width        , rect.size.height + value);
	default:
		NSCAssert1(NO, @"invalid CGRectEdge %i provided to CGRectGrow()", (int)edge);
	}
	
	return rect;
}

CGRect UberCGRectHorizontallyCenteredInRect(CGRect rectToCenter, CGRect parentRect) {
    return CGRectMake(
        parentRect.origin.x + floor(parentRect.size.width  / 2 - rectToCenter.size.width  / 2),
        rectToCenter.origin.y,
        rectToCenter.size.width,
        rectToCenter.size.height
    );
}

CGRect UberCGRectVerticallyCenteredInRect(CGRect rectToCenter, CGRect parentRect) {
    return CGRectMake(
        rectToCenter.origin.x,
        parentRect.origin.y + floor(parentRect.size.height / 2 - rectToCenter.size.height / 2),
        rectToCenter.size.width,
        rectToCenter.size.height
    );
}