//
//  AGNViewController.m
//  AGNDirect
//
//  Created by Mark Wells on 9/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

////////////////////////////////////////////////////////////////////

// Parent of view controllers to support reloading data when syncing occurs

////////////////////////////////////////////////////////////////////


#import "AGNViewController.h"
#import "AGNAppDelegate.h"

@interface AGNViewController ()

@property (nonatomic) BOOL needsRefresh;
@property (nonatomic) BOOL onScreen;

@end


@implementation AGNViewController

- (BOOL)needsUndoState {
    return NO;
}

- (void)createUndoState {
    // Default behavior is a no-op
}

- (void)reloadContent {
    // Default behavior is a no-op
}

- (void)reloadContent:(NSNotification*)notification {
    if (self.onScreen)
        [self reloadContent];
    else
        self.needsRefresh = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadContent:) name:kDDSFNotificationSyncEnded object:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.onScreen = YES;
    if (self.needsRefresh) {
        [self reloadContent];
        self.needsRefresh = NO;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.onScreen = NO;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
