//
//  AGNCallProductSampleCell.m
//  AGNDirect
//
//  Created by Mark Wells on 8/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCallProductSampleCell.h"
#import "AGNSampleInventoryLine.h"

@implementation AGNCallProductSampleCell
@synthesize label;
@synthesize quantityLabel;
@synthesize quantityTextField;
@synthesize expiredLotLabel;
@synthesize model = _model;
@synthesize actualQuantityLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.label = [[UILabel alloc] init];
        self.label.font = [UIFont AGNAvenirHeavy14];
        self.label.textColor = [UIColor AGNGreyMatter];
        [self.label setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.label.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.label];
        
        self.quantityLabel = [[UILabel alloc] init];
        self.quantityLabel.font = [UIFont AGNAvenirHeavy14];
        self.quantityLabel.textColor = [UIColor AGNGreyMatter];
        self.quantityLabel.text = @"QTY:";
        self.quantityLabel.backgroundColor = [UIColor clearColor];
        [self.quantityLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.quantityLabel];

        
        self.actualQuantityLabel = [[UILabel alloc] init];
        self.actualQuantityLabel.font = [UIFont AGNAvenirHeavy14];
        self.actualQuantityLabel.textColor = [UIColor AGNGreyMatter];
        self.actualQuantityLabel.backgroundColor = [UIColor clearColor];
        [self.actualQuantityLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.actualQuantityLabel];
        

        self.expiredLotLabel = [[UILabel alloc] init];
        self.expiredLotLabel.font = [UIFont AGNAvenirHeavy14];
        self.expiredLotLabel.textColor = [UIColor AGNWarny];
        self.expiredLotLabel.text = @"EXPIRED LOT";
        self.expiredLotLabel.backgroundColor = [UIColor clearColor];
        [self.expiredLotLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.expiredLotLabel];
        
        self.expiredLotLabel.hidden=YES;

        
        self.quantityTextField = [[UITextField alloc] init];
        self.quantityTextField.borderStyle = UITextBorderStyleRoundedRect;
        self.quantityTextField.font = [UIFont AGNAvenirHeavy14];
        self.quantityTextField.textColor = [UIColor AGNGreyMatter];
        self.quantityTextField.delegate = self;
        self.quantityTextField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        self.quantityTextField.returnKeyType = UIReturnKeyDone;
        self.quantityTextField.adjustsFontSizeToFitWidth = YES;
        [self.quantityTextField setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.quantityTextField];
        
        NSDictionary *constraintsViewsDictionary = @{ @"label" : self.label , @"qtyLabel" : self.quantityLabel , @"qtyTextField" : self.quantityTextField, @"expiredLotLabel": self.expiredLotLabel , @"actualQuantityLabel" : self.actualQuantityLabel };
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[label(>=100)]-8-[qtyLabel(==34)]-8-[qtyTextField(==56)]-12-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[qtyLabel(==34)]-8-[actualQuantityLabel(==56)]-12-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|->=12-[expiredLotLabel]-12-|" options:0 metrics:nil views:constraintsViewsDictionary]];

        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[qtyTextField(==24)]" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.label attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.quantityLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.actualQuantityLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.quantityTextField attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.expiredLotLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];

    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];

    self.model = nil;
    self.label.text = nil;
    self.quantityTextField.text = nil;
    self.quantityTextField.backgroundColor = [UIColor whiteColor];
    self.editing = NO;
}

- (void)setSku:(AGNProductSKU *)sku {
    _sku = sku;
    if (_sku) {
        if (_model)
            self.label.text = [NSString stringWithFormat:@"%@ - %@", sku.productDescription, self.model.sampleInventoryLine.lotNumber];
        else
            self.label.text = sku.productDescription;
    }
    else
        self.label.text = @"";
}

- (void)setModel:(AGNSampleDrop *)model {
    _model = model;
    if (model == nil) {
        return;
    }
    AGNProductSKU *sku = ((AGNSampleInventoryLine *)_model.sampleInventoryLine).product;
    self.label.text = [NSString stringWithFormat:@"%@ - %@", model.productDescription?model.productDescription: sku.productDescription,
                       model.lotNumber?model.lotNumber:self.model.sampleInventoryLine.lotNumber];
    self.quantityTextField.text = _model.quantity.stringValue;
    self.actualQuantityLabel.text = _model.quantity.stringValue;
    [self updateValidationState];
}

- (BOOL)isQuantityValid {
    
    if (self.model.call.isClosed)
        return YES;
    else if ([self.model.quantity intValue] > [self.model.sampleInventoryLine.quantity intValue])
        return NO;
    else if ([self.model.quantity intValue]<1)
        return NO;
    else
        return YES;
}

- (void)updateValidationState {
    
    if (self.isQuantityValid) {
        self.quantityTextField.backgroundColor = [UIColor whiteColor];
        self.quantityTextField.textColor = [UIColor AGNGreyMatter];
    }
    else {
        self.quantityTextField.backgroundColor = [UIColor AGNWarny];
        self.quantityTextField.textColor = [UIColor whiteColor];
    }
    
    if((!self.model.sampleInventoryLine  ||self.model.sampleInventoryLine.isExpired) && !self.model.call.isClosed){
        self.quantityLabel.hidden=YES;
        self.quantityTextField.hidden=YES;
        self.expiredLotLabel.hidden=NO;
        if(!self.model.sampleInventoryLine){
            self.expiredLotLabel.text = @"INVALID LOT";
        }else{
            self.expiredLotLabel.text = @"EXPIRED LOT";
        }

    }else{
        self.quantityLabel.hidden=NO;
        self.quantityTextField.hidden=NO;
        self.expiredLotLabel.hidden=YES;
    }
    
    if(self.model.call.isClosed || self.model.call.signatureCaptureDate){
        self.actualQuantityLabel.hidden=NO;
        self.quantityTextField.hidden=YES;
    }else{
        self.actualQuantityLabel.hidden=YES;
    }
}


//------------------------------------------------------------------------------
#pragma mark - UITextField Delegate Methods
//------------------------------------------------------------------------------
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    
    NSNumber *inventoryNumber;
    
    NSString *inventoryString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    range = NSMakeRange(0, [inventoryString length]);
    
    [numberFormatter getObjectValue:&inventoryNumber forString:inventoryString range:&range error:nil];
    
    self.model.quantity = inventoryNumber;
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNSampleCellQuantityChangedNotification object:self];
    
    if (([inventoryString length] > 0) && (inventoryNumber == nil || range.length < [inventoryString length])) {
        return NO;
    } else {
        return YES;
    }
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNSampleCellDidBeginEditing object:self];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self updateValidationState];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
