//
//  NSEntityDescription+UberDataExtensions.h
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-11.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 * @ingroup UberData
 *
 * Extensions to Core Data's \c NSEntityDescription.
 */
@interface NSEntityDescription (UberDataExtensions)
/**
 * Returns an \c NSEntityDescription identified by looking up the name of \a cls
 * in the default UberCoreDataManager#managedObjectModel.
 */
+ (NSEntityDescription *)uber_entityForClass:(Class)cls;
@end
