//
//  NSManagedObject+UberDataExtensions.h
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-10.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 * @ingroup UberData
 *
 * Extensions to Core Data's \c NSManagedObject.
 */
@interface NSManagedObject (UberDataExtensions) <NSCoding, NSCopying> 
/**
 * Returns the \c NSEntityDescription associated with the class name of the
 * receiver in the default UberCoreDataManager#managedObjectModel.
 */
+ (NSEntityDescription *)entity;

/**
 * Returns an \c NSFetchRequest initialized for fetching objects of the
 * receiver's #entity.
 */
+ (NSFetchRequest *)uber_fetchRequestForInstances;

/**
 * Executes a fetch for all objects of the receiver's #entity in the
 * UberCoreDataManager#managedObjectContext for the current thread and returns the
 * results. If an error occurs, \c nil is returned.
 *
 * @warning No batch size is used when executing the fetch. This may lead to
 * excessive memory consumption. If your usage demands fine-tuned performance,
 * configure and use the result of #fetchRequestForInstances instead.
 */
+ (NSArray *)uber_allInstances;

/**
 * Executes a fetch for all objects of the receiver's #entity in the
 * UberCoreDataManager#managedObjectContext for the current thread and returns the
 * results. The results are sorted by the \c NSSortDescriptor objects contained
 * within \a sortDescriptors. If an error occurs, \c nil is returned.
 *
 * @warning No batch size is used when executing the fetch. This may lead to
 * excessive memory consumption. If your usage demands fine-tuned performance,
 * configure and use the result of #fetchRequestForInstances instead.
 */
+ (NSArray *)uber_allInstancesSortedByDescriptors:(NSArray *)sortDescriptors;

/**
 * Executes a fetch for objects of the receiver's #entity that match \a
 * predicate in the UberCoreDataManager#managedObjectContext for the current thread
 * and returns the results. If an error occurs, \c nil is returned.
 *
 * @warning No batch size is used when executing the fetch. This may lead to
 * excessive memory consumption. If your usage demands fine-tuned performance,
 * configure and use the result of #fetchRequestForInstances instead.
 */
+ (NSArray *)uber_instancesFilteredByPredicate:(NSPredicate *)predicate;

/**
 * Executes a fetch for objects of the receiver's #entity that match \a
 * predicate in the UberCoreDataManager#managedObjectContext for the current thread
 * and returns the results. The results are sorted by the \c NSSortDescriptor objects
 * contained within \a sortDescriptors. If an error occurs, \c nil is returned.
 *
 * @warning No batch size is used when executing the fetch. This may lead to
 * excessive memory consumption. If your usage demands fine-tuned performance,
 * configure and use the result of #fetchRequestForInstances instead.
 */
+ (NSArray *)uber_instancesFilteredByPredicate:(NSPredicate *)predicate sortedByDescriptors:(NSArray *)sortDescriptors;

/**
 * Returns an autoreleased instance of the receiver inserted into the current thread's
 * UberCoreDataManager#managedObjectContext. The \c NSEntityDescription for the returned
 * object is identified using by looking up the receiver's class name in the default
 * UberCoreDataManager#managedObjectModel.
 */
+ (id)uber_managedObjectInsertedIntoCurrentContext;

/**
 * Returns an autoreleased instance of the receiver that is not inserted into
 * any managed object context. The \c NSEntityDescription for the returned
 * object is identified using by looking up the receiver's class name in the default
 * UberCoreDataManager#managedObjectModel.
 */
+ (id)uber_managedObjectWithoutContext;

/**
 * Initializes a managed object using data extracted from \a coder. The returned
 * object is not inserted into any managed object context, and may not be the
 * same instance as the receiver.
 *
 * Internally, this uses #setValuesFromDictionary: after the object has been
 * initialized with a valid entity description.
 *
 * @sa encodeWithCoder:
 */
- (id)initWithCoder:(NSCoder *)coder;

/**
 * Returns a shallow copy of the receiver. To preserve any object relationships,
 * the new instance is inserted into the same managed object context as the
 * receiver. Only many-to-many and many-to-one relationships (where the receiver
 * is one of the many) are preserved; all others are skipped.
 *
 * This method uses the receiver's \c NSEntityDescription to determine which
 * properties to preserve in the copy. If you have custom instance variables, or
 * need to modify the properties being preserved, you should override this
 * method and perform your modifications after invoking \c super.
 *
 * @todo Preserve one-to-one and one-to-many relationships safely.
 */
- (id)copyWithZone:(NSZone *)zone;

/**
 * Encodes the receiver and any associated properties using \a coder. As part of
 * this serialization, the \c NSEntityDescription is also encoded to help support
 * adding the decoding objects back into a managed object context.
 *
 * Internally, this uses #dictionaryValue to encode the properties of the
 * receiver. If you need more lightweight encoding, consider encoding only the result
 * of #dictionaryValue instead.
 *
 * @sa initWithCoder:
 */
- (void)encodeWithCoder:(NSCoder *)coder;

/**
 * Returns a dictionary constructed using the keys and values of the receiver.
 * This method uses the receiver's \c NSEntityDescription to determine which
 * properties to insert into the dictionary. If you have custom instance
 * variables, or need to modify the properties being preserved, you should
 * override this method and perform your modifications after invoking \c super.
 */
- (NSMutableDictionary *)uber_dictionaryValue;

/**
 * Attempts to parse \a value into a type suitable for association with \a key,
 * validates the resultant value (if one was determined) using \c
 * validateValue:forKey:error:, and associates the validated value with \a key.
 *
 * Returns \c YES on success. Returns \c NO if an error occurred during parsing
 * or validation, if \a key refers to a relationship (rather than an attribute),
 * or if \a key does not exist on the receiver.
 *
 * @note During parsing, \a value is interpreted according to the current
 * locale. If a conversion to binary data is required, the string is encoded into
 * UTF-8 data. Dates are parsed using ISO 8601 format.
 *
 * @warning This method is meant for use only with properties defined in the data
 * model. It will not work with dynamic or custom properties.
 */
- (BOOL)uber_setStringValue:(NSString *)value forKey:(NSString *)key;

/**
 * Updates the properties of the receiver using keys and values from \a dict.
 * The keys in \a dict may be strings or \c NSPropertyDescription objects.
 *
 * @warning This method performs no validation on \a dict to ensure that the keys
 * exist, or that the corresponding values are valid.
 */
- (void)uber_setValuesFromDictionary:(NSDictionary *)dict;
@end
