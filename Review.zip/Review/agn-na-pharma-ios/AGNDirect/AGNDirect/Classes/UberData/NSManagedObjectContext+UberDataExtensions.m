//
//  NSManagedObjectContext+UberDataExtensions.m
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-10.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import "NSManagedObjectContext+UberDataExtensions.h"

@implementation NSManagedObjectContext (UberDataExtensions)
- (void)uber_deleteObjects:(id)objects {
	NSParameterAssert(objects != nil);
	NSParameterAssert([objects conformsToProtocol:@protocol(NSFastEnumeration)]);

	for (id obj in objects) {
		NSAssert1([obj isKindOfClass:[NSManagedObject class]] || [obj isKindOfClass:[NSManagedObjectID class]], @"object passed to deleteObjects: was not an NSManagedObject or NSManagedObjectID: %@", obj);

		if ([obj isKindOfClass:[NSManagedObjectID class]])
			obj = [self objectWithID:obj];

		[self deleteObject:obj];
	}
}

- (void)uber_insertObjects:(id)objects {
	NSParameterAssert(objects != nil);
	NSParameterAssert([objects conformsToProtocol:@protocol(NSFastEnumeration)]);

	for (NSManagedObject *obj in objects) {
		NSAssert1([obj isKindOfClass:[NSManagedObject class]], @"object passed to insertObjects: was not an NSManagedObject: %@", obj);

		[self insertObject:obj];
	}
}

- (NSArray *)uber_managedObjectsForObjectIDs:(id)objectIDs {
	NSParameterAssert(objectIDs != nil);
	NSParameterAssert([objectIDs conformsToProtocol:@protocol(NSFastEnumeration)]);

	NSMutableArray *result;
	if ([objectIDs respondsToSelector:@selector(count)]) {
		result = [NSMutableArray arrayWithCapacity:[objectIDs count]];
	} else {
		result = [NSMutableArray array];
	}

	for (NSManagedObjectID *objID in objectIDs) {
		NSAssert1([objID isKindOfClass:[NSManagedObjectID class]], @"object passed to managedObjectsForObjectIDs: was not an NSManagedObjectID: %@", objID);

		[result addObject:[self objectWithID:objID]];
	}

	return result;
}

- (NSArray *)uber_objectIDsForManagedObjects:(id)objects {
	NSParameterAssert(objects != nil);
	NSParameterAssert([objects conformsToProtocol:@protocol(NSFastEnumeration)]);

	NSMutableArray *result;
	if ([objects respondsToSelector:@selector(count)]) {
		result = [NSMutableArray arrayWithCapacity:[objects count]];
	} else {
		result = [NSMutableArray array];
	}

	for (NSManagedObject *obj in objects) {
		NSAssert1([obj isKindOfClass:[NSManagedObject class]], @"object passed to objectIDsForManagedObjects: was not an NSManagedObject: %@", obj);

		[result addObject:[obj objectID]];
	}

	return result;
}

- (BOOL)uber_saveWithMergePolicy:(id)mergePolicy error:(NSError **)error {
 	id previousMergePolicy = [self mergePolicy];

	[self setMergePolicy:mergePolicy];
	BOOL result = [self save:error];
	[self setMergePolicy:previousMergePolicy];
	
	return result;
}

@end
