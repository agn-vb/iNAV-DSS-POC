//
//  UberCoreDataManager.h
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-10.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 * @ingroup UberData
 * 
 * Helps manage Core Data state global to the application. An object of this
 * class can keep track of the application's current #managedObjectModel,
 * #persistentStoreCoordinator, and one or more managed object contexts.
 *
 * Although meant to be used as a singleton, it is valid to instantiate this
 * class and use the instance separate from the singleton. Such a pattern might
 * be useful in the presence of multiple object models or persistent stores.
 */
@interface UberCoreDataManager : NSObject {
}

/**
 * The managed object model for the application. This should always be the \e
 * current managed object model, not an older version.
 *
 * If this property is not set up, the application's main bundle is searched for
 * object model definitions, which are loaded using <tt>+[NSManagedObjectModel
 * mergedModelFromBundles:]</tt>.
 *
 * @note This property is thread-safe for both reading and writing.
 *
 * @warning This property should never be set to \c nil in a multi-threaded
 * context. This does not affect \c -dealloc, as it is guaranteed by the runtime
 * to be synchronized as appropriate.
 */
@property (nonatomic, retain) NSManagedObjectModel *managedObjectModel;

/**
 * The persistent store coordinator to use with new managed object contexts. If
 * this property is not set up, #persistentStoreCoordinatorNamed: is invoked
 * using the \c CFBundleName or \c CFBundleDisplayName (whichever is available
 * first) from the \c Info.plist to create a new store in the style
 * "ApplicationName.sqlite".
 *
 * @note This property is thread-safe for both reading and writing.
 *
 * \c NSMigratePersistentStoresAutomaticallyOption and \c NSInferMappingModelAutomaticallyOption 
 * option flags are both used during creation to automatically perform "lightweight" 
 * migrations between different versions of the CoreData model.
 *
 * @warning This property should never be set to \c nil in a multi-threaded
 * context. This does not affect \c -dealloc, as it is guaranteed by the runtime
 * to be synchronized as appropriate.
 */
@property (nonatomic, retain) NSPersistentStoreCoordinator *persistentStoreCoordinator;

/**
 * Returns a persistent store coordinator that uses a SQLite store named \a
 * storeName in the application's Application Support folder and the existing
 * #managedObjectModel.
 *
 * \c NSMigratePersistentStoresAutomaticallyOption and \c NSInferMappingModelAutomaticallyOption 
 * option flags are both used during creation to automatically perform "lightweight" 
 * migrations between different versions of the CoreData model.
 */
- (NSPersistentStoreCoordinator *)persistentStoreCoordinatorNamed:(NSString*)storeName;

/**
 * A managed object context specifically <em>for the current thread</em>. If no
 * context already exists for the current thread, one is created. Any contexts
 * created in such a manner are automatically destroyed upon thread exit without
 * saving, except for the main thread's managed object context, which may be
 * saved if #automaticallySaveMainThreadContext is \c YES.
 *
 * Use of this property can make multi-threaded Core Data operations easier and
 * simpler by handling most of the synchronization issues implicitly. Keep in
 * mind that the returned \c NSManagedObjectContext and any associated \c
 * NSManagedObject instances still cannot be passed between threads.
 *
 * @sa #automaticallySaveMainThreadContext
 * @sa #automaticallyMergeChangesIntoMainThreadContext
 */
@property (nonatomic, readonly) NSManagedObjectContext *managedObjectContext;

/**
 * If this is set to \c YES (the default), the managed object context
 * associated with the main thread is automatically saved at significant
 * points in the application lifecycle, such as when the application resigns
 * its active state, moves to the background, or exits. Any merge conflicts are
 * logged to the console and thereafter ignored (i.e., no overwriting will
 * occur).
 *
 * @warning This property is \e not thread-safe, and is meant to be changed only
 * from the main thread.
 */
@property (nonatomic, assign) BOOL automaticallySaveMainThreadContext;

/**
 * If this is set to \c YES, the receiver will listen for postings of \c
 * NSManagedObjectContextDidSaveNotification and attempt to merge the changes
 * into the main thread's managed object context when such a notification is
 * received. This can help minimize merge conflicts caused by performing
 * operations on the background.
 *
 * The default value is \c NO.
 *
 * @warning This property is \e not thread-safe, and is meant to be changed only
 * from the main thread.
 */
@property (nonatomic, assign) BOOL automaticallyMergeChangesIntoMainThreadContext;

/**
 * Returns the singleton manager object.
 */
+ (UberCoreDataManager *)defaultManager;

@end
