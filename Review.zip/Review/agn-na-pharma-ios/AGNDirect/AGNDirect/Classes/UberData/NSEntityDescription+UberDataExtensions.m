//
//  NSEntityDescription+UberDataExtensions.m
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-11.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import "NSEntityDescription+UberDataExtensions.h"
#import "UberCoreDataManager.h"

@implementation NSEntityDescription (UberDataExtensions)
+ (NSEntityDescription *)uber_entityForClass:(Class)cls {
	NSManagedObjectModel *model = [UberCoreDataManager defaultManager].managedObjectModel;
	NSString *entityName = NSStringFromClass(cls);
	return [[model entitiesByName] objectForKey:entityName];
}
@end
