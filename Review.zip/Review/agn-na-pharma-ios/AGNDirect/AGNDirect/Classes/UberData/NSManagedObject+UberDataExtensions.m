//
//  NSManagedObject+UberDataExtensions.m
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-10.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import "NSManagedObject+UberDataExtensions.h"
#import "NSEntityDescription+UberDataExtensions.h"
#import "UberCoreDataManager.h"

@implementation NSManagedObject (UberDataExtensions)
+ (NSEntityDescription *)entity {
	return [NSEntityDescription uber_entityForClass:self];
}

+ (NSFetchRequest *)uber_fetchRequestForInstances {
	NSFetchRequest *fetchRequest = [[[NSFetchRequest alloc] init] autorelease];
	[fetchRequest setEntity:[self entity]];

	return fetchRequest;
}

+ (NSArray *)uber_allInstances {
	NSFetchRequest *fetchRequest = [self uber_fetchRequestForInstances];
	NSManagedObjectContext *context = [UberCoreDataManager defaultManager].managedObjectContext;

	return [context executeFetchRequest:fetchRequest error:NULL];
}

+ (NSArray *)uber_allInstancesSortedByDescriptors:(NSArray *)sortDescriptors {
	NSFetchRequest *fetchRequest = [self uber_fetchRequestForInstances];
	NSManagedObjectContext *context = [UberCoreDataManager defaultManager].managedObjectContext;

	[fetchRequest setSortDescriptors:sortDescriptors];

	return [context executeFetchRequest:fetchRequest error:NULL];
}

+ (NSArray *)uber_instancesFilteredByPredicate:(NSPredicate *)predicate {
	NSFetchRequest *fetchRequest = [self uber_fetchRequestForInstances];
	NSManagedObjectContext *context = [UberCoreDataManager defaultManager].managedObjectContext;

	[fetchRequest setPredicate:predicate];

	return [context executeFetchRequest:fetchRequest error:NULL];
}

+ (NSArray *)uber_instancesFilteredByPredicate:(NSPredicate *)predicate sortedByDescriptors:(NSArray *)sortDescriptors {
	NSFetchRequest *fetchRequest = [self uber_fetchRequestForInstances];
	NSManagedObjectContext *context = [UberCoreDataManager defaultManager].managedObjectContext;

	[fetchRequest setPredicate:predicate];
	[fetchRequest setSortDescriptors:sortDescriptors];

	return [context executeFetchRequest:fetchRequest error:NULL];
}

+ (id)uber_managedObjectInsertedIntoCurrentContext {
	NSEntityDescription *entity = [self entity];
	NSManagedObjectContext *context = [UberCoreDataManager defaultManager].managedObjectContext;

	return [[[self alloc] initWithEntity:entity insertIntoManagedObjectContext:context] autorelease];
}

+ (id)uber_managedObjectWithoutContext {
	NSEntityDescription *entity = [self entity];

	return [[[self alloc] initWithEntity:entity insertIntoManagedObjectContext:nil] autorelease];
}

- (id)initWithCoder:(NSCoder *)coder {
	NSEntityDescription *entity = [coder decodeObjectForKey:@"entityDescription"];
	if ((self = [self initWithEntity:entity insertIntoManagedObjectContext:nil])) {
		NSDictionary *dict = [coder decodeObjectForKey:@"propertyValues"];
		if (!dict) {
			[self release];
			return nil;
		}

		[self uber_setValuesFromDictionary:dict];
	}

	return self;
}

- (id)copyWithZone:(NSZone *)zone {
	NSEntityDescription *entity = [self entity];
	NSManagedObjectContext *context = [self managedObjectContext];
	NSManagedObject *copiedObject = [[[self class] allocWithZone:zone] initWithEntity:entity insertIntoManagedObjectContext:context];

	NSDictionary *properties = [entity propertiesByName];
	for (NSString *key in properties) {
		id propertyDescription = [properties objectForKey:key];
		id selfValue = [self valueForKey:key];

		if ([propertyDescription isKindOfClass:[NSRelationshipDescription class]]) {
			/*
			 * There are caveats associated with saving relationships:
			 *
			 * 	One-to-one: The destination object would have to be copied as
			 * 	well. Since a one-to-one relationship is circular by definition,
			 * 	there would need to be a way to prevent infinite recursion.
			 *
			 * 	One-to-many: All of the destination objects would have to be
			 * 	copied as well.
			 *
			 * 	Many-to-one: Generally safe. The destination object must allow
			 * 	an additional object, but the integrity of the relationship is
			 * 	easily maintained.
			 *
			 *	Many-to-many: Generally safe. The destination objects must allow
			 *	an additional object, but the integrity of the relationship is
			 *	easily maintained, and no additional copying should be
			 *	necessary.
			 *
			 * Because of these difficulties, currently only many-to-X
			 * relationships are supported.
			 */
			NSRelationshipDescription *relationship = propertyDescription;
			NSRelationshipDescription *inverseRelationship = [relationship inverseRelationship];

			// if many-to-one or many-to-many...
			if ([inverseRelationship isToMany]) {
				// preserve the relationship
				[copiedObject setValue:selfValue forKey:key];
			}
		} else {
			[copiedObject setValue:selfValue forKey:key];
		}
	}

	return copiedObject;
}

- (void)encodeWithCoder:(NSCoder *)coder {
	[coder encodeObject:[self entity] forKey:@"entityDescription"];

	// although probably less efficient, using a dictionary ensures that we can
	// store nil values properly (since the default value of a given property
	// may not actually be nil, this is useful)

	NSDictionary *dict = [self uber_dictionaryValue];
	if (!dict) {
		NSAssert1(NO, @"Could not create dictionary value for %@", self);
		return;
	}

	[coder encodeObject:dict forKey:@"propertyValues"];
}

- (NSMutableDictionary *)uber_dictionaryValue {
	NSEntityDescription *entity = [self entity];
	NSDictionary *properties = [entity propertiesByName];

	NSMutableDictionary *result = [NSMutableDictionary dictionaryWithCapacity:[properties count]];
	for (NSString *key in properties) {
		id selfValue = [self valueForKey:key];
		[result setValue:selfValue forKey:key];
	}

	return result;
}

- (BOOL)uber_setStringValue:(NSString *)value forKey:(NSString *)key {
	NSDictionary *allProperties = [[self entity] propertiesByName];
	NSAttributeDescription *attribute = [allProperties objectForKey:key];

	// also catches nil (if the property doesn't exist)
	if (![attribute isKindOfClass:[NSAttributeDescription class]]) {
		return NO;
	}

	id parsedValue = nil;
	switch ([attribute attributeType]) {
	case NSStringAttributeType:
	case NSUndefinedAttributeType:
	case NSTransformableAttributeType:
		// try to use the value as-is
		parsedValue = value;
		break;
	
	case NSInteger16AttributeType:
	case NSInteger32AttributeType:
	case NSInteger64AttributeType:
	case NSDecimalAttributeType:
	case NSDoubleAttributeType:
	case NSFloatAttributeType:
		parsedValue = [NSDecimalNumber decimalNumberWithString:value];
		break;
	
	case NSBooleanAttributeType:
		parsedValue = [NSNumber numberWithBool:[value boolValue]];
		break;
	
	case NSBinaryDataAttributeType:
		parsedValue = [value dataUsingEncoding:NSUTF8StringEncoding];
		break;
	
	case NSDateAttributeType:
		{
			NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

			NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
			[formatter setLocale:locale];
			[locale release];

			// ISO 8601
			[formatter setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"];
			[formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];

			parsedValue = [formatter dateFromString:value];
			[formatter release];
		}

		break;
	
	case NSObjectIDAttributeType:
	default:
		// unrecognized/unsupported type
		;
	}

	NSError *error = nil;
	if (!parsedValue || ![self validateValue:&parsedValue forKey:key error:&error])
		return NO;
	
	[self setValue:parsedValue forKey:key];
	return YES;
}

- (void)uber_setValuesFromDictionary:(NSDictionary *)dict {
	NSParameterAssert(dict != nil);

	for (id key in dict) {
		NSString *keyName;
		if ([key isKindOfClass:[NSPropertyDescription class]]) {
			keyName = [key name];
		} else if ([key isKindOfClass:[NSString class]]) {
			keyName = key;
		} else {
			NSAssert(NO, @"keys provided to setValuesFromDictionary: must be strings or property descriptions");
			continue;
		}

		id value = [dict valueForKey:key];
		[self setValue:value forKey:keyName];
	}
}

@end
