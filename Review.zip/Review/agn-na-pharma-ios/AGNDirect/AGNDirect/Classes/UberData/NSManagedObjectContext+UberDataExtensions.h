//
//  NSManagedObjectContext+UberDataExtensions.h
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-10.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import <CoreData/CoreData.h>

/**
 * @ingroup UberData
 *
 * Extensions to the CoreData's \c NSManagedObjectContext.
 */
@interface NSManagedObjectContext (UberDataExtensions)
/**
 * Deletes all of \a objects from the receiver. \a objects, which may be any
 * collection supporting fast enumeration, should only contain instances of \c
 * NSManagedObject or \c NSManagedObjectID.
 */
- (void)uber_deleteObjects:(id)objects;

/**
 * Inserts all of \a objects into the receiver. \a objects, which may be any
 * collection supporting fast enumeration, should only contain instances of \c
 * NSManagedObject.
 */
- (void)uber_insertObjects:(id)objects;

/**
 * Converts all of \a objectIDs into instances of \c NSManagedObject associated
 * with the receiver. \a objectIDs, which may be any collection supporting fast
 * enumeration, should only contain instances of \c NSManagedObjectID.
 *
 * The returned array is guaranteed to have exactly as many items as \a
 * objectIDs.
 */
- (NSArray *)uber_managedObjectsForObjectIDs:(id)objectIDs;

/**
 * Converts all of \a objects into instances of \c NSManagedObjectID. \a
 * objects, which may be any collection supporting fast enumeration, should only
 * contain instances of \c NSManagedObject.
 *
 * The returned array is guaranteed to have exactly as many items as \a objects.
 */
- (NSArray *)uber_objectIDsForManagedObjects:(id)objects;

/**
 * Attempts to save this managed object context using the specified merge
 * policy. If an error occurs, \c NO is returned and \a error (if provided) is
 * populated with information about the error that occurred.
 *
 * The merge policy specified is used only for this save operation. The merge
 * policy of the context before saving is restored afterward, regardless of
 * success or failure.
 */
- (BOOL)uber_saveWithMergePolicy:(id)mergePolicy error:(NSError **)error;
@end
