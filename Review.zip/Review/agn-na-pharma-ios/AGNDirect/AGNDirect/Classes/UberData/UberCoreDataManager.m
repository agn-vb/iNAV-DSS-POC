//
//  UberCoreDataManager.m
//  UberData
//
//  Created by Justin Spahr-Summers on 2010-12-10.
//  Copyright 2010 Übermind, Inc. All rights reserved.
//

#import "UberCoreDataManager.h"
#import "NSManagedObjectContext+UberDataExtensions.h"
#import "UIApplication+UberFoundationExtensions.h"
#import <libkern/OSAtomic.h>

////UberLoggingFeatureComponent(UberData, UberCoreDataManager);

@interface UberCoreDataManager () {
	NSManagedObjectModel * volatile m_managedObjectModel;
	NSPersistentStoreCoordinator * volatile m_persistentStoreCoordinator;

	CFMutableDictionaryRef managedObjectContextsByThread;
	NSLock *managedObjectContextsLock;

	// ivars associated with synthesized properties are purposely not defined
}

@property (nonatomic, retain) NSManagedObjectContext *mainThreadContext;

- (void)savePointNotification:(NSNotification *)notification;
@end

@implementation UberCoreDataManager
+ (UberCoreDataManager *)defaultManager {
	static id singleton = nil;
	static dispatch_once_t pred;

	dispatch_once(
		&pred,
		^{ singleton = [[self alloc] init]; }
	);

	return singleton;
}

@dynamic managedObjectModel;
@dynamic persistentStoreCoordinator;
@dynamic managedObjectContext;

- (NSManagedObjectModel *)managedObjectModel {
	NSManagedObjectModel *model = m_managedObjectModel;
	if (!model) {
		NSManagedObjectModel *defaultModel = [NSManagedObjectModel mergedModelFromBundles:nil];

		if (!defaultModel) {
			//UberLogWarning(@"Could not construct a default managed object model by merging models in the main bundle");
			return nil;
		}

		// try to install the default model, or use one installed in the
		// interim, but never return nil
		for (;;) {
			NSManagedObjectModel *readModel = m_managedObjectModel;
			if (readModel) {
				model = readModel;
				break;
			}

			if (OSAtomicCompareAndSwapPtrBarrier(nil, defaultModel, (void * volatile *)&m_managedObjectModel)) {
				// only retain once successfully installed
				model = [defaultModel retain];
				break;
			}
		}
	}

	return model;
}

- (void)setManagedObjectModel:(NSManagedObjectModel *)newModel {
	// pre-emptively retain the new model
	[newModel retain];

	for (;;) {
		NSManagedObjectModel *previousModel = m_managedObjectModel;
		if (OSAtomicCompareAndSwapPtrBarrier(previousModel, newModel, (void * volatile *)&m_managedObjectModel)) {
			// if the new model was installed successfully, release the old one
			[previousModel autorelease];
			break;
		}
	}
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator 
{
	NSPersistentStoreCoordinator *coordinator = m_persistentStoreCoordinator;
	if (!coordinator) 
	{
		NSBundle *bundle = [NSBundle mainBundle];
		NSString *bundleName = [bundle objectForInfoDictionaryKey:(NSString *)kCFBundleNameKey];
		
		if (!bundleName) 
		{
			bundleName = [bundle objectForInfoDictionaryKey:@"CFBundleDisplayName"];
			
			if (!bundleName) 
			{
				//UberLogWarning(@"Could not get bundle name from Info.plist keys in order to create default persistent store");

				// fall back to a stupid name
				bundleName = @"CoreData";
			}
		}

		NSString *storeName = [[NSString alloc] initWithFormat:@"%@.sqlite", bundleName];
		
		NSPersistentStoreCoordinator *defaultCoordinator = [self persistentStoreCoordinatorNamed:storeName];
		[storeName release];

		// try to install the default coordinator, or use one installed in the
		// interim, but never return nil
		for (;;) {
			NSPersistentStoreCoordinator *readCoordinator = m_persistentStoreCoordinator;
			if (readCoordinator) {
				coordinator = readCoordinator;
				break;
			}

			if (OSAtomicCompareAndSwapPtrBarrier(nil, defaultCoordinator, (void * volatile *)&m_persistentStoreCoordinator)) {
				// only retain once successfully installed
				coordinator = [defaultCoordinator retain];
				break;
			}
		}
	}

	return coordinator;
}

- (void)setPersistentStoreCoordinator:(NSPersistentStoreCoordinator*)newCoordinator 
{
	// pre-emptively retain the new coordinator
	[newCoordinator retain];

	for (;;) {
		NSPersistentStoreCoordinator *previousCoordinator = m_persistentStoreCoordinator;
		if (OSAtomicCompareAndSwapPtrBarrier(previousCoordinator, newCoordinator, (void * volatile *)&m_persistentStoreCoordinator)) {
			// if the new coordinator was installed successfully, release the old one
			[previousCoordinator release];
			break;
		}
	}
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinatorNamed:(NSString*)storeName
{
	//UberLogDebug(@"app: %@", [UIApplication sharedApplication]);
	
	NSString *storePath = [UIApplication uber_applicationSupportDirectoryPath];
	//UberLogDebug(@"storePath: %@", storePath);
	
	//UberLogDebug(@"storeName: %@", storeName);
	storePath = [storePath stringByAppendingPathComponent:storeName];
	
	//UberLogDebug(@"new storePath: %@", storePath);
	
	NSManagedObjectModel *model = self.managedObjectModel;
	NSPersistentStoreCoordinator *defaultCoordinator = [[[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model] autorelease];
	
	if (!defaultCoordinator) {
		// if the coordinator couldn't be created, error out
		//UberLogWarning(@"Could not create a default persistent store coordinator using model %@", model);
		return nil;
	}
	
	NSError *error = nil;
	NSURL *storeURL = [NSURL fileURLWithPath:storePath isDirectory:NO];
	NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
							 [NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption,
							 [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption, nil];
	
	if (![defaultCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:options error:&error]) {
		// if a persistent store couldn't be added, error out
		//UberLogWarning(@"Could not create a persistent SQLite store at %@ using coordinator %@", storeURL, defaultCoordinator);
		return nil;
	}    
	
	// try to install the default coordinator, or use one installed in the
	// interim, but never return nil
	return defaultCoordinator;
}

- (NSManagedObjectContext *)managedObjectContext {
	if ([NSThread isMainThread]) {
		// the main thread is a special case, mainly because its managed object
		// context doesn't ever really need to be deallocated, but also because
		// we want a quick reference to it to save if necessary
		if (!self.mainThreadContext) {
			NSManagedObjectContext *context = [[NSManagedObjectContext alloc] init];
			[context setPersistentStoreCoordinator:self.persistentStoreCoordinator];

			self.mainThreadContext = context;
			[context release];
		}

		return self.mainThreadContext;
	}

	/*
	 * The rest of this method deals with obtaining managed object contexts for
	 * background threads. The approach for doing this deserves some
	 * explanation.
	 *
	 * Basically, we use a mutable dictionary (managedObjectContextsByThread) to
	 * associate a given NSThread object with an NSManagedObjectContext for that
	 * thread, created on demand. When we receive notification of a thread
	 * exiting, that entry in the dictionary is deleted, and the context thus
	 * destroyed.
	 *
	 * This is all well and good, but Core Data goes to great lengths to prevent
	 * NSManagedObjectContexts from being used across threads. When a thread
	 * "finishes," any associated MOCs still alive will be released automagically
	 * by Core Data. This is fine (and perhaps even beneficial) in most cases,
	 * but NSOperationQueues throw a monkey wrench into this behavior because
	 * of how they pseudo-recycle threads. It turns out that this thread
	 * "recycling" will destroy any MOCs, for instance, but NOT destroy certain
	 * thread-specific information, like the NSThread object, or the object's
	 * -threadDictionary, and it won't post notifications about thread exit.
	 *
	 * Because we store threads and MOCs in a shared data structure, we are
	 * subject to this problem too. Rather than trying to prevent Core Data from
	 * doing the releasing thing (which may not even be possible), we simply
	 * retain MOCs twice. If we thereafter find a MOC which has a retain count
	 * less than two, we know that Core Data attempted to destroy it, and we
	 * therefore discard it and create another. If a thread cleanly exits, we
	 * make sure to release the MOC twice to match its instantiation.
	 */
	
	NSThread *thread = [NSThread currentThread];
	//UberLogDebug(@"thread: %@", thread);

	NSManagedObjectContext *context = nil;

	// synchronize on this lock to prevent multiple threads from accessing the
	// mutable dictionary of managed object contexts
	[managedObjectContextsLock lock];

	// check our dictionary for a managed object context associated with the
	// current thread
	if (managedObjectContextsByThread) {
		context = (id)CFDictionaryGetValue(managedObjectContextsByThread, thread);

		//UberLogDebug(@"context: %@", context);
	} else {
		//UberLogDebug(@"creating managedObjectContextsByThread dictionary");

		// if the dictionary hasn't been created yet, do that now
		// use default memory management semantics for both keys (NSThreads) and
		// values (NSManagedObjectContexts)
		managedObjectContextsByThread = CFDictionaryCreateMutable(
			NULL,
			0,
			&kCFTypeDictionaryKeyCallBacks,
			&kCFTypeDictionaryValueCallBacks
		);
	}

	if ([context retainCount] == 1) {
		// if the retain count of the context is 1, that means that Core Data
		// released it for us behind our back (how nice)
		//UberLogDebug(@"context %@ was released by Core Data directly, tearing it down", context);

		// fully tear it down (decrementing the retain count as part of this
		// removal)
		CFDictionaryRemoveValue(managedObjectContextsByThread, thread);
		context = nil;
	}

	if (!context) {
		// if no context already exists for this thread, create one
		context = [[[NSManagedObjectContext alloc] init] autorelease];

		//UberLogDebug(@"creating new context: %@", context);

		NSPersistentStoreCoordinator *coordinator = self.persistentStoreCoordinator;
		//UberLogDebug(@"persistent store coordinator: %@", coordinator);

		[context setPersistentStoreCoordinator:coordinator];

		// associate the new context with this thread in the
		// managedObjectContexts dictionary
		CFDictionarySetValue(
			managedObjectContextsByThread,
			thread,
			context
		);

		/*
		 * Context purposely has a retain count of 2 after this line:
		 * 	1	alloc
		 * 	0	autorelease
		 * 	1	CFDictionarySetValue()
		 * 	2 	retain
		 * 
		 * We do this to detect Core Data destroying it behind-the-scenes without
		 * hitting an EXC_BAD_ACCESS. It's fully released either when we discover
		 * this case (above) or when the thread exits cleanly
		 * (in -threadWillExit:).
		 *
		 * Note that performSelector: is used to prevent Clang from complaining
		 * about this false positive.
		 */
		[context performSelector:@selector(retain)];

		// watch for this thread to exit so that we can release the context at
		// that time
		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(threadWillExit:)
			name:NSThreadWillExitNotification
			object:thread
		];
	}

	[managedObjectContextsLock unlock];

	// verify that we actually have a MOC (which might not be the case during
	// cases of crazy thread-stomping)
	if (![context isKindOfClass:[NSManagedObjectContext class]]) {
		//UberLogCritical(@"object retrieved from managedObjectContextsByThread is not an NSManagedObjectContext -- this may be a result of memory corruption!");

		// returning nil may break some things, but not as much as returning an
		// object of a different class
		context = nil;
	}

	return context;
}

@synthesize mainThreadContext;
@synthesize automaticallySaveMainThreadContext;
@synthesize automaticallyMergeChangesIntoMainThreadContext;

- (id)init {
  	if ((self = [super init])) {
		managedObjectContextsLock = [[NSLock alloc] init];

		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(savePointNotification:)
			name:UIApplicationWillResignActiveNotification
			object:nil
		];

		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(savePointNotification:)
			name:UIApplicationWillTerminateNotification
			object:nil
		];

		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(mergeChanges:)
			name:NSManagedObjectContextDidSaveNotification
			object:nil
		];
	}

	return self;
}

- (void)dealloc {
	// now might be a good time to attempt a save
	[self savePointNotification:nil];

	[[NSNotificationCenter defaultCenter] removeObserver:self];

	if (managedObjectContextsByThread) {
		CFRelease(managedObjectContextsByThread);
		managedObjectContextsByThread = NULL;
	}

  	self.managedObjectModel = nil;
	self.persistentStoreCoordinator = nil;
	self.mainThreadContext = nil;

	[managedObjectContextsLock release]; managedObjectContextsLock = nil;
	[super dealloc];
}

#pragma mark Notifications

- (void)savePointNotification:(NSNotification *)notification {
	if (![NSThread isMainThread]) {
		[self performSelectorOnMainThread:@selector(savePointNotification:) withObject:notification waitUntilDone:YES];
		return;
	}

	if (self.automaticallySaveMainThreadContext && self.mainThreadContext) {
		NSError *error = nil;
		if (![self.mainThreadContext uber_saveWithMergePolicy:NSErrorMergePolicy error:&error]) {
			//UberLogError(@"Could not save main thread managed object context: %@", error);
		}
	}
}

- (void)mergeChanges:(NSNotification *)notification {
	if (![NSThread isMainThread]) {
		[self performSelectorOnMainThread:@selector(mergeChanges:) withObject:notification waitUntilDone:NO];
		return;
	}

	// disregard the changes if we're not supposed to auto-merge, or if the save
	// came from the main thread context itself
	if (self.automaticallyMergeChangesIntoMainThreadContext && [notification object] != self.mainThreadContext) {
		// notify the main thread context
		[self.mainThreadContext mergeChangesFromContextDidSaveNotification:notification];
	}
}

- (void)threadWillExit:(NSNotification *)notification {
  	NSThread *thread = [notification object];
	//UberLogDebug(@"removing %@ from managedObjectContextsByThread dictionary", thread);

	[managedObjectContextsLock lock];

	// we doubly-retain the managed object context (the reasons for which are
	// explained in -managedObjectContext), so we need to fully release it right
	// now if necessary
	NSManagedObjectContext *context = (id)CFDictionaryGetValue(managedObjectContextsByThread, thread);

	// if the retain count is already less than 2, we assume that Core Data
	// released it already, so we (obviously) can't release it twice without
	// causing problems
	if ([context retainCount] >= 2) {
		//UberLogDebug(@"doubly-releasing %@ to match its allocation", context);
		
		// counteract our original double-retain
		[context performSelector:@selector(release)];
	}

	// release our last ownership of the MOC by removing it from the dictionary
	// 
	// even if the resultant retain count is still >= 2, we assume that it's
	// the result of external memory management, and will eventually be
	// corrected
	CFDictionaryRemoveValue(managedObjectContextsByThread, thread);

	[managedObjectContextsLock unlock];

	// and, finally, de-register for any further notifications from this thread
	[[NSNotificationCenter defaultCenter]
		removeObserver:self
		name:nil
		object:thread
	];
}

@end
