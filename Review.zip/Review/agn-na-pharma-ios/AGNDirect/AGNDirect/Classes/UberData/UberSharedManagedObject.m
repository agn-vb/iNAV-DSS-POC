//
//  UberSharedManagedObject.m
//  UberData
//
//  Created by Justin Spahr-Summers on 2011-04-12.
//  Copyright 2011 Übermind, Inc. All rights reserved.
//

#import "UberSharedManagedObject.h"
#import "UberCoreDataManager.h"
#import <objc/runtime.h>

//#import <UberFoundation///UberLogging.h>

////UberLoggingFeatureComponent(UberData, UberSharedManagedObject);

@interface UberSharedManagedObject () {
	NSManagedObjectID *m_objectID;
}

- (NSManagedObject *)managedObjectForCurrentThread;

@end

@implementation UberSharedManagedObject
@synthesize objectID = m_objectID;

+ (id)sharedManagedObjectWithManagedObject:(NSManagedObject *)managedObject {
	return [[[self alloc] initWithManagedObject:managedObject] autorelease];
}

+ (id)sharedManagedObjectWithManagedObjectID:(NSManagedObjectID *)managedObjectID {
	return [[[self alloc] initWithManagedObjectID:managedObjectID] autorelease];
}

- (id)initWithManagedObject:(NSManagedObject *)managedObject {
	NSParameterAssert(managedObject != nil);

//	//UberLogDebug(@"ID: %@", [managedObject objectID]);
	if ([[managedObject objectID] isTemporaryID]) {
		NSManagedObjectContext *context = [managedObject managedObjectContext];
		if (!context) {
//			//UberLogError(@"Cannot create a shared managed object for %@ not in a context", managedObject);
			[[super init] release];
			return nil;
		}

		NSError *error = nil;
		NSArray *objects = [[NSArray alloc] initWithObjects:managedObject, nil];
		BOOL success = [context obtainPermanentIDsForObjects:objects error:&error];
		[objects release];

		if (!success) {
//			//UberLogDebug(@"[[managedObject objectID] persistentStore]: %@", [[managedObject objectID] persistentStore]);

//			//UberLogError(@"Cannot make ID of managed object %@ permanent: %@", managedObject, error);
			[[super init] release];
			return nil;
		}
	}

	return [self initWithManagedObjectID:[managedObject objectID]];
}

- (id)initWithManagedObjectID:(NSManagedObjectID *)managedObjectID {
	NSParameterAssert(managedObjectID != nil);

//	//UberLogDebug(@"managedObjectID: %@", managedObjectID);

	if ((self = [super init])) {
		if ([managedObjectID isTemporaryID]) {
//			//UberLogError(@"Cannot create a shared managed object on a temporary object ID");
			[self release];
			return nil;
		}

		m_objectID = [managedObjectID retain];
	}

	return self;
}

- (void)dealloc {
	[m_objectID release];
	[super dealloc];
}

- (NSManagedObject *)managedObjectForCurrentThread {
	NSManagedObjectContext *context = [UberCoreDataManager defaultManager].managedObjectContext;
	NSManagedObject *obj = [context objectWithID:m_objectID];
	[context refreshObject:obj mergeChanges:YES];

	return obj;
}

#pragma mark NSObject protocol

- (BOOL)conformsToProtocol:(Protocol *)aProtocol {
	// short-circuit known cases
	if ([super conformsToProtocol:aProtocol])
		return YES;
	
	return [[self managedObjectForCurrentThread] conformsToProtocol:aProtocol];
}

- (NSString *)description {
	return [[self managedObjectForCurrentThread] description];
}

- (NSUInteger)hash {
	return [[self managedObjectForCurrentThread] hash];
}

- (BOOL)isEqual:(id)anObject {
  	if (self == anObject) {
		// short-circuit identity
		return YES;
	}

	return [[self managedObjectForCurrentThread] isEqual:anObject];
}

- (BOOL)isKindOfClass:(Class)class {
	// short-circuit known cases
	if ([super isKindOfClass:class] || [class isEqual:[NSManagedObject class]])
		return YES;
	
	return [[self managedObjectForCurrentThread] isKindOfClass:class];
}

- (BOOL)isMemberOfClass:(Class)class {
	// short-circuit known cases
	if ([super isMemberOfClass:class])
		return YES;
	
	return [[self managedObjectForCurrentThread] isMemberOfClass:class];
}

- (BOOL)isProxy {
  	return YES;
}

- (BOOL)respondsToSelector:(SEL)aSelector {
	if ([object_getClass(self) instancesRespondToSelector:aSelector]) {
		// return YES for any method implemented in this class or the NSObject
		// protocol
		return YES;
	}

	return [[self managedObjectForCurrentThread] respondsToSelector:aSelector];
}

#pragma mark Forwarding

- (void)forwardInvocation:(NSInvocation *)anInvocation {
	[anInvocation invokeWithTarget:[self managedObjectForCurrentThread]];
}

- (id)forwardingTargetForSelector:(SEL)aSelector {
	return [self managedObjectForCurrentThread];
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector {
	// obtain the method signature for any method implemented in this class or
	// the NSObject protocol
	NSMethodSignature *signature = [object_getClass(self) instanceMethodSignatureForSelector:aSelector];
	if (signature)
		return signature;

	return [[self managedObjectForCurrentThread] methodSignatureForSelector:aSelector];
}
@end
