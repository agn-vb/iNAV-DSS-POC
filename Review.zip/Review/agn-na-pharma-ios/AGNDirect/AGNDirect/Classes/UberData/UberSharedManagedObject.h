//
//  UberSharedManagedObject.h
//  UberData
//
//  Created by Justin Spahr-Summers on 2011-04-12.
//  Copyright 2011 Übermind, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

/**
 * @ingroup UberData
 *
 * Semi-transparently proxies a managed object across thread boundaries, to make
 * multithreaded uses of Core Data easier. Instances of this class can be used
 * as if they were instances of the \c NSManagedObject used at the time of
 * initialization. This class will use the managed object contexts set up by the
 * shared #UberCoreDataManager in order to obtain a version of the managed
 * object for each thread.
 *
 * Note that this class does not (and cannot) maintain outstanding changes
 * between threads. You are still responsible for saving a thread's managed
 * object context when finishing a set of modifications. This class will,
 * however, always use the latest version of the object present in the
 * persistent store.
 */
@interface UberSharedManagedObject : NSObject {
}

/**
 * The ID for the managed object proxied by this object.
 */
@property (nonatomic, readonly) NSManagedObjectID *objectID;

/**
 * Returns a shared managed object initialized with #initWithManagedObject:.
 */
+ (id)sharedManagedObjectWithManagedObject:(NSManagedObject *)managedObject;

/**
 * Returns a shared managed object initialized with #initWithManagedObjectID:.
 */
+ (id)sharedManagedObjectWithManagedObjectID:(NSManagedObjectID *)managedObjectID;

/**
 * Initializes this shared managed object to proxy \a managedObject. \a
 * managedObject must be inserted into a managed object context, though not
 * necessarily saved yet. If its current managed object ID is temporary,
 * a permanent one is obtained.
 */
- (id)initWithManagedObject:(NSManagedObject *)managedObject;

/**
 * Initializes this shared managed object to proxy the managed object identified
 * with \a managedObjectID. \a managedObjectID must be a permanent ID.
 *
 * This is the designated initializer for this class.
 */
- (id)initWithManagedObjectID:(NSManagedObjectID *)managedObjectID;

/**
 * Returns the managed object proxied by the receiver, as it exists in the
 * UberCoreDataManager#managedObjectContext for the current thread. The returned
 * object will not include outstanding changes from other managed object
 * contexts. The returned object will not automatically update if other managed
 * object contexts are saved, but may be updated if this method is invoked again
 * or the receiver is used in its capacity as a proxy.
 */
- (NSManagedObject *)managedObjectForCurrentThread;

@end
