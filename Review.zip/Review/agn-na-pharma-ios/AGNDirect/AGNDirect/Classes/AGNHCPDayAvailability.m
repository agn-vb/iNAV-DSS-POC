//
//  AGNHCPDayAvailability.m
//  TestApp
//
//  Created by Adam McLain on 10/18/12.
//  Copyright (c) 2012 AdamMcLain. All rights reserved.
//

#import "AGNHCPDayAvailability.h"

@implementation AGNHCPDayAvailability

- (BOOL)isUnavailable {
    if (self.startTime == nil || self.endTime == nil) {
        return YES;
    }
    
    return NO;
}

- (void)setUnavailable {
    self.startTime = nil;
    self.endTime = nil;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@ %@ %@", self.day, [self.startTime descriptionWithLocale:[NSLocale systemLocale]], [self.endTime descriptionWithLocale:[NSLocale systemLocale]]];
}

@end
