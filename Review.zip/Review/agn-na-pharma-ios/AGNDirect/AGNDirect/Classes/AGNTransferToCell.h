//
//  AGNTransferToCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSimplePopoverTableViewController.h"

static NSString *AGNTransferToSelectedNotificationKey = @"AGNTransferToSelectedNotificationKey";


@interface AGNTransferToCell : UITableViewCell <UITextFieldDelegate,AGNPopoverDelegate,UISearchBarDelegate>
@property (weak, nonatomic) IBOutlet UILabel *transferToNameLabel;
@property (weak, nonatomic) IBOutlet UITextField *transferNumberTextField;
@property (strong, nonatomic) AGNSampleInventoryTransaction *transaction;
@property (strong, nonatomic) NSMutableArray *filteredReps;
@property (weak, nonatomic) AGNSimplePopoverTableViewController *popover;
@property (weak, nonatomic) IBOutlet UILabel *transferToLabel;
@property (weak, nonatomic) IBOutlet UILabel *transferNumberLabel;
@property (weak, nonatomic) IBOutlet UITextField *toNameTextField;
@end
