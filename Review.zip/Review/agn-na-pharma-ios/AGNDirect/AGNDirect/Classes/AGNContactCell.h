//
//  AGNContactCell.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNContactCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *contactCategoryLabel;
@property (strong, nonatomic) IBOutlet UILabel *contactDetailLabel;

+ (CGFloat)heightForAttributedString:(NSAttributedString *)string withWidth:(CGFloat)width;
+ (CGFloat)heightForString:(NSString *)string withWidth:(CGFloat)width;
@end
