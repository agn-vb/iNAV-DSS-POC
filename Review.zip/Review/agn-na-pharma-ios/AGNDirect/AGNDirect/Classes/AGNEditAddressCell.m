//
//  AGNEditAddressCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNEditAddressCell.h"
#import "AGNAddressCell.h"
#import "AGNCategoryHeaders.h"
#import "AGNSuppressedAddress.h"
#import <MapKit/MapKit.h>
#import <AddressBook/ABPerson.h>

@implementation AGNEditAddressCell

@synthesize address = _address;
@synthesize isSelected;
@synthesize addressView;
@synthesize addressLabel;
@synthesize eligibilityLabel;
@synthesize eligibilityImageView;
@synthesize officeHoursView;
@synthesize officeHoursEditView;
@synthesize editMode=_editMode;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self agnSetStyledSelectedBackground];
        self.addressView = [[UIView alloc] init];
        [self.contentView addSubview:self.addressView];
        self.addressLabel = [[UILabel alloc] init];
        self.addressLabel.font = [UIFont AGNAvenirHeavy16];
        self.addressLabel.textColor = [UIColor AGNGreyMatter];
        [self.addressLabel setHighlightedTextColor:[UIColor AGNHighliteWhite]];
        self.addressLabel.backgroundColor = [UIColor clearColor];
        self.addressLabel.numberOfLines = 0;
        [self.addressView addSubview:self.addressLabel];
        self.eligibilityLabel = [[UILabel alloc] init];
        self.eligibilityLabel.font = [UIFont AGNAvenirRoman16];
        self.eligibilityLabel.textColor = [UIColor AGNSecondGrayd];
        [self.eligibilityLabel setHighlightedTextColor:[UIColor AGNSilberLining]];
        self.eligibilityLabel.backgroundColor = [UIColor clearColor];
        self.eligibilityImageView = [[UIImageView alloc] init];
        [self.addressView addSubview:self.eligibilityImageView];
        [self.addressView addSubview:self.eligibilityLabel];
        
        [self.addressView setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.addressLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.eligibilityLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.eligibilityImageView setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        NSDictionary *views =
        @{
        @"addressView" : self.addressView ,
        @"addressLabel" : self.addressLabel ,
        @"eligibilityLabel" : self.eligibilityLabel ,
        @"eligibilityImageView" : self.eligibilityImageView         };
        UIView *parentView = self.addressView;
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-[addressView]-|" options:0 metrics:nil views:views]];
        NSString *constraint = [NSString stringWithFormat:@"V:|[addressView(==%f)]", kEditAddressCellHeight];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:constraint options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[addressLabel(>=5)]-[eligibilityImageView(==23)]-8-[eligibilityLabel(==125)]|" options:0 metrics:nil views:views]];
        [self.addressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(>=8)-[addressLabel]-|" options:0 metrics:nil views:views]];
        [self.addressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(>=8)-[eligibilityLabel]-|" options:0 metrics:nil views:views]];
        [self.addressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[eligibilityImageView(==23)]" options:0 metrics:nil views:views]];
        [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.eligibilityLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.eligibilityImageView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0.0]];

    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];

    self.address = nil;
    self.isSelected = NO;
}

- (void)setAddress:(AGNAddress *)address {
    _address = address;
    self.addressLabel.text = address.multiLineFormattedStringWithPhone;
    self.eligibilityLabel.text = address.canSample ? @"SAMPLING" : @"NO SAMPLING";
    self.eligibilityImageView.image = address.canSample ? [UIImage imageNamed:@"thumb_up"] : [UIImage imageNamed:@"thumb_dn"];
}




@end
