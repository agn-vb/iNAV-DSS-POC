//
//  AGNAddressAvailabilityCell.h
//  AGNDirect
//
//  Created by Adam McLain on 10/25/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNAvailabilityGrid.h"
#import "AGNAddressCell.h"

#define kAddressCellGridHeight 118.0f
#define kAddressAvailabilityCellHeight (kAddressCellHeight + kAddressCellGridHeight)

@interface AGNAddressAvailabilityCell : AGNAddressCell
@property (strong, nonatomic) AGNAvailabilityGrid *gridView;
@end
