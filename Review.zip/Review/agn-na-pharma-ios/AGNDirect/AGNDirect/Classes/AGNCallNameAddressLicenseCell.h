//
//  AGNCallNameAddressLicenseCell.h
//  AGNDirect
//
//  Created by Mark Wells on 8/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNCallNameAddressLicenseCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UILabel *licenseLabel;

@end
