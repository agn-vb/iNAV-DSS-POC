//
//  UITableViewCell+UITableViewCell_AGNTableViewCell.m
//  AGNDirect
//
//  Created by Adam McLain on 9/27/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "UITableViewCell+UITableViewCell_AGNTableViewCell.h"

@implementation UITableViewCell (UITableViewCell_AGNTableViewCell)

- (void)agnSetStyledSelectedBackground {
    UIImage *backgroundImage = [[UIImage imageNamed:@"selcell"] resizableImageWithCapInsets:UIEdgeInsetsMake(0.0f, 4.0f, 0.0f, 0.0f)];
    UIImageView *background = [[UIImageView alloc] initWithImage:backgroundImage];
    self.selectedBackgroundView = background;
}

@end
