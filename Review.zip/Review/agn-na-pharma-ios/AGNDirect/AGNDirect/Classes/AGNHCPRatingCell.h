//
//  AGNHCPRatingCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITableViewCell+UITableViewCell_AGNTableViewCell.h"

@interface AGNHCPRatingCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *salesTeamLabel;
@property (strong, nonatomic) IBOutlet UILabel *frequencyLabel;
@property (strong, nonatomic) IBOutlet UILabel *ratingLabel;

-(void)setPrimarySalesTeam:(BOOL)primary;
@end
