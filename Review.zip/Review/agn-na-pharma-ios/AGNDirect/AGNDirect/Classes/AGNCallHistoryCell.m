//
//  AGNClosedCallCell.m
//  AGNDirect
//
//  Created by Adam McLain on 8/8/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCallHistoryCell.h"
#import "AGNCategoryHeaders.h"

@implementation AGNCallHistoryCell
@synthesize mainLabel;
@synthesize secondaryLabel;

#define kCallHistoryMarginWidth 44.0f
#define kCallHistoryMarginHeight 12.0f

+ (CGFloat)heightForAttributedString:(NSAttributedString *)anAttributedString withWidth:(CGFloat)width {
    UIFont *mainFont = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    
    // Magic number: content view is smaller due to disclosure accessory view
    CGFloat chevronWidth = 9.0f;
    CGFloat adjustedWidth = width - kCallHistoryMarginWidth * 2 - chevronWidth;
    CGSize maxSize = CGSizeMake(adjustedWidth, CGFLOAT_MAX);
    
    UILabel *label = [[UILabel alloc] init];
    label.numberOfLines = 0;
    label.attributedText = anAttributedString;
    
    CGSize detailSize = [label sizeThatFits:maxSize];
    
    return mainFont.pointSize + detailSize.height + kCallHistoryMarginHeight * 2 + 1;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (!(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        return nil;
    }
    
    [self agnSetStyledSelectedBackground];
    
    UILabel *aMainLabel = [[UILabel alloc] init];
    self.mainLabel  = aMainLabel;
    self.mainLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.mainLabel.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    [self.contentView addSubview:self.mainLabel];
    self.mainLabel.textColor = [UIColor AGNGreyMatter];
    self.mainLabel.highlightedTextColor = [UIColor whiteColor];
    self.mainLabel.backgroundColor = [UIColor clearColor];
    
    UILabel *aSecondaryLabel = [[UILabel alloc] init];
    self.secondaryLabel = aSecondaryLabel;
    self.secondaryLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.secondaryLabel.font = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    [self.contentView addSubview:self.secondaryLabel];
    self.secondaryLabel.textColor = [UIColor AGNSecondGrayd];
    self.secondaryLabel.highlightedTextColor = [UIColor AGNSilberLining];
    self.secondaryLabel.numberOfLines = 0;
    self.secondaryLabel.backgroundColor = [UIColor clearColor];
    
    NSDictionary *views = NSDictionaryOfVariableBindings(aMainLabel, aSecondaryLabel);
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[aMainLabel]-22-|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[aSecondaryLabel]-22-|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-12-[aMainLabel(16)][aSecondaryLabel]-6-|" options:0 metrics:nil views:views]];
    
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return self;
}


-(void)prepareForReuse{
    [super prepareForReuse];

    self.selectionStyle = UITableViewCellSelectionStyleGray;
    [self agnSetStyledSelectedBackground];
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
