//
//  AGNHourSelectionCell.h
//  AGNDirect
//
//  Created by Adam McLain on 10/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNDualSlider.h"
#import "AGNHCPDayAvailability.h"

@interface AGNHourSelectionCell : UITableViewCell
@property (strong, nonatomic, readonly) UILabel *day;
@property (strong, nonatomic, readonly) AGNDualSlider *hourSlider;
@property (strong, nonatomic, readonly) UISwitch *inOutSwitch;
@property (strong, nonatomic) AGNHCPDayAvailability *availability;
@end
