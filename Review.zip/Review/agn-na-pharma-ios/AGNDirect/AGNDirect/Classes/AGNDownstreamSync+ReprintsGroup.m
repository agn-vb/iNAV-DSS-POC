//
//  AGNDownstreamSync+ReprintsGroup.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/10/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNDownstreamSync+ReprintsGroup.h"
#import "AGNAPC.h"
#import "AGNMarketingCollateral.h"
#import "AGNMarketingDisbursement.h"
#import "NSManagedObjectContext+DDSFExtensions.h"
#import "NSArray+AGNOnConvert.h"


@implementation AGNDownstreamSync (ReprintsGroup)

 - (DDSFSyncItem*)reprintsGroup {
    __weak AGNDownstreamSync * _self = self;

    NSInteger numMonthsOfCallHistoryToRetrieve = [AGNAppDelegate sharedDelegate].monthsCallHistory;
    NSDate * earliestDate = [NSDate dateWithTimeIntervalSinceNow:(-numMonthsOfCallHistoryToRetrieve*30*24*3600)];
    NSString * earliestDateString = [earliestDate agnRFC3339FormattedTimestampString];

    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];

    DDSFSyncStep * full = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return nil;

        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"MarketingQueryString.txt", earliestDateString, nil];
    }];
    full.name = @"full-marketing";

    full.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        NSArray *reprintRecords = (NSArray *)json[@"records"];
        [self addEntities:reprintRecords withName:@"AGNMarketingDisbursement"];

        for (NSDictionary *record in reprintRecords) {
            NSDictionary *contents = (NSDictionary *) record[@"Marketing_Contents__r"];
            if (contents && ![contents isEqual:[NSNull null]]) {
                [_self addEntities:contents[@"records"] withName:@"AGNMarketingCollateral"];
            }
        }

    };

    [group setSteps:@[full] forMode:kDDSFDownstreamSyncModeFull];
   // [group setSteps:@[full] forMode:kDDSFDownstreamSyncModeIncremental];
     ///services/apexrest/FetchRecordIds?syncobject=Request_Form__c&createdDate=2013-08-06T00:00:00.000Z&salesTeam=SF10

     // applySharing means respect security / sharing rules
     NSString * path = [NSString stringWithFormat:@"/services/apexrest/FetchRecordIds?syncobject=Marketing_Disbursement__c&applySharing=true&createdDate=%@",earliestDateString];
     DDSFSyncStep * idService = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest getRequestForPath:path]];



     //    DDSFSyncStep * ids = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
     //        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
     //            return nil;
     //
     //        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"MarketingIDsQueryString.txt", earliestDateString, nil];
     //    }];
     idService.name = @"delta-reprint-ids";

     idService.onConvert = ^(NSArray * array) {
         return [array AGNconvertResponseToDictionaryWithKey:@"ids"];
     };

     idService.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
         if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
             return;

         log4Info(@"==> reprint ids fetched");

         NSMutableSet * serverIds = [NSMutableSet setWithArray:json[@"ids"]];

         if(serverIds.count>AGNMaxGenericIDs){
             _self.deletedReprintIds=nil;
             _self.remainingReprintIds=nil;
             _self.addedReprintIds=nil;
         }else{

             NSSet * localIds = [_self.managedContext ddsf_idsForAllEntitiesNamed:@"AGNMarketingDisbursement"];

             // Identify reprints to delete
             _self.deletedReprintIds = [NSMutableSet setWithSet:localIds];
             [_self.deletedReprintIds minusSet:serverIds];

             // Remaining is everything we don't have as of right now
             _self.remainingReprintIds = serverIds;
             [_self.remainingReprintIds minusSet:localIds];

             _self.addedReprintIds = [NSSet setWithSet:_self.remainingReprintIds]; // All of these are not present locally, and we need to preserve the ids for processing
         }
     };

     idService.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
         if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
             return;

         // Just need to delete the reprints marked for deletion
         if (_self.deletedReprintIds.count > 0) {
             for (NSString * salesForceId in _self.deletedReprintIds) {
                 AGNMarketingDisbursement * reprint = [_self.managedContext ddsf_objectOfType:@"AGNMarketingDisbursement" forId:salesForceId];
                 if (reprint)
                     [_self.managedContext deleteObject:reprint];
             }
             [_self saveContext];
         }
     };
     
    DDSFSyncStep * idsDirect = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return nil;

        if(_self.remainingReprintIds || _self.deletedReprintIds || _self.addedReprintIds)
            return nil;// already fetched the ids, can skip that step

        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"MarketingIDsQueryString.txt", earliestDateString, nil];
    }];
    idsDirect.name = @"delta-reprint-ids-direct";

     idsDirect.onConvert = ^(NSArray * array) {
         NSMutableDictionary * dictionary = [[NSMutableDictionary alloc]init];
         dictionary[@"ids"]=array;
         return dictionary;
     };

    idsDirect.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return;

        log4Info(@"==> reprint ids fetched");

        NSMutableSet * serverIds = [NSMutableSet setWithArray:json[@"ids"]];
        NSSet * localIds = [_self.managedContext ddsf_idsForAllEntitiesNamed:@"AGNMarketingDisbursement"];

        // Identify reprints to delete
        _self.deletedReprintIds = [NSMutableSet setWithSet:localIds];
        [_self.deletedReprintIds minusSet:serverIds];

        // Remaining is everything we don't have as of right now
        _self.remainingReprintIds = serverIds;
        [_self.remainingReprintIds minusSet:localIds];

        _self.addedReprintIds = [NSSet setWithSet:_self.remainingReprintIds]; // All of these are not present locally, and we need to preserve the ids for processing
    };

    idsDirect.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return;

        // Just need to delete the reprints marked for deletion
        if (_self.deletedReprintIds.count > 0) {
            for (NSString * salesForceId in _self.deletedReprintIds) {
                AGNMarketingDisbursement * reprint = [_self.managedContext ddsf_objectOfType:@"AGNMarketingDisbursement" forId:salesForceId];
                if (reprint)
                    [_self.managedContext deleteObject:reprint];
            }
            [_self saveContext];
        }
    };

    DDSFSyncStep * modified = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return nil;

        NSString * modifiedSinceDateString = earliestDateString;
        if (_self.syncManager.utcCurrentSyncLastTimestamp)
            modifiedSinceDateString = [_self.syncManager.utcCurrentSyncLastTimestamp agnRFC3339FormattedTimestampString];

        modifiedSinceDateString = @"2013-07-02T12:20:29.000-0700";

        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"MarketingModifiedQueryString.txt", earliestDateString, modifiedSinceDateString, nil];
    }];
    modified.name = @"delta-reprint-modified";

    modified.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return;

        log4Info(@"==> modified reprints fetched");

        NSArray * records = json[@"records"];
        NSSet * receivedIds = [NSSet setWithArray:[records valueForKey:@"Id"]];
        log4Debug(@"Received Ids: %@", receivedIds);

        // Since we may have received some of the missing ones, let's update our remaining Ids
        [_self.remainingReprintIds minusSet:receivedIds];
        log4Debug(@"Remaining Ids: %@", _self.remainingReprintIds);
    };

    modified.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return;

        NSArray * records = json[@"records"];
        if (records.count > 0) {
            for (NSDictionary * reprint in records) {
                NSString * salesForceId = reprint[@"Id"];
                if ([_self.addedReprintIds containsObject:salesForceId]) {
                    [_self addEntities:@[reprint] withName:@"AGNMarketingDisbursement"];
                    log4Debug(@"Added 1 reprint.");

                    NSDictionary *contents = (NSDictionary *) reprint[@"Marketing_Contents__r"];
                    if (contents && ![contents isEqual:[NSNull null]]) {
                        [_self addEntities:contents[@"records"] withName:@"AGNMarketingCollateral"];
                    }

                }
                else {
                    [_self updateEntities:@[reprint] withName:@"AGNMarketingDisbursement" whereIdWithKey:@"Id" notIn:nil];
                    log4Debug(@"Updated 1 reprint.");

                    NSDictionary *contents = (NSDictionary *) reprint[@"Marketing_Contents__r"];
                    if (contents && ![contents isEqual:[NSNull null]]) {
                        [_self updateEntities:contents[@"records"] withName:@"AGNMarketingCollateral" whereIdWithKey:@"Id" notIn:nil];

                    }
                }
            }
            [_self saveContext];
        }
    };


    DDSFSyncStep * missing = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return nil;

        if (_self.remainingReprintIds.count == 0)
            return nil;

        NSString * ids = [_self.remainingReprintIds.allObjects componentsJoinedByString:@"','"];
        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"MarketingMissingQueryString.txt",
                [NSString stringWithFormat:@"'%@'", ids], nil];
    }];
    missing.name = @"delta-reprint-missing";

    missing.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncReprints)
            return;

        [_self addEntities:json[@"records"] withName:@"AGNMarketingDisbursement"];
        log4Debug(@"Added %d  reprints.", [json[@"records"] count]);
    };


    [group setSteps:@[idService, idsDirect, modified, missing] forMode:kDDSFDownstreamSyncModeIncremental];

    group.postProcess = ^(DDSFDownstreamSync * sync) {
        NSArray * reprints = [self.managedContext ddsf_allEntitiesNamed:@"AGNMarketingDisbursement"];
        for (AGNMarketingDisbursement * reprint in reprints)
            [reprint buildRelationships];
        
        [self saveContext];
    };

    return group;

}



- (DDSFSyncItem*) reprintsReferenceGroup{
    __weak AGNDownstreamSync * _self = self;


    NSInteger numMonthsOfCallHistoryToRetrieve = [AGNAppDelegate sharedDelegate].monthsCallHistory;
    NSDate *earliestDate = [NSDate dateWithTimeIntervalSinceNow:(-numMonthsOfCallHistoryToRetrieve*30*24*3600)];
    NSString *earliestDateString = [earliestDate agnStringFromDate];


   
    DDSFSyncStep * allReprintItems = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if ([AGNAppDelegate sharedDelegate].shouldSyncReprints ){
            NSString * salesTeam = _self.loggedInSalesRep.salesTeamName;
            return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"APCsQueryString.txt", salesTeam,  earliestDateString, nil];
        }
        else
            return nil;

    }];
    allReprintItems.name = @"APCs";

    allReprintItems.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        [_self addEntities:json[@"records"] withName:@"AGNAPC"];
        log4Debug(@"Added %d  APC codes.", [json[@"records"] count]);
    };


    allReprintItems.postProcess = ^(DDSFDownstreamSync *sync) {
        [_self saveContext];
    };
    
    return allReprintItems;

    
}

@end
