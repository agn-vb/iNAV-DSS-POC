//
//  AGNInventoryViewController.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNViewController.h"
#import "AGNTableView.h"

@interface AGNInventoryViewController : AGNViewController <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet AGNTableView *outgoingProductTableView;
@property (weak, nonatomic) IBOutlet AGNTableView *incomingProductTableView;

@property (strong,nonatomic) NSArray *outgoingProducts;
@property (strong,nonatomic) NSArray *incomingProducts;
@property (weak, nonatomic) IBOutlet UIButton *startNewTransferButton;
@property (weak, nonatomic) IBOutlet UIButton *startNewReturnButton;
@property (weak, nonatomic) IBOutlet UIButton *viewCurrentInventoryButton;

@end
