//
//  AGNSignatureImageTableViewCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/20/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNSignatureImageTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *signatureDisplayView;
@property (weak, nonatomic) IBOutlet UILabel *signatureAcceptedDateLabel;
@property (weak, nonatomic) IBOutlet UILabel *dottedLineLabel;
@property (weak, nonatomic) IBOutlet UILabel *signatureAcceptedLabel;

-(void)setClosedCallSignatureAcceptedMode:(NSString *)dateString;
-(void)setClosedCallNoSignatureMode;
-(void)setSignatureAcceptedMode:(UIImage *)image;
-(void)setSignatureCaptureMode;
-(void)setSignaturePendingMode;
@end
