//
//  AGNSettingsViewController.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <QuartzCore/QuartzCore.h>
#import "AGNViewController.h"
#import "AGNBigGreyButton.h"

@interface AGNSettingsViewController : AGNViewController <MFMailComposeViewControllerDelegate>

@property (weak, nonatomic) IBOutlet AGNBigGreyButton *sendDebugLogButton;
@property (weak, nonatomic) IBOutlet AGNBigGreyButton *signOutButton;
@property (weak, nonatomic) IBOutlet AGNBigGreyButton *performDeltaSyncButton;
@property (weak, nonatomic) IBOutlet AGNBigGreyButton *forceFullSyncButton;
- (IBAction)performDeltaSyncPressed:(id)sender;
- (IBAction)forceFullSyncPressed:(id)sender;
- (IBAction)sendDebugPressed:(id)sender;
- (IBAction)signoutPressed:(id)sender;
@end
