//
//  AGNInventoryTransferCell.m
//  AGNDirect
//
//  Created by Adam McLain on 11/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNInventoryTransferCell.h"

@interface AGNInventoryTransferCell ()
@property (strong, nonatomic, readwrite) UILabel *nameLabel;
@property (strong, nonatomic, readwrite) UILabel *dateLabel;
@property (strong, nonatomic, readwrite) UILabel *transferLabel;
@property (strong, nonatomic, readwrite) UILabel *statusLabel;
@end

@implementation AGNInventoryTransferCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        UILabel *name = self.nameLabel = [[UILabel alloc] init];
        name.textColor = [UIColor AGNGreyMatter];
        name.highlightedTextColor = [UIColor whiteColor];
        name.font = [UIFont AGNAvenirHeavy16];
        
        UILabel *status = self.statusLabel = [[UILabel alloc] init];
        status.textColor = [UIColor AGNGreyMatter];
        status.highlightedTextColor = [UIColor whiteColor];
        status.font = [UIFont AGNAvenirRoman16];
        status.textAlignment = NSTextAlignmentRight;
        status.text = @"DRAFT";
        
        UILabel *date = self.dateLabel = [[UILabel alloc] init];
        date.font = [UIFont AGNAvenirRoman16];
        date.textColor = [UIColor AGNGreyMatter];
        date.highlightedTextColor = [UIColor whiteColor];
        date.textAlignment = NSTextAlignmentRight;
        
        UILabel *transfer = self.transferLabel = [[UILabel alloc] init];
        transfer.font = [UIFont AGNAvenirRoman16];
        transfer.textColor = [UIColor AGNGreyMatter];
        transfer.highlightedTextColor = [UIColor whiteColor];
        transfer.text = NSLocalizedString(@"Transfer:", @"transfer label static text");
        
        NSDictionary *views = NSDictionaryOfVariableBindings(name, date, transfer, status);
        UIView *parentView = self.contentView;
        for (UIView *view in [views allValues]) {
            [view setTranslatesAutoresizingMaskIntoConstraints:NO];
            [parentView addSubview:view];
            view.backgroundColor = [UIColor clearColor];
        }
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[name][date(==100)]-22-|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[transfer][status(>=60)]-22-|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[transfer][name]-10-|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[status][date]-10-|" options:0 metrics:nil views:views]];
        [parentView addConstraint:[NSLayoutConstraint constraintWithItem:date attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:name attribute:NSLayoutAttributeCenterY multiplier:1.0f constant:0.0f]];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setTransaction:(AGNSampleInventoryTransaction *)transaction {
    if (_transaction == transaction) {
        return;
    }
    
    self.dateLabel.text = transaction.shipmentDate?[transaction.shipmentDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN", @"Placeholder for missing date in inventory landing");
}

- (void)setActive {
    self.transferLabel.textColor = [UIColor AGNGreyMatter];
    self.dateLabel.textColor = [UIColor AGNWAwawa];
    self.nameLabel.textColor = [UIColor AGNGreyMatter];
    self.statusLabel.hidden = NO;
}

- (void)setPassive {
    self.transferLabel.textColor = [UIColor AGNDarkGray];
    self.dateLabel.textColor = [UIColor AGNDarkGray];
    self.nameLabel.textColor = [UIColor AGNDarkGray];
    self.statusLabel.hidden = YES;
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.nameLabel.text = nil;
    self.dateLabel.hidden = NO;
    self.statusLabel.hidden = NO;
}
@end
