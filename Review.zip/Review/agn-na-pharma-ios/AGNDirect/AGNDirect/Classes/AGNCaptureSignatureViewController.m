//
//  AGNCaptureSignatureViewController.m
//  AGNDirect
//
//  Created by Adam McLain on 10/11/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  PRESENTED WHEN GET SIGNATURE IS TAPPED

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNCaptureSignatureViewController.h"
#import "AGNTableView.h"
#import "AG_SignatureCaptureView.h"
#import "AGNSignatureViewController.h"
#import "AGNRequestFormItem.h"

@interface AGNCaptureSignatureViewController ()
@property (nonatomic, strong, readwrite) IBOutlet AGNTableView *tableView;
@property (strong, nonatomic) IBOutlet UILabel *addressLabel;
@property (strong, nonatomic) IBOutlet UILabel *disclosureLabel;
@property (nonatomic, strong) IBOutlet AG_SignatureCaptureView *signatureView;
@property (strong, nonatomic) IBOutlet UIButton *acceptButton;
@property (strong, nonatomic) IBOutlet UIImageView *toolbar;
@property BOOL acceptingSignature;
@property (weak, nonatomic) IBOutlet UILabel *licenseLabel;
@property (strong, nonatomic) AGNLicense * license;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;


@property  (strong, nonatomic) UIAlertView* lowMemoryAlertView;
@end

@implementation AGNCaptureSignatureViewController

@synthesize memoryBuffer=_memoryBuffer;
@synthesize topHeaderViewConstraint;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.acceptButton.enabled = NO;
    self.acceptButton.alpha = .5;
    self.signatureView.delegate = self;
    self.tableView.tableFooterView = [[UIView alloc] init];
    if ([[UIDevice currentDevice].systemVersion floatValue] > 6.1) {
        // separator causes header to look janky in ios7
        self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    }


    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
    UIView *parentView = self.addressLabel.superview;
    
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.disclosureLabel attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.addressLabel attribute:NSLayoutAttributeLeading multiplier:1.0f constant:0.0f]];
    [self.toolbar setImage:[UIImage imageNamed:@"bar-bigblue"]];
    //    UIImageView *allergan = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"allergan-wordmark~ipad"]];
    //    NSMutableArray *toolbarItems = self.toolbar.items.mutableCopy;
    //    int idx = [toolbarItems indexOfObject:self.centerBarItem];
    //    [toolbarItems replaceObjectAtIndex:idx withObject:[[UIBarButtonItem alloc] initWithCustomView:allergan]];
    //    self.toolbar.items = toolbarItems;
    if(self.call && self.call.isDSSCall != nil && self.call.isDSSCall == [NSNumber numberWithInt:1]){
        [self InitQLView ];
         //self.legaleseLabel.hidden = YES;
         //self.legaleseLabel.frame.size = CGSizeMake(10,10);//, <#CGFloat height#>)
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    if ([self.account.licenses count] > 0) {
        self.license = [self.account samplingLicenseForAddress:self.address];
    }
    
    self.addressLabel.attributedText = [self nameAddressLabel];
    self.licenseLabel.attributedText = [self licenseLabelText];
    
    [self.addressLabel sizeToFit];
    if(self.requestForm){
        self.legaleseLabel.attributedText=[self formsLegalese];
    }
    log4Info(@"Launching signature capture view for %@",self.call?self.call:self.requestForm);
    [self.signatureView resetValidation];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.tableView.contentSize = newContentSize;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(AGNAddress*)address{
    if(self.call)
        return self.call.address;
    if(self.requestForm)
        return self.requestForm.address;
    return nil;
}


-(AGNAccount*)account{
    if(self.call)
        return self.call.account;
    if(self.requestForm)
        return self.requestForm.account;
    return nil;
}

- (NSAttributedString *)nameAddressLicenseLabelXX {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:14.0f];
    UIFont *romanFont = [UIFont AGNAvenirRomanFontWithSize:14.0f];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : romanFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    if ([self.account formattedName].length > 0) {
        NSAttributedString *formattedName = [[NSAttributedString alloc] initWithString:[self.account formattedName] attributes:boldAttributes];
        [formattedString appendAttributedString:formattedName];
    }
    
    if (self.account.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)", self.account.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:romanAttributes]];
    }
    
    NSString *addressString = [NSString stringWithFormat:@"\n%@",self.address.singleLineFormattedString];
    if (addressString.length > 0) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:addressString attributes:romanAttributes]];
    }
    
    if (self.license) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\nLICENSE: " attributes:romanAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:self.license.licenseNumber attributes:boldAttributes]];
        NSDate *licenseExpDate = self.license.expirationDate;
        if (licenseExpDate) {
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"  EXPIRES: " attributes:romanAttributes]];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[licenseExpDate agnFormattedDateString] attributes:boldAttributes]];
        }
    }
    
    return formattedString;
}


- (NSAttributedString *)licenseLabelText {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:14.0f];
    UIFont *romanFont = [UIFont AGNAvenirRomanFontWithSize:14.0f];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : romanFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];

    if(self.license){
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"LICENSE: " attributes:romanAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:self.license.licenseNumber attributes:boldAttributes]];
        NSDate *licenseExpDate = self.license.expirationDate;
        if (licenseExpDate) {
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"  EXPIRES: " attributes:romanAttributes]];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[licenseExpDate agnFormattedDateString] attributes:boldAttributes]];
        }
    }else if (self.requestForm){ // this is a hack but if no license for forms, put the delivery info here
                                // if there is a license put it in the legalese label
        [formattedString appendAttributedString:[self deliveryInfoAttributedString]];
    }

    return formattedString;
}

-(NSAttributedString *)deliveryInfoAttributedString{
    UIFont *romanFont = [UIFont AGNAvenirRomanFontWithSize:14.0f];
    NSDictionary *romanAttributes = @{ NSFontAttributeName : romanFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:14.0f];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    NSString * phoneNumber = self.requestForm.phone;
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"Phone: " attributes:romanAttributes]];
    if (phoneNumber) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:phoneNumber attributes:boldAttributes]];
    }

    NSString * deliveryMethod = [self deliveryMethodString];
    
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"      Delivery Method: " attributes:romanAttributes]];
    
    if (deliveryMethod) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:deliveryMethod attributes:boldAttributes]];
    }
       
    return formattedString;
}

-(NSString *)deliveryMethodString{
    if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodEmail]){
        return [NSString stringWithFormat:@"%@ - %@\n",self.requestForm.deliveryMethod,self.requestForm.email];
    }else if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodFax]){
        return [NSString stringWithFormat:@"%@ - %@\n",self.requestForm.deliveryMethod,self.requestForm.fax];
    }else{
        return [NSString stringWithFormat:@"%@ \n",self.requestForm.deliveryMethod];
    }
    
}

-(NSAttributedString *)formsLegalese{
    
    UIFont *romanFont = [UIFont AGNAvenirRomanFontWithSize:14.0f];
    NSDictionary *romanAttributes = @{ NSFontAttributeName : romanFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
   
    NSString * legalese = NSLocalizedString(@"\nThis confirms that without any solicitation or suggestion by an Allergan employee or representative, I have requested the above information.", @"Legaese for forms");

    if(self.license)
        [formattedString appendAttributedString:[self deliveryInfoAttributedString]];
    
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:legalese attributes:romanAttributes]];
    return formattedString;
    
}


- (NSAttributedString *)nameAddressLabel {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:14.0f];
    UIFont *romanFont = [UIFont AGNAvenirRomanFontWithSize:14.0f];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : romanFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    if ([self.account formattedName].length > 0) {
        NSAttributedString *formattedName = [[NSAttributedString alloc] initWithString:[self.account formattedName] attributes:boldAttributes];
        [formattedString appendAttributedString:formattedName];
    }
    
    if (self.account.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)", self.account.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:romanAttributes]];
    }
    
    NSString *addressString = [NSString stringWithFormat:@"\n%@",self.address.singleLineFormattedString];
    if (addressString.length > 0) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:addressString attributes:romanAttributes]];
    }

   
    return formattedString;
}

//------------------------------------------------------------------------------
// MARK: - UITableView
//------------------------------------------------------------------------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(!self.call)
        return self.requestForm.items.count+1;
    return self.call.liveSampleDrops.count +1;
}
- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = nil;
    int row = indexPath.row;
    
    UIImage *bgImage = [[UIImage imageNamed:@"subhead-grey"] resizableImageWithCapInsets:UIEdgeInsetsMake(1.0f, 0.0f, 4.0f, 0.0f)];
    UIImageView *headerBackground = [[UIImageView alloc] initWithImage:bgImage];
    [headerBackground setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    void (^setCellBackground)(UITableViewCell *) = ^(UITableViewCell *aCell){
        UIView *contentView = aCell.contentView;
        [contentView addSubview:headerBackground];
        [contentView sendSubviewToBack:headerBackground];
        
        NSDictionary *views = NSDictionaryOfVariableBindings(headerBackground);
        [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[headerBackground]|" options:0 metrics:nil views:views]];
        [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[headerBackground]" options:0 metrics:nil views:views]];
        [contentView addConstraint:[NSLayoutConstraint constraintWithItem:headerBackground attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:contentView attribute:NSLayoutAttributeHeight multiplier:1.0 constant:1.0]];
    };
    
    if (row == 0 && self.call) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"SampleHeaderCell"];
        setCellBackground(cell);
    } else if(self.call) {
        cell = [aTableView dequeueReusableCellWithIdentifier:@"SampleDetailCell"];
        // TODOPHASE2
        
        AGNSampleDrop *drop = self.call.liveSampleDrops[row-1];
        
        ((UILabel *)[cell viewWithTag:1]).text = [NSString stringWithFormat:@"%@ (%@)", drop.sampleInventoryLine.product.productDescription, drop.sampleInventoryLine.product.manufacturer];
        ((UILabel *)[cell viewWithTag:2]).text = drop.sampleInventoryLine.lotNumber;
        ((UILabel *)[cell viewWithTag:3]).text = drop.quantity.stringValue;
        ((UILabel *)[cell viewWithTag:4]).text = drop.sampleInventoryLine.product.molecularName;
    }else if (self.requestForm) {
        if (row==0) {
            
            cell = [aTableView dequeueReusableCellWithIdentifier:@"RequestFormHeaderCell"];
            setCellBackground(cell);
        } else{   /// Request Form
            cell = [aTableView dequeueReusableCellWithIdentifier:@"RequestFormDetailCell"];
            
            AGNRequestFormItem * item = [self.requestForm itemForOrdinal:indexPath.row];
            ((UILabel *)[cell viewWithTag:1]).text = item.productName ;
            UILabel* questionLabel = ((UILabel *)[cell viewWithTag:2]);
            questionLabel.lineBreakMode = NSLineBreakByWordWrapping;
            questionLabel.numberOfLines=0;
            questionLabel.text = item.displayedQuestion;
        }
    }
    
    if (!cell) {
        log4Debug(@"oops...no cell for row %d", row);
    }
    //useful for finding constraint violations
    log4Trace(@"\nCell: %@, Reuse id %@\n",cell,cell.reuseIdentifier);
    return cell;
}


- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 0 && self.call) {
        return 28.0f;
    } else if(self.call) {
        return 34.0f;
    }
    else if (indexPath.row == 0 && self.requestForm) {
        return 28.0f;
    } else if(self.requestForm) {
        int ordinal = indexPath.row;
        AGNRequestFormItem * item = [self.requestForm itemForOrdinal:ordinal];
        return [self heightForString:item.displayedQuestion withWidth:587.0f];

    }
    // tableView.rowHeight;
    return 34.0f;
}

- (CGFloat)heightForString:(NSString *)string withWidth:(CGFloat)width {
    CGSize maxSize = CGSizeMake(width, CGFLOAT_MAX);
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.numberOfLines = 0;
    label.text = string;
    CGSize attributedRect = [label sizeThatFits:maxSize];
    return attributedRect.height;
}

//------------------------------------------------------------------------------
// MARK: - Toolbar actions
//------------------------------------------------------------------------------

- (IBAction)cancel:(id)sender {
    log4Info(@"Cancelling signature capture");
    self.acceptingSignature=NO;
    NSString *  title = NSLocalizedString(@"Signature Cancelled","Title when cancel signtaure pressed");
    NSString *message = NSLocalizedString(@"The signature has been cancelled.  Representative to confirm cancellation.","Message when cancel signtaure pressed");
    NSString *buttonTitle = NSLocalizedString(@"Continue", @"Cancel signature continue button title");
    UIAlertView *cancelSignature = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:buttonTitle otherButtonTitles:nil];
    [cancelSignature show];
}

- (IBAction)accept:(id)sender {
    self.acceptingSignature=YES;
    log4Info(@"Accepting signature");
    NSString *  title  = NSLocalizedString(@"Signature Accepted","Title when cancel signtaure accepted");
    NSString *callsMessage = NSLocalizedString(@"The signature has been accepted.  Representative to complete sample disbursement.","Message when accept signtaure pressed for calls");
    NSString *formsMessage = NSLocalizedString(@"The signature has been accepted.  Please return iPad to representative.","Message when accept signtaure pressed for forms");
    NSString *buttonTitle = NSLocalizedString(@"Continue", @"Accept signature continue button title");
    NSString *message = self.call?callsMessage:formsMessage;
    if(self.call)
        [self.call stampComplianceFields:NO];
    if(self.requestForm)
        [self.requestForm stampComplianceFields];
    UIAlertView *acceptSignature = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:nil otherButtonTitles:buttonTitle,nil];
    [acceptSignature show];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if(alertView==self.lowMemoryAlertView){
        // don't do anything
        
    }else{ // is HCP dismissing the instruction to hand over to rep
        
        if(self.acceptingSignature)
            [self acceptButtonPressed:nil];
        else
            [self cancelButtonPressed:nil];
    }
}


- (void)cancelButtonPressed:(UILongPressGestureRecognizer *)gestureRecognizer {
    {
        log4Info(@"Signature canceled");
        if(self.memoryBuffer){
            log4Info(@"Freeing memory buffer...");
            free(self.memoryBuffer);
            self.memoryBuffer=nil;
        }
        [self dismissViewControllerAnimated:YES completion:^{
            log4Info(@"Cancelled out of accept signature screen.");
        }];
    }
}

- (void)willPresentAlertView:(UIAlertView *)alertView {
    if(alertView==self.lowMemoryAlertView){
        //       self.lowMemoryAlertView.frame = CGRectMake(alertView.frame.origin.x, alertView.frame.origin.y, alertView.frame.size.width*2,alertView.frame.size.height*2);
    }
}

-(UIImage *)signatureImage{
    AG_SignatureCaptureView *captureView =  self.signatureView;
    
    // Capture and add the date to the captured signature before
    // we save and convert it to a Base64 PNG
    UILabel *dateLabel = [[UILabel alloc] init];
    dateLabel.font = [UIFont fontWithName:@"Courier" size:12.0f];
    dateLabel.backgroundColor = [UIColor clearColor];
    dateLabel.translatesAutoresizingMaskIntoConstraints = NO;
    
    [captureView addSubview:dateLabel];
    NSDictionary *views = NSDictionaryOfVariableBindings(captureView, dateLabel);
    [captureView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[dateLabel]|" options:0 metrics:nil views:views]];
    [captureView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[dateLabel(==35)]|" options:0 metrics:nil views:views]];
    
    NSString *identifier = nil;
    if(self.call)
        identifier = self.call.salesForceId.length > 0 ? self.call.salesForceId : self.call.guid;
    else if (self.requestForm)
        identifier = self.requestForm.salesForceId.length > 0 ? self.requestForm.salesForceId : self.requestForm.guid;
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss Z"];
    df.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSString *timestampString = [df stringFromDate:[NSDate date]];
    NSString * type = self.call?@"Call":self.requestForm.type;
    NSString *timeStamp = [NSString stringWithFormat:@"%@ - %@ : %@",timestampString ,type, identifier];
    dateLabel.text = timeStamp.uppercaseString;
    
    UIImage *signatureImage = [captureView signatureImage];
    return signatureImage;
}


- (void)acceptButtonPressed:(UILongPressGestureRecognizer *)gestureRecognizer
{
    
    log4Info(@"Signature accepted");
    if(self.memoryBuffer){
        log4Info(@"Freeing memory buffer...");
        free(self.memoryBuffer);
        self.memoryBuffer=nil;
    }
    
    UIImage *signatureImage  = [self signatureImage];
    NSData *imageData = UIImagePNGRepresentation(signatureImage);
    NSString *signatureJSON =  [imageData agnBase64EncodedString];
    log4Info(@"Generated signature JSON %@",[signatureJSON substringToIndex:100]);
    
    if(!signatureImage || !signatureJSON || !signatureJSON.length>0){
        log4Error(@"Could not save signature Image %@ or signature JSON %@, showing alert!",signatureImage,[signatureJSON substringToIndex:100]);
        
        self.lowMemoryAlertView = [[UIAlertView alloc]initWithTitle:@"ERROR!!  Signature Not Captured" message:@"DO NOT CLOSE THIS APPLICATION OR SIGNATURE WILL BE PERMANENTLY LOST.  You may be running low on memory - use the following instructions to close some other applications.  \n 1) Double click the Home button; the dock at the bottom of the screen will show a list of all the recently used apps and some of them could still be running in the background. \n 2) Touch and hold the icon for an application you wish to close. \n 3) Touch the red minus sign in the corner of the application. \n 4) Touch the background of the iNAV application to return to it. " delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        self.lowMemoryAlertView.delegate=self;
        [self.lowMemoryAlertView show];
        return ;
    }
    
    if(self.call){
        self.call.signatureImage = signatureImage;
        self.call.signatureJSON = signatureJSON;
        //Set the editable state of the call to NO
        self.call.signatureCaptureDate = [NSDate date];
        if(!self.call.startDate)
            self.call.startDate = [NSDate agnDateRoundedDownToThirtyMinutes:[NSDate date]];
        
        log4Info(@"Captured signature at %@, saving signature JSON to call %@",self.call.signatureCaptureDate,[self.call.signatureJSON substringToIndex:100]);
        
    }
    
    if(self.requestForm){
        self.requestForm.signatureImage = signatureImage;
        self.requestForm.signatureJSON = signatureJSON;
        self.requestForm.signatureCaptureDate = [NSDate date];
        if(!self.requestForm.startDate)
            self.requestForm.startDate = [NSDate date];
        log4Info(@"Captured signature at %@, saving signature JSON to form %@",self.requestForm.signatureCaptureDate,[self.requestForm.signatureJSON substringToIndex:100]);
        
    }
    
    
    //#if TARGET_IPHONE_SIMULATOR
    //    NSArray *pathArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //    NSString *documentsDirectory = [pathArray objectAtIndex:0];
    //    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"sig.png"];
    //    [UIImagePNGRepresentation(signatureImage) writeToFile:path atomically: YES];
    //#endif
    
    NSError *error = nil;
    [[self managedObjectContext] save:&error];
    //TODO: handle error
    if (error) {
        log4Error(@"Could not save signature capture date. Error = %@", error);
    }
    
    [self dismissViewControllerAnimated:YES completion:^{
        log4Info(@"Accepted signature for %@ ",self.call?self.call:self.requestForm);
        log4Info(@"Signature image  : %@ ", self.call?self.call.signatureImage:self.requestForm.signatureImage );
    }];
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:AGNSignatureCapturedNotification object:signatureImage]];
}

-(NSManagedObjectContext *)managedObjectContext{
    if(self.call)
        return self.call.managedObjectContext;
    return self.requestForm.managedObjectContext;
}

- (IBAction)clearSignature:(id)sender {
    log4Info(@"Clearing signature for %@ ",self.call?self.call:self.requestForm);
    [self.signatureView clear];
}

//------------------------------------------------------------------------------
// MARK: - AGN Signature Capture Delegate
//------------------------------------------------------------------------------
- (void) signatureCaptureViewHasValidSignature: (BOOL) valid {
    if (valid) {
        self.acceptButton.enabled = YES;
        self.acceptButton.alpha = 1.0;
    } else {
        self.acceptButton.enabled = NO;
        self.acceptButton.alpha = .5;
    }
}

- (NSInteger) numberOfPreviewItemsInPreviewController: (QLPreviewController *) controller
{
    return 1;
}

- (id <QLPreviewItem>)previewController: (QLPreviewController *)controller previewItemAtIndex:(NSInteger)index
{
    // Break the path into its components (filename and extension)
    // NSArray *fileComponents = [[arrayOfDocuments objectAtIndex: index] componentsSeparatedByString:@"."];
    
    // Use the filename (index 0) and the extension (index 1) to get path
    //NSString *path = [[NSBundle mainBundle] pathForResource:[fileComponents objectAtIndex:0] ofType:[fileComponents objectAtIndex:1]];
    //if (dataPath == nil)
    {
        NSString *file = [[NSBundle mainBundle]  pathForResource:@"SafetyInstructions001" ofType:@"pdf"];
        //NSData * confData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"environments" ofType:@"json"]];
        
        NSURL *url1 = [NSURL   fileURLWithPath:file ];
         NSURL *url =  [NSURL fileURLWithPath:@"SafetyInstructions001.pdf" isDirectory:false];
        return url1;//[NSURL fileURLWithPath:@"SafetyInstructions001.pdf" isDirectory:false];
        
    }
    //return [NSURL fileURLWithPath:dataPath];
}

-(void) InitQLView
{
    
    //QLPreviewController* previewController = [[[QLPreviewController alloc] init] ];
    //if (preview == nil)
    preview = [[QLPreviewController alloc] init];
    //preview.navigationItem.rightBarButtonItem =
    
    preview.dataSource = self;
    preview.delegate = self;
    //[self addChildViewController:preview];//*view controller containment
    //set the frame from the parent view
    //CGFloat w= self.view.frame.size.width;
    //CGFloat h= self.quickLookView.frame.size.height;
    //self.legaleseLabel.window.frame.
    CGFloat x = self.legaleseLabel.window.frame.origin.x;
    CGFloat y = self.legaleseLabel.window.frame.origin.y;
    CGFloat w =self.view.bounds.size.width -20;
    //self.legaleseLabel.window.frame.size.width;
    CGFloat h = 200;//self.legaleseLabel.window.frame.size.height;
    preview.view.frame =  CGRectMake(0, 310,w,h);
    //self.legaleseLabel.window.frame; //
    [self.view addSubview:preview.view];
    preview.navigationController.toolbarHidden = NO;
    [preview didMoveToParentViewController:self];
    [self.view setNeedsDisplay];
    //self.strQLStatus = @"Yes";
    //save a reference to the preview controller in an ivar
    //  self.previewController = preview;
}

@end
