//
//  AGNSyncStatusView.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 10/3/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSyncStatusView.h"
#import "UIFont+AGNFont.h"
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>

@interface AGNSyncStatusView ()

@property (nonatomic, strong) UIImageView * icon;
@property (nonatomic, strong) UIImageView * badge;
@property (nonatomic, strong) UILabel * badgeLabel;

@property (nonatomic, strong) CAAnimation * spinAnimation;

@end


@implementation AGNSyncStatusView

- (id)initWithCoder:(NSCoder *)aDecoder {
    if ((self = [super initWithCoder:aDecoder])) {
        [self setTranslatesAutoresizingMaskIntoConstraints:NO];

        _icon = [[UIImageView alloc] initWithFrame:self.bounds];
        [self addSubview:_icon];
        _icon.backgroundColor = [UIColor clearColor];
        [_icon setTranslatesAutoresizingMaskIntoConstraints:NO];
        _icon.hidden = YES;
        
        UIImage * image = [UIImage imageNamed:@"queue_count-numberbadge"];
        UIEdgeInsets insets = UIEdgeInsetsMake(21, 10, 0, 10);
        image = [image resizableImageWithCapInsets:insets];
        _badge = [[UIImageView alloc] initWithImage:image];
        _badge.hidden = YES;
        [_badge setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self addSubview:_badge];

        _badgeLabel = [[UILabel alloc] init];
        _badgeLabel.text = @"1";
        _badgeLabel.font = [UIFont AGNHelveticaNeueBold12];
        _badgeLabel.backgroundColor = [UIColor clearColor];
        _badgeLabel.textColor = [UIColor whiteColor];
        [_badgeLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        _badgeLabel.hidden = YES;
        [self addSubview:_badgeLabel];
        
        NSDictionary *constraintsViewsDictionary = @{ @"badge" : self.badge , @"label" : self.badgeLabel, @"icon":self.icon };
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[icon]|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[icon]|" options:0 metrics:nil views:constraintsViewsDictionary]];        
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[badge(>=21)]|" options:0 metrics:nil views:constraintsViewsDictionary]];
        NSLayoutConstraint * constraint = [NSLayoutConstraint constraintWithItem:self.badge attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self.badgeLabel attribute:NSLayoutAttributeWidth multiplier:1.0 constant:10.0];
        [self addConstraint:constraint];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[badge(==21)]" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.badgeLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.badge attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:-2]];
        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.badgeLabel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.badge attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];
        
        [self updateState];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resumeAnimation:) name:UIApplicationWillEnterForegroundNotification object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)resumeAnimation:(NSNotification*)notification {
    if (_isSyncing) {
        [self.icon.layer removeAllAnimations];
        _spinAnimation = nil;
        [self spinIcon];
    }
}

- (CAAnimation *)animationForSpinning {
    static CATransform3D originalTransform;
    static CATransform3D transform;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        originalTransform = self.icon.layer.transform;
        transform = CATransform3DMakeRotation(M_PI, 0.0, 0.0, 1.0);
    });
    
	
	// Create a basic animation to animate the layer's transform
	CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"transform"];
                 
    // Now assign the transform as the animation's value. While
    // animating, CABasicAnimation will vary the transform
    // attribute of its target, which for this transform will spin
    // the target like a wheel on its z-axis.
    animation.fromValue = [NSValue valueWithCATransform3D:transform];
    animation.toValue = [NSValue valueWithCATransform3D:originalTransform];
    animation.duration = 1.2;
    animation.cumulative = YES;
    animation.repeatCount = 1e38f;  // this is infinity in IEEE 754 floating point format
    return animation;
}
                 
- (void)spinIcon {
    if (!_spinAnimation) {
        // Create a new spinning animation
        _spinAnimation = [self animationForSpinning];

        // Assign this animation to the provided layer's opacity attribute.
        // Any subsequent change to the layer's opacity will
        // trigger the animation.
        [self.icon.layer addAnimation:_spinAnimation forKey:@"spinAnimation"];
    }
}

- (void)stopSpinning {
    if (_spinAnimation) {
        [self.icon.layer removeAnimationForKey:@"spinAnimation"];
        _spinAnimation = nil;
    }
}
         
- (void)updateState {
    if (_isSyncing) {
        self.icon.image = [UIImage imageNamed:@"queue_count-syncing"];
        self.icon.hidden = NO;
        [self spinIcon];
    }
    else {
        [self stopSpinning];
        
        if (_badgeCount > 0) {
            self.icon.image = [UIImage imageNamed:@"queue_count-pending"];
            self.icon.hidden = NO;            
        }
        else {
            self.icon.hidden = YES;
        }
    }

    if (_badgeCount > 0) {
        self.badge.hidden = NO;
        self.badgeLabel.hidden = NO;
        if (_badgeCount > 1000)
            self.badgeLabel.text = @">1000";
        else
            self.badgeLabel.text = [NSString stringWithFormat:@"%d", _badgeCount];
    }
    else {
        self.badge.hidden = YES;
        self.badgeLabel.hidden = YES;
    }
}

- (void)setBadgeCount:(NSUInteger)badgeCount {
    if (badgeCount != _badgeCount) {
        _badgeCount = badgeCount;
        [self updateState];
    }
}

- (void)setIsSyncing:(BOOL)isSyncing {
    if ((_isSyncing && !isSyncing) || (!_isSyncing && isSyncing)) {
        _isSyncing = isSyncing;
        [self updateState];
    }
}

@end
