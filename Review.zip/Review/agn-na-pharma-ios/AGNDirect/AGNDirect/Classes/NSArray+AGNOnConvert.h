//
//  NSArray+AGNOnConvert.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/13/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (AGNOnConvert)

-(NSDictionary *)AGNconvertResponseToDictionaryWithKey:(NSString *)key;

@end
