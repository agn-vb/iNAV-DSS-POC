//
//  AGNShipmentViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/13/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSampleInventoryTransaction.h"
#import "AGNShipmentItemCell.h"
#import "AGNViewController.h"
#import "AGNTableView.h"

@interface AGNShipmentViewController : AGNViewController <UITableViewDataSource,UITableViewDelegate,AGNShipmentItemCellDelegate>

@property (strong,nonatomic) AGNSampleInventoryTransaction *transaction;
@property (weak, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UIButton *acceptShipmentButton;
@property (weak, nonatomic) IBOutlet UIButton *acceptAllButton;
- (IBAction)acceptAllButtonClicked:(id)sender;

@property (strong,nonatomic) UILabel *shippedDateLabel;
@property (strong,nonatomic) UILabel *acceptedDateLabel;
@property (strong,nonatomic) UILabel *orderNumberLabel;
@property (strong,nonatomic) UILabel *trackingNumberLabel;

- (IBAction)acceptShipmentButtonClicked:(id)sender;
@property (weak, nonatomic) IBOutlet AGNTableView *shipmentManifestTableView;
@property (weak, nonatomic) IBOutlet UILabel *shipmentManifestLabel;

@end
