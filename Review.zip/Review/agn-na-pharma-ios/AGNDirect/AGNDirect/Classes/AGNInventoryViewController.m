//
//  AGNInventoryViewController.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNInventoryViewController.h"
#import "AGNCurrentInventoryViewController.h"
#import "AGNSampleInventoryTransaction.h"

#import "AGNCategoryHeaders.h"
#import "AGNShipmentViewController.h"
#import "AGNTableViewHeader.h"
#import "AGNTransferViewController.h"
#import "AGNInventoryTransferCell.h"

@interface AGNInventoryViewController ()
@property (weak, nonatomic) IBOutlet UIView *leftView;
@property (weak, nonatomic) IBOutlet UIView *rightView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topSpaceRightView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topSpaceLeftView;
@end

@implementation AGNInventoryViewController

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------
@synthesize startNewTransferButton;
@synthesize startNewReturnButton;
@synthesize viewCurrentInventoryButton;
@synthesize topSpaceLeftView;
@synthesize topSpaceRightView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topSpaceLeftView.constant=0.0f;
        self.topSpaceRightView.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topSpaceLeftView.constant=20.0f;
        self.topSpaceRightView.constant=20.0f;
    }
    
    self.incomingProductTableView.separatorColor = [UIColor whiteColor];
    self.incomingProductTableView.backgroundColor = [UIColor AGNNorilskSneg];
    self.outgoingProductTableView.separatorColor = [UIColor whiteColor];
    self.outgoingProductTableView.backgroundColor = [UIColor AGNNorilskSneg];
    self.leftView.backgroundColor=[UIColor AGNDarkGray];
    self.leftView.backgroundColor=[UIColor AGNDarkGray];    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    self.outgoingProductTableView.tableFooterView = [[UIView alloc] init];
    self.incomingProductTableView.tableFooterView = [[UIView alloc] init];

    if([AGNAppDelegate sharedDelegate].databaseUnavailable){
        self.startNewTransferButton.enabled=NO;
        self.startNewReturnButton.enabled=NO;
        self.viewCurrentInventoryButton.enabled=NO;
    }
    
}

-(void)reloadContent{
    [self fetchProductsAndReloadTables];
}

- (void)fetchProductsAndReloadTables {
    self.incomingProducts = [[AGNDataManager defaultInstance] getIncomingProductForLoggedInUser];
    self.outgoingProducts = [[AGNDataManager defaultInstance] getOutgoingProductForLoggedInUser];
    [self.incomingProductTableView reloadData];
    [self.outgoingProductTableView reloadData];
}

-(void)viewWillAppear:(BOOL)animated   {
    [super viewWillAppear:animated];
    log4Info(@"Viewing inventory landing");

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleUpdateTransactionRevert:)
                                                 name:AGNUpdateTransactionRevertedNotificationKey
                                               object:nil];
    [self fetchProductsAndReloadTables];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateTransactionRevertedNotificationKey object:nil];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newIncomingContentSize = self.incomingProductTableView.contentSize;
    newIncomingContentSize.width = self.view.frame.size.width/2;
    self.incomingProductTableView.contentSize = newIncomingContentSize;
    
    CGSize newOutgoingContentSize = self.outgoingProductTableView.contentSize;
    newOutgoingContentSize.width = self.view.frame.size.width/2;
    self.outgoingProductTableView.contentSize = newOutgoingContentSize;

}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"CurrentInventorySegue"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
        log4Debug(@"Current Inventory tapped");
    }
    
    else if([segue.identifier isEqualToString:@"SelectShipmentSegue"]){
        AGNShipmentViewController *vc = segue.destinationViewController;
        vc.transaction=(AGNSampleInventoryTransaction *)sender;
    }
    
    else if ([segue.identifier isEqualToString:@"StartNewTransferSegue"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:nil];
        AGNTransferViewController *vc = segue.destinationViewController;
        vc.targetType = kOutboundTransferType;
        log4Debug(@"Start New Transfer tapped");
    }
    
    else if ([segue.identifier isEqualToString:@"OpenTransferSegue"]) {
        AGNTransferViewController *vc = segue.destinationViewController;
        vc.transaction = (AGNSampleInventoryTransaction*)sender;
    }
    
    else if ([segue.identifier isEqualToString:@"StartNewReturnSegue"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:nil];
        AGNTransferViewController *vc = segue.destinationViewController;
        vc.targetType = kReturnType;
        log4Debug(@"Start New Transfer tapped");
    }
}


//------------------------------------------------------------------------------
// MARK: - Table View Data Source
//------------------------------------------------------------------------------

-(NSMutableAttributedString *)attributedPlaceholderText{
    UIFont *font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    NSDictionary *attributes =  @{ NSFontAttributeName : font, NSForegroundColorAttributeName : [UIColor AGNGreyMatter]};
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:AGNPlaceholderText attributes:attributes];
    return formattedString;
}

-(void) configureOutgoingShipment:(AGNInventoryTransferCell *)cell withSIT:(AGNSampleInventoryTransaction *)transaction{
 
    BOOL submitted = ![transaction.status isEqualToString:kOpenStatusType];
    NSString *dateString = transaction.sfdcCreatedDate?[transaction.sfdcCreatedDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN1", @"Placeholder for missing date in inventory landing");
    cell.dateLabel.text = dateString;

    if (transaction.transferAuthorizationNumber)
        cell.transferLabel.text = [NSString stringWithFormat:@"Sample Return: %@", transaction.transferAuthorizationNumber];
    else
        cell.transferLabel.text = @"Sample Return:";
    
    if (submitted) {
        [cell setPassive];
    }
    else {
        cell.dateLabel.hidden = YES;
        [cell setActive];
    }
}

-(void) configureIncomingShipment:(AGNInventoryTransferCell *)cell withSIT:(AGNSampleInventoryTransaction *)transaction{
//    UIFont *font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
//    NSDictionary *attributes = @{ NSFontAttributeName : font, NSForegroundColorAttributeName : [UIColor AGNGreyMatter]};
    
    cell.transferLabel.text = [@"Shipment: " stringByAppendingString:transaction.shipmentId];
    if([transaction isOpen]){
        NSString *dateString = transaction.shipmentDate ? [transaction.shipmentDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN", @"Placeholder for missing date in inventory landing");
        cell.dateLabel.text = dateString;
        [cell setActive];
    }
    else{
        NSString *dateString = transaction.actualReceivedDate ? [transaction.actualReceivedDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN", @"Placeholder for missing date in inventory landing");
        cell.dateLabel.text = dateString;
        [cell setPassive];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    AGNInventoryTransferCell *transferCell = [tableView dequeueReusableCellWithIdentifier:@"TransferCell"];
    if (!transferCell) {
        transferCell = [[AGNInventoryTransferCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TransferCell"];
    }
    [transferCell agnSetStyledSelectedBackground];
    
    if((tableView==self.outgoingProductTableView && ([self.outgoingProducts count]==0)) ||(tableView==self.incomingProductTableView &&[self.incomingProducts count]==0)){
        [transferCell setAccessoryType:UITableViewCellAccessoryNone];
        transferCell.transferLabel.attributedText = [self attributedPlaceholderText];
        transferCell.detailTextLabel.text=nil;
        transferCell.dateLabel.text = nil;
        transferCell.statusLabel.text = nil;
        transferCell.selectionStyle=UITableViewCellSelectionStyleNone;
        return transferCell;
    }
    
    if(tableView==self.outgoingProductTableView){
        transferCell.statusLabel.text = @"DRAFT";
        AGNSampleInventoryTransaction *transaction = self.outgoingProducts[indexPath.row];
        
        if(![transaction isReturn]){ // transfer
            BOOL submitted = ![transaction.status isEqualToString:kOpenStatusType];
            NSString *dateString = transaction.sfdcCreatedDate?[transaction.sfdcCreatedDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN", @"Placeholder for missing date in inventory landing");
            transferCell.nameLabel.text = [transaction toRepDisplayString];
            transferCell.dateLabel.text = dateString;
            
            if (transaction.transferAuthorizationNumber)
                transferCell.transferLabel.text = [NSString stringWithFormat:@"Transfer %@ to:", transaction.transferAuthorizationNumber];
            else
                transferCell.transferLabel.text = @"Transfer to:";

            if (submitted) {
                [transferCell setPassive];
            }
            else {
                transferCell.dateLabel.hidden = YES;
                [transferCell setActive];
            }
            
            return transferCell;
        }
        
        [self configureOutgoingShipment:transferCell withSIT:transaction];
        [transferCell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];

    }
    else {
        transferCell.statusLabel.text = @"OPEN";
        AGNSampleInventoryTransaction *transaction = self.incomingProducts[indexPath.row];
        
        if(![transaction isIncomingShipment]) { //transfer
            transferCell.transferLabel.text = [@"Transfer: " stringByAppendingString:transaction.transferAuthorizationNumber];
            
            if([transaction isOpen]){
//                NSString *dateString = transaction.shipmentDate?[transaction.shipmentDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN", @"Placeholder for missing date in inventory landing");
                transferCell.nameLabel.text = [transaction fromRepDisplayString];
                transferCell.dateLabel.text = @"";
                [transferCell setActive];
            }
            else{
                NSString *dateString = transaction.actualReceivedDate?[transaction.actualReceivedDate agnFormattedDateString]:NSLocalizedString(@"UNKNOWN", @"Placeholder for missing date in inventory landing");
                transferCell.nameLabel.text = [transaction fromRepDisplayString];
                transferCell.dateLabel.text = dateString;
                [transferCell setPassive];
            }
            
            return transferCell;
        }
        
        // shipment
        [self configureIncomingShipment:transferCell withSIT:transaction];
        [transferCell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    return transferCell;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(tableView==self.outgoingProductTableView)
        return [self.outgoingProducts count]>0?[self.outgoingProducts count]:1;
    return [self.incomingProducts count]>0?[self.incomingProducts count]:1;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(tableView==self.outgoingProductTableView)
        return [NSLocalizedString(@"Outbound", @"Heading for Outgoing Product section of Inventory Landing Page") uppercaseString];
    return [NSLocalizedString(@"Inbound", @"Heading for Incoming Product section of Inventory Landing Page") uppercaseString];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    AGNTableViewHeader *header = [[AGNTableViewHeader alloc] init];
    header.leftLabel.text = [self tableView:tableView titleForHeaderInSection:section];
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 28.0f;
}


//------------------------------------------------------------------------------
// MARK: - Table View Delegate
//------------------------------------------------------------------------------


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.outgoingProductTableView) {
        if([self.outgoingProducts count]==0)
            return NO;
        AGNSampleInventoryTransaction * transaction = self.outgoingProducts[indexPath.row];
        if ([transaction.status isEqualToString:kOpenStatusType])
            return YES;
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.outgoingProductTableView && editingStyle == UITableViewCellEditingStyleDelete) {
        [tableView beginUpdates];
        AGNSampleInventoryTransaction * transaction = self.outgoingProducts[indexPath.row];
        [transaction deleteDraft];
        self.outgoingProducts = [[AGNDataManager defaultInstance] getOutgoingProductForLoggedInUser];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        if([self.outgoingProducts count]==0){
            [tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
        [tableView endUpdates];
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.outgoingProductTableView) {
        AGNSampleInventoryTransaction * transaction = self.outgoingProducts[indexPath.row];
        if ([transaction.status isEqualToString:kOpenStatusType])
            return UITableViewCellEditingStyleDelete;
    }
    return UITableViewCellEditingStyleNone;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(tableView==self.incomingProductTableView){
        if([self.incomingProducts count]==0)
            return;
        AGNSampleInventoryTransaction *txn = self.incomingProducts[indexPath.row];
        [self performSegueWithIdentifier:@"SelectShipmentSegue" sender:txn];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:nil];
    }
    else {
        if([self.outgoingProducts count]==0)
            return;
        AGNSampleInventoryTransaction *txn = self.outgoingProducts[indexPath.row];
        [self performSegueWithIdentifier:@"OpenTransferSegue" sender:txn];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:nil];        
    }
}

- (void)handleUpdateTransactionRevert:(NSNotification *)notification {
    [self fetchProductsAndReloadTables];
}


@end
