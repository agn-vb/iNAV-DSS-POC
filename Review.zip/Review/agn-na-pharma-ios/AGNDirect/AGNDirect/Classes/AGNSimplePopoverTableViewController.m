//
//  AGNViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

////////////////////////////////////////////////////////////////////

// Used throughout the application for the popover selection dialogs

////////////////////////////////////////////////////////////////////

#import "AGNSimplePopoverTableViewController.h"
#import "AGNTableView.h"

static const float kMaxHeightPercentage=.66;

@interface AGNSimplePopoverTableViewController ()
@property (nonatomic, strong) UINavigationController *navigationController;
@property (strong, nonatomic, readwrite) UIViewController *viewController;
@property (nonatomic, strong, readwrite) AGNTableView *tableView;
@end

@implementation AGNSimplePopoverTableViewController

@synthesize headerView=_headerView;
@synthesize maxWidthPercentage=_maxWidthPercentage;

- (id)initWithDelegate:(id<AGNPopoverDelegate>)delegate andTitle:(NSString *)title {
    self.includeSearchBar=NO;
    self.rowHeight=-1.0; // means not set
    AGNTableView *table = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view = table;
    vc.title = title;
    self.viewController = vc;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    self = [super initWithContentViewController:nav];
    if (self) {
        table.delegate = self;
        table.dataSource = self;
        self.tableView = table;
        self.popOverDelegate = delegate;
        self.delegate = (id)delegate;
        self.navigationController = nav;
    }

    return self;
}

- (void)presentPopoverFromRect:(CGRect)rect inView:(UIView *)view permittedArrowDirections:(UIPopoverArrowDirection)arrowDirections animated:(BOOL)animated {
    [self.tableView reloadData];
    [self.tableView layoutIfNeeded];
    CGSize size = [self.tableView contentSize];
    
    if(view){
        float height = size.height;
        float maxHeight =  view.frame.size.height *kMaxHeightPercentage;
        float width = view.frame.size.width;
        if(self.maxWidthPercentage){
            width = width*[self.maxWidthPercentage floatValue];
        }
        if(size.height > maxHeight)
            height = maxHeight;
        if (height <= self.tableView.contentSize.height) {
            self.tableView.scrollEnabled = NO;
        } else {
            self.tableView.scrollEnabled = YES;
        }
        height += self.navigationController.navigationBar.frame.size.height;
        size = CGSizeMake(width,height);
    }
    self.popoverContentSize = size;
    [self.tableView setScrollEnabled:YES];
    
    [super presentPopoverFromRect:rect inView:view permittedArrowDirections:arrowDirections animated:animated];
    
//    [self.searchBar becomeFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.numberRowsBlock)
        return self.numberRowsBlock(tableView,section);
    return self.objectArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.cellBlock) {
        return self.cellBlock(tableView, indexPath);
    }

    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if(self.includeSearchBar){
        return 44.0;
    }
    return 0.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(self.rowHeight>0)
        return self.rowHeight;
    return tableView.rowHeight;
}


-(UIView *)headerView{
    if(!_headerView){
        _headerView = [[UIView alloc]init];
        self.searchBar = [[UISearchBar alloc]init];
        if(self.searchBarDelegate)
            self.searchBar.delegate=self.searchBarDelegate;
        self.searchBar.translatesAutoresizingMaskIntoConstraints = NO;
        [self.headerView addSubview:self.searchBar];
        
        NSDictionary *viewsDict = @{ @"searchBar" : self.searchBar, @"view" :self.headerView };
        NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[searchBar]|" options:0 metrics:nil views:viewsDict];
        [self.headerView addConstraints:constraints];
        constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[searchBar(==44)]" options:0 metrics:nil views:viewsDict];
        [self.headerView addConstraints:constraints];
        constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[view(==searchBar)]" options:0 metrics:nil views:viewsDict];
        [self.headerView addConstraints:constraints];
        if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
            self.searchBar.backgroundImage = [UIImage imageNamed:@"bar-bigblue"];
        }else{
        self.searchBar.backgroundImage = [UIImage imageNamed:@"bar-biggrey"];

        }


        return self.headerView;

    }
    return _headerView;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if(self.includeSearchBar) {
        return self.headerView;
    }
    else return nil;
}

-(void)addBackButton{
    UIImage *normal = [[UIImage imageNamed:@"btn-smblue"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 4.0f, 2.0f)];
    UIImage *highlighted = [[UIImage imageNamed:@"btn-smblue-hi"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 3.0f, 2.0f)];
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithTitle:@"BACK" style:UIBarButtonItemStyleBordered target:self action:@selector(backButtonTapped)];
    [back setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [back setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
    self.viewController.navigationItem.leftBarButtonItem = back;
}

-(void)backButtonTapped{
    [self.popOverDelegate popoverBackButtonPressed:(self)];
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([self.popOverDelegate respondsToSelector:@selector(objectSelected:)]){
        [self.popOverDelegate objectSelected:indexPath.row];
    }
    
    if (!self.tableView.allowsMultipleSelection) {
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    }
}

@end
