//
//  AGNCallHistoryViewController.h
//  AGNDirect
//
//  Created by Adam McLain on 8/8/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSimplePopoverTableViewController.h"
#import "AGNViewController.h"
#import "AGNRequestForm.h"

static NSString * const AGNCallHistorySelectedKey = @"AGNCallHistorySelected";

@interface AGNCallHistoryViewController : AGNViewController <UITableViewDelegate, UITableViewDataSource, AGNPopoverDelegate, UIPopoverControllerDelegate>


- (void)navigateToCall:(AGNCall *)call;
- (void)navigateToForm:(AGNRequestForm *)form;

@end
