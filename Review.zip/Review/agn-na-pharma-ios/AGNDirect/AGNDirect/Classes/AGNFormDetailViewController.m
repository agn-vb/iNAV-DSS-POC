//
//  AGNFormDetailViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/29/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNFormDetailViewController.h"
#import "AGNSignatureViewController.h"
#import "AGNRequestFormItem.h"
#import "NSManagedObjectContext+DDSFExtensions.h"
#import "AGNTableViewHeader.h"
#import "AGNTextFieldCell.h"
#import "AGNCaptureSignatureViewController.h"
#import "AGNAccountAddressPopover.h"
#import "NSManagedObjectContext+RequestFormExtensions.h"
#import "AGNSingleLineCell.h"
#import "AGNRequestFormItemCell.h"
#import "AGNContactInfoPopoverController.h"
#import "AGNPopoverTableViewController.h"
#import "AGNRSS.h"
#import "AGNODRReason.h"
#import "AGNRootViewController.h"

typedef void (^AGNVoidBlock) (void);

enum DeliveryMethods  {
    DMMail=0,
    DMEmail,
    DMFax,
    DMPhone,
    DMOther
};

#define kHeight 44

static NSString *kCellIdentifier = @"Cell";

@interface AGNFormDetailViewController ()

@property (nonatomic, assign) BOOL readonly;

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property int* memoryBuffer;
@property (strong, nonatomic) AGNAccountAddressPopover * accountAddressPopover;
@property (strong, nonatomic) AGNSimplePopoverTableViewController *productPopover;
@property (strong, nonatomic) AGNRequestFormItemCell * popoverTargetCell;
@property (strong, nonatomic) NSMutableArray * availableProducts;

@property (strong, nonatomic) AGNTableViewHeader *tableHeaderView;

@property (strong, nonatomic) NSMutableArray * items;

@property (strong, nonatomic) AGNContactInfoPopoverController *phonePopover;
@property (strong, nonatomic) AGNContactInfoPopoverController *faxPopover;
@property (strong, nonatomic) AGNContactInfoPopoverController *emailPopover;

@property (strong, nonatomic) AGNPopoverTableViewController *rssPopover;
@property (strong, nonatomic) AGNPopoverTableViewController *odrReasonPopover;

@property (strong, nonatomic) NSMutableArray * phoneNumbers;

@property int selectedPhone;

@property (nonatomic, strong) NSIndexPath * indexPathForAddedRow;
@property (nonatomic, assign) BOOL animating;

@property (strong, nonatomic) NSMutableArray * faxNumbers;
@property int selectedFax;

@property (strong, nonatomic) NSMutableArray * emailAddresses;
@property int selectedEmail;

@property (strong, nonatomic) NSMutableArray * rssEntries;
@property (strong, nonatomic) NSMutableArray * odrReasons;

@property (strong, nonatomic) AGNUpdateTransactionValueHolder * updateAccountTxn;


@property (weak, nonatomic) IBOutlet UILabel *reasonLabel;

@property (weak, nonatomic) IBOutlet UILabel *rssLabel;

@property (strong, nonatomic) UIAlertView *canDismissAlertView;

@property (weak, nonatomic) UITextView * activeField;

@property (strong, nonatomic) NSIndexPath * returnToIndexPath;

@property (nonatomic, assign) BOOL editing;
@property (nonatomic, assign) BOOL keyboardUp;

@property (nonatomic, copy) AGNVoidBlock blockToDoWhenKeyboardDown;

@property (strong, nonatomic) NSString * salesForceId;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topImageViewConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *hcpLabelConstraint;


@end

@implementation AGNFormDetailViewController {
    BOOL _loaded;
    BOOL _addingRow;
}

static const int  kAGNMemoryBufferSize=7*1024*1024;
@synthesize topImageViewConstraint;
@synthesize topHeaderHeightConstraint;
@synthesize hcpLabelConstraint;

- (NSMutableArray*)items {
    if (!_items)
        _items = [NSMutableArray array];

    return _items;
}

- (int)allowedNumberOfQuestions {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSNumber * value = [defaults objectForKey:kAGNUserDefaultsKeyAllowedNumberOfQuestions];
    if (value)
        return [value intValue];
    else
        return 10;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderHeightConstraint.constant=44.0f;
        self.topImageViewConstraint.constant=0.0f;
        self.hcpLabelConstraint.constant=0.0f;
        
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderHeightConstraint.constant=64.0f;
        self.topImageViewConstraint.constant=20.0f;
        self.hcpLabelConstraint.constant=20.0f;
    }

	// Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor AGNNorilskSneg];
    self.requestItemsTableView.delegate=self;
    self.requestItemsTableView.dataSource=self;
    self.phoneTextField.delegate = self;
    self.rssTextField.delegate = self;
    self.reasonTextField.delegate = self;
    
    
    
    // Hide empty rows on the table view
    UIView * footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1024, 1)];
    footerView.backgroundColor = [UIColor clearColor];
    self.requestItemsTableView.tableFooterView = footerView;
    self.requestItemsTableView.backgroundColor = [UIColor clearColor];
    self.headerContainerView.backgroundColor = [UIColor AGNDropShadow];
    
    // Setup label colors
    self.rssLabel.textColor = [UIColor AGNGreyMatter];
    self.rssTextField.textColor = [UIColor AGNGreyMatter];
    self.reasonLabel.textColor = [UIColor AGNGreyMatter];
    self.reasonTextField.textColor = [UIColor AGNGreyMatter];
    self.phoneLabel.textColor = [UIColor AGNGreyMatter];
    self.phoneTextField.textColor = [UIColor AGNGreyMatter];
    self.deliveryMethodLabel.textColor = [UIColor AGNGreyMatter];
    
    NSAttributedString * buttonString = [[NSAttributedString alloc] initWithString:@"GET SIGNATURE" attributes:[UIButton agnAttributedStringAttributes]];
    [self.getSignatureButton setAttributedTitle:buttonString forState:UIControlStateNormal];

    [self hideReason];

    [self setupConstraints];
 }

-(void)hideReason{
    self.reasonLabel.hidden=YES;
    self.reasonTextField.hidden=YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNSignatureCapturedNotification object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _loaded=NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(signatureCaptured:) name:AGNSignatureCapturedNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(cellBeganEditing:)
                                                 name:kAGNNotificationRequestFormBeganEditing object:nil];


    [self.deliveryMethodControl addTarget:self
                              action:@selector(updateDeliveryMethod)
                    forControlEvents:UIControlEventValueChanged];

    if(!self.requestForm){
        _readonly = NO;
        self.updateAccountTxn=nil;
        [self allocateMemoryBuffer];
        self.requestForm = (AGNRequestForm *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNRequestForm" inManagedObjectContext:self.managedObjectContext];
        self.requestForm.address = (AGNAddress*)[self.requestForm.managedObjectContext objectWithID:self.hcpAddress.objectID];
        self.requestForm.account = (AGNAccount*)[self.requestForm.managedObjectContext objectWithID:self.hcp.objectID];
        self.requestForm.salesForceAccountId = self.requestForm.account.salesForceId;
        self.requestForm.salesForceAddressId = self.requestForm.address.salesForceId;
        if ([AGNAppDelegate sharedDelegate].loggedInSalesRep) {
            self.requestForm.salesRep =  (AGNSalesRep*)[self.requestForm.managedObjectContext objectWithID:[AGNAppDelegate sharedDelegate].loggedInSalesRep.objectID];
        }
        self.requestForm.salesForceRepId=self.requestForm.salesRep.salesForceId;
        self.requestForm.type=self.requestFormType;
        self.requestForm.guid = [[NSUUID UUID] UUIDString];
        self.requestForm.status = kAGNRequestFormStatusNew;
        if(self.requestForm.account.phone){
            self.requestForm.phone = self.requestForm.account.phone;
            self.phoneTextField.text = self.requestForm.account.phone;
        }
        self.requestForm.deliveryMethod = kAGNRequestFormDeliveryMethodMail;
        self.requestForm.mobileCreateTimestamp = [NSDate date];
        // add the restore state key
        [self persistCurrentFormInfo];

        // Also, add the first row
        AGNRequestFormItem * item = [NSEntityDescription insertNewObjectForEntityForName:@"AGNRequestFormItem" inManagedObjectContext:self.managedObjectContext];
        item.form = self.requestForm;
        [self.items addObject:item];
        [self.requestItemsTableView reloadData];
        log4Info(@"Created new form %@ ",self.requestForm);
        
        _loaded = YES;
    }
    if (!_loaded) {
        self.salesForceId=self.requestForm.salesForceId;
        log4Info(@"Opened form %@",self.requestForm);
        _readonly = !self.requestForm.hasNewStatus; // Loading an existing form
        NSSortDescriptor * sort = [[NSSortDescriptor alloc]initWithKey:@"ordinal" ascending:YES];
        _items = [[self.requestForm.items.allObjects sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort] ] mutableCopy];
//        if(self.requestForm.odrReason)
//            self.reasonTextField.text=self.requestForm.odrReason;
        if(self.requestForm.rssName)
            self.rssTextField.text = self.requestForm.rssName;
        if(self.requestForm.phone)
            self.phoneTextField.text = self.requestForm.phone;
        [self updateSelectedDeliveryMethodState];
        [self.requestItemsTableView reloadData];
        _loaded = YES;
    }

    [self configureView];

}

-(void) reloadContent{
    if(_readonly && self.salesForceId){
        log4Info(@"reloading form");
        AGNRequestForm *refreshedForm = nil;
        if(self.salesForceId){
            refreshedForm = (AGNRequestForm *)[[AGNDataManager defaultInstance]undeletedObjectOfType:@"AGNRequestForm" forId:self.salesForceId];
        }
        if(!refreshedForm){
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
        }
        else{
            NSSortDescriptor * sort = [[NSSortDescriptor alloc]initWithKey:@"ordinal" ascending:YES];
            _items = [[self.requestForm.items.allObjects sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort] ] mutableCopy];
            if(self.requestForm.odrReason)
                self.reasonTextField.text=self.requestForm.odrReason;
            if(self.requestForm.rssName)
                self.rssTextField.text = self.requestForm.rssName;
            if(self.requestForm.phone)
                self.phoneTextField.text = self.requestForm.phone;
            [self updateSelectedDeliveryMethodState];
            [self.requestItemsTableView reloadData];
        }
    }
}

-(void)configureViewElement:(UIView*)view{
    [view setTranslatesAutoresizingMaskIntoConstraints:NO];
    [view removeConstraints:view.constraints];
}

-(BOOL)shouldShowRSS{
    if(!self.requestForm.hasNewStatus){
        return YES;
    }
    NSArray * rssEntries = [self.managedObjectContext  AGNAllActiveRSS];
    return [rssEntries count]>0;
}

- (void)setupConstraints {

    [self configureViewElement:self.rssTextField];
    [self configureViewElement:self.rssLabel];
    [self configureViewElement:self.phoneLabel];
    [self configureViewElement:self.phoneTextField];
    [self configureViewElement:self.reasonTextField];
    [self configureViewElement:self.reasonLabel];
    [self configureViewElement:self.deliveryMethodLabel];
    [self configureViewElement:self.deliveryMethodControl];
    [self configureViewElement:self.deliveryInfoLabel];
    [self configureViewElement:self.doctorInfoLabel];
    [self configureViewElement:self.signatureView];
    [self configureViewElement:self.getSignatureButton];

    self.deliveryInfoLabel.font=[UIFont boldSystemFontOfSize:14];
    self.deliveryInfoLabel.lineBreakMode=NSLineBreakByWordWrapping;
    self.deliveryInfoLabel.numberOfLines=0;


    NSDictionary *views =
    @{
      @"headerContainerView" :self.rssTextField.superview,
      @"rssLabel" : self.rssLabel ,
      @"rssTextField" : self.rssTextField ,
      @"phoneLabel" : self.phoneLabel ,
      @"phoneTextField" : self.phoneTextField ,
      @"reasonLabel" : self.reasonLabel ,
      @"reasonTextField" : self.reasonTextField,
      @"deliveryMethodLabel" : self.deliveryMethodLabel ,
      @"deliveryMethodControl" : self.deliveryMethodControl ,
      @"deliveryInfoLabel" : self.deliveryInfoLabel ,
      @"doctorInfoLabel" : self.doctorInfoLabel ,
      @"signatureView" : self.signatureView ,
      @"getSignatureButton" : self.getSignatureButton
      };
    
    UIView *parentView = self.detailsView;

    NSArray * existingConstraints = self.rssTextField.superview.constraints;
    [self.rssLabel.superview removeConstraints:existingConstraints];
    
    // Set up vertical grid
    [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-[reasonLabel]-16-[phoneLabel]-(>=10)-[doctorInfoLabel]-|" options:0 metrics:nil views:views]];
    
    // Let's distribute the longest, and then we will align the rest: reason + delivery method
    [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                @"|-[reasonLabel]-[reasonTextField]-(>=8)-[deliveryMethodLabel]-[deliveryMethodControl(==300)]-|"
                                                                       options:0 metrics:nil views:views]];
    
    
    // Now align the other labels/fields

    // Reason
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.reasonTextField attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.reasonLabel attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    
    // Phone
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.phoneLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.reasonLabel attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.phoneTextField attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.reasonTextField attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.phoneTextField attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.reasonTextField attribute:NSLayoutAttributeWidth multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.phoneTextField attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.phoneLabel attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    
    // RSS
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.rssLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.reasonLabel attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.rssTextField attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.reasonLabel attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.rssLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodLabel attribute:NSLayoutAttributeRight multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.rssTextField attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodControl attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.rssTextField attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodControl attribute:NSLayoutAttributeWidth multiplier:1.0 constant:0]];
    
    // Delivery method
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.deliveryMethodLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.phoneLabel attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.deliveryMethodControl attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.phoneLabel attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    
    // Delivery value
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.deliveryInfoLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.phoneLabel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:10.0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.deliveryInfoLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodLabel attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0.0]];

    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.deliveryInfoLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodControl attribute:NSLayoutAttributeRight multiplier:1.0 constant:0.0]];


    // Doctor Info Label
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.doctorInfoLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.phoneLabel attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0.0]];
//    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.doctorInfoLabel attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:parentView attribute:NSLayoutAttributeWidth multiplier:0.47 constant:0.0]];

    // Signature View
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.signatureView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodControl attribute:NSLayoutAttributeRight multiplier:1.0 constant:0.0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.signatureView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:parentView attribute:NSLayoutAttributeWidth multiplier:0.47 constant:0.0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.signatureView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.deliveryInfoLabel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:8.0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.signatureView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.doctorInfoLabel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0.0]];
    [self.signatureView setupConstraints];
    
    // Signature button
    [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                @"V:[getSignatureButton(==34)]" options:0 metrics:nil views:views]];
    
    
    [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                @"|-[doctorInfoLabel]-[getSignatureButton(==200)]-|" options:0 metrics:nil views:views]];
    
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.getSignatureButton attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.doctorInfoLabel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0.0]];
    [parentView addConstraint:[NSLayoutConstraint constraintWithItem:self.getSignatureButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.deliveryMethodControl attribute:NSLayoutAttributeRight multiplier:1.0 constant:0.0]];

    self.doctorInfoLabel.lineBreakMode=NSLineBreakByWordWrapping;

}

-(void)updateSelectedDeliveryMethodState{
    if(self.requestForm.deliveryMethod){
        if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodEmail])
            self.deliveryMethodControl.selectedSegmentIndex=DMEmail;
        else if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodFax])
            self.deliveryMethodControl.selectedSegmentIndex=DMFax;
        else if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodPhone])
            self.deliveryMethodControl.selectedSegmentIndex=DMPhone;
        else 
            self.deliveryMethodControl.selectedSegmentIndex=DMMail;
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [self updateButtonEnablement];
}


-(NSManagedObjectContext *)managedObjectContext{
    if(!_managedObjectContext){
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
      [_managedObjectContext setPersistentStoreCoordinator:[AGNAppDelegate sharedDelegate].persistentStoreCoordinator];

    }
    return _managedObjectContext;
}

- (void)switchToReadonly {
    self.getSignatureButton.hidden = YES;
    self.switchHCPButton.hidden = YES;
    
    self.signatureView.hidden = NO;
    self.getSignatureButton.hidden = YES;
    
    // Disable the remaining fields
    self.deliveryMethodControl.userInteractionEnabled = NO;
    
    self.phoneTextField.userInteractionEnabled = NO;
    self.phoneTextField.backgroundColor = [UIColor clearColor];
    self.phoneTextField.borderStyle = UITextBorderStyleNone;
    self.phoneTextField.font = [UIFont AGNAvenirMedium16];
    
    self.rssTextField.userInteractionEnabled = NO;
    self.rssTextField.userInteractionEnabled = NO;
    self.rssTextField.backgroundColor = [UIColor clearColor];
    self.rssTextField.borderStyle = UITextBorderStyleNone;
    self.rssTextField.font = [UIFont AGNAvenirMedium16];
    
    self.reasonTextField.userInteractionEnabled = NO;
    self.reasonTextField.userInteractionEnabled = NO;
    self.reasonTextField.backgroundColor = [UIColor clearColor];
    self.reasonTextField.borderStyle = UITextBorderStyleNone;
    self.reasonTextField.font = [UIFont AGNAvenirMedium16];

}

- (void)configureView {
    [self configureHCPLabel];
    [self configureHCPInfo];
    [self deliveryMethodUpdated];
    [self configureForType];
    [self configureSegmentedControlOldAssets];
 
    if (_readonly) {
        self.submitFormButton.hidden = YES;
        [self switchToReadonly];
        [self.signatureView setClosedMode:[self.requestForm.signatureCaptureDate agnFormattedTimestampString]];
    }
    else if (self.requestForm.signatureImage) {
        self.signatureView.hidden = NO;
        self.getSignatureButton.hidden = YES;
        [self switchToReadonly];        
        [self.signatureView setSignatureCapturedMode:self.requestForm.signatureImage];
    }
    else {
        self.signatureView.hidden = YES;
        self.getSignatureButton.hidden = NO;
        [self updateButtonEnablement];
    }

    if(![self shouldShowRSS]){
        //        self.rssLabel.hidden=YES;
        //        self.rssTextField.hidden=YES;

        self.rssTextField.enabled=NO;
        self.rssTextField.alpha=.4f;
    }else{
        //        self.rssLabel.hidden=NO;
        //        self.rssTextField.hidden=NO;
        self.rssTextField.enabled=YES;
        self.rssTextField.alpha=1.0f;
    }

}

- (void)configureSegmentedControl {
    UIImage *noneSelected = [UIImage imageNamed:@"FormsSegmentedControl-EndLeftUnselected"];

    UIImage *unselected = [[UIImage imageNamed:@"FormsSegmentedControl-StretchUnselected"]resizableImageWithCapInsets:UIEdgeInsetsMake(15.0f, 0.0f, 15.0f, 0.0f)];
    UIImage *selected = [[UIImage imageNamed:@"FormsSegmentedControl-StretchSelected"]resizableImageWithCapInsets:UIEdgeInsetsMake(15.0f, 0.0f, 15.0f, 0.0f)];

    [self.deliveryMethodControl setDividerImage:noneSelected forLeftSegmentState:UIControlStateSelected rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setDividerImage:noneSelected forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setDividerImage:noneSelected forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    NSShadow * shadow  = [[NSShadow alloc]init];
    shadow.shadowColor = [UIColor clearColor];
    [shadow setShadowOffset:CGSizeMake(0, 1)];

    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor whiteColor], NSForegroundColorAttributeName,
                                shadow, NSShadowAttributeName,
                                nil];
    
    [self.deliveryMethodControl setTitleTextAttributes:attributes
                                    forState:UIControlStateNormal];
    
    [self.deliveryMethodControl setBackgroundImage:unselected forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setBackgroundImage:selected forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];

}

-(void)configureSegmentedControlOldAssets{
    UIImage *leftDividerSelected = [UIImage imageNamed:@"SegmentedControl-divider-LeftSelectedRightUnselected"];
    UIImage *rightDividerSelected = [UIImage imageNamed:@"SegmentedControl-divider-LeftUnselectedRightSelected"];
    UIImage *noDividerSelected = [UIImage imageNamed:@"SegmentedControl-divider-LeftUnselectedRightUnselected"];
    UIImage *unselected = [[UIImage imageNamed:@"SegmentedControl-StretchUnselected"] resizableImageWithCapInsets:UIEdgeInsetsMake(15.0f, 0.0f, 15.0f, 0.0f)];
    UIImage *selected = [[UIImage imageNamed:@"SegmentedControl-StretchSelected"] resizableImageWithCapInsets:UIEdgeInsetsMake(15.0f, 0.0f, 15.0f, 0.0f)];
    [self.deliveryMethodControl setDividerImage:leftDividerSelected forLeftSegmentState:UIControlStateSelected rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setDividerImage:rightDividerSelected forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setDividerImage:noDividerSelected forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setBackgroundImage:unselected forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.deliveryMethodControl setBackgroundImage:selected forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];

    UIFont *Boldfont = [UIFont boldSystemFontOfSize:14.0f];

    NSShadow * shadow  = [[NSShadow alloc]init];
    shadow.shadowColor = [UIColor clearColor];
    [shadow setShadowOffset:CGSizeMake(0, 1)];

    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor whiteColor], NSForegroundColorAttributeName,
                                shadow, NSShadowAttributeName,
                                Boldfont,NSFontAttributeName,
                                nil];
    
    [self.deliveryMethodControl setTitleTextAttributes:attributes
                                              forState:UIControlStateNormal];
}

-(void)configureForType{
    if (self.requestForm.isMIR) {
        self.reasonTextField.hidden = YES;
        self.rssTextField.hidden = YES;
        self.reasonLabel.hidden = YES;
        self.rssLabel.hidden = YES;
        
        // Resize the views
        self.headerHeightConstraint.constant = 220.0f;
        self.detailsTopConstraint.constant = -30.0f;
    }
}

-(void)configureHCPLabel{
    self.hcpNameAddressLabel.attributedText = [self attrStringHCPLabel];
}



-(void)configureHCPInfo{
    self.doctorInfoLabel.numberOfLines=6;
    NSMutableAttributedString * string = [[NSMutableAttributedString alloc]init];
    [string appendAttributedString:self.requestForm.nameAddressLabel];

    NSAttributedString * licenseString = [self.requestForm.account licenseLabel:self.requestForm.address];
    if (licenseString.length > 0) {
        [string appendAttributedString:[[NSAttributedString alloc]initWithString:@"\n"]];
        [string appendAttributedString:licenseString];
    }
    self.doctorInfoLabel.attributedText = string;
}

-(NSString *)hcpName{
    if(self.requestForm.account){
        NSString *name = [NSString stringWithFormat:@"%@ %@ ", [self.requestForm.account.firstName uppercaseString], [self.requestForm.account.lastName uppercaseString]];
        return name;
    }


    NSString *name = [NSString stringWithFormat:@"%@ %@ ", [self.requestForm.stampHCPFirstName uppercaseString], [self.requestForm.stampHCPLastName uppercaseString]];
    return name;
}

-(NSAttributedString *)attrStringHCPLabel{

    UIFont *black21 = [UIFont AGNAvenirBlack21];
    UIFont *medium21 = [UIFont AGNAvenirMedium21];
    UIFont *medium16 = [UIFont AGNAvenirMedium16];

    NSDictionary *blackAttributes = @{ NSFontAttributeName : black21, NSForegroundColorAttributeName : [UIColor whiteColor] };
    NSDictionary *med21Attributes = @{ NSFontAttributeName : medium21, NSForegroundColorAttributeName : [UIColor whiteColor] };
    NSDictionary *med16Attributes = @{ NSFontAttributeName : medium16, NSForegroundColorAttributeName : [UIColor whiteColor] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[self hcpName] attributes:blackAttributes]];
    NSString *profDesig = [NSString stringWithFormat:@" - %@   ",[[self.requestForm professionalDesignation]uppercaseString]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profDesig attributes:med21Attributes]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[self.requestForm singleLineFormattedAddressString] attributes:med16Attributes]];
    return formattedString;
}

-(NSMutableArray *)availableProducts{
    if(!_availableProducts){
        _availableProducts = [[NSMutableArray alloc]initWithCapacity:30];
    }
    return _availableProducts;
}

- (void)objectSelected:(NSInteger)selected {
    AGNRequestFormProduct * product = (AGNRequestFormProduct*)self.availableProducts[selected];
    log4Info(@"Selected product %@ ",product.productDescription);
    
    self.popoverTargetCell.item.productName = product.productDescription;
    [self.popoverTargetCell update];
    
    [self.productPopover dismissPopoverAnimated:YES];
    self.productPopover = nil; // Make sure it's cleaned up
    
    [self updateButtonEnablement];
    
    if (self.popoverTargetCell.item.question.length == 0)
        [self.popoverTargetCell beginEditing];
    
    self.popoverTargetCell.productHighlighted = NO;
    self.popoverTargetCell = nil;
}

-(AGNTableViewHeader *)tableHeaderView{
    if(!_tableHeaderView){
        _tableHeaderView = [[AGNTableViewHeader alloc] init];
        UIButton *editButton = [[UIButton alloc] init];
        self.editButton = editButton;
        [self.editButton addTarget:self action:@selector(toggleEditMode:) forControlEvents:UIControlEventTouchUpInside];
        
        if (_readonly)
            _tableHeaderView.leftLabel.text = [[self.requestForm formTitle] stringByAppendingFormat:@" (%@)", self.requestForm.status];
        else
            _tableHeaderView.leftLabel.text = [self.requestForm formTitle];
        
        [_tableHeaderView addSecondaryButton:editButton withTitle:@"EDIT"];
        
        [_tableHeaderView.button setImage:[[UIImage imageNamed:@"PlusIcon"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateNormal];
        [_tableHeaderView.button setImage:[[UIImage imageNamed:@"PlusIcon"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateHighlighted];
        NSAttributedString *buttonString = [[NSAttributedString alloc] initWithString:@"" attributes:[UIButton agnAttributedStringAttributes]];
        [_tableHeaderView.button setAttributedTitle:buttonString forState:UIControlStateNormal];

        [_tableHeaderView.button addTarget:self action:@selector(addTapped) forControlEvents:UIControlEventTouchUpInside];
        
        [self updateHeaderButtons];
    }
    return _tableHeaderView;
}

- (void)updateHeaderButtons {
    
    static NSAttributedString * doneString;
    static NSAttributedString * editString;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        doneString = [[NSAttributedString alloc] initWithString:@"DONE" attributes:[UIButton agnAttributedStringAttributes]];
        editString = [[NSAttributedString alloc] initWithString:@"EDIT" attributes:[UIButton agnAttributedStringAttributes]];
    });
    
    
    if (self.requestForm.signatureImage || ![self.requestForm hasNewStatus] || _readonly) {
        self.editButton.hidden = YES;
        self.tableHeaderView.button.hidden = YES;
        return;
    }
    
    if (self.editing) {
        [self.editButton setAttributedTitle:doneString forState:UIControlStateNormal];
        self.tableHeaderView.button.enabled = NO;
        self.tableHeaderView.button.alpha = 0.5f;
    }
    else {
        [self.editButton setAttributedTitle:editString forState:UIControlStateNormal];
        
        if (self.items.count < [self allowedNumberOfQuestions]) {
            self.tableHeaderView.button.enabled = YES;
            self.tableHeaderView.button.alpha = 1.0f;
        }
        else {
            self.tableHeaderView.button.enabled = NO;
            self.tableHeaderView.button.alpha = 0.5f;
        }
    }
    
    if (self.items.count == 0) {
        self.editButton.enabled = NO;
        self.editButton.alpha = 0.5f;
    }
    else {
        self.editButton.enabled = YES;
        self.editButton.alpha = 1.0f;
    }
    
    [self.editButton setNeedsDisplay];
    [self.tableHeaderView.button setNeedsDisplay];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.requestItemsTableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.requestItemsTableView.contentSize = newContentSize;
    
    // Also, if we have product popover, we need to move that cell to visible and re-display the popover from the new position
    if (self.productPopover) {
        [self.requestItemsTableView scrollRectToVisible:self.popoverTargetCell.frame animated:NO];
        [self.productPopover dismissPopoverAnimated:NO];
        self.productPopover = nil;
        [self displayProductPopoverForCell:self.popoverTargetCell forView:self.popoverTargetCell.viewForPopover];
    }

    if (self.rssPopover.popoverVisible) {
        [self.rssPopover dismissPopoverAnimated:NO];
        [self showRSSPopover];
    }
    if(self.odrReasonPopover.popoverVisible){
        [self.odrReasonPopover dismissPopoverAnimated:NO];
        [self showReasonPopover];
    }
    if(self.emailPopover.popoverVisible){
        [self.emailPopover dismissPopoverAnimated:YES];
        [self showEmailPopover];
    }
    if(self.faxPopover.popoverVisible){
        [self.faxPopover dismissPopoverAnimated:YES];
        [self showFaxPopover];
    }
    if(self.phonePopover.popoverVisible){
        [self.phonePopover dismissPopoverAnimated:YES];
        [self showPhonePopover];
    }
    if(self.accountAddressPopover.popoverVisible){
        [self.accountAddressPopover dismissPopoverAnimated:YES];
        [self showSwitchHCPPopover];
    }
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark SearchBar Delegate
//------------------------------------------------------------------------------

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)aSearchText {
    NSArray *searchResults = [self.managedObjectContext AGNProductsForFilterString:aSearchText];
    [self.availableProducts removeAllObjects];
    [self.availableProducts  addObjectsFromArray:searchResults];
    [self.productPopover.tableView reloadData];
    [self.productPopover.searchBar becomeFirstResponder];
}

-(void)deliveryMethodUpdated{
    if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodFax]){
        self.requestForm.email=nil;
        self.updateAccountTxn=nil;
        self.deliveryInfoLabel.text=self.requestForm.fax;
    }
    else if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodEmail]){
        self.requestForm.fax=nil;
        self.deliveryInfoLabel.text=self.requestForm.email;
    }
    else if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodPhone]){
        self.requestForm.email=nil;
        self.updateAccountTxn=nil;
        self.requestForm.fax=nil;
        self.deliveryInfoLabel.text=self.requestForm.phone;
    }
    else{
        self.requestForm.email=nil;
        self.requestForm.fax=nil;
        self.updateAccountTxn=nil;
        self.deliveryInfoLabel.text=self.requestForm.address.singleLineFormattedString;
    }
    log4Info(@"Delivery method updated : %@ %@",self.requestForm.deliveryMethod,self.deliveryInfoLabel.text);
}

-(void)updateDeliveryMethod{
    int deliveryMethod = [self.deliveryMethodControl selectedSegmentIndex];
    switch(deliveryMethod){
        case DMMail: //Mail
            self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodMail;
            log4Info(@"Selected delivery method Mail");
            break;
        case DMEmail: //EMail
            [self showEmailPopover];
            break;
        case DMFax: //Fax
            [self showFaxPopover];
            break;
        case DMPhone: //Phone
            self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodPhone;
            log4Info(@"Selected delivery method Phone");
            break;
        default:
            log4Warn(@"Unexpected value %d from segmented control",deliveryMethod);
    }
    [self deliveryMethodUpdated];
}


//------------------------------------------------------------------------------
// MARK: - TableView Data Source / Delegate
//------------------------------------------------------------------------------

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    if (self.indexPathForAddedRow) {
        AGNRequestFormItemCell * cell = (AGNRequestFormItemCell*)[self.requestItemsTableView cellForRowAtIndexPath:self.indexPathForAddedRow];
        [cell chooseProduct];
        self.indexPathForAddedRow = nil;
        self.animating = NO;
        _addingRow = NO;
    }    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.animating && [self.indexPathForAddedRow isEqual:indexPath]) {
        AGNRequestFormItemCell * c = (AGNRequestFormItemCell*)cell;
        self.indexPathForAddedRow = nil;
        double delayInSeconds = 0.2;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            //code to be executed on the main queue after delay
            [c chooseProduct];
        });
        
        _addingRow = NO;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.items count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"AGNRequestFormItemCell";

    AGNRequestFormItemCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[AGNRequestFormItemCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.delegate = self;
    }

    AGNRequestFormItem * item = self.items[indexPath.row];
    cell.item = item;
    
    if ([self.requestForm.status isEqualToString:kAGNRequestFormStatusNew] && !self.requestForm.signatureImage && !tableView.editing)
        cell.readonly = NO;
    else
        cell.readonly = YES;
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    [self updateHeaderButtons];
    return self.tableHeaderView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kAGNTableViewHeaderHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))
        return 82.0f;
    else
        return 100.f;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath{
    return NO;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return !_readonly && !self.requestForm.signatureImage;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    AGNRequestFormItem * item = (AGNRequestFormItem *)self.items[indexPath.row];
   // [self.managedObjectContext deleteObject:item];

    log4Info(@"Deleting form item %@ at index %d",item,indexPath.row);
    item.form=nil;
    [self.items removeObjectAtIndex:indexPath.row];
    [self.requestItemsTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
    [self updateButtonEnablement];
    
    if (self.items.count == 0) {
        self.requestItemsTableView.editing = NO;
        self.editing = NO;
    }
    
    [self updateHeaderButtons];
}



//------------------------------------------------------------------------------
// MARK: - buttons
//------------------------------------------------------------------------------

- (void)addTapped {
    // We will ignore rapid tapping of the + button - no do anything if we're still adding a previous row
    if (!_addingRow) {
        _addingRow = YES;
        
        __weak AGNFormDetailViewController * _self = self;
        
        self.blockToDoWhenKeyboardDown = ^{
            // Ok, here we need to actually add a row, and then show the product popover for that row
            int index = _self.items.count;
            
            AGNRequestFormItem * item = [NSEntityDescription insertNewObjectForEntityForName:@"AGNRequestFormItem" inManagedObjectContext:_self.requestForm.managedObjectContext];
            item.form = _self.requestForm;
            [_self.items addObject:item];
            [_self.requestItemsTableView reloadData];
            
            _self.indexPathForAddedRow = [NSIndexPath indexPathForRow:index inSection:0];
            
            // Product popover should display after the cell scrolls into view, if we're scrolling.  Otherwise it should appear right after cell is displayed.
            
            CGRect rect = [_self.requestItemsTableView rectForRowAtIndexPath:_self.indexPathForAddedRow];
            // Is cell at least partially invisible?
            if (rect.origin.y + rect.size.height > _self.requestItemsTableView.frame.size.height + _self.requestItemsTableView.contentOffset.y) {
                _self.animating = YES;
                [_self.requestItemsTableView scrollRectToVisible:rect animated:YES];
            }
            [_self updateHeaderButtons];
            [_self updateButtonEnablement];
        };
        
        if (!self.keyboardUp) { // Keyboard is not up, just do it right away
            self.blockToDoWhenKeyboardDown();
            self.blockToDoWhenKeyboardDown = nil;
        }
        else {
            // Dismiss keyboard
            [self.activeField resignFirstResponder];
        }
    }
}

- (IBAction)submitButtonPressed:(id)sender {

    NSDate * now = [NSDate date];
    self.requestForm.startDate=now;
    self.requestForm.endDate=now;
    self.requestForm.status=kAGNRequestFormStatusOpen;
    self.requestForm.mobileLastUpdateTimestamp = [NSDate date];

    log4Info(@"Submitting Request Form %@ with items %@",self.requestForm,self.requestForm.items);
    NSArray *transactions = [self createManageUpdateTransactions];
    [self saveAndEnqueueTransactions:transactions];
    // get rid of restore state key
    [self clearCurrentFormInfo];
    [self saveContext];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];

}

- (void)toggleEditMode:(id)sender {
    //don't allow editing if the call is closed
    if (!self.requestForm.signatureImage && [self.requestForm hasNewStatus]) {
        self.requestItemsTableView.editing = self.editing = !self.editing;
        // Force reload of first header view to display correct button title
        [self.requestItemsTableView reloadData];
    }
}

#pragma mark -
#pragma mark Saving

- (void)completeForm {
    // The form already has all the objects, just need to add ordinals
    NSAssert(self.items.count == self.requestForm.items.count, @"Something went wrong and we're missing items!");
    
    int ordinal = 1;
    for (AGNRequestFormItem * item in self.items)
        item.ordinal = [NSNumber numberWithInt:ordinal++];
}


- (void)saveAndEnqueueTransactions:(NSArray *)updateTransactions {
    //Appending the transactions saves the context, including data model changes.
    //If it fails, it does a rollback - we need to inform user and refresh the interface.
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:updateTransactions]) {
        //TODO: notify user of fail and refresh interface
        log4Error(@"Failed to save call - either appendTransactions failed or MOC save failed");
    }
}


// These are the update statements we'll send to SFDC
- (NSArray *)createManageUpdateTransactions {
    if(!self.requestForm.signatureJSON){
        log4Info(@"Signature JSON should not be null here but it is, trying to regenerate from image %@",self.requestForm.signatureImage);
        NSData *imageData = UIImagePNGRepresentation(self.requestForm.signatureImage);
        self.requestForm.signatureJSON = [imageData agnBase64EncodedString];
        log4Info(@"Regenerated signature %@",[self.requestForm.signatureJSON substringToIndex:100]);
    }

//    upTxn.currentJSONRepresentation = [NSString stringWithFormat:@"{\"encodedSignature\":\"%@\"}",self.call.signatureJSON];


    NSString *currentJSONRepresentation = [self.requestForm jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpsertRequestForm];
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.deleteModelObjectOnRevert = @YES;
    upTxn.guid = self.requestForm.guid;
    upTxn.modelClassName = @"AGNRequestForm";
    upTxn.salesForceId = self.requestForm.salesForceId;
    upTxn.mustSucceed = @YES;
    self.requestForm.signatureImage=nil;

    if(self.updateAccountTxn)
        return @[upTxn,self.updateAccountTxn];
    return @[upTxn];
}


- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
        }
    }
}

-(void)allocateMemoryBuffer{
    if(self.memoryBuffer)
        return;
    log4Info(@"About to launch signature capture, allocating memory");
    self.memoryBuffer = malloc(kAGNMemoryBufferSize);
    if(!self.memoryBuffer){
        log4Error(@"Unable to allocate memory for signature capture!!  Showing alert.");
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Low Memory Detected" message:@"You seem to be running low on memory - please close some other applications before proceeding. If the problem persists, restart your device." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];

        return ;
    }

}

-(void)signatureCaptured:(NSNotification *)notification {

    //    UIImage *image = (UIImage *)notification.object;
    [self.signatureView setSignatureCapturedMode:self.requestForm.signatureImage];
    self.getSignatureButton.hidden = YES;
    self.signatureView.hidden = NO;
    [self switchToReadonly];
    self.requestItemsTableView.editing = NO;
    self.editing = NO;
    [self updateHeaderButtons];
    [self updateButtonEnablement];
    [self.requestItemsTableView reloadData];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

    if([segue.identifier isEqualToString:@"FormsGetSignature"]){
        [self completeForm];
        AGNCaptureSignatureViewController *signatureViewController = (AGNCaptureSignatureViewController *)segue.destinationViewController;
        signatureViewController.memoryBuffer=self.memoryBuffer;
        self.memoryBuffer=nil;
        signatureViewController.requestForm = self.requestForm;
    }
}


//------------------------------------------------------------------------------
// MARK: - switch HCP
//------------------------------------------------------------------------------


-(void) showSwitchHCPPopover {
    __weak AGNFormDetailViewController * _self = self;

    self.accountAddressPopover = [[AGNAccountAddressPopover alloc] initWithTitle:NSLocalizedString(@"Switch HCP", @"Switch HCP Popover Title")
                                                                        onSelect:^(AGNAccount *account, AGNAddress *address) {
                                                                            account = (AGNAccount*)[self.requestForm.managedObjectContext objectWithID:account.objectID];
                                                                                address = (AGNAddress*)[self.requestForm.managedObjectContext objectWithID:address.objectID];
                                                                                _self.requestForm.address = address;
                                                                                _self.requestForm.account = account;
                                                                                _self.requestForm.deliveryMethod = kAGNRequestFormDeliveryMethodMail;
                                                                                _self.phoneTextField.text=nil;
                                                                                _self.requestForm.fax=nil;
                                                                                _self.requestForm.phone=nil;
                                                                                _self.requestForm.email=nil;
                                                                                _self.deliveryMethodControl.selectedSegmentIndex = 0;
                                                                                log4Info(@"switched HCP, new request form %@",self.requestForm);
                                                                                [_self configureView];
                                                                                [_self deliveryMethodUpdated];
                                                                                [self updateButtonEnablement];
                                                                            
                                                                            [_self.accountAddressPopover dismissPopoverAnimated:YES];
                                                                            _self.accountAddressPopover=nil;
                                                                        }];

    CGRect rect = self.switchHCPButton.frame;
    rect = [self.view convertRect:rect fromView:self.switchHCPButton.superview];
    [self.accountAddressPopover presentPopoverFromRect:rect
                                                inView:self.view
                              permittedArrowDirections:UIPopoverArrowDirectionUp
                                              animated:YES];    
}


- (IBAction)switchHCPTapped:(id)sender {
    log4Info(@"Switch HCP Tapped");
    
    [self showSwitchHCPPopover];
}

-(void)updateButtonEnablement{
    if ([self canGetSignature]) {
        self.getSignatureButton.enabled = YES;
        self.getSignatureButton.alpha = 1.0f;
    }
    else {
        self.getSignatureButton.enabled = NO;
        self.getSignatureButton.alpha = 0.5f;
    }
    
    if (self.requestForm.hasNewStatus && self.requestForm.signatureImage)
        self.submitFormButton.enabled = YES;
    else
        self.submitFormButton.enabled = NO;

    if(self.requestForm.signatureImage || self.readonly)
        self.switchHCPButton.hidden=YES;
    else
        self.switchHCPButton.hidden=NO;

    if(self.requestForm.phone && ![self.requestForm.phone AGNIsValidFormattedPhoneNumber])
        self.phoneTextField.backgroundColor = [UIColor AGNWarny];
}

- (BOOL)canGetSignature {
    if(![self.requestForm hasNewStatus])
        return NO;

    if(self.requestForm.signatureImage)
        return NO;

    if(self.items.count==0)
        return NO;

    if(!self.requestForm.phone || ![self.requestForm.phone AGNIsValidFormattedPhoneNumber])
        return NO;

    if(![self allLinesAreValid])
        return NO;

    if(!self.requestForm.deliveryMethod)
        return NO;

//    if(self.requestForm.isODR){
//        if(!self.requestForm.odrReason)
//            return NO;
//    }

    return YES;
}

- (BOOL)allLinesAreValid {
    for (AGNRequestFormItem * item in self.items) {
        if ([item.question stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length == 0)
            return NO;
        if (item.productName.length == 0)
            return NO;
    }
    return YES;
}

//------------------------------------------------------------------------------
// MARK: - Phone popover
//------------------------------------------------------------------------------

-(void)textFieldDidBeginEditing:(UITextField *)textField    {
    if(textField==self.phoneTextField){
        [textField resignFirstResponder];
        [self showPhonePopover];
    }
    if(textField==self.rssTextField){
        [textField resignFirstResponder];
        [self showRSSPopover];
    }
    if(textField==self.reasonTextField){
        [textField resignFirstResponder];
        [self showReasonPopover];

    }
}

-(void)setPhone:(NSString *) phone{
    self.phoneTextField.text = phone;
    self.requestForm.phone = phone;
    if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodPhone])
        self.deliveryInfoLabel.text=phone;
    [self updateButtonEnablement];

}

-(void)addPhone:(NSString *)phone{
    [self.phoneNumbers addObject:phone];
    [self setPhone:phone];
    [self.phoneTextField resignFirstResponder];
    self.selectedPhone= [self.phoneNumbers indexOfObject:phone];
}

-(NSMutableArray *)phoneNumbers{
    if(!_phoneNumbers){
        _phoneNumbers = [[NSMutableArray alloc]initWithCapacity:4];
    }
    return _phoneNumbers;
}

-(NSMutableArray *)faxNumbers{
    if(!_faxNumbers){
        _faxNumbers = [[NSMutableArray alloc]initWithCapacity:4];
    }
    return _faxNumbers;
}

-(NSMutableArray *)emailAddresses{
    if(!_emailAddresses){
        _emailAddresses = [[NSMutableArray alloc]initWithCapacity:4];
    }
    return _emailAddresses;
}


-(void) showPhonePopover {
    self.phoneTextField.backgroundColor = [UIColor whiteColor];
    self.selectedPhone=-1;
    _phonePopover = [[AGNContactInfoPopoverController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Telephone Numbers On File", @"Phone Popover Title") andMode:Phone];
    [self.phoneNumbers removeAllObjects];
    if(self.requestForm.account.phone && self.requestForm.account.phone.length==10){
        [self.phoneNumbers addObject:self.requestForm.account.phone];
        self.selectedPhone=0;
    }
    if(self.requestForm.account.mobilePhone){
        [self.phoneNumbers addObject:self.requestForm.account.mobilePhone];
    }
    if(self.requestForm.address.officePhone){
        [self.phoneNumbers addObject:self.requestForm.address.officePhone];
    }
    if(self.phoneTextField.text && [self.phoneTextField.text AGNIsValidFormattedPhoneNumber] ){
        if(![self.phoneNumbers containsObject:self.phoneTextField.text] && [self.phoneTextField.text AGNIsValidFormattedPhoneNumber])
            [self.phoneNumbers addObject:self.phoneTextField.text];
        self.selectedPhone=[self.phoneNumbers indexOfObject:self.phoneTextField.text];
    }

    __weak AGNFormDetailViewController * _self = self;


    self.phonePopover.objectArray = self.phoneNumbers;
    self.phonePopover.selected=^(){
        return [_self selectedPhone];
    };
    self.phonePopover.onSelect=^(int selected){
        _self.selectedPhone=selected;
        [_self setPhone:_self.phoneNumbers[selected]];
        _log4Info(@"Selected phone number %@",_self.requestForm.phone);
        [_self.phoneTextField resignFirstResponder];

    };
    self.phonePopover.onAdd=^(NSString * newPhone){
        if([newPhone AGNIsValidFormattedPhoneNumber]){
            _log4Info(@"Adding new phone number %@",newPhone);
            [_self addPhone:newPhone];
        }else if(_self.requestForm.phone){
            _self.phoneTextField.text = _self.requestForm.phone;
        }else{
            _self.phoneTextField.text = newPhone;
            _self.phoneTextField.backgroundColor = [UIColor AGNWarny];
        }
    };
    
    CGRect rect = self.phoneTextField.frame;
    rect = [self.view convertRect:rect fromView:self.phoneTextField.superview];
    [self.phonePopover presentPopoverFromRect:rect
                                  inView:self.view
                permittedArrowDirections:UIPopoverArrowDirectionDown
                                animated:YES];
}

-(void)resetToDeliveryMethodMail{
    self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodMail;
    self.deliveryMethodControl.selectedSegmentIndex=DMMail;
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController{
    log4Debug(@"Dismissed popover %@",popoverController);
    if (self.productPopover == popoverController) {
        self.productPopover = nil;
        self.popoverTargetCell.productHighlighted = NO;
        self.popoverTargetCell = nil;
    }
    else {
        if ([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodEmail]&& ! (self.requestForm.email.length >0))
            [self resetToDeliveryMethodMail];
        else if([self.requestForm.deliveryMethod isEqualToString:kAGNRequestFormDeliveryMethodFax]&&!(self.requestForm.fax.length > 0))
            [self resetToDeliveryMethodMail];
        [self updateSelectedDeliveryMethodState];
        [self updateButtonEnablement];
    }
}

-(void) showFaxPopover {
    self.selectedFax=-1;
    self.faxPopover = [[AGNContactInfoPopoverController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Fax Numbers On File", @"Fax Popover Title") andMode:Phone];

    [self.faxNumbers removeAllObjects];
    if(self.requestForm.fax){
        self.selectedFax=0;
        [self.faxNumbers addObject:self.requestForm.fax ];
    }
    if(self.requestForm.account.fax  && ![self.faxNumbers containsObject:self.requestForm.account.fax]){
        [self.faxNumbers addObject:self.requestForm.account.fax];
    }
    if(self.requestForm.address.faxPhone && ![self.faxNumbers containsObject:self.requestForm.address.faxPhone]){
        [self.faxNumbers addObject:self.requestForm.address.faxPhone];
    }


    __weak AGNFormDetailViewController * _self = self;


    self.faxPopover.objectArray = self.faxNumbers;
    self.faxPopover.selected=^(){
        return [_self selectedFax];
    };
    self.faxPopover.onSelect=^(int selected){
        _self.selectedFax=selected;
        _self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodFax;
        _self.requestForm.fax = _self.faxNumbers[selected];
        [_self deliveryMethodUpdated];
    };
    self.faxPopover.onAdd=^(NSString * newFax){
        _self.requestForm.fax = newFax;
        _self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodFax;
        [_self deliveryMethodUpdated];
    };

    CGRect rect = self.deliveryMethodControl.frame;
    rect = [self.view convertRect:rect fromView:self.deliveryMethodControl.superview];
    [self.faxPopover presentPopoverFromRect:rect
                                       inView:self.view
                     permittedArrowDirections:UIPopoverArrowDirectionDown
                                     animated:YES];
}


-(void) showEmailPopover {
    self.selectedEmail=-1;
    self.EmailPopover = [[AGNContactInfoPopoverController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Email Addresses On File", @"Email Popover Title") andMode:Email];

    [self.emailAddresses removeAllObjects];
    if(self.requestForm.email){
        if(![self.emailAddresses containsObject:self.requestForm.email])
            [self.emailAddresses addObject:self.requestForm.email];
        self.selectedEmail=0;

    }
    if(self.requestForm.account.email1){
        if(![self.emailAddresses containsObject:self.requestForm.account.email1])
        [self.emailAddresses addObject:self.requestForm.account.email1];
    }
    if(self.requestForm.account.email2){
        if(![self.emailAddresses containsObject:self.requestForm.account.email2])
            [self.emailAddresses addObject:self.requestForm.account.email2];
    }
    if(self.requestForm.account.email3){
        if(![self.emailAddresses containsObject:self.requestForm.account.email3])
            [self.emailAddresses addObject:self.requestForm.account.email3];
    }


    __weak AGNFormDetailViewController * _self = self;


    self.emailPopover.objectArray = self.emailAddresses;
    self.emailPopover.selected=^(){
        return [_self selectedEmail];
    };
    self.emailPopover.onSelect=^(int selected){
        _self.selectedEmail=selected;
        _self.requestForm.Email = _self.emailAddresses[selected];
        _self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodEmail;
        [_self deliveryMethodUpdated];
    };
    self.emailPopover.onAdd=^(NSString * newEmail){
        if(![newEmail AGNIsValidEmail]){
            [_self resetToDeliveryMethodMail];
            NSString * title = NSLocalizedString(@"Invalid Email Address", @"Title for invalid email alert view");
            NSString * message = NSLocalizedString(@"Please enter a valid email address.", @"Message for invalid email alert view");
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:title message:message delegate:_self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alertView show];
        }else{
            _self.requestForm.Email = newEmail;
            _self.requestForm.deliveryMethod=kAGNRequestFormDeliveryMethodEmail;
            if ([_self.requestForm.account addEmailIfPossible:newEmail]) {
                _self.updateAccountTxn=[_self createUpdateAccountTxn];
            }
            [_self deliveryMethodUpdated];
        }
    };

    CGRect rect = self.deliveryMethodControl.frame;
    rect = [self.view convertRect:rect fromView:self.deliveryMethodControl.superview];
    [self.emailPopover presentPopoverFromRect:rect
                                     inView:self.view
                   permittedArrowDirections:UIPopoverArrowDirectionDown
                                   animated:YES];
}

- (AGNUpdateTransactionValueHolder *)createUpdateAccountTxn
{
    AGNAccount *account = self.requestForm.account;
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init];

    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpdateAccount];
    upTxn.undoJSONRepresentation = account.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = [account jsonRepresentationForUpdate];
    upTxn.deleteModelObjectOnRevert = @NO;
    upTxn.modelClassName = @"AGNAccount";
    upTxn.salesForceId = account.salesForceId;

    //    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:@[upTxn]]) {
    //        log4Error(@"Failed to save account - either appendTransactions failed or MOC save failed");
    //    }

    return upTxn;
}

//------------------------------------------------------------------------------
// MARK: - RSS popover
//------------------------------------------------------------------------------


-(NSMutableArray *)rssEntries{
    if(!_rssEntries){
        _rssEntries = [[NSMutableArray alloc]init];
    }
    return _rssEntries;
}

-(void) showRSSPopover {
    self.rssPopover =   [[AGNPopoverTableViewController alloc]initWithDelegate:self andTitle:NSLocalizedString(@"RSS", @"RSS popover title")];

    [self.rssEntries removeAllObjects];
    [self.rssEntries addObjectsFromArray:[self.requestForm.managedObjectContext  AGNAllActiveRSS]];
    self.rssPopover.objectArray = self.rssEntries;

    __weak AGNFormDetailViewController * _self = self;
    self.rssPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        AGNSingleLineCell *cell = [aTableView dequeueReusableCellWithIdentifier:kCellIdentifier];
        if (cell == nil) {
            cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier];
        }

        AGNRSS * rss = (AGNRSS*)_self.rssEntries[indexPath.row];
        cell.mainLabel.text = rss.name;
        return cell;
    };

    self.rssPopover.onSelectBlock=^(int selected){
        AGNRSS * rss = (AGNRSS*)_self.rssEntries[selected];
        _self.requestForm.rss = rss;
        _self.requestForm.salesForceRSSId=rss.salesForceId;
        _self.rssTextField.text=rss.name;
        [_self.rssPopover dismissPopoverAnimated:YES];
        [_self updateButtonEnablement];

    };

    CGRect rect = self.rssTextField.frame;
    rect = [self.view convertRect:rect fromView:self.rssTextField.superview];
    [self.rssPopover presentPopoverFromRect:rect
                                           inView:self.view
                         permittedArrowDirections:UIPopoverArrowDirectionDown
                                         animated:YES];
}




-(NSMutableArray *)odrReasons{
    if(!_odrReasons){
        _odrReasons = [[NSMutableArray alloc]init];
    }
    return _odrReasons;
}

-(void) showReasonPopover {
    self.odrReasonPopover = [[AGNPopoverTableViewController alloc]initWithDelegate:self andTitle:NSLocalizedString(@"ODR Reason", @"ODR Reason popover title")];

    [self.odrReasons removeAllObjects];
    [self.odrReasons addObjectsFromArray:[self.requestForm.managedObjectContext  AGNAllODRReason]];
    self.odrReasonPopover.objectArray = self.odrReasons;

    __weak AGNFormDetailViewController * _self = self;
    self.odrReasonPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        AGNSingleLineCell *cell = [aTableView dequeueReusableCellWithIdentifier:kCellIdentifier];
        if (cell == nil) {
            cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier];
        }

        AGNODRReason * reason = (AGNODRReason*)_self.odrReasons[indexPath.row];
        cell.mainLabel.text = reason.label;
        return cell;
    };

    self.odrReasonPopover.onSelectBlock=^(int selected){
        AGNODRReason * reason = (AGNODRReason*)_self.odrReasons[selected];
        _self.requestForm.odrReason=reason.value;
        _self.reasonTextField.text=reason.label;
        [_self.odrReasonPopover dismissPopoverAnimated:YES];
        [_self updateButtonEnablement];


    };

    CGRect rect = self.reasonTextField.frame;
    rect = [self.view convertRect:rect fromView:self.rssTextField.superview];
    [self.odrReasonPopover presentPopoverFromRect:rect
                                     inView:self.view
                   permittedArrowDirections:UIPopoverArrowDirectionDown
                                   animated:YES];
}



//------------------------------------------------------------------------------
// MARK: - Trigger Lock
//------------------------------------------------------------------------------

//  Called by the RootViewController in response to Back Button, other Navigation requests
//  If the call has not been modified, return Yes to allow the view to be dismissed.
//  If the call HAS been modified, prompt the user to save or discard changes.
-(BOOL)canDismiss{

    if(![self.requestForm hasNewStatus]){
        [self clearCurrentFormInfo];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
        return YES;
    }

    if([self.requestForm signatureImage]){
        // Have to close before dismissal
        UIAlertView *mustCloseAlertView = [[UIAlertView alloc] initWithTitle:@"Please Submit Form" message:@"Once signature is captured you must submit the form before leaving this screen" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [mustCloseAlertView show];

        return NO;
    }

    log4Info(@"Prompting user to save form %@",self.requestForm );    
    
    self.canDismissAlertView = [[UIAlertView alloc]init];
    self.canDismissAlertView.delegate = self;
    self.canDismissAlertView.title = NSLocalizedString(@"Changes Made", @"Title on action sheet when dismissing form view controller without saving");
    self.canDismissAlertView.message = NSLocalizedString(@"Changes made to this form will not be saved.", @"Message on action sheet when dismissing form view controller without saving");
    [self.canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Discard", @"When dismissing form view, indicates changes won't be saved") ];
    [self.canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Cancel", @"When dismissing form view, indicates cancle will be dismissed so editing may continue")];
    [self.canDismissAlertView show ];

    // just refuse to dismiss, and we'll request dismissal in UIActionSheet delegate methods
    return NO;
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{

    if(alertView==self.canDismissAlertView){
        switch(buttonIndex){
            case 0: // discard changes - just pop the view controller
                log4Info(@"Discarding form %@",self.requestForm);
                [self.managedObjectContext rollback];
                // get rid of restore state key
                [self clearCurrentFormInfo];

                [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];

                break;
            default:
                // continue editing - cancel any outstanding navigation request
                [[NSNotificationCenter defaultCenter] postNotificationName:AGNCancelNavigationRequestNotificationKey object:nil];
                break;
        }
    }
}

#pragma mark -
#pragma mark AGNRequestFormCellItemDelegate

- (void)displayProductPopoverForCell:(AGNRequestFormItemCell*)cell forView:(UIView*)view {
    __weak AGNFormDetailViewController * _self = self;
    
    AGNVoidBlock block = ^{
        _self.popoverTargetCell = cell;
        cell.productHighlighted = YES;
        if (_self.productPopover) {
            [_self.productPopover dismissPopoverAnimated:YES];
            _self.productPopover= nil;
        }
        _self.productPopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:_self andTitle:NSLocalizedString(@"Products", @"Products Popover Title")];
        
        _self.productPopover.includeSearchBar = YES;
        _self.productPopover.searchBarDelegate = _self;
        _self.productPopover.maxWidthPercentage = [NSNumber numberWithFloat:.5];
        [_self.availableProducts removeAllObjects];
        [_self.availableProducts addObjectsFromArray:[_self.managedObjectContext AGNProductsForFilterString:nil]];
        _self.productPopover.objectArray = _self.availableProducts;
        _self.productPopover.delegate = _self;
        
        _self.productPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"CellIdentifier";
            
            AGNSingleLineCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            AGNRequestFormProduct *product = (AGNRequestFormProduct*)_self.availableProducts[indexPath.row];
            cell.mainLabel.text = product.productDescription;
            return cell;
        };
        
        CGRect rect = [_self.view convertRect:view.bounds fromView:view];
        [_self.productPopover presentPopoverFromRect:rect
                                             inView:_self.view
                           permittedArrowDirections:UIPopoverArrowDirectionLeft
                                           animated:YES];
    };
    
    if (self.keyboardUp) {
        self.blockToDoWhenKeyboardDown = block;
        [self.activeField resignFirstResponder];
    }
    else
        block();
}

- (void)questionUpdatedOnCell:(AGNRequestFormItemCell*)cell {
    [self updateButtonEnablement];
}

-(void)clearCurrentFormInfo{
    log4Info(@"Clearing kCurrentFormRestoreStateKey");
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:kCurrentFormRestoreStateKey];
}


-(void)persistCurrentFormInfo{
    AGNRequestForm *form = self.requestForm;
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:kCurrentFormRestoreStateKey];

    NSString *objectId = form.guid;
    if(objectId){
        [standardUserDefaults setValue:objectId forKey:kCurrentFormRestoreStateKey];
        log4Info(@"Setting kCurrentFormRestoreStateKey to %@",objectId);

    }
}

#pragma mark -
#pragma mark Keyboard-related scrolling

-(void)cellBeganEditing:(NSNotification *)notification {
    self.activeField=((UITextView*)notification.object);
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    
    UITableViewCell *cell = (UITableViewCell *)[[self.activeField superview] superview];
    NSIndexPath * indexPath = [self.requestItemsTableView indexPathForCell:cell];
    if(!indexPath)
        return;
    
    
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    UIEdgeInsets contentInsets;
    
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
        if (self.requestForm.isMIR)
            contentInsets = UIEdgeInsetsMake(0.0, 0.0, 137.0, 0.0);
        else
            contentInsets = UIEdgeInsetsMake(0.0, 0.0, 107.0, 0.0);
    }
    else {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
        if (self.requestForm.isMIR)
            contentInsets = UIEdgeInsetsMake(0.0, 0.0, 62.0, 0.0);
        else
            contentInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0);
    }
    
    
    self.requestItemsTableView.contentInset = contentInsets;
    self.requestItemsTableView.scrollIndicatorInsets = contentInsets;
    
    
    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.requestItemsTableView.frame;
    aRect.size.height -= (keyboardHeight+kHeight);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        self.returnToIndexPath=[self firstVisibleRow];
        [self.requestItemsTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
    
    self.keyboardUp = YES;

    /*
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    CGPoint keyboardOrigin, keyboardOriginLocal;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
        keyboardOrigin = CGPointMake(0, [AGNAppDelegate sharedDelegate].window.frame.size.width - keyboardHeight);
        keyboardOriginLocal = [self.requestItemsTableView convertPoint:keyboardOrigin fromView:[AGNAppDelegate sharedDelegate].rootViewController.view];
    }
    else {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
        keyboardOrigin = CGPointMake(0, [UIScreen mainScreen].bounds.size.height - keyboardHeight);
        keyboardOriginLocal = [self.requestItemsTableView convertPoint:keyboardOrigin fromView:[AGNAppDelegate sharedDelegate].rootViewController.view];
    }
    
    // Translate top of keyboard to tableview
    
    
    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, self.requestItemsTableView.frame.size.height - keyboardOriginLocal.y - kAGNTableViewHeaderHeight, 0.0);
    self.requestItemsTableView.contentInset = contentInsets;
    self.requestItemsTableView.scrollIndicatorInsets = contentInsets;
    
    
    // Let's just scroll the active cell into the view
    CGRect targetFrame = [self.requestItemsTableView rectForRowAtIndexPath:indexPath];
    CGRect visibleFrame = self.requestItemsTableView.bounds;
    visibleFrame.origin = self.requestItemsTableView.contentOffset;
    visibleFrame.origin.y += kAGNTableViewHeaderHeight;
    visibleFrame.size.height -= kAGNTableViewHeaderHeight;
    
    self.requestItemsTableView.backgroundColor = [UIColor blueColor];
    
    if (!CGRectContainsRect(visibleFrame, targetFrame)) {
//        self.returnToIndexPath = [self firstVisibleRow];
        [self.requestItemsTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
//
//        // Need to scroll
//        if (visibleFrame.origin.x > targetFrame.origin.x) {
//            // The cell is above, need to scroll down
//            [self.requestItemsTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
//        }
//        else {
//        }
    }
     */
    
}

-(NSIndexPath *)firstVisibleRow{
    NSArray* indexPaths = [self.requestItemsTableView indexPathsForVisibleRows];
    NSArray* sortedIndexPaths = [indexPaths sortedArrayUsingSelector:@selector(compare:)];
    return (NSIndexPath*)[sortedIndexPaths objectAtIndex:0];
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    // for some reason getting a UIKeyboardDidHideNotification on rotation even though the keyboard stays up
    // so hold on to the previous active field.
    //self.activeField = nil;
    
    self.keyboardUp = NO;

    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];
    
    if (self.blockToDoWhenKeyboardDown) {
        UIEdgeInsets contentInsets = UIEdgeInsetsZero;
        self.requestItemsTableView.contentInset = contentInsets;
        self.requestItemsTableView.scrollIndicatorInsets = contentInsets;
        
        self.blockToDoWhenKeyboardDown();
        self.blockToDoWhenKeyboardDown = nil;
        
    }
    else {
        [UIView animateWithDuration:[animationTime doubleValue] animations:^{
            UIEdgeInsets contentInsets = UIEdgeInsetsZero;
            self.requestItemsTableView.contentInset = contentInsets;
            self.requestItemsTableView.scrollIndicatorInsets = contentInsets;
        }];
        if (self.returnToIndexPath) {
            [self.requestItemsTableView scrollToRowAtIndexPath:self.returnToIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
            self.returnToIndexPath=nil;
        }
    }

    
    
}

@end
