//
//  AGNInventoryCell.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *AGNMonthlyCountsQuantityChangedNotificationKey = @"AGNMonthlyCountsQuantityChangedNotificationKey";
typedef void (^textFieldActiveCell)(UITextField *);

@interface AGNInventoryCell : UITableViewCell <UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UILabel *sampleLabel;
@property (strong, nonatomic) IBOutlet UILabel *lotTitle;
@property (strong, nonatomic) IBOutlet UILabel *lotNumber;
@property (strong, nonatomic) IBOutlet UILabel *expirationTitle;
@property (strong, nonatomic) IBOutlet UILabel *expirationDate;
@property (strong, nonatomic) IBOutlet UILabel *quantityTitle;
@property (strong, nonatomic) IBOutlet UILabel *quantityLabel;
@property (strong, nonatomic) IBOutlet UILabel *varianceTitle;
@property (weak, nonatomic) IBOutlet UITextField *actualQuantityTextField;
@property (strong, nonatomic) AGNSampleInventoryTransactionLine *line;
@property (strong, nonatomic) textFieldActiveCell textFieldActiveBlock;
@property (weak, nonatomic) IBOutlet UILabel *varianceLabel;
@end
