//
//  AGNSyncStatusView.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 10/3/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNSyncStatusView : UIView

@property (nonatomic) NSUInteger badgeCount;
@property (nonatomic) BOOL isSyncing;

@end
