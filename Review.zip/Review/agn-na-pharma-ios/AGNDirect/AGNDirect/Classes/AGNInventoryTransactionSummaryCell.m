//
//  AGNInventoryTransactionSummaryCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNInventoryTransactionSummaryCell.h"

@implementation AGNInventoryTransactionSummaryCell



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        
        self.leftLabel = [[UILabel alloc] init];
        self.leftLabel.font = [UIFont AGNAvenirHeavy14];
        self.leftLabel.textColor = [UIColor AGNEleventhHour];
        [self.leftLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.leftLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.leftLabel];
        
        self.rightLabel = [[UILabel alloc] init];
        self.rightLabel.font = [UIFont AGNAvenirHeavy14];
        self.rightLabel.textColor = [UIColor AGNEleventhHour];
        [self.rightLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.rightLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.rightLabel];

        
        NSDictionary *constraintsViewsDictionary = @{ @"leftLabel" : self.leftLabel , @"rightLabel" : self.rightLabel };
        [self.contentView addConstraints:[NSLayoutConstraint
                                          constraintsWithVisualFormat:@"|-22-[leftLabel]-(>=22)-[rightLabel]-22-|"
                                          options:0
                                          metrics:nil
                                          views:constraintsViewsDictionary]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.leftLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.rightLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];

    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];

    self.leftLabel.text = nil;
    self.rightLabel.text = nil;
}


@end
