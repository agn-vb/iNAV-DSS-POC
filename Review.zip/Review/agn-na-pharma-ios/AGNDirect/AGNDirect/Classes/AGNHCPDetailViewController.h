//
//  AGNHCPDetailViewController.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/10/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNAccount.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNViewController.h"
#import "AGNTableView.h"
#import "AGNButtonMenuView.h"

@interface AGNHCPDetailViewController : AGNViewController <UIPopoverControllerDelegate, AGNPopoverDelegate>

@property (strong, nonatomic) AGNAccount *account;
@property (strong, nonatomic) IBOutlet AGNTableView *tableView;

@property (weak, nonatomic) IBOutlet AGNButtonMenuView * menu;

- (IBAction)openDraft:(id)sender;

@end
