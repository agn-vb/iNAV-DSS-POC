//
//  UITableViewCell+UITableViewCell_AGNTableViewCell.h
//  AGNDirect
//
//  Created by Adam McLain on 9/27/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (UITableViewCell_AGNTableViewCell)

- (void)agnSetStyledSelectedBackground;

@end
