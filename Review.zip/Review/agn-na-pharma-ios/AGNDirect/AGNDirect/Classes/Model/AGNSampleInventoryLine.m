//
//  AGNSampleInventoryLine.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSampleInventoryLine.h"
#import "AGNProductSKU.h"
#import "AGNCategoryHeaders.h"
#import "AGNAppDelegate.h"

//AGN_LOG_LEVEL(AGNSampleInventoryLine, DEBUG_INT)

@implementation AGNSampleInventoryLine

static NSDictionary *fieldMapping = nil;

@dynamic expiration;
@dynamic lotNumber;
@dynamic quantity;
@dynamic salesForceId;
@dynamic productSalesForceId;
@dynamic salesRepSalesForceId;
@dynamic storageUnitSalesForceId;
@dynamic product;
@dynamic salesRep;
@dynamic sampleDrops;
@dynamic sampleInventoryTransactionLines;
// not sure if this will remain or move to sales rep
@dynamic storageUnit;

+(void)initialize{
    fieldMapping =
    @{
    @"Id": @"salesForceId",
    @"Lot_Number__c": @"lotNumber",
    @"Expiration__c": @"expiration",
    @"Quantity__c" : @"quantity",
    @"OwnerId": @"salesRepSalesForceId",
    @"Product_SKU__c": @"productSalesForceId"
    };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}


- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    for(NSString *key in objectDict){
        if([key isEqualToString:@"Expiration__c"]) {
            self.expiration = [NSDate agnDateFromString:objectDict[key]];
        }
        else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on SIL to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on SIL to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }        
    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerSampleInventoryLine:self];
}

-(BOOL) isExpired{
    if([self.expiration compare:[NSDate date] ]==NSOrderedAscending)
        return YES;
    return NO;
}

- (BOOL)hasSamplePermission{
    // note we are relying on the fact that we'll only have sample permissions for current user
    if([self.product.samplePermissions count]==0){
        log4Debug(@"Can't sample %@, no sample permission", self.lotNumber);
        return NO;
    }
    return YES;
}

-(BOOL) canSample{
    if([self isExpired]){
        log4Debug(@"Can't sample %@, product expired on %@", self.lotNumber,self.expiration);
        return NO;
    }
    if([self.quantity intValue]<=0){
        log4Debug(@"Can't sample lot number %@, quantity is %d", self.lotNumber, [self.quantity intValue]);
        return NO;
    }
    if(![self hasSamplePermission]){
        log4Debug(@"Can't sample %@, no sample permission", self.lotNumber);
        return NO;
    }
    return YES;
}


- (BOOL)canShip {
    return [self.quantity intValue] > 0;
}

@end
