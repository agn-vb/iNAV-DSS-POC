//
//  AGNDetailPosition.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"   

@class AGNCallDetail, AGNSalesRep;

@interface AGNDetailPosition : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * detailTopic;
@property (nonatomic, retain) NSDate * effectiveDate;
@property (nonatomic, retain) NSDate * endDate;
@property (nonatomic, retain) NSNumber * position;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * salesForceProductId;
@property (nonatomic, retain) NSString * displayName;
@property (nonatomic, retain) NSSet *callDetails;
@property (nonatomic, retain) NSSet *salesRep;
@property (nonatomic, retain) AGNProductBrand *product;

-(NSString *)productDescription;
-(NSString *)displayString;
-(BOOL)isValidForDate:(NSDate *)callDate;

@end

@interface AGNDetailPosition (CoreDataGeneratedAccessors)

- (void)addCallDetailsObject:(AGNCallDetail *)value;
- (void)removeCallDetailsObject:(AGNCallDetail *)value;
- (void)addCallDetails:(NSSet *)values;
- (void)removeCallDetails:(NSSet *)values;

- (void)addSalesRepObject:(AGNSalesRep *)value;
- (void)removeSalesRepObject:(AGNSalesRep *)value;
- (void)addSalesRep:(NSSet *)values;
- (void)removeSalesRep:(NSSet *)values;
@end
