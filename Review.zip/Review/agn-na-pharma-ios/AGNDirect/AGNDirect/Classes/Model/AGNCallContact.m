//
//  AGNCallContact.m
//  AGNDirect
//
//  Created by Mark Wells on 10/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCallContact.h"
#import "AGNCall.h"
#import "AGNContact.h"
#import "AGNContactRole.h"
#import "AGNAppDelegate.h"


@interface AGNCallContact (PrimitiveAccessors)
- (void)setPrimitiveCall:(AGNCall *)aCall;
- (void)setPrimitiveContact:(AGNContact *)aContact;
@end

@implementation AGNCallContact

@dynamic guid;
@dynamic salesForceId;
@dynamic callSalesForceId;
@dynamic contactSalesForceId;

@dynamic mobileCreateTimestamp;
@dynamic mobileLastUpdateTimestamp;
@dynamic stampFirstName;
@dynamic stampLastName;
@dynamic stampMiddleName;
@dynamic stampPhone;
@dynamic stampEmail;
@dynamic stampProfessionalRole;

@dynamic call;
@dynamic contact;

static NSDictionary *fieldMapping = nil;


+ (void)initialize
{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"GUID" : @"guid",
    @"Call" : @"callSalesForceId",
    @"Contact" : @"contactSalesForceId",
    @"First_Name" : @"stampFirstName",
    @"Email" : @"stampEmail",
    @"Last_Name" : @"stampLastName",
    @"Middle_Name" : @"stampMiddleName",
    @"MobileLastModifiedDate" : @"mobileLastUpdateTimestamp",
    @"MobileCreatedDate" : @"mobileCreateTimestamp",
    @"Phone" : @"stampPhone",
    @"Professional_Role" : @"stampProfessionalRole"
    };
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark - AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict
{
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict
{
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for (NSString *key in objectDict) {
        NSString *objectKey = fieldMapping[key];
        if (objectKey) { // if unexpected field, skip it
            id objectVal = objectDict[key];
            if([key isEqualToString:@"MobileLastModifiedDate"]) {
                if (objectVal && ![objectVal isEqual:[NSNull null]]) {
                    self.mobileLastUpdateTimestamp = [NSDate agnDateFromRFC3339TimestampString:objectVal];
                }
            }
            else if([key isEqualToString:@"MobileCreatedDate"]) {
                if (objectVal && ![objectVal isEqual:[NSNull null]]) {
                    self.mobileCreateTimestamp = [NSDate agnDateFromRFC3339TimestampString:objectVal];
                }
            }
            else {
                if ([objectVal isEqual:[NSNull null]]) {
                    objectVal = nil;
                }
                log4Trace(@"Setting %@ on call contact to %@", objectKey, objectVal);
                [self setValue:objectVal forKey:objectKey];
            }
        }
    }
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;

    
    self.call = sync.currentCall;
    if (!self.call) {
        self.call = [sync callBySFDCID:self.callSalesForceId];
    }
    if (!self.call) {
        log4Error(@"Expected sync context to have call with Id %@, but it is nil", self.callSalesForceId);
    }
}

- (void)buildRelationships {
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;
    self.contact = [sync contactBySFDCID:self.contactSalesForceId];
}

- (NSString *)jsonRepresentationForUpdate {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    if(self.contact && self.contact.guid){
        [result appendFormat:@"\"Contact_GUID\": \"%@\",", [self.contact.guid agnEscapedString]];
    }

    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
        if ([((NSString *)value) isEqualToString:@"mobileLastUpdateTimestamp"]) {
            if (self.mobileLastUpdateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileLastModifiedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"mobileCreateTimestamp"]) {
            if (self.mobileCreateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileCreatedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if (prop) {
            if ([prop isKindOfClass:[NSString class]]) {
                [result appendFormat:@"\"%@\": \"%@\",",key, [prop agnEscapedString]];
            }
            else{
                [result appendFormat:@"\"%@\": \"%@\",",key, prop];
            }
        }
    }];
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark - Custom setters
//------------------------------------------------------------------------------

- (void)setCall:(AGNCall *)aCall {
    [self willChangeValueForKey:@"call"];
    [self setPrimitiveCall:aCall];
    if (aCall) {
        self.callSalesForceId = aCall.salesForceId;
    }
    [self didChangeValueForKey:@"call"];
}

- (void)setContact:(AGNContact *)aContact {
    [self willChangeValueForKey:@"contact"];
    [self setPrimitiveContact:aContact];
    if (aContact) {
        self.contactSalesForceId = aContact.salesForceId;
    }
    [self didChangeValueForKey:@"contact"];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark - Public methods
//------------------------------------------------------------------------------

- (void)stampComplianceFields {
    self.stampFirstName = [self.contact.firstName copy];
    self.stampLastName = [self.contact.lastName copy];
    self.stampMiddleName = [self.contact.middleName copy];
    self.stampPhone = [self.contact.phone copy];
    self.stampEmail = [self.contact.email copy];
    self.stampProfessionalRole = [self.contact.contactRole copy];
}

- (NSString *)formattedStampedNameAndRole {
    NSMutableString *contactString = [NSMutableString string];
    NSString *name = self.stampFirstName.length>0?self.stampFirstName:self.stampLastName;
    if (name.length > 0) {
        [contactString appendString:name];
        if (self.stampProfessionalRole) {
            [contactString appendFormat:@" (%@)", self.stampProfessionalRole];
        }
    }
    return contactString;
}


@end
