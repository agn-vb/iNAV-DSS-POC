//
//  AGNMarketingCollateral.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/11/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNMarketingCollateral.h"
#import "AGNMarketingDisbursement.h"
#import "NSManagedObjectContext+DDSFExtensions.h"


@implementation AGNMarketingCollateral

@dynamic salesForceId;
@dynamic apcRemoteId;
@dynamic apcCode;
@dynamic guid;
@dynamic apcJobName;
@dynamic quantity;
@dynamic disbursement;
@dynamic disbursementRemoteId;
@dynamic apcProductName;

@synthesize apcValue;

static NSDictionary *fieldMapping = nil;

+(void)initialize{
    fieldMapping =
    @{
      @"Id"         : @"salesForceId",
      @"APC__c":@"apcRemoteId",
      @"APC_Code__c":@"apcCode",
      @"GUID__c":@"guid",
      @"Job_Name__c":@"apcJobName",
      @"Marketing_Disbursement__c":@"disbursementRemoteId",
      @"Quantity__c":@"quantity",
      @"Product__c":@"apcProductName"
      };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *  objectDict = dict;
    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict{
    NSDictionary * objectDict = dict;
    for(NSString *key in objectDict){
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }
        NSString *objectKey = fieldMapping[key];
        if(objectKey)
            [self setValue:value forKey:objectKey];
    }

    [[AGNAppDelegate sharedDelegate].syncManager.sync registerMarketingContent:self];
    [self buildRelationships];
//    log4Info(@"Marketing Content %@",self);

}

- (void)buildRelationships {
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;

    if (sync) {
        if (self.disbursementRemoteId && !self.disbursement) {
            self.disbursement = [sync disbursementBySFDCID:self.disbursementRemoteId];
        }
        
    }
    else {
        if (self.disbursementRemoteId && !self.disbursement) {
            self.disbursement = [self.managedObjectContext ddsf_objectOfType:@"AGNMarketingDisbursement" forId:self.disbursementRemoteId];
        }
       
    }
    
}

- (NSNumber *) totalValue{
    return [NSNumber numberWithDouble:[self.apcValue doubleValue]*[self.quantity doubleValue]];
}

- (NSString *)jsonRepresentationForUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
     
            if (!prop || [prop isEqual:[NSNull null]]) {
                prop = @"";
            }
            if ([prop isKindOfClass:[NSString class]]) {
                [result appendFormat:@"\"%@\": \"%@\",",[key upsertKey], [prop agnEscapedString]];
            }
            else{
                [result appendFormat:@"\"%@\": \"%@\",",[key upsertKey], prop];
            }

        
    }];
    [result appendFormat:@"\"%@\": %@",@"TotalValue", [self totalValue] ];

    [result appendString:@"}"];
    return result;
}


@end
