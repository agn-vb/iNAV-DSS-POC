//
//  AGNProduct.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNProduct.h"


@implementation AGNProduct

static NSDictionary *fieldMapping = nil;


@dynamic manufacturer;
@dynamic productCode;
@dynamic salesForceId;
@dynamic sampleInventoryLines;
@dynamic sampleInventoryTransactionLines;
@dynamic samplePermissions;
@dynamic blacklists;

+(void)initialize{
    fieldMapping =
    @{
    @"Id"         : @"salesForceId",
    @"ProductSKU"        : @"productCode"
    };
}

- (void)initWithDictionary:(NSDictionary *)dict {
    for(NSString *key in dict){
      
    NSString *objectKey = fieldMapping[key];
    if(objectKey) // if unexpected field, skip it
    {
        log4Trace(@"Setting %@ on product to %@",objectKey,dict[key]);
        [self setValue:dict[key] forKey:objectKey];
    }

    }
}


@end
