//
//  AGNScheduleEntry.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/28/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  Superclass of AGNCall and AGNTimeOffTerritory to support showing both on the Schedule View

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNScheduleEntry.h"
#import "NSDate+AGNDate.h"

@implementation AGNScheduleEntry

@dynamic startDate;
@dynamic endDate;
@dynamic startDay;
@dynamic toBeDeletedFlag;
@dynamic salesForceId;
@dynamic salesForceRepId;
@dynamic guid;

static NSDateFormatter *dateFormatter;

// cache the dateFormatter for performance
+ (void)initialize{
    dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.timeZone = [NSTimeZone localTimeZone];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
}

- (NSString *)startDay {
    [self willAccessValueForKey:@"startDay"];
    NSString * theDay = [dateFormatter stringFromDate:self.startDate];
    [self didAccessValueForKey:@"startDay"];
    return theDay;
}

// determines appearance on schedule view. must be overridden by subclasses
- (BOOL)activeEntry{
    return YES;
}

@end
