//
//  AGNRequestFormItem.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/3/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

static const int kAGNQuestionMaxChars=250;

@class AGNRequestForm, AGNRequestFormProduct;

@interface AGNRequestFormItem : NSManagedObject

@property (nonatomic, retain) NSNumber * ordinal;
@property (nonatomic, retain) NSString * question;
@property (nonatomic, retain) NSString * productName;
@property (nonatomic, retain) AGNRequestForm *form;
@property (nonatomic, readonly) NSString * displayedQuestion;

@end
