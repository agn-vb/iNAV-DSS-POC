//
//  AGNSampleDrop.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSampleDrop.h"
#import "AGNCall.h"
#import "AGNSampleInventoryLine.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNSampleInventoryTransactionLine.h"


@implementation AGNSampleDrop

static NSDictionary *fieldMapping = nil;


@dynamic quantity;
@dynamic guid;
@dynamic salesForceId;
@dynamic expirationDate;
@dynamic lotNumber;
@dynamic manufacturer;
@dynamic productCode;
@dynamic productDescription;
@dynamic salesRepId;
@dynamic call;
@dynamic sampleInventoryLine;
@dynamic toBeDeletedFlag;

@dynamic callSalesForceId;
@dynamic sampleInventoryLineSaleForceId;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"Quantity" : @"quantity",
    @"GUID" : @"guid",
    @"Call"   : @"callSalesForceId",
    @"Product" : @"sampleInventoryLineSaleForceId",
    @"Expiration" : @"expirationDate",
    @"Lot_Number" : @"lotNumber",
    @"Manufacturer" : @"manufacturer",
    @"Product_Code" : @"productCode",
    @"Product_Description" : @"productDescription",
    @"Sales_Rep_Id" : @"salesRepId"
    };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;
}


- (void)initWithDictionary:(NSDictionary *)dict {
//    AGNDataManager *dm = [AGNAppDelegate sharedDelegate].dataManager;
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for(NSString *key in objectDict){
        if([key isEqualToString:@"Quantity"]){
            if(objectDict[key]!=[NSNull null])
                self.quantity = objectDict[key];//[NSNumber numberWithInt:[(NSString *)objectDict[key] integerValue]];
        }
        else if([key isEqualToString:@"Expiration"]) {
            self.expirationDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on sample drop to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on sample drop to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }

    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;
    if (self.callSalesForceId && !self.call) {
        self.call = sync.currentCall;
        if (!self.call) {
            self.call = [sync callBySFDCID:self.callSalesForceId];
            if (!self.call) {
                log4Warn(@"Expected sync context to have call with Id %@, but it is nil", self.callSalesForceId);
            }
        }
    }
    
    [self buildRelationships];
}

- (void)buildRelationships {
    
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;
    
    if (self.sampleInventoryLineSaleForceId && !self.sampleInventoryLine){
        self.sampleInventoryLine = [sync inventoryLineBySFDCID:self.sampleInventoryLineSaleForceId];
    }
}

- (NSString *)jsonRepresentationForUpdateWithPosition:(int)position {
    NSMutableString *result = [NSMutableString stringWithString:@"{ "];
    NSString *productId = self.sampleInventoryLine.salesForceId;
    [result appendFormat:@"\"toBeDeleted\": %@,", [self.toBeDeletedFlag boolValue] ? @"true" : @"false"];
    if (productId)
        [result appendFormat:@"\"Product\" : \"%@\", ", productId];
    [result appendFormat:@"\"Product_Code\" : \"%@\", ", self.sampleInventoryLine.product.productCode];
    [result appendFormat:@"\"Lot_Number\" : \"%@\", ", self.sampleInventoryLine.lotNumber];
    [result appendFormat:@"\"Quantity\" : %@, ", self.quantity ? self.quantity : @"null"];
    [result appendFormat:@"\"GUID\" : \"%@\", ", self.guid];
    [result appendFormat:@"\"Position\" : %d ", position];
    if (self.salesForceId) {
        [result appendFormat:@", \"Id\" : \"%@\"", self.salesForceId];
    }
    [result appendString:@"}"];
    return result;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdateWithPosition:0];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    return [self initWithDictionary:dict];
}

- (BOOL)isToBeDeleted {
    return [self.toBeDeletedFlag boolValue];
}

- (void)stampComplianceFields {
    // No-op - since the stamped fields are actually formula fields
}

@end
