//
//  AGNScheduleEntry.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/28/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface AGNScheduleEntry : NSManagedObject

@property (nonatomic, retain) NSDate * startDate;
@property (nonatomic, retain) NSString * startDay;
@property (nonatomic, retain) NSDate * endDate;
@property (nonatomic, retain) NSNumber *toBeDeletedFlag;
@property (nonatomic, retain) NSString *salesForceId;
@property (nonatomic, retain) NSString * salesForceRepId;
@property (nonatomic, retain) NSString * guid;



- (BOOL)activeEntry;
@end
