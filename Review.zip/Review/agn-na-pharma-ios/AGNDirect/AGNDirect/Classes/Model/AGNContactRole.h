//
//  AGNContactRole.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface AGNContactRole : NSManagedObject
@property (nonatomic, retain) NSString * roleName;
@end

@interface AGNContactRole (CoreDataGeneratedAccessors)

@end
