//
//  AGNDetailBlacklist.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNDetailBlacklist.h"
#import "AGNAccount.h"
#import "AGNProductBrand.h"


@implementation AGNDetailBlacklist


static NSDictionary *fieldMapping = nil;

@dynamic salesForceId;
@dynamic salesForceAccountId;
@dynamic salesForceProductId;
@dynamic product;
@dynamic account;

+(void)initialize{
    fieldMapping =
    @{
    @"Id"  : @"salesForceId",
    @"Product_Brand__c":@"salesForceProductId",
    @"Account__c":@"salesForceAccountId"
    };
}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    for(NSString *key in objectDict){
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on detail blacklist to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on detail blacklist to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
}

@end
