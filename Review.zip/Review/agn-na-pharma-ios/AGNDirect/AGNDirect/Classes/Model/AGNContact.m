//
//  AGNContact.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNContact.h"
#import "AGNAccount.h"
#import "AGNCall.h"
#import "AGNContact.h"
#import "AGNCategoryHeaders.h"
#import "AGNContactRole.h"


@implementation AGNContact

static NSDictionary *fieldMapping = nil;

@dynamic email;
@dynamic firstName;
@dynamic guid;
@dynamic lastName;
@dynamic mobileCreateTimestamp;
@dynamic mobileLastUpdateTimestamp;
@dynamic phone;
@dynamic salesForceAccountId;
@dynamic salesForceId;
@dynamic middleName;
@dynamic hcp;
@dynamic callContacts;
@dynamic contactRole;
@dynamic contactRoleSalesForceId;
@dynamic toBeDeletedFlag;


@synthesize undoJSONRepresentation=_undoJSONRepresentation;


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    // Note: apex returns 'AccountId', rest request returns 'HCP__c' for the id of the account - consider changing for consistency
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"FirstName" : @"firstName",
    @"GUID" : @"guid",
    @"LastName" : @"lastName",
    @"Middle_Name" : @"middleName",
    @"Phone" : @"phone",
    @"Email" : @"email",
    @"Professional_Role" : @"contactRole",
    @"HCP" : @"salesForceAccountId",
    @"AccountId" : @"salesForceAccountId"
    };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;
}


- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for(NSString *key in objectDict){
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on contact to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on contact to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
    if (self.salesForceAccountId && !self.hcp) {
        self.hcp = [[AGNAppDelegate sharedDelegate].syncManager.sync accountBySFDCID:self.salesForceAccountId];
    }
    // remove orphaned contacts
    if (!self.hcp) {
        [[AGNAppDelegate sharedDelegate].syncManager.sync.managedContext deleteObject:self];
    }
    else
        [[AGNAppDelegate sharedDelegate].syncManager.sync registerContact:self];
}

- (void)buildRelationships {}

- (NSString *)jsonRepresentationForUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [result appendFormat:@"\"FirstName\" : \"%@\",", self.firstName ? [self.firstName agnEscapedString] : @""];
    [result appendFormat:@"\"LastName\" : \"%@\",", self.lastName ? [self.lastName agnEscapedString] : @""];
    [result appendFormat:@"\"Professional_Role__c\" : \"%@\",", self.contactRole ? self.contactRole : @""];
    [result appendFormat:@"\"HCP__c\" : \"%@\",", self.salesForceAccountId ? self.salesForceAccountId : @""];
    if([self.toBeDeletedFlag boolValue]) {
        // service doesn't understand this, just put it here to let the queue manager know to delete instead of upsert
        [result appendFormat:@"\"toBeDeleted\": %@,", [self.toBeDeletedFlag boolValue] ? @"true" : @"false"];
    }
    
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict {
    NSString *contactId =  [[jsonDict valueForKey:@"id"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"id"];
    NSNumber *success =  [[jsonDict valueForKey:@"success"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"success"]; 
    if ([success boolValue]) {
        if (!self.salesForceId && contactId) {
            self.salesForceId = contactId;
        }
    }
}

- (void)setUndoRepresentation {
    self.undoJSONRepresentation = [self jsonRepresentationForUndo];
}

- (void)clearUndoRepresentation {
    self.undoJSONRepresentation = nil;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    return [self initWithDictionary:dict];
}

- (BOOL)isToBeDeleted {
    return [self.toBeDeletedFlag boolValue];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

- (NSString *)description {
    return [NSString stringWithFormat:@" %@ %@ - %@ ",self.firstName,self.lastName,self.contactRole];
}

- (NSString *)formattedNameAndRole {
    NSMutableString *contactString = [NSMutableString string];
    NSString *name = self.firstName.length>0?self.firstName:self.lastName;
    if (name.length > 0) {
        [contactString appendString:name];
        if (self.contactRole) {
            [contactString appendFormat:@" (%@)", self.contactRole];
        }
    }
    return contactString;
}

- (NSAttributedString *)attributedNameAndRole {
    
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    NSString *name = self.firstName.length>0?self.firstName:self.lastName;

    if (name.length > 0) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:name attributes:heavyAttributes]];
        if (self.contactRole > 0) {
            NSString *role = [NSString stringWithFormat:@" (%@)", self.contactRole];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:role attributes:romanAttributes]];
        }
    }
    
    return formattedString;
}

- (NSAttributedString *)callClosureAttributedNameAndRole {
    
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    NSString *separator = (self.lastName && self.firstName)?@", ":@"";
    NSString *name = [NSString stringWithFormat:@"%@%@%@",self.lastName?[self.lastName uppercaseString]:@"",separator,self.firstName?[self.firstName uppercaseString]:@""];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:name attributes:heavyAttributes]];
    if(self.contactRole){
        NSString *role = [NSString stringWithFormat:@" - %@", self.contactRole];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:role attributes:romanAttributes]];
    }
    
    
    return formattedString;
}

@end
