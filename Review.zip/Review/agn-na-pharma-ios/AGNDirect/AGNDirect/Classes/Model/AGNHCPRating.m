
//
//  AGNHCPRating.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNHCPRating.h"


@implementation AGNHCPRating


static NSDictionary *fieldMapping = nil;

@dynamic salesForceId;
@dynamic salesForceAccountId;
@dynamic salesForceSalesTeamId;
@dynamic ratingType;
@dynamic ratingValue;
@dynamic account;
@dynamic salesTeamName;


+(void)initialize{
    fieldMapping =
    @{
    @"Id"  : @"salesForceId",
    @"HCP" : @"salesForceAccountId",
    @"Rating_Type" : @"ratingType",
    @"Rating_Value" : @"ratingValue",
    @"Sales_Team" : @"salesForceSalesTeamId"
    };
}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for(NSString *key in objectDict){
        if([key isEqualToString:@"Sales_Team__r"]) {
            id value = objectDict[key];
            NSDictionary *salesTeamDict = [value isEqual:[NSNull null]]?nil:value;
            value = salesTeamDict[@"Name__c"];
            NSString *theSalesTeam = [value isEqual:[NSNull null]]?nil:value;
            self.salesTeamName=theSalesTeam;
        }else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on rating to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on rating to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }
    log4Debug(@"Finished populating rating %@",self);
    if (self.salesForceAccountId && !self.account)
        self.account = [[AGNAppDelegate sharedDelegate].syncManager.sync accountBySFDCID:self.salesForceAccountId];
    
}



@end
