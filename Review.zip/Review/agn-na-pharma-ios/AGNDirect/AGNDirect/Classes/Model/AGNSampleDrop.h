//
//  AGNSampleDrop.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNCall, AGNSampleInventoryLine, AGNSampleInventoryTransaction, AGNSampleInventoryTransactionLine;

@interface AGNSampleDrop : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSNumber * quantity;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSDate * expirationDate;
@property (nonatomic, retain) NSString * lotNumber;
@property (nonatomic, retain) NSString * manufacturer;
@property (nonatomic, retain) NSString * productCode;
@property (nonatomic, retain) NSString * productDescription;
@property (nonatomic, retain) NSString * salesRepId;
@property (nonatomic, retain) AGNCall *call;
@property (nonatomic, retain) AGNSampleInventoryLine *sampleInventoryLine;
@property (nonatomic, retain) NSNumber * toBeDeletedFlag;

@property (nonatomic, retain) NSString * callSalesForceId;
@property (nonatomic, retain) NSString * sampleInventoryLineSaleForceId;
@end

@interface AGNSampleDrop (CoreDataGeneratedAccessors)

- (NSString *)jsonRepresentationForUpdateWithPosition:(int)i;

- (void)stampComplianceFields;

@end

