//
//  AGNProductSKU.h
//  AGNDirect
//
//  Created by Mark Wells on 9/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNSampleInventoryLine, AGNSampleInventoryTransactionLine, AGNSamplePermission;

@interface AGNProductSKU : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * manufacturer;
@property (nonatomic, retain) NSString * productCode;
@property (nonatomic, retain) NSString * productDescription;
@property (nonatomic, retain) NSString * molecularName;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSSet *sampleInventoryLines;
@property (nonatomic, retain) NSSet *sampleInventoryTransactionLines;
@property (nonatomic, retain) NSSet *samplePermissions;
@property (nonatomic, retain) NSNumber * dssOnlySku;
@end

@interface AGNProductSKU (CoreDataGeneratedAccessors)

- (NSString *)fullDescription;

- (void)addSampleInventoryLinesObject:(AGNSampleInventoryLine *)value;
- (void)removeSampleInventoryLinesObject:(AGNSampleInventoryLine *)value;
- (void)addSampleInventoryLines:(NSSet *)values;
- (void)removeSampleInventoryLines:(NSSet *)values;

- (void)addSampleInventoryTransactionLinesObject:(AGNSampleInventoryTransactionLine *)value;
- (void)removeSampleInventoryTransactionLinesObject:(AGNSampleInventoryTransactionLine *)value;
- (void)addSampleInventoryTransactionLines:(NSSet *)values;
- (void)removeSampleInventoryTransactionLines:(NSSet *)values;

- (void)addSamplePermissionsObject:(AGNSamplePermission *)value;
- (void)removeSamplePermissionsObject:(AGNSamplePermission *)value;
- (void)addSamplePermissions:(NSSet *)values;
- (void)removeSamplePermissions:(NSSet *)values;

@end
