//
//  NSManagedObjectContext+RequestFormExtensions.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/7/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObjectContext (RequestFormExtensions)

-(NSArray *) AGNProductsForFilterString:(NSString *)filterString;
-(NSArray *) AGNAllActiveRSS;
-(NSArray *) AGNAllODRReason;
-(NSArray *) AGNAllAPC:(NSArray *)sortDescriptors;
-(NSArray *) AGNValidAPCs:(NSArray *)sortDescriptors;

@end
