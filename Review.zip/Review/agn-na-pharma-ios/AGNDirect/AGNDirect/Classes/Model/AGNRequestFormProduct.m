//
//  AGNRequestFormProduct.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/3/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNRequestFormProduct.h"
#import "AGNRequestFormItem.h"


@implementation AGNRequestFormProduct

@dynamic salesForceId;
@dynamic productDescription;
@dynamic formItems;

static NSDictionary *fieldMapping = nil;

+(void)initialize {
    fieldMapping =
    @{
      @"Product_Name__c"       : @"productDescription"
      };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
       return YES;

}
- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if(!objectDict)
        objectDict=dict;
    for(NSString *key in objectDict){

        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on request form product to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on request form product to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
}

@end
