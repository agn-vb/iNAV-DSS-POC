//
//  AGNProductSKU.m
//  AGNDirect
//
//  Created by Mark Wells on 9/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNProductSKU.h"
#import "AGNSampleInventoryLine.h"
#import "AGNSampleInventoryTransactionLine.h"
#import "AGNSamplePermission.h"
#import "AGNAppDelegate.h"

static NSDictionary *fieldMapping = nil;

@implementation AGNProductSKU

@dynamic manufacturer;
@dynamic productCode;
@dynamic productDescription;
@dynamic molecularName;
@dynamic salesForceId;
@dynamic sampleInventoryLines;
@dynamic sampleInventoryTransactionLines;
@dynamic samplePermissions;



+(void)initialize{
    fieldMapping =
    @{
    @"Id"           : @"salesForceId",
    @"Manufacturer__c"   : @"manufacturer",
    @"Product_Code__c"   : @"productCode",
    @"Molecular_Name__c"   : @"molecularName",
    @"Product_Description__c"   : @"productDescription",
    @"DSS_Only_SKU__c" : @"dssOnlySku"
    //    @"SKU_Code__c" : not yet mapped - may be same as Product_Code__c
    };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    for(NSString *key in objectDict){
        
        NSString *objectKey = fieldMapping[key];
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on product SKU to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on product SKU to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
            if([key isEqualToString:@"DSS_Only_SKU__c"]) {
                NSLog(@"debug value %@",value);
                self.dssOnlySku = [NSNumber numberWithInt:((NSString *)value).intValue]; ;
            }
        }
    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerProductSKU:self];
}

- (NSString *)fullDescription {
    return [self.productDescription stringByAppendingFormat:@" - %@ -%@", self.productCode , self.dssOnlySku];
}



@end
