//
//  AGNODRReason.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/3/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface AGNODRReason :  NSManagedObject 

@property (nonatomic, retain) NSString * label;
@property (nonatomic, retain) NSString * value;

@end
