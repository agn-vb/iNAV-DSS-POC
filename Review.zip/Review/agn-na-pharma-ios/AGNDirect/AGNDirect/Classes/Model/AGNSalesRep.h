//
//  AGNSalesRep.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNCall, AGNDetailPosition, AGNSampleInventoryLine, AGNSampleInventoryTransaction, AGNSamplePermission, AGNStorageUnit, AGNTimeOffTerritory;

@interface AGNSalesRep : NSManagedObject <AGNModelProtocol>


@property (nonatomic, retain) NSString * alias;
@property (nonatomic, retain) NSString * communityNickname;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * lastName;
@property (nonatomic, retain) NSString * middleName;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * salesForceSalesTeamId;
@property (nonatomic, retain) NSString * salesTeamName;
@property (nonatomic, retain) NSNumber * sample;
@property (nonatomic, retain) NSString * samplingStatus;
@property (nonatomic, retain) NSString * status;
@property (nonatomic, retain) NSString * territoryId;
@property (nonatomic, retain) NSString * territoryName;
@property (nonatomic, retain) NSString * username;
@property (nonatomic, retain) NSString * businessUnit;
@property (nonatomic, retain) NSString * managerName;
@property (nonatomic, retain) NSString * serverTimeZone;

@property (nonatomic, retain) NSSet *calls;
@property (nonatomic, retain) NSSet *detailPositions;
@property (nonatomic, retain) NSSet *sampleInventoryLines;
@property (nonatomic, retain) NSSet *samplePermissions;
@property (nonatomic, retain) NSSet *storageUnit;
@property (nonatomic, retain) NSSet *timeOffTerritory;
@property (nonatomic, retain) NSSet *transactionsFrom;
@property (nonatomic, retain) NSSet *transactionsTo;
@property (nonatomic, retain) NSSet *suppressedAddresses;

// transient
@property (nonatomic,strong) NSTimeZone *userTimeZone;

- (BOOL) canSample;
- (BOOL) hasSuppressedAddress:(AGNAddress *)address;

@end

@interface AGNSalesRep (CoreDataGeneratedAccessors)

- (void)addCallsObject:(AGNCall *)value;
- (void)removeCallsObject:(AGNCall *)value;
- (void)addCalls:(NSSet *)values;
- (void)removeCalls:(NSSet *)values;

- (void)addDetailPositionsObject:(AGNDetailPosition *)value;
- (void)removeDetailPositionsObject:(AGNDetailPosition *)value;
- (void)addDetailPositions:(NSSet *)values;
- (void)removeDetailPositions:(NSSet *)values;

- (void)addSampleInventoryLinesObject:(AGNSampleInventoryLine *)value;
- (void)removeSampleInventoryLinesObject:(AGNSampleInventoryLine *)value;
- (void)addSampleInventoryLines:(NSSet *)values;
- (void)removeSampleInventoryLines:(NSSet *)values;

- (void)addSamplePermissionsObject:(AGNSamplePermission *)value;
- (void)removeSamplePermissionsObject:(AGNSamplePermission *)value;
- (void)addSamplePermissions:(NSSet *)values;
- (void)removeSamplePermissions:(NSSet *)values;

- (void)addStorageUnitObject:(AGNStorageUnit *)value;
- (void)removeStorageUnitObject:(AGNStorageUnit *)value;
- (void)addStorageUnit:(NSSet *)values;
- (void)removeStorageUnit:(NSSet *)values;

- (void)addTimeOffTerritoryObject:(AGNTimeOffTerritory *)value;
- (void)removeTimeOffTerritoryObject:(AGNTimeOffTerritory *)value;
- (void)addTimeOffTerritory:(NSSet *)values;
- (void)removeTimeOffTerritory:(NSSet *)values;

- (void)addTransactionsFromObject:(AGNSampleInventoryTransaction *)value;
- (void)removeTransactionsFromObject:(AGNSampleInventoryTransaction *)value;
- (void)addTransactionsFrom:(NSSet *)values;
- (void)removeTransactionsFrom:(NSSet *)values;

- (void)addTransactionsToObject:(AGNSampleInventoryTransaction *)value;
- (void)removeTransactionsToObject:(AGNSampleInventoryTransaction *)value;
- (void)addTransactionsTo:(NSSet *)values;
- (void)removeTransactionsTo:(NSSet *)values;

- (NSString *)formattedName;


@end
