//
//  AGNCallDetail.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCallDetail.h"
#import "AGNCall.h"


@implementation AGNCallDetail

static NSDictionary *fieldMapping = nil;

@dynamic callSalesForceId;
@dynamic detailPositionSalesForceId;
@dynamic position;
@dynamic salesForceId;
@dynamic guid;
@dynamic productDetailed;
@dynamic call;
@dynamic detailPosition;
@dynamic toBeDeletedFlag;
@dynamic brand;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"GUID" : @"guid",
    @"Call" : @"callSalesForceId",
    @"Detail_Position" : @"detailPositionSalesForceId",
    @"Position" : @"position",
    @"Product_Detailed" : @"productDetailed",
    @"Detail": @"brand"
    };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for(NSString *key in objectDict){
        if([key isEqualToString:@"Position"]){
            if(dict[key]!=[NSNull null])
                self.position = [NSNumber numberWithInt:[(NSString *)objectDict[key] integerValue]];
        }
        else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on call detail to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on call detail to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }

    [self buildRelationships];
}

- (void)buildRelationships {
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;
    if (self.callSalesForceId && !self.call) {
        if (sync.currentCall) {
            self.call = sync.currentCall;
        } else {
            self.call = [sync callBySFDCID:self.callSalesForceId];
            if (!self.call) {
                log4Warn(@"Expected sync context to have call with Id %@, but it is nil", self.callSalesForceId);
            }
        }
    }
    
    if (self.detailPositionSalesForceId && !self.detailPosition)
        self.detailPosition = [sync detailPositionBySFDCID:self.detailPositionSalesForceId];
}

- (NSString *)jsonRepresentationForUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{ "];
    NSString *detailPos = self.detailPosition.salesForceId;
    [result appendFormat:@"\"toBeDeleted\": %@,", [self.toBeDeletedFlag boolValue] ? @"true" : @"false"];
    [result appendFormat:@"\"Detail_Position\" : \"%@\", ", detailPos];
    [result appendFormat:@"\"Position\" : %@, ", self.position];
    [result appendFormat:@"\"GUID\" : \"%@\"", self.guid];
    if (self.salesForceId) {
        [result appendFormat:@", \"Id\" : \"%@\"", self.salesForceId];
    }
    [result appendString:@"}"];
    return result;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    return [self initWithDictionary:dict];
}

- (BOOL)isToBeDeleted {
    return [self.toBeDeletedFlag boolValue];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

//- (void) setPosition:(NSNumber *)position {
//    [self willChangeValueForKey:@"position"];
//    [self setPrimitiveValue:position forKey:@"position"];
//    [self didChangeValueForKey:@"position"];
//}

-(void)incrementPosition{
    int currentPosition = [self.position intValue];
    currentPosition++;
    self.position = [NSNumber numberWithInt:currentPosition];
}

-(void)decrementPosition{
    if([self.position intValue]==0)
        return;
    self.position = [NSNumber numberWithInt:([self.position intValue]-1)];
}

-(NSString *)displayString{
    if(self.detailPosition)
        return [self.detailPosition displayString];
    
    else if (self.brand)
        return self.brand;
    
    return NSLocalizedString(@"UNKNOWN", @"Call detail display string when detail position is null");
}

-(BOOL)isValidForDate:(NSDate *)callDate{
    if(!self.detailPosition)
        return NO;

    if(![self.detailPosition isValidForDate:callDate])
        return NO;

    return YES;

}


- (void)stampComplianceFields {
    // No-op - since the stamped fields are actually formula fields
}

@end
