//
//  AGNCall.h
//  AGNDirect
//
//  Created by Mark Wells on 8/31/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNHCPActivity.h"

@class AGNAccount, AGNAddress, AGNCallContact, AGNCallDetail, AGNSalesRep, AGNSampleDrop, AGNSampleInventoryTransaction;

@interface AGNCall : AGNHCPActivity <AGNModelProtocol>

@property (nonatomic, retain) NSString * accompaniedBy;
@property (nonatomic, retain) NSDate * callClosedTimestamp;
@property (nonatomic, retain) NSDate * callDate;
@property (nonatomic, retain) NSDate * callEntryDate;
@property (nonatomic, retain) NSString * callTopic;
@property (nonatomic, retain) NSNumber * closed;
@property (nonatomic, retain) NSNumber * duration;
@property (nonatomic, retain) NSNumber * emailReceiptRequested;
@property (nonatomic, retain) NSNumber * mailReceiptRequested;
@property (nonatomic, retain) NSNumber * nonMDCall;
@property (nonatomic, retain) NSString * receiptEmailAddress;
@property (nonatomic, retain) NSString * salesForceContactId;
@property (nonatomic, retain) NSDate * syncDate;
@property (nonatomic, retain) NSMutableSet *callContacts;
@property (nonatomic, retain) NSMutableOrderedSet *callDetails;
@property (nonatomic, retain) NSMutableOrderedSet *sampleDrops;
@property (nonatomic, retain) NSMutableSet *sampleInventoryTransactions;

@property (nonatomic, retain) NSNumber * isDSSCall;

@property (nonatomic, strong) NSString *undoJSONRepresentation; //transient
@property (nonatomic, strong) NSString * signatureJSON; //transient


@end

@interface AGNCall (CoreDataGeneratedAccessors)

- (void)addCallContactsObject:(AGNCallContact *)value;
- (void)removeCallContactsObject:(AGNCallContact *)value;
- (void)addCallContacts:(NSSet *)values;
- (void)removeCallContacts:(NSSet *)values;

- (void)insertObject:(AGNCallDetail *)value inCallDetailsAtIndex:(NSUInteger)idx;
- (void)removeObjectFromCallDetailsAtIndex:(NSUInteger)idx;
- (void)insertCallDetails:(NSArray *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeCallDetailsAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInCallDetailsAtIndex:(NSUInteger)idx withObject:(AGNCallDetail *)value;
- (void)replaceCallDetailsAtIndexes:(NSIndexSet *)indexes withCallDetails:(NSArray *)values;
- (void)addCallDetailsObject:(AGNCallDetail *)value;
- (void)removeCallDetailsObject:(AGNCallDetail *)value;
- (void)addCallDetails:(NSOrderedSet *)values;
- (void)removeCallDetails:(NSOrderedSet *)values;

- (void)insertObject:(AGNSampleDrop *)value inSampleDropsAtIndex:(NSUInteger)idx;
- (void)removeObjectFromSampleDropsAtIndex:(NSUInteger)idx;
- (void)insertSampleDrops:(NSArray *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeSampleDropsAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInSampleDropsAtIndex:(NSUInteger)idx withObject:(AGNSampleDrop *)value;
- (void)replaceSampleDropsAtIndexes:(NSIndexSet *)indexes withSampleDrops:(NSArray *)values;
- (void)addSampleDropsObject:(AGNSampleDrop *)value;
- (void)removeSampleDropsObject:(AGNSampleDrop *)value;
- (void)addSampleDrops:(NSOrderedSet *)values;
- (void)removeSampleDrops:(NSOrderedSet *)values;

- (void)addSampleInventoryTransactionsObject:(AGNSampleInventoryTransaction *)value;
- (void)removeSampleInventoryTransactionsObject:(AGNSampleInventoryTransaction *)value;
- (void)addSampleInventoryTransactions:(NSSet *)values;
- (void)removeSampleInventoryTransactions:(NSSet *)values;

// Custom (non-CoreData) methods
- (NSString *)formattedRepName;
- (NSAttributedString *)formattedSampleAndDetail;
- (NSString *)formattedDateAndRepName;
- (void)setStartDate:(NSDate *)date duration:(NSUInteger)callDuration;
- (void)setStartDateAndDurationFromEndDate;
- (BOOL)canClose;
- (BOOL)canSchedule;
- (BOOL)canGetSignature;
- (BOOL)canSampleAtAddress;
- (BOOL)canSample;
- (BOOL)canAddSamples;
- (BOOL)canAddDetails;
- (BOOL)isClosed;
- (BOOL)isDSCall;

- (void)stampComplianceFields:(BOOL)isClosure;

- (NSArray *)orderedCallDetails;
- (void)moveDetailAtIndex:(NSUInteger)from toIndex:(NSUInteger)to;
- (void)addDetail:(AGNCallDetail *)detail;
- (void)printDetailPositions;
- (void)removeExpiredSamples;


- (NSMutableOrderedSet *)liveCallDetails; //Call details excluding those marked as toBeDeleted
- (NSMutableOrderedSet *)liveSampleDrops; //Sample drops excluding those marked as toBeDeleted

- (BOOL) hasContact:(AGNContact *)contact;

- (NSDate *)projectedCloseDate;

- (BOOL) hasInvalidDetails;

- (BOOL) hasBeenUpserted; // whether we have queued an upsert request for this call ever


@end
