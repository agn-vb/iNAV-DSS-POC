//
//  AGNSampleInventoryTransactionLine.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

#import "AGNSampleInventoryTransactionLine.h"
#import "AGNProductSKU.h"
#import "AGNSampleDrop.h"
#import "AGNSampleInventoryLine.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNSampleInventoryTransactionLine.h"

@class AGNProductSKU, AGNSampleInventoryLine, AGNSampleInventoryTransaction, AGNSampleInventoryTransactionLine;

@interface AGNSampleInventoryTransactionLine : NSManagedObject <AGNModelProtocol>


@property (nonatomic, retain) NSNumber * actualQuantity;
@property (nonatomic, retain) NSNumber * availableQuantity;
@property (nonatomic, retain) NSNumber * expectedQuantity;
@property (nonatomic, retain) NSDate * expirationDate;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSNumber * isAccepted;
@property (nonatomic, retain) NSString * lotNumber;
@property (nonatomic, retain) NSDate * mobileCreateTimestamp;
@property (nonatomic, retain) NSDate * mobileLastUpdateTimestamp;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * productSalesForceId;
@property (nonatomic, retain) NSString * productCode;
@property (nonatomic, retain) NSString * productDescription;
@property (nonatomic, retain) NSString * itemCode;
@property (nonatomic, retain) NSString * sampleInventoryLineSalesForceId;
@property (nonatomic, retain) NSString * sampleInventoryTransactionSalesForceId;
@property (nonatomic, retain) NSDate * shipmentDate;
@property (nonatomic, retain) AGNProductSKU *product;
@property (nonatomic, retain) AGNSampleInventoryLine *sampleInventoryLine;
@property (nonatomic, retain) AGNSampleInventoryTransaction *sampleInventoryTransaction;

- (void)populateFromSIL:(AGNSampleInventoryLine *)sil;
- (void)revertInventoryQuantityUpdateForTransaction:(AGNSampleInventoryTransaction *)sit;
- (NSNumber *)variance;
- (NSNumber *)varianceForInventoryCount;
@end
