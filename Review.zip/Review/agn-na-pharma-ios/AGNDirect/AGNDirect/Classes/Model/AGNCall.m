
//
//  AGNCall.m
//  AGNDirect
//
//  Created by Mark Wells on 8/31/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCall.h"
#import "AGNAccount.h"
#import "AGNAddress.h"
#import "AGNCallContact.h"
#import "AGNCallDetail.h"
#import "AGNSalesRep.h"
#import "AGNSampleDrop.h"
#import "AGNSampleInventoryTransaction.h"
#import "NSDate+AGNDate.h"
#import "NSManagedObjectContext+DDSFExtensions.h"

static int kAGNDefaultCallDurationMinutes = 30;

@implementation AGNCall

static NSDictionary *fieldMapping = nil;
static NSDictionary *complianceFieldMapping = nil;

@dynamic accompaniedBy;
@dynamic callClosedTimestamp;
@dynamic callDate;
@dynamic callEntryDate;
@dynamic callTopic;
@dynamic closed;
@dynamic duration;
@dynamic emailReceiptRequested;
@dynamic mailReceiptRequested;
@dynamic nonMDCall;
@dynamic receiptEmailAddress;
@dynamic salesForceContactId;
@dynamic syncDate;

@dynamic callContacts;
@dynamic callDetails;
@dynamic sampleDrops;
@dynamic sampleInventoryTransactions;
@dynamic isDSSCall;

@synthesize undoJSONRepresentation=_undoJSONRepresentation;
@synthesize signatureJSON=_signatureJSON;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"Accompanied_By" : @"accompaniedBy",
    @"Call_Date" : @"callDate",
    @"Call_Entry_Date" : @"callEntryDate",
    @"Signature_Capture_Date" : @"signatureCaptureDate",
    @"Close_Time" : @"callClosedTimestamp",
    @"Start_Date" : @"startDate",
    @"End_Date" : @"endDate",
    @"Duration" : @"duration",
    @"Call_Topic" : @"callTopic",
    @"Contact" : @"salesForceContactId",
    @"Rep" : @"salesForceRepId",
    @"HCP" : @"salesForceAccountId",
    @"Address" : @"salesForceAddressId",
    @"Status" : @"closed",
    @"Non_MD_Call" : @"nonMDCall",
    @"Request_Email_Receipt": @"emailReceiptRequested",
    @"Request_Email": @"receiptEmailAddress",
    @"Request_Mail_Receipt": @"mailReceiptRequested",
    @"Duration": @"duration",
    @"GUID": @"guid",
    @"MobileLastModifiedDate" : @"mobileLastUpdateTimestamp",
    @"MobileCreatedDate" : @"mobileCreateTimestamp"
    //@"DSS_Call" : @"isDSCall"
    };
    
    complianceFieldMapping =
    @{
    @"Call_Address_Line_1" : @"stampAddressLine1",
    @"Call_Address_Line_2" : @"stampAddressLine2",
    @"Call_Address_Line_3" : @"stampAddressLine3",
    @"Call_City" : @"stampAddressCity",
    @"Call_Country" : @"stampAddressCountry",
    @"Call_State" : @"stampAddressState",
    @"Call_Zip_Code" : @"stampAddressZip",
    @"HCP_First_Name" : @"stampHCPFirstName",
    @"HCP_Last_Name" : @"stampHCPLastName",
    @"HCP_Middle_Name" : @"stampHCPMiddleName",
    @"HCP_MDM_ID" : @"stampHCPMDMID",
    @"License_Expiration" : @"stampLicenseExpirationDate",
    @"License_State" : @"stampLicenseState",
    @"License_Number" : @"stampLicenseNumber",
    @"Rep_First_Name": @"repFirstName",
    @"Rep_Last_Name": @"repLastName",
    @"Rep_Middle_Name": @"repMiddleName",
    @"Rep_Manager": @"stampRepManagerName",
    @"Physician_Specialty": @"stampPhysicianSpecialty",
    @"Professional_Designation": @"stampProfessionalDesignation"
    };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSArray *keys = @[ @"Start_Date__c", @"HCP__c", @"Address__c", @"Id" ];
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict;
    }
    for (NSString *key in keys) {

        if (![objectDict valueForKey:key] || [[objectDict valueForKey:key] isEqual:[NSNull null]]) {
            log4Warn(@"Unable to create call object from json, missing required field %@",key);
            return NO;
        }
    }
    return YES;
}


- (void)initWithDictionary:(NSDictionary *)dict{
    [self initWithDictionary:dict isUndo:NO];
}

- (void)initWithDictionary:(NSDictionary *)dict isUndo:(BOOL)undo{
    AGNDataManager *dm = [AGNAppDelegate sharedDelegate].dataManager;
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];//a00W0000001kPVuIAM
    self.closed=[NSNumber numberWithBool:NO];
    for(NSString *key in objectDict){
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }
        
        if([key isEqualToString:@"Start_Date"]) {
            [self setStartDateFromDictionary:objectDict isUndo:undo];
        }
        else if([key isEqualToString:@"End_Date"]) {
            //ignore - it will be set from start + duration
        }
        else if([key isEqualToString:@"Call_Date"]) {
            self.callDate = [NSDate agnDateFromString:value];
        }
        else if([key isEqualToString:@"Call_Entry_Date"]) {
            self.callEntryDate = [NSDate agnDateFromString:value];
        }
        else if([key isEqualToString:@"Closed_Time"]) {
            if (value) {
                self.callClosedTimestamp = [NSDate agnDateFromRFC3339TimestampString:value];
                self.closed=[NSNumber numberWithBool:YES];
            }
        }else if([key isEqualToString:@"Close_Time"]){
            if(undo && value){
                self.callClosedTimestamp = [self dateFromUpdateFormat:value];
                self.closed=[NSNumber numberWithBool:YES];
            }
        }
        else if([key isEqualToString:@"Signature_Capture_Date"]) {
            if (value) {
                self.signatureCaptureDate = [NSDate agnDateFromRFC3339TimestampString:value];
            }
        }
        else if([key isEqualToString:@"MobileLastModifiedDate"]) {
            if (value && ![value isEqual:[NSNull null]]) {
                self.mobileLastUpdateTimestamp = [NSDate agnDateFromRFC3339TimestampString:value];
            }
        }
        else if([key isEqualToString:@"MobileCreatedDate"]) {
            if (value && ![value isEqual:[NSNull null]]) {
                self.mobileCreateTimestamp = [NSDate agnDateFromRFC3339TimestampString:value];
            }
        }
        else if([key isEqualToString:@"Duration"]) {
            self.duration = [NSNumber numberWithInt:((NSString *)value).intValue];
        }
        else if([key isEqualToString:@"Non_MD_Call"]) {
            self.nonMDCall = [NSNumber numberWithInt:((NSString *)value).intValue];
        }
        else if([key isEqualToString:@"Status"]) {
            self.closed = [NSNumber numberWithBool:[(NSString *)value isEqualToString:@"Closed"]];
        }
        else if([key isEqualToString:@"IsDSSCall"]) {
            NSLog(@"debug value %@",value);
            self.isDSSCall = [NSNumber numberWithInt:((NSString *)value).intValue];
            //[NSNumber numberWithBool:[(NSString *)value isEqualToString:@"true"]];
        }
        else if([key isEqualToString:@"Sample_Drops"]) {
            NSArray *sampleDropsJSONArray = (NSArray *)objectDict[key];
            for (NSDictionary *sdDict in sampleDropsJSONArray) {
                AGNSampleDrop *sd;
                NSString *sdID;
                // Get either the SFDC ID or GUID of the object
                sdID = [sdDict objectForKey:@"Id"];
                if (!sdID) {
                    sdID = [sdDict objectForKey:@"GUID"];
                }
                // Try to find the corresponding object in CoreData
                if (sdID) {
                    sd = (AGNSampleDrop *)[dm objectOfType:@"AGNSampleDrop" forId:sdID];
                }
                // If not there, create it
                if (!sd) {
                    sd = (AGNSampleDrop *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleDrop" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
                }
                // Initialize (or update) the object from the dictionary
                [sd initWithDictionary:sdDict];
                // Update the object with it's owning Call
                sd.callSalesForceId = self.salesForceId;
                sd.call = self;
            }
        }
        else if([key isEqualToString:@"Call_Details"]) {
            NSArray *callDetailsJSONArray = (NSArray *)objectDict[key];
            for (NSDictionary *cdDict in callDetailsJSONArray) {
                AGNCallDetail *cd;
                NSString *cdID;
                // Get either the SFDC ID or GUID of the object
                cdID = [cdDict objectForKey:@"Id"];
                if (!cdID) {
                    cdID = [cdDict objectForKey:@"GUID"];
                }
                // Try to find the corresponding object in CoreData
                if (cdID) {
                    cd = (AGNCallDetail *)[dm objectOfType:@"AGNCallDetail" forId:cdID];
                }
                // If not there, create it
                if (!cd) {
                    cd = (AGNCallDetail *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNCallDetail" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
                }
                // Initialize (or update) the object from the dictionary
                [cd initWithDictionary:cdDict];
                // Update the object with it's owning Call
                cd.callSalesForceId = self.salesForceId;
                cd.call = self;
            }
        }
        else{
            NSString *objectKey = fieldMapping[key];
            if(!objectKey) // try the compliance fields
                objectKey = complianceFieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on call to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on call to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }

        }
    }
    [self setEndDateFromStartDateAndDuration];
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerCall:self];
    [self buildRelationships];
}

- (void)buildRelationships {
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;
    
    if (sync) {
        if (self.salesForceAccountId && !self.account) {
            self.account = [sync accountBySFDCID:self.salesForceAccountId];
        }
        if (self.salesForceAddressId && !self.address) {
            self.address = [sync addressBySFDCID:self.salesForceAddressId];
        }
        if (self.salesForceRepId && !self.salesRep) {
            self.salesRep = [sync salesRepBySFDCID:self.salesForceRepId];
        }
    }
    else {
        if (self.salesForceAccountId && !self.account) {
            self.account = [self.managedObjectContext ddsf_objectOfType:@"AGNAccount" forId:self.salesForceAccountId];
        }
        if (self.salesForceAddressId && !self.address) {
            self.address = [self.managedObjectContext ddsf_objectOfType:@"AGNAddress" forId:self.salesForceAddressId];
        }
        if (self.salesForceRepId && !self.salesRep) {
            self.salesRep = [self.managedObjectContext ddsf_objectOfType:@"AGNSalesRep" forId:self.salesForceRepId];
        }
    }

    if (!self.account)
        log4Warn(@"Missing account on call %@ after sync, accountId = %@", self.salesForceId, self.salesForceAccountId);
    
    if (!self.salesRep)
        log4Debug(@"Missing sales rep on call %@ after sync, salesRepId = %@", self.salesForceId, self.salesForceRepId);
    
}

-(NSDate *)dateFromUpdateFormat:(NSString *)dateString{

    if([dateString isEqual:[NSNull null]]){
        return nil;
    }
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    return [dateFormatter dateFromString:dateString];
}

- (NSString *)jsonRepresentationForUpdate {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [result appendFormat:@"\"toBeDeleted\": %@,", [self.toBeDeletedFlag boolValue] ? @"true" : @"false"];
    if(self.address && self.address.guid){
        [result appendFormat:@"\"Address_GUID\": \"%@\",", [self.address.guid agnEscapedString]];
    }
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
        if ([((NSString *)value) isEqualToString:@"closed"]) {
            prop = [((NSNumber *)prop) boolValue] ? @"\"Closed\"" : @"\"Draft\"";
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        /*else if ([((NSString *)value) isEqualToString:@"isDSCall"]) {
            //prop = [((NSNumber *)prop) boolValue] ? @"\"Closed\"" : @"\"Draft\"";
            [result appendFormat:@"\"%@\": %@,",key, prop];
            
        }*/
        else if ([((NSString *)value) isEqualToString:@"nonMDCall"]) {
            prop = [((NSNumber *)prop) boolValue] ? @"true" : @"false";
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else if ([((NSString *)value) isEqualToString:@"emailReceiptRequested"]) {
            prop = [((NSNumber *)prop) boolValue] ? @"true" : @"false";
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else if ([((NSString *)value) isEqualToString:@"mailReceiptRequested"]) {
            prop = [((NSNumber *)prop) boolValue] ? @"true" : @"false";
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else if ([((NSString *)value) isEqualToString:@"salesForceRepId"]) {
            [result appendFormat:@"\"Rep\": \"%@\",", [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId];
        }
        else if ([((NSString *)value) isEqualToString:@"mobileLastUpdateTimestamp"]) {
            if (self.mobileLastUpdateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileLastModifiedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"mobileCreateTimestamp"]) {
            if (self.mobileCreateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileCreatedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        
        else if ([prop isKindOfClass:[NSNumber class]]) {
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else if ([((NSString *)value) isEqualToString:@"startDate"]) {
            NSString *startDateString = [self.startDate agnSfdcDateComponentString];
            NSString *startTimeString = [self.startDate agnSfdcTimeComponentString];
            [result appendFormat:@"\"Start_Date\":\"%@\",\"Start_Time\":\"%@\",", startDateString, startTimeString];
        }
        else if ([((NSString *)value) isEqualToString:@"endDate"]) {
            NSString *endDateString = [self.endDate agnSfdcDateComponentString];
            NSString *endTimeString = [self.endDate agnSfdcTimeComponentString];
            [result appendFormat:@"\"End_Date\":\"%@\",\"End_Time\":\"%@\",", endDateString, endTimeString];
        }
        else if ([((NSString *)value) isEqualToString:@"callDate"] || [((NSString *)value) isEqualToString:@"callEntryDate"]) {
            prop = [prop agnGMTStringFromDate];
            if (prop) {
                [result appendFormat:@"\"%@\": \"%@\",",key, prop];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"callClosedTimestamp"] || [((NSString *)value) isEqualToString:@"signatureCaptureDate"]) {
            NSTimeZone *local = [df timeZone];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [df setTimeZone:gmt];
            NSString *timeStamp = [df stringFromDate:prop];
            [df setTimeZone:local];
            if (prop) {
                [result appendFormat:@"\"%@\": \"%@\",",key, timeStamp];
            }
        }
        else {
            if (prop) {
                if ([prop isKindOfClass:[NSString class]]) {
                    [result appendFormat:@"\"%@\": \"%@\",",key, [prop agnEscapedString]];
                }
                else{
                    [result appendFormat:@"\"%@\": \"%@\",",key, prop];
                }
            }
        }
    }];
    
    if ([self isClosed]) {
        [result appendString:@"\"ComplianceData\": {"];
        [complianceFieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
            if ([((NSString *)value) isEqualToString:@"stampLicenseExpirationDate"] && self.stampLicenseExpirationDate) {
                [result appendFormat:@"\"License_Expiration\":\"%@\",", [self.stampLicenseExpirationDate agnGMTStringFromDate]];
            }
            else if (prop) {
                if ([prop isKindOfClass:[NSString class]]) {
                    [result appendFormat:@"\"%@\": \"%@\",",key, [prop agnEscapedString]];
                }
                else{
                    [result appendFormat:@"\"%@\": \"%@\",",key, prop];
                }
            }
        }];
        result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
        [result appendString:@"},"];
    }
    if ([self.callContacts count] > 0) {
        [result appendString:@"\"Call_Contacts\" : ["];
        for (AGNCallContact *cc in self.callContacts) {
            [result appendFormat:@" %@,", [cc jsonRepresentationForUpdate]];
        }
        result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
        [result appendString:@"],"];
    }
    if ([self.callDetails count] > 0) {
        int position = 0;
        [result appendString:@"\"Call_Details\" : ["];
        for (AGNCallDetail *cd in [self sortedCallDetails]) {
            if ([cd.toBeDeletedFlag boolValue]) {
                //don't send delete - service changed to delete all then re-add
            }
            else {
                // Make sure we set the position on the call detail object before sending
                position++;
                if(![cd.position isEqualToNumber:[NSNumber numberWithInt:position]])
                     cd.position = [NSNumber numberWithInt:position];
                [result appendFormat:@" %@,", [cd jsonRepresentationForUpdate]];
            }
        }
        result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
        [result appendString:@"],"];
    }
    if ([self.sampleDrops count] > 0) {
        [result appendString:@"\"Sample_Drops\" : ["];
        int i = 1;
        for (AGNSampleDrop *sd in self.sampleDrops) {
            if ([sd.toBeDeletedFlag boolValue]) {
                //don't send delete - service changed to delete all then re-add
            }
            else {
                [result appendFormat:@" %@,", [sd jsonRepresentationForUpdateWithPosition:i]];
            }
            i++;
        }
        result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
        [result appendString:@"],"];
    }
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict {
    NSString *callGUID =  [[jsonDict valueForKey:@"callGUID"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"callGUID"];
    NSString *callId = [[jsonDict valueForKey:@"callId"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"callId"];
    NSString *callStatusCode = [[jsonDict valueForKey:@"StatusCode"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"StatusCode"];
    if ([callStatusCode isEqualToString:@"SUCCESS"]) {
        if ([self.guid isEqualToString:callGUID] && callId && callId.length>0) {
                self.salesForceId = callId;
        }
        if ([jsonDict valueForKey:@"Call_Contact"] != [NSNull null]) {
            NSArray *callContacts = (NSArray *)[jsonDict valueForKey:@"Call_Contact"];
            for (NSDictionary *dict in callContacts) {
                NSString *callContactGUID = [[jsonDict valueForKey:@"GUID"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"GUID"];
                NSString *callContactId = [[jsonDict valueForKey:@"Id"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"Id"];
                NSString *callContactStatusCode =  [[jsonDict valueForKey:@"StatusCode"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"StatusCode"];
                NSString *callContactRecordStatus =  [[jsonDict valueForKey:@"RecordStatus"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"RecordStatus"];
                if ([callContactStatusCode isEqualToString:@"SUCCESS"]) {
                    [self.callContacts enumerateObjectsUsingBlock:^(id obj, BOOL*stop) {
                        AGNCallContact *cd = (AGNCallContact *)obj;
                        if (cd.salesForceId && [callContactId isEqualToString:cd.salesForceId]) {
                            if ([callContactRecordStatus isEqualToString:@"DELETED"]) {
                                [self.callContacts removeObject:cd];
                                [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:cd];
                            }
                            *stop = YES;
                        }
                        else if ([cd.guid isEqualToString:callContactGUID]) {
                            if (callContactId) {
                                cd.salesForceId = callContactId;
                            }
                            *stop = YES;
                        }
                    }];
                }
            }
        }
        if ([jsonDict valueForKey:@"Call_Detail"] != [NSNull null]) {
            NSArray *callDetails =  [[jsonDict valueForKey:@"Call_Detail"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"Call_Detail"];
            for (NSDictionary *dict in callDetails) {
                NSString *callDetailGUID =  [[dict valueForKey:@"GUID"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"GUID"];
                NSString *callDetailId =  [[dict valueForKey:@"Id"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"Id"];
                NSString *callDetailStatusCode =  [[dict valueForKey:@"StatusCode"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"StatusCode"];         
                NSString *callDetailRecordStatus =  [[dict valueForKey:@"RecordStatus"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"RecordStatus"];
                if ([callDetailStatusCode isEqualToString:@"SUCCESS"]) {
                    [self.callDetails enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL*stop) {
                        AGNCallDetail *cd = (AGNCallDetail *)obj;
                        if (cd.salesForceId && [callDetailId isEqualToString:cd.salesForceId]) {
                            if ([callDetailRecordStatus isEqualToString:@"DELETED"]) {
                                [self.callDetails removeObject:cd];
                                [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:cd];
                            }
                            *stop = YES;
                        }
                        else if ([cd.guid isEqualToString:callDetailGUID]) {
                            if (callDetailId) {
                                cd.salesForceId = callDetailId;
                            }
                            *stop = YES;
                        }
                    }];
                }
            }
        }
        if ([jsonDict valueForKey:@"Sample_Drop"]  != [NSNull null]) {
            NSArray *sampleDrops =  [[jsonDict valueForKey:@"Sample_Drop"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"Sample_Drop"];
            for (NSDictionary *dict in sampleDrops) {
                NSString *sampleDropGUID =  [[dict valueForKey:@"GUID"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"GUID"];
                NSString *sampleDropId =  [[dict valueForKey:@"Id"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"Id"];
                NSString *sampleDropStatusCode =  [[dict valueForKey:@"StatusCode"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"StatusCode"];
                NSString *sampleDropRecordStatus =  [[dict valueForKey:@"RecordStatus"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"RecordStatus"];
                if ([sampleDropStatusCode isEqualToString:@"SUCCESS"]) {
                    [[self.sampleDrops copy] enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL*stop) {
                        AGNSampleDrop *sd = (AGNSampleDrop *)obj;
                        if (sd.salesForceId && [sampleDropId isEqualToString:sd.salesForceId]) {
                            if ([sampleDropRecordStatus isEqualToString:@"DELETED"]) {
                                [self.sampleDrops removeObject:sd];
                                [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:sd];
                            }
                            *stop = YES;
                        }
                        else if ([sd.guid isEqualToString:sampleDropGUID]) {
                            if (sampleDropId) {
                                sd.salesForceId = sampleDropId;
                            }
                            *stop = YES;
                        }
                    }];
                }
            }
        }
    }
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)setUndoRepresentation {
    self.undoJSONRepresentation = [self jsonRepresentationForUndo];
}

- (void)clearUndoRepresentation {
    self.undoJSONRepresentation = nil;
}

-(void)clearObject{
    NSDictionary *attributes = [self.entity attributesByName];
    for (NSString *attr in attributes) {
        [self setValue:nil forKey:attr];
    }
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    [self clearObject]; // null everything out so we don't end up retaining fields not in the undo dictionary

    [self initWithDictionary:dict isUndo:YES];
    // Remove any call details that do not have a salesForceId - these did not get saved to SFDC
    [[self.callDetails copy] enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL*stop) {
        AGNCallDetail *cd = (AGNCallDetail *)obj;
        if (!cd.salesForceId) {
            [self.callDetails removeObject:cd];
        }
        else if ([cd isToBeDeleted]) {
            cd.toBeDeletedFlag = @NO;
        }
    }];
    // Remove any sample drops that do not have a salesForceId - these did not get saved to SFDC
    [[self.sampleDrops copy] enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL*stop) {
        AGNSampleDrop *sd = (AGNSampleDrop *)obj;
        if (!sd.salesForceId) {
            [self.sampleDrops removeObject:sd];
        }
        else if ([sd isToBeDeleted]) {
            sd.toBeDeletedFlag = @NO;
        }
    }];
}

- (BOOL)isToBeDeleted {
    return [self.toBeDeletedFlag boolValue];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Private sync utility methods
//------------------------------------------------------------------------------

-(void)setStartDateFromDictionary:(NSDictionary *)objectDict isUndo:(BOOL)undo {
    if([objectDict[@"Start_Date"] isEqual:[NSNull null]] || [objectDict[@"Start_Time"] isEqual:[NSNull null]]){
        log4Warn(@"Unable to parse start date for call %@", objectDict);
        return;
    }
    NSString *startDateString = objectDict[@"Start_Date"];
    NSString *startTimeString = objectDict[@"Start_Time"];
    NSDate *dateSent = [NSDate agnDateFromDateTimeComponents:startDateString :startTimeString];

    if(undo){
        // if we are in a revert, the date is in GMT
        self.startDate = dateSent;

    }else{
        // if not reverting, the date is coming from SFDC
        // SFDC gives us the start date in the timezone for the user on the server
        // We need to convert it to GMT so we can display it in the device timezone
        // On upsert we're expected to send GMT
        AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;

        NSTimeZone* userTimeZone = sync.loggedInSalesRep.userTimeZone;
        NSInteger gmtOffset = [userTimeZone secondsFromGMTForDate:dateSent];
        self.startDate = [dateSent dateByAddingTimeInterval:-1*gmtOffset];
    }
    if(!self.startDate){
        log4Warn(@"Unable to parse start date for call %@", objectDict);
    }
}

- (NSArray *)sortedCallDetails {
    return [self.callDetails sortedArrayUsingComparator:^(id obj1, id obj2) {
        return [((AGNCallDetail *)obj1).position compare:((AGNCallDetail *)obj2).position];
    }];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

- (void)setStartDate:(NSDate *)date duration:(NSUInteger)callDurationMinutes {
    self.startDate = date;
    if (!callDurationMinutes) {
        callDurationMinutes = 30;
    }
    self.duration = [NSNumber numberWithInteger:callDurationMinutes];
    self.endDate = [date dateByAddingTimeInterval:(callDurationMinutes * 60)];
    self.callDate = date; //Necessary - SFDC constrains callDate to same as StartDate - why we have both is a mystery to me
}

- (void)setEndDateFromStartDateAndDuration {
    if (!self.startDate) {
        self.endDate = nil;
    }
    else {
        int durMinutes = [self.duration intValue] ? [self.duration intValue] : kAGNDefaultCallDurationMinutes;
        self.endDate = [self.startDate dateByAddingTimeInterval:(durMinutes * 60)];
    }
}

-(void)setStartDateAndDurationFromEndDate{
    int durMinutes = [self.duration intValue] ? [self.duration intValue] : kAGNDefaultCallDurationMinutes;
    self.startDate = [self.endDate dateByAddingTimeInterval:(durMinutes * 60 *-1)];
    self.duration = [NSNumber numberWithInteger:kAGNDefaultCallDurationMinutes];
}

- (NSString *)formattedRepName {
    if(!self.salesRep){
        NSString *repName = self.repLastName ? [self.repLastName uppercaseString] : @"UNKNOWN";
        if (self.repFirstName) {
            repName = [repName stringByAppendingFormat:@", %@", [self.repFirstName uppercaseString]];
        }
        return repName;
    }
    return self.salesRep.formattedName;
}

- (NSAttributedString *)formattedSampleAndDetail {
    NSOrderedSet *liveCallDetails = [self liveCallDetails];
    NSOrderedSet *liveSampleDrops = [self liveSampleDrops];
    
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    /*
     if (self.role.length > 0) {
     NSString *role = [NSString stringWithFormat:@" (%@)", self.role];
     [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:role attributes:romanAttributes]];
     }
     
     return formattedString;
     
     NSArray *contacts = [self.account.contacts allObjects];
     
     if (contacts.count > 0 ) {
     NSMutableAttributedString *contactsString = [[NSMutableAttributedString alloc] init];
     for (AGNContact *contact in contacts) {
     NSMutableAttributedString *contactString = [[contact attributedFirstNameAndRole] mutableCopy];
     if (contact != contacts.lastObject) {
     
     [contactString appendAttributedString:commaSpace];
     }
     [contactsString appendAttributedString:contactString];
     }
     
     */
    
    NSAttributedString *commaSpace = [[NSAttributedString alloc] initWithString:@", " attributes:romanAttributes];
    if (liveCallDetails.count > 0) {
        NSMutableAttributedString *details = [[NSMutableAttributedString alloc] init];
        [details appendAttributedString:[[NSAttributedString alloc] initWithString:@"Detail: " attributes:heavyAttributes]];
        
        for (AGNCallDetail *detail in liveCallDetails) {
            if (detail.displayString) {
                [details appendAttributedString:[[NSAttributedString alloc] initWithString:detail.displayString attributes:romanAttributes]];
                if (self.callDetails.lastObject != detail) {
                    [details appendAttributedString:commaSpace];
                }
            }
        }
        
        [formattedString appendAttributedString:details];
    }
    
    if (liveCallDetails.count > 0 && liveSampleDrops.count > 0) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"    " attributes:romanAttributes]];
    }
    
    if (liveSampleDrops.count > 0) {
        NSMutableAttributedString *samples = [[NSMutableAttributedString alloc] init];
        [samples appendAttributedString:[[NSAttributedString alloc] initWithString:@"Sample: " attributes:heavyAttributes]];
        
        for (AGNSampleDrop *drop in liveSampleDrops) {
            NSString *prodDescr = drop.productDescription ? drop.productDescription : drop.sampleInventoryLine.product.productDescription;
            if (prodDescr && [drop.quantity intValue] > 0) {
                NSString * dropString = [NSString stringWithFormat:@"%@ (%d)", prodDescr, [drop.quantity intValue]];
                [samples appendAttributedString:[[NSAttributedString alloc] initWithString:dropString attributes:romanAttributes]];
                if (self.sampleDrops.lastObject != drop) {
                    [samples appendAttributedString:commaSpace];
                }
            }
        }
        
        [formattedString appendAttributedString:samples];
    }
    
    return formattedString;
}

-(NSString *)description {
    return [NSString stringWithFormat:@"%@|%@, status %@",self.guid,self.salesForceId,[self isClosed]?@"Closed":@"Draft"];
}

- (NSString *)formattedDateAndRepName {
    NSString *string = @"";
    NSDate *date = self.endDate ? self.endDate : self.startDate;
    
    
    if ([date agnFormattedDateString].length > 0) {
        string = [NSString stringWithFormat:@"%@    %@", [date agnFormattedDateString], self.formattedRepName.uppercaseString];
    } else {
        string = self.formattedRepName.uppercaseString;
    }
    
    return string;
}

// validate that the call is in such a state that it can be closed - i.e. if samples, must have signature etc.

- (BOOL)canClose {
    NSOrderedSet *liveCallDetails = [self liveCallDetails];
    NSOrderedSet *liveSampleDrops = [self liveSampleDrops];
    BOOL result = NO;
    if([self isClosed])
        return NO;
    if(self.signatureCaptureDate){
        // already got a signature so we had better let them close regardless of anything else
        result = YES;
    }

    if ([liveSampleDrops count] == 0 && [liveCallDetails count] > 0) {
        result = YES;
    }

    for(AGNCallDetail *detail in liveCallDetails){
        if(![detail isValidForDate:[self projectedCloseDate]]){
            result = NO;
        }
    }

    return result;
}

- (BOOL) hasInvalidDetails{
    for(AGNCallDetail *detail in [self liveCallDetails] ){
        if(!detail.detailPosition)
            return YES;
    }
    return NO;
}

- (NSArray *)orderedCallDetails {
    return [self.liveCallDetails sortedArrayUsingComparator: ^(AGNCallDetail *obj1, AGNCallDetail *obj2) {
        return [obj1.position compare:obj2.position];
    }];
}

// Add in a detail, setting position appropriately
- (void)addDetail:(AGNCallDetail *)detail {
    NSArray * sortedDetails = [self orderedCallDetails];
    AGNCallDetail *lastDetail = [sortedDetails lastObject];
    detail.position = lastDetail? [NSNumber numberWithInt:([lastDetail.position intValue]+1)]:[NSNumber numberWithInt:1];
    detail.call = self;
}

// support reordering of details
- (void)moveDetailAtIndex:(NSUInteger)from toIndex:(NSUInteger)to {
    if(from==to)return;
    NSArray * orderedCallDetails = [self orderedCallDetails];
    AGNCallDetail *movedDetail = orderedCallDetails[from];
    if(from>to){
        // slide existing rows up one
        NSMutableArray *toIncrement = [[NSMutableArray alloc]init];
        for(int index = to; index < from; index++){
            [toIncrement addObject:orderedCallDetails[index]];
        }
        for(AGNCallDetail *detail in toIncrement){
            [detail incrementPosition];
        }
        
    } else if(to>from){
        // slide existing rows down one
        NSMutableArray *toDecrement = [[NSMutableArray alloc]init];
        for(int index = to; index > from; index--){
            [toDecrement addObject:orderedCallDetails[index]];
        }
        for(AGNCallDetail *detail in toDecrement){
            [detail decrementPosition];
        }
        
    }
    
    movedDetail.position = [NSNumber numberWithInt:to+1];
}

- (void)printDetailPositions {
    NSArray *ordered = [self orderedCallDetails];
    log4Debug(@"\n\nPRINTING DETAILS ");
    for(AGNCallDetail *detail in ordered){
        NSString *desc = detail.detailPosition.displayName;
        log4Debug(@"DETAIL: %@ %@",desc,detail.position);
        
    }
    log4Debug(@"\n");
}

- (void)removeExpiredSamples {
    NSOrderedSet *liveSampleDrops = [self liveSampleDrops];
    for(AGNSampleDrop *sampleDrop in liveSampleDrops){
        if([sampleDrop.sampleInventoryLine.expiration compare:[NSDate date]]==NSOrderedAscending)
            sampleDrop.toBeDeletedFlag = @YES;
    }
}

- (BOOL)canGetSignature {
    if(![self.salesRep canSample])
        return NO;
    if(![self canSampleAtAddress])
        return NO;
    NSOrderedSet *liveSampleDrops = [self liveSampleDrops];
    BOOL result = NO;
    if ([liveSampleDrops count] > 0 && !self.signatureCaptureDate) {
        result = YES;
        for (AGNSampleDrop *drop in liveSampleDrops) {
            if ([drop.quantity intValue] <= 0) {
                result = NO;
            }
            if([drop.quantity intValue] > [drop.sampleInventoryLine.quantity intValue]){
                result = NO;
            }
            if([drop.sampleInventoryLine.expiration compare:[NSDate date]]==NSOrderedAscending){
                result = NO;
            }
            if(![drop.sampleInventoryLine hasSamplePermission]){
                result = NO;
            }
            if (!drop.sampleInventoryLine){
                result = NO;
            }
            
        }
    }
    return result;
}

- (BOOL) canSampleAtAddress {
    return [self.account canSampleAtAddress:self.address];
}

- (BOOL) canSample {
    return [self.account canSampleAtAddress:self.address] && [self.salesRep canSample];
}

- (BOOL) canAddSamples {
    return [self canSample] && (self.signatureCaptureDate==nil) && ![self.closed boolValue];
}

-(BOOL) canAddDetails {
    return  (self.closed == [NSNumber numberWithInt:0]);
}

-(BOOL) isClosed {
    return (self.closed == [NSNumber numberWithInt:1]);
}


-(BOOL) isDSCall {
    NSLog(@"DSCALL VALUE %@",self.isDSSCall);
    if (self.isDSSCall != nil && self.isDSSCall == [NSNumber numberWithInt:1])
        return true;
    else
        return false;
    
    //return (self.isDSSCall) ; // == [NSNumber numberWithInt:1]);
}


- (BOOL) canSchedule {
    if([self isClosed])
        return NO;
    if(self.signatureCaptureDate)
        return NO;
    if(self.hasInvalidDetails)
        return NO;
    return YES;
}

// We delete samples, details on the device by flagging the records to be deleted so the request can be sent to SFDC.
// This method returns the details which do not have the delete flag set.  
- (NSMutableOrderedSet *)liveCallDetails {
    NSMutableOrderedSet *result = [self.callDetails mutableCopy];
    [self.callDetails enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL *stop) {
        if (((AGNCallDetail *)obj).toBeDeletedFlag.boolValue) {
            [result removeObject:obj];
        }
    }];
    return result;
}

// We delete samples, details on the device by flagging the records to be deleted so the request can be sent to SFDC.
// This method returns the samples which do not have the delete flag set.
- (NSMutableOrderedSet *)liveSampleDrops {
    NSMutableOrderedSet *result = [self.sampleDrops mutableCopy];
    [self.sampleDrops enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL *stop) {
        if (((AGNSampleDrop *)obj).toBeDeletedFlag.boolValue) {
            [result removeObject:obj];
        }
    }];
    return result;
}

- (void)stampComplianceFields:(BOOL)isClosure {
    AGNSalesRep *rep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    if(rep){
        self.repFirstName = [rep.firstName copy];
        self.repLastName = [rep.lastName copy];
        self.repMiddleName = [rep.middleName copy];
        self.stampRepManagerName = [rep.managerName copy];
        self.stampSalesTeam = [[AGNAppDelegate sharedDelegate].loggedInSalesRep.salesTeamName copy];
        self.stampTerritory = [[AGNAppDelegate sharedDelegate].loggedInSalesRep.territoryName copy];

    }
    if (self.address) {
        self.stampAddressLine1 = [self.address.line1 copy];
        self.stampAddressLine2 = [self.address.line2 copy];
        self.stampAddressLine3 = [self.address.line3 copy];
        self.stampAddressCity = [self.address.city copy];
        self.stampAddressCountry = @"USA";
        self.stampAddressState = [self.address.usState copy];
        self.stampAddressZip = [self.address.zip copy];
    }
    if (self.account) {
        self.stampHCPFirstName = [self.account.firstName copy];
        self.stampHCPLastName = [self.account.lastName copy];
        self.stampHCPMiddleName = [self.account.middleName copy];
        self.stampHCPMDMID = [self.account.mdmId copy];
        self.stampPhysicianSpecialty = [self.account.primarySpecialty copy];
        self.stampProfessionalDesignation = [self.account.professionalDesignation copy];
        AGNLicense *license = [self.account samplingLicenseForAddress:self.address];
        if (license) {
            self.stampLicenseExpirationDate = [license.expirationDate copy];
            self.stampLicenseState = [license.usState copy];
            self.stampLicenseNumber = [license.licenseNumber copy];
        }
    }

    if(isClosure){
        [self.callDetails enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL *stop) {
            [((AGNCallDetail *)obj) stampComplianceFields]; // currently a no-op
        }];
        [self.callContacts enumerateObjectsUsingBlock:^(id obj, BOOL *stop) {
            [((AGNCallContact *)obj) stampComplianceFields];
        }];

    }

    [self.sampleDrops enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL *stop) {
        [((AGNSampleDrop *)obj) stampComplianceFields]; // currently a no-op
    }];

    
}

- (BOOL) hasContact:(AGNContact *)contact{
    for(AGNCallContact *callContact in self.callContacts){
        if([contact isEqual:callContact.contact])
            return YES;
    }
    return NO;
}

-(NSDate *)projectedCloseDate{
    return self.startDate?self.startDate:[NSDate date];
}

// TODO - not ideal, but we aren't ready to upgrade the model
// should probably add an attribute once we're ready for core data migrations
-(BOOL) hasBeenUpserted{

    // we've discovered it's possible for open calls to get saved in 'the background'
    // upserting and setting start date both happen as the view is dismissed
    // so we'll use that to determine whether we've queued the upsert

    if(self.startDate)
        return YES;
    return NO;
}

- (BOOL)activeEntry{
    return ![self isClosed];
}

@end


