//
//  AGNContact.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNAccount, AGNCall, AGNContact;

@interface AGNContact : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSString * lastName;
@property (nonatomic, retain) NSDate * mobileCreateTimestamp;
@property (nonatomic, retain) NSDate * mobileLastUpdateTimestamp;
@property (nonatomic, retain) NSString * phone;
@property (nonatomic, retain) NSString * salesForceAccountId;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * middleName;
@property (nonatomic, retain) AGNAccount *hcp;
@property (nonatomic, retain) NSSet *callContacts;
@property (nonatomic, strong) NSString *undoJSONRepresentation;
@property (nonatomic, retain) NSNumber *toBeDeletedFlag;
@property (nonatomic, retain) NSString *contactRole;
@property (nonatomic, retain) NSString *contactRoleSalesForceId;

@end

@interface AGNContact (CoreDataGeneratedAccessors)

- (void)addCallContactsObject:(NSManagedObject *)value;
- (void)removeCallContactsObject:(NSManagedObject *)value;
- (void)addCallContacts:(NSSet *)values;
- (void)removeCallContacts:(NSSet *)values;
- (NSString *)formattedNameAndRole;
- (NSAttributedString *)attributedNameAndRole;
- (NSAttributedString *)callClosureAttributedNameAndRole;
@end
