//
//  AGNAccount.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNAddress, AGNCall, AGNContact, AGNLicense, AGNHCPRating;

@interface AGNAccount : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * amdmPhysicianId;
@property (nonatomic, retain) NSNumber * doNotMail;
@property (nonatomic, retain) NSString * email1;
@property (nonatomic, retain) NSString * email2;
@property (nonatomic, retain) NSString * email3;
@property (nonatomic, retain) NSString * fax;
@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * lastName;
@property (nonatomic, retain) NSString * mdmId;
@property (nonatomic, retain) NSString * middleName;
@property (nonatomic, retain) NSString * mobilePhone;
@property (nonatomic, retain) NSString * nameSuffix;
@property (nonatomic, retain) NSString * phone;
@property (nonatomic, retain) NSString * physicianStatus;
@property (nonatomic, retain) NSString * primarySpecialty;
@property (nonatomic, retain) NSString * professionalDesignation;
@property (nonatomic, retain) NSString * recordType;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSNumber * sort_frequency;
@property (nonatomic, retain) NSString * sort_rating;
@property (nonatomic, retain) NSSet *addresses;
@property (nonatomic, retain) NSSet *calls;
@property (nonatomic, retain) NSSet *contacts;
@property (nonatomic, retain) NSSet *licenses;
@property (nonatomic, retain) NSSet *blacklists;
@property (nonatomic, retain) NSSet *ratings;
@property (nonatomic, retain) NSSet *forms;

@property (nonatomic, strong) NSString *undoJSONRepresentation;


- (AGNAddress *)primaryAddress;
- (NSString *)formattedName;
- (NSString *)doctorNameAndDesignation;
- (NSMutableAttributedString *)attributedDoctorNameAndDesignation;
- (NSMutableAttributedString *)attributedDoctorNameDesignationAndSpecialty;
- (NSAttributedString *)callClosureDoctorNameAndDesignation;

-(AGNLicense *)samplingLicenseForAddress:(AGNAddress *) address;
- (BOOL) canSampleAtAddress:(AGNAddress *) address;
- (NSSet *) blacklistProducts;
- (BOOL) addEmailIfPossible:(NSString*) email;
- (NSString *)defaultEmailAddress;

- (NSArray *)visibleAddresses;
- (NSMutableSet *)liveContacts;
- (NSDictionary *)ratingsToDisplay;

- (NSAttributedString *)attributedPhone:(NSString *)phone withLabel:(NSString *)label;
- (NSAttributedString  *)attributedPhone;
- (NSAttributedString  *)attributedFax;
-  (NSAttributedString  *)attributedMobile;

@end

@interface AGNAccount (CoreDataGeneratedAccessors)

- (void)addAddressesObject:(AGNAddress *)value;
- (void)removeAddressesObject:(AGNAddress *)value;
- (void)addAddresses:(NSSet *)values;
- (void)removeAddresses:(NSSet *)values;

- (void)addCallsObject:(AGNCall *)value;
- (void)removeCallsObject:(AGNCall *)value;
- (void)addCalls:(NSSet *)values;
- (void)removeCalls:(NSSet *)values;

- (void)addContactsObject:(AGNContact *)value;
- (void)removeContactsObject:(AGNContact *)value;
- (void)addContacts:(NSSet *)values;
- (void)removeContacts:(NSSet *)values;

- (void)addLicensesObject:(AGNLicense *)value;
- (void)removeLicensesObject:(AGNLicense *)value;
- (void)addLicenses:(NSSet *)values;
- (void)removeLicenses:(NSSet *)values;

- (void)addBlacklistsObject:(NSManagedObject *)value;
- (void)removeBlacklistsObject:(NSManagedObject *)value;
- (void)addBlacklists:(NSSet *)values;
- (void)removeBlacklists:(NSSet *)values;

- (void)addRatingsObject:(AGNHCPRating *)value;
- (void)removeRatingsObject:(AGNHCPRating *)value;
- (void)addRatings:(NSSet *)values;
- (void)removeRatings:(NSSet *)values;

- (NSString *)jsonRepresentationForUpdate;
- (AGNHCPRating *)ratingForCurrentUser;
- (AGNHCPRating *)ratingForSalesTeam:(NSString *)salesForceSalesTeamId;

- (NSAttributedString *)nameAddressLabel:(AGNAddress *)address;
- (NSAttributedString *)licenseLabel:(AGNAddress *)address;


@end
