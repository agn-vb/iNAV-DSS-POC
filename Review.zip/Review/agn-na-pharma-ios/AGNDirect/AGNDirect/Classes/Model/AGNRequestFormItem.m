//
//  AGNRequestFormItem.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/3/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNRequestFormItem.h"
#import "AGNRequestForm.h"


@implementation AGNRequestFormItem

@dynamic ordinal;
@dynamic question;
@dynamic form;

@dynamic productName;


-(NSString*)displayedQuestion{
    NSString * string =  [self.question stringByReplacingOccurrencesOfString:@"\n" withString:@" "];
    string = [string stringByReplacingOccurrencesOfString:@"\r\n" withString:@" "];
    while([string rangeOfString:@"  "].location!=NSNotFound){
        string = [string stringByReplacingOccurrencesOfString:@"  " withString:@" "];
    }
    return string;
}

-(NSString *)description    {
    return [NSString stringWithFormat:@"%@ %@ %@",self.ordinal,self.productName,self.question];
}

@end
