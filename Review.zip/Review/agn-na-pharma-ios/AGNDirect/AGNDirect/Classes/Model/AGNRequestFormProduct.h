//
//  AGNRequestFormProduct.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/3/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNRequestFormItem;

@interface AGNRequestFormProduct : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * productDescription;
@property (nonatomic, retain) AGNRequestFormItem *formItems;

@end
