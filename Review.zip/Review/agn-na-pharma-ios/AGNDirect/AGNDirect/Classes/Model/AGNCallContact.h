//
//  AGNCallContact.h
//  AGNDirect
//
//  Created by Mark Wells on 10/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNCall, AGNContact;

@interface AGNCallContact : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * callSalesForceId;
@property (nonatomic, retain) NSString * contactSalesForceId;

@property (nonatomic, retain) NSDate * mobileCreateTimestamp;
@property (nonatomic, retain) NSDate * mobileLastUpdateTimestamp;

@property (nonatomic, retain) NSString * stampFirstName;
@property (nonatomic, retain) NSString * stampLastName;
@property (nonatomic, retain) NSString * stampMiddleName;
@property (nonatomic, retain) NSString * stampPhone;
@property (nonatomic, retain) NSString * stampEmail;
@property (nonatomic, retain) NSString * stampProfessionalRole;

@property (nonatomic, retain) AGNCall *call;
@property (nonatomic, retain) AGNContact *contact;

- (void)stampComplianceFields;
- (NSString *)formattedStampedNameAndRole;

@end
