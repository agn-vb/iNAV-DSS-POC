//
//  AGNCallSignature.m
//  AGNDirect
//
//  Created by Mark Wells on 10/17/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCallSignature.h"


@implementation AGNCallSignature

@dynamic base64EncodedImage;
@dynamic callSalesForceId;
@dynamic guid;


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

// AGNCallSignature is an up-sync only container object. 
+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    return NO;
}

- (void)initWithDictionary:(NSDictionary *)dict {
    // Not applicable
}

// Note: this simply returns the Base64 encoded image, since the apex wrapper is not expecting JSON
- (NSString *)jsonRepresentationForUpdate {
    return self.base64EncodedImage;
}

@end
