//
//  AGNContactRole.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNContactRole.h"
#import "AGNContact.h"


@implementation AGNContactRole

@dynamic roleName;

@end
