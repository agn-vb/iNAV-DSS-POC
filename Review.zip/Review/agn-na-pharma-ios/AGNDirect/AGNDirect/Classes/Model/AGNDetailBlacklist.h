//
//  AGNDetailBlacklist.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNAccount, AGNProductBrand;

@interface AGNDetailBlacklist : NSManagedObject  <AGNModelProtocol>


@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * salesForceAccountId;
@property (nonatomic, retain) NSString * salesForceProductId;
@property (nonatomic, retain) AGNProductBrand *product;
@property (nonatomic, retain) AGNAccount *account;

@end
