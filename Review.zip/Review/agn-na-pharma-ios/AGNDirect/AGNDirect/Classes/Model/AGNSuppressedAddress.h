//
//  AGNSuppressedAddress.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/11/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNAccount, AGNAddress, AGNSalesRep;

@interface AGNSuppressedAddress : NSManagedObject

@property (nonatomic, retain) NSString * salesForceAddressId;
@property (nonatomic, retain) NSString * salesForceSalesRepId;
@property (nonatomic, retain) NSString * salesForceHCPId;
@property (nonatomic, retain) AGNSalesRep *salesRep;

@end
