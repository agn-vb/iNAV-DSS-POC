//
//  AGNRequestForm.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/24/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNHCPActivity.h"
#import "AGNRSS.h"

@class AGNAccount, AGNAddress, AGNProductBrand, AGNSalesRep;

extern NSString * const kAGNRequestFormTypeMIR;
extern NSString * const kAGNRequestFormTypeODR;

extern NSString * const kAGNRequestFormTitleMIR;
extern NSString * const kAGNRequestFormTitleODR;


extern NSString * const kAGNRequestFormStatusNew;
extern NSString * const kAGNRequestFormStatusOpen;

extern NSString * const kAGNRequestFormDeliveryMethodEmail;
extern NSString * const kAGNRequestFormDeliveryMethodMail;
extern NSString * const kAGNRequestFormDeliveryMethodFax;
extern NSString * const kAGNRequestFormDeliveryMethodPhone;

@interface AGNRequestForm : AGNHCPActivity <AGNModelProtocol>

@property (nonatomic, retain) NSString * salesForceRSSId;
@property (nonatomic, retain) NSString * assignedTo;
@property (nonatomic, retain) NSString * status;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * fax;
@property (nonatomic, retain) NSString * phone;
@property (nonatomic, retain) NSString * odrReason;
@property (nonatomic, retain) NSString * deliveryMethod;
@property (nonatomic, retain) NSDate * closeDate;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSMutableSet *items;
@property (nonatomic, retain) AGNRSS *rss;

@property (nonatomic, retain) NSString * stampRssName;


@property (nonatomic, strong) NSString *undoJSONRepresentation; //transient
@property (nonatomic, strong) NSString * signatureJSON; //transient

// assigned_to if exists else stampRSSName else rss.name
@property (nonatomic,readonly) NSString *rssName;

-(BOOL)hasNewStatus;
-(AGNRequestFormItem *)itemForOrdinal:(int)index;


- (NSString*)statusString;
- (NSString*)formTitle;
- (BOOL)isMIR;
- (BOOL)isODR;

- (NSAttributedString *)formattedTypeAndStatus;
- (NSString *)formattedRepName;
- (void)stampComplianceFields;

- (NSAttributedString *)nameAddressLabel;
- (NSString *)singleLineFormattedAddressString;
- (NSString *)professionalDesignation;
- (NSMutableAttributedString *)attributedDoctorNameDesignationAndSpecialty;
- (NSString *)doctorNameAndDesignation;

@end
