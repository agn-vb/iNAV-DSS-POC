//
//  AGNProductBrand.h
//  AGNDirect
//
//  Created by Mark Wells on 9/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNDetailBlacklist, AGNDetailPosition;

@interface AGNProductBrand : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * manufacturer;
@property (nonatomic, retain) NSString * productDescription;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSSet *blacklists;
@property (nonatomic, retain) NSSet *detailPositions;
@end

@interface AGNProductBrand (CoreDataGeneratedAccessors)

- (void)addBlacklistsObject:(AGNDetailBlacklist *)value;
- (void)removeBlacklistsObject:(AGNDetailBlacklist *)value;
- (void)addBlacklists:(NSSet *)values;
- (void)removeBlacklists:(NSSet *)values;

- (void)addDetailPositionsObject:(AGNDetailPosition *)value;
- (void)removeDetailPositionsObject:(AGNDetailPosition *)value;
- (void)addDetailPositions:(NSSet *)values;
- (void)removeDetailPositions:(NSSet *)values;

@end
