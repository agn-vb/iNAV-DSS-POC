//
//  AGNSalesRep.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


#import "AGNSalesRep.h"
#import "AGNCall.h"
#import "AGNDetailPosition.h"
#import "AGNSampleInventoryLine.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNSamplePermission.h"
#import "AGNStorageUnit.h"
#import "AGNTimeOffTerritory.h"
#import "AGNSuppressedAddress.h"

//AGN_LOG_LEVEL(AGNSalesRep, DEBUG_INT)

@implementation AGNSalesRep

static NSDictionary *fieldMapping = nil;


@dynamic firstName;
@dynamic lastName;
@dynamic salesForceId;
@dynamic sample;
@dynamic salesForceSalesTeamId;
@dynamic salesTeamName;
@dynamic alias;
@dynamic communityNickname;
@dynamic email;
@dynamic middleName;
@dynamic samplingStatus;
@dynamic status;
@dynamic territoryId;
@dynamic territoryName;
@dynamic username;
@dynamic businessUnit;
@dynamic managerName;
@dynamic calls;
@dynamic detailPositions;
@dynamic sampleInventoryLines;
@dynamic samplePermissions;
@dynamic storageUnit;
@dynamic timeOffTerritory;
@dynamic transactionsFrom;
@dynamic transactionsTo;
@dynamic suppressedAddresses;
@dynamic serverTimeZone;

@synthesize userTimeZone=_userTimeZone;


+(void)initialize{
    fieldMapping =
    @{
    @"Id"         : @"salesForceId",
    @"FirstName" : @"firstName",
    @"LastName" :@"lastName",
    @"Email":@"email",
    @"Alias":@"alias",
    @"Username":@"username",
    @"CommunityNickname":@"communityNickname",
    @"salesTeamId":@"salesForceSalesTeamId",
    @"salesTeamName":@"salesTeamName",
    @"Business_Unit__c":@"businessUnit",
    @"Sampling_Status__c":@"samplingStatus",
    @"TimeZoneSidKey":@"serverTimeZone"
    
    };
}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}


- (void)initWithDictionary:(NSDictionary *)dict {
    for(NSString *key in dict){
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            log4Trace(@"Setting %@ on SalesRep to %@",objectKey,dict[key]);
            id value = [dict[key] isEqual:[NSNull null]]?nil:dict[key];
            [self setValue:value forKey:objectKey];
        }
        if ([key isEqualToString:@"Sampling_Status__c"]) {
            id value = [dict[key] isEqual:[NSNull null]]?nil:dict[key];

            self.sample = [NSNumber numberWithBool:[value isEqualToString:@"Eligible"]];
        }
    }
    NSDictionary *userDataDict = [dict objectForKey:@"userData"];
    for (NSString *key in userDataDict){
        if ([key isEqualToString:@"Manager"]) {
            NSDictionary *managerDict = userDataDict[key];
            if (managerDict) {
                self.managerName = [managerDict objectForKey:@"Name"];
            }
            else {
                log4Info(@"No manager set for current user");
            }
        }
        if ([key isEqualToString:@"Sampling_Status__c"]) {
            id value = [userDataDict[key] isEqual:[NSNull null]]?nil:userDataDict[key] ;

            self.sample = [NSNumber numberWithBool:[value isEqualToString:@"Eligible"]];
        }
        if([key isEqualToString:@"TimeZoneSidKey"]){
            self.serverTimeZone=[userDataDict[key] isEqual:[NSNull null]]?nil:userDataDict[key];
            // update cached value in case it changed
            self.userTimeZone = [self timeZone];
            log4Info(@"Setting user timezone to %@",self.userTimeZone);

        }
      
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            log4Trace(@"Setting %@ on SalesRep to %@",objectKey,userDataDict[key]);
            id value = [userDataDict[key] isEqual:[NSNull null]]?nil:userDataDict[key] ;

            [self setValue:value forKey:objectKey];
        }
        
        
    }
    if(self.salesForceId){
        [[AGNAppDelegate sharedDelegate].syncManager.sync registerSalesRep:self];
    }else{
        log4Error(@"No sales force id found on sales rep data %@",userDataDict);
    }
}

-(NSTimeZone *)timeZone{
    if(self.serverTimeZone){
        return [NSTimeZone timeZoneWithName:self.serverTimeZone];
    }
    return nil;
}

// cache it so we don't create every time we need to use
-(NSTimeZone *)userTimeZone{
    if(!_userTimeZone){
        _userTimeZone = [self timeZone];
    }
    return _userTimeZone;
}


-(BOOL) canSample {
    if(self.sample!=nil && [self.sample boolValue])
        return YES;
    return NO;
}

- (NSString *)formattedName {
    
    NSString *repName = self.lastName ? [self.lastName uppercaseString] : @"UNKNOWN";
    if (self.firstName) {
        repName = [repName stringByAppendingFormat:@", %@", [self.firstName uppercaseString]];
    }
    
    return repName;
}

- (BOOL) hasSuppressedAddress:(AGNAddress *)address{
    for(AGNSuppressedAddress *suppress in self.suppressedAddresses){
        if([suppress.salesForceAddressId isEqualToString:address.salesForceId])
            return YES;
    }
    return NO;
}


@end
