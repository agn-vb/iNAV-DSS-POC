//
//  AGNSamplePermission.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNProductSKU;

@interface AGNSamplePermission : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * salesForceProductId;
@property (nonatomic, retain) NSString * salesForceSalesTeamId;
@property (nonatomic, retain) NSString * salesForceSalesRepId;
@property (nonatomic, retain) AGNProductSKU *product;
@property (nonatomic, retain) AGNSalesRep *salesRep;

@end
