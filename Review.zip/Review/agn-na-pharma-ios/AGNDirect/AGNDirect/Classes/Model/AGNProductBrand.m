//
//  AGNProductBrand.m
//  AGNDirect
//
//  Created by Mark Wells on 9/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNProductBrand.h"
#import "AGNDetailBlacklist.h"
#import "AGNDetailPosition.h"
#import "AGNAppDelegate.h"

static NSDictionary *fieldMapping = nil;

@implementation AGNProductBrand

@dynamic manufacturer;
@dynamic productDescription;
@dynamic salesForceId;
@dynamic blacklists;
@dynamic detailPositions;


+(void)initialize {
    fieldMapping =
    @{
    @"Id"                       : @"salesForceId",
    @"Product_Description__c"       : @"productDescription",
    @"Manufacturer__c"       : @"manufacturer"
    };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}
- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if(!objectDict)
        objectDict=dict;
    for(NSString *key in objectDict){
        
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on product brand to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on product brand to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerProductBrand:self];
}

@end
