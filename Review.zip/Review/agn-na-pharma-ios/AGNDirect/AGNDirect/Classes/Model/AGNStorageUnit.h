//
//  AGNStorageUnit.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNSalesRep, AGNSampleInventoryLine, AGNSampleInventoryTransaction;

@interface AGNStorageUnit : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSNumber * salesForceId;
@property (nonatomic, retain) NSString * unit;
@property (nonatomic, retain) NSManagedObject *salesRep;
@property (nonatomic, retain) AGNSampleInventoryLine *sampleInventoryLines;
@property (nonatomic, retain) AGNSampleInventoryTransaction *sampleInventoryTransactions;

@end

@interface AGNStorageUnit (CoreDataGeneratedAccessors)

- (void)addSampleInventoryLinesObject:(AGNSampleInventoryLine *)value;
- (void)removeSampleInventoryLinesObject:(AGNSampleInventoryLine *)value;
- (void)addSampleInventoryLines:(NSSet *)values;
- (void)removeSampleInventoryLines:(NSSet *)values;

- (void)addSampleInventoryTransactionsObject:(AGNSampleInventoryTransaction *)value;
- (void)removeSampleInventoryTransactionsObject:(AGNSampleInventoryTransaction *)value;
- (void)addSampleInventoryTransactions:(NSSet *)values;
- (void)removeSampleInventoryTransactions:(NSSet *)values;

@end
