//
//  AGNTimeOffTerritory.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTimeOffTerritory.h"
#import "AGNSalesRep.h"
#import "AGNCategoryHeaders.h"



@implementation AGNTimeOffTerritory

static NSDictionary *fieldMapping = nil;


@dynamic activityType;
@dynamic allDay;
@dynamic comments;
@dynamic endDate;
@dynamic salesForceId;
@dynamic startDate;
@dynamic salesRep;

+(void)initialize{
    fieldMapping =
    @{
    @"Id"         : @"salesForceId",
    @"AllDay" : @"allDay",
    @"Comments" :@"comments",
    @"Activity_Type__c":@"activityType",
    @"Rep__c":@"salesForceRepId" 
    
    };
}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}


- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = dict;
    for(NSString *key in objectDict){
        if([key isEqualToString:@"Start_Date__c"]) {
            if(objectDict[key]!=[NSNull null])
                [self setStartDateFromDictionary:objectDict];
        }
        else if([key isEqualToString:@"End_Date__c"]) {
            if(objectDict[key]!=[NSNull null])
                [self setEndDateFromDictionary:objectDict];
        }

        else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on TOT to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on TOT to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }

}

-(void)setStartDateFromDictionary:(NSDictionary *)objectDict {
    NSString *startDateString = objectDict[@"Start_Date__c"];
    NSString *startTimeString = objectDict[@"Start_Time__c"];
    if(!startTimeString){
        startTimeString = [self defaultStartTime];
        self.allDay=@1;
    }
    self.startDate = [NSDate agnUTCDateFromDateString:startDateString andTimeString:startTimeString];
    if(!self.startDate){
        log4Warn(@"Unable to parse start date for TOT %@", objectDict);
    }
}

-(NSString *)defaultStartTime {
    return @"12:00 AM";
}

-(NSString *)defaultEndTime {
    return @"11:59 PM";
}

-(void)setEndDateFromDictionary:(NSDictionary *)objectDict {
    NSString *endDateString = objectDict[@"End_Date__c"];
    NSString *endTimeString = objectDict[@"End_Time__c"];
    if(!endTimeString){
        endTimeString = [self defaultEndTime];
        self.allDay=@1;
    }
    self.endDate = [NSDate agnUTCDateFromDateString:endDateString andTimeString:endTimeString];
    if(!self.endDate){
        log4Warn(@"Unable to parse end date for TOT %@", objectDict);
    }
}

- (BOOL)activeEntry{
    if ([self.startDate compare:[NSDate date]] == NSOrderedAscending) // if in the past, it's inactive
        return NO;
    else
        return YES;
}


@end
