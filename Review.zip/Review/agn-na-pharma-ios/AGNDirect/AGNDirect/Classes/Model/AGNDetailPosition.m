//
//  AGNDetailPosition.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNDetailPosition.h"
#import "AGNCallDetail.h"
#import "AGNSalesRep.h"
#import "AGNCategoryHeaders.h"

@implementation AGNDetailPosition

static NSDictionary *fieldMapping = nil;


@dynamic detailTopic;
@dynamic effectiveDate;
@dynamic endDate;
@dynamic position;
@dynamic salesForceId;
@dynamic salesForceProductId;
@dynamic displayName;
@dynamic callDetails;
@dynamic salesRep;
@dynamic product;

+ (void)initialize{
    fieldMapping =
    @{
    @"Id"  : @"salesForceId",
    @"Detail_Topic__c" : @"detailTopic",
    @"Effective_Date__c" : @"effectiveDate",
    @"End_Date__c" : @"endDate",
    @"Position__c" : @"position",
    @"Product_Brand__c":@"salesForceProductId",
    @"Name":@"displayName"
    };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    for(NSString *key in objectDict){
        if([key isEqualToString:@"Effective_Date__c"]) {
            if(objectDict[key]!=[NSNull null])
                self.effectiveDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else if([key isEqualToString:@"End_Date__c"]) {
            if(objectDict[key]!=[NSNull null])
               self.endDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else if([key isEqualToString:@"Position__c"]) {
            if(objectDict[key]!=[NSNull null])
               self.position = [NSNumber numberWithInt:[(NSString *)objectDict[key] integerValue]];
        }
        else {
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on detail position to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on detail position to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerDetailPosition:self];
}

-(NSString *)productDescription{
    return self.product.productDescription;
}

-(NSString *)displayString {
    return self.displayName;
//    return [NSString stringWithFormat:@"%@ - %@",self.position ,[self.product productDescription] ];
}


-(BOOL)isValidForDate:(NSDate *)callDate{

    if([self.effectiveDate compare:callDate]==NSOrderedDescending)
        return NO;

    if([callDate compare:self.endDate]==NSOrderedDescending)
        return NO;

    return YES;
}


@end
