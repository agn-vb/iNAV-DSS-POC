//
//  AGNAddress.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAddress.h"
#import "AGNAccount.h"
#import "AGNCall.h"
#import "AGNHCPDayAvailability.h"
#import "AGNAppDelegate.h"


@implementation AGNAddress

static NSDictionary *fieldMapping = nil;

@dynamic active;
@dynamic city;
@dynamic deaNumber;
@dynamic faxPhone;
@dynamic guid;
@dynamic line1;
@dynamic line2;
@dynamic line3;
@dynamic addressType;
@dynamic mobileCreateTimestamp;
@dynamic mobileLastUpdateTimestamp;
@dynamic mobilePhone;
@dynamic officePhone;
@dynamic primary;
@dynamic salesForceAccountId;
@dynamic salesForceId;
@dynamic usState;
@dynamic zip;
@dynamic account;
@dynamic calls;
@dynamic mondayOpenTime;
@dynamic mondayCloseTime;
@dynamic tuesdayOpenTime;
@dynamic tuesdayCloseTime;
@dynamic wednesdayOpenTime;
@dynamic wednesdayCloseTime;
@dynamic thursdayOpenTime;
@dynamic thursdayCloseTime;
@dynamic fridayOpenTime;
@dynamic fridayCloseTime;

@synthesize availabilityManager=_availabilityManager;
@synthesize undoJSONRepresentation=_undoJSONRepresentation;
@synthesize notSynced=_notSynced;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"Address_Type__c" : @"addressType",
    @"Address_Line_1__c" : @"line1",
    @"Address_Line_2__c" : @"line2",
    @"Address_Line_3__c" : @"line3",
    @"City__c" : @"city",
    @"DEA_Number__c" : @"deaNumber",
    @"State__c" : @"usState",
    @"Zip_Code__c" : @"zip",
    @"Office_Phone__c" : @"officePhone",
    @"Mobile_Phone__c" : @"mobilePhone",
    @"Fax__c" : @"faxPhone",
    @"GUID__c" : @"guid",
    @"HCA_HCP__c" : @"salesForceAccountId",
    @"Monday_Start_Time__c": @"mondayOpenTime",
    @"Monday_End_Time__c": @"mondayCloseTime",
    @"Tuesday_Start_Time__c": @"tuesdayOpenTime",
    @"Tuesday_End_Time__c": @"tuesdayCloseTime",
    @"Wednesday_Start_Time__c": @"wednesdayOpenTime",
    @"Wednesday_End_Time__c": @"wednesdayCloseTime",
    @"Thursday_Start_Time__c": @"thursdayOpenTime",
    @"Thursday_End_Time__c": @"thursdayCloseTime",
    @"Friday_Start_Time__c": @"fridayOpenTime",
    @"Friday_End_Time__c": @"fridayCloseTime"
   };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;
}


-(void)clearOfficeHours{
    self.mondayOpenTime=nil;
    self.mondayCloseTime=nil;
    self.tuesdayOpenTime=nil;
    self.tuesdayCloseTime=nil;
    self.wednesdayOpenTime=nil;
    self.wednesdayCloseTime=nil;
    self.thursdayOpenTime=nil;
    self.thursdayCloseTime=nil;
    self.fridayOpenTime=nil;
    self.fridayCloseTime=nil;
}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    
    [self clearOfficeHours];
    
    for(NSString *key in objectDict){
        
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on address to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            // convert open / close times to uppercase to correctly detect changes
            else if ([key rangeOfString:@"Time__c"].location != NSNotFound) {
                NSDate *dt = [NSDate dateFromAddressAvailabilityString:objectDict[key]];
                NSString *val = [dt agnSfdcTimeComponentString];
                log4Trace(@"Setting %@ on address to %@",objectKey,val);
                [self setValue:val forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on address to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
    if ([dict objectForKey:@"isprimary"] && ![[dict objectForKey:@"isprimary"] isEqual:[NSNull null]]) {
        self.primary = [dict objectForKey:@"isprimary"];
    }

    if (self.salesForceAccountId && !self.account)
        self.account = [[AGNAppDelegate sharedDelegate].syncManager.sync accountBySFDCID:self.salesForceAccountId];
    
    // in case we're undoing, need to reset the availability manager
    self.availabilityManager = nil;

    [[AGNAppDelegate sharedDelegate].syncManager.sync registerAddress:self];
}

- (NSString *)jsonRepresentationForAvailabilityUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
        if ([key rangeOfString:@"Time__c"].location != NSNotFound) {
            if (!prop || [prop isEqual:[NSNull null]]) {
                prop = @"";
            }
            [result appendFormat:@"\"%@\": \"%@\",",key, prop];
        }
    }];
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (NSString *)jsonRepresentationForUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
        if ([key isEqualToString:@"GUID__c"] || [key isEqualToString:@"Id"]) {
            //Do not include in upsert sobject
        }
        else if ([key isEqualToString:@"Office_Phone__c"] || [key isEqualToString:@"Mobile_Phone__c"] || [key isEqualToString:@"Fax__c"]) {
            if (!prop) {
                prop = @"";
            }
            [result appendFormat:@"\"%@\": \"%@\",", key,  [((NSString *)prop) agnEscapedString]];
        }
        else {
            if (!prop || [prop isEqual:[NSNull null]]) {
                prop = @"";
            }
            if ([prop isKindOfClass:[NSString class]]) {
                [result appendFormat:@"\"%@\": \"%@\",",key, [prop agnEscapedString]];
            }
            else{
                [result appendFormat:@"\"%@\": \"%@\",",key, prop];
            }

        }
    }];
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict {
    NSString *addressId = [[jsonDict valueForKey:@"id"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"id"];
    NSNumber *success = [[jsonDict valueForKey:@"success"] isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"success"];
    if ([success boolValue]) {
        if (!self.salesForceId && addressId) {
            self.salesForceId = addressId;
        }
    }
}

- (void)setUndoRepresentation {
    self.undoJSONRepresentation = [self jsonRepresentationForUndo];
}

- (void)clearUndoRepresentation {
    self.undoJSONRepresentation = nil;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    return [self initWithDictionary:dict];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

- (NSString *)singleLineStreetString {
    NSMutableString *str = [[NSMutableString alloc] initWithString:(self.line1 ? self.line1 : @"")];
    if (self.line2.length > 0) {
        [str appendFormat:@", %@", self.line2];
    }
    if (self.line3.length > 0) {
        [str appendFormat:@", %@", self.line3];
    }
    return str;
}

- (NSString *)cityStateZipFormattedString {
    NSMutableString *str = [[NSMutableString alloc] init];
    if (self.city || self.usState || self.zip) {
        [self appendCityStateZipStringTo:str];
    }
    return str;
}

- (NSString *)singleLineFormattedString {
    NSMutableString *str = [[NSMutableString alloc] initWithString:(self.line1 ? self.line1 : @"")];
    if (self.line2.length > 0) {
        [str appendFormat:@", %@", self.line2];
    }
    if (self.line3.length > 0) {
        [str appendFormat:@", %@", self.line3];
    }
    if (self.city || self.usState || self.zip) {
        [str appendString:@", "];
        [self appendCityStateZipStringTo:str];
    }
    return str;
}

- (NSString *)doubleLineFormattedString {
    NSMutableString *str = [[NSMutableString alloc] initWithString:(self.line1 ? self.line1 : @"")];
    if (self.line2.length > 0) {
        [str appendFormat:@", %@", self.line2];
    }
    if (self.line3.length > 0) {
        [str appendFormat:@", %@", self.line3];
    }
    if (self.city || self.usState || self.zip) {
        [str appendString:@"\n"];
        [self appendCityStateZipStringTo:str];
    }
    return str;
}

- (NSString *)multiLineFormattedStringWithPhone {
    NSMutableString *str = [[NSMutableString alloc] initWithString:(self.line1 ? self.line1 : @"")];
    if (self.line2.length > 0) {
        [str appendFormat:@"\n%@", self.line2];
    }
    [str appendString:@"\n"];
    [self appendCityStateZipStringTo:str];
    if(self.officePhone.length > 0){
        [str appendFormat:@"\n%@", self.officePhone];
    }
    return str;
}

- (int)numberOfLinesInMultiLineFormattedString {
    return 2 + ((self.line2.length > 0) ? 1 : 0) + ((self.officePhone.length > 0) ? 1 : 0);
}

- (int)numberOfLinesMissingInMultiLineFormattedString {
    return 4 - [self numberOfLinesInMultiLineFormattedString];
}

- (void)appendCityStateZipStringTo:(NSMutableString *)str {
    if (self.city.length > 0) {
        [str appendFormat:@"%@, ", self.city];
    }
    if (self.usState.length > 0) {
        [str appendFormat:@"%@ ", self.usState];
    }
    if (self.zip.length > 0) {
        [str appendFormat:@"%@", self.zip];
    }
}

- (NSString *)canSampleTag {
    if([self.account canSampleAtAddress:self]){
        return @"(YES)";
    }
    return @"(NO)";
}

- (BOOL)canSample {
    return [self.account canSampleAtAddress:self];
}

- (NSString *)line1WithTag{
    return [NSString stringWithFormat:@"%@ %@",self.line1,[self canSampleTag]];
}

-(BOOL) isHidden{
    AGNSalesRep *rep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    if([rep hasSuppressedAddress:self])
        return YES;
    return NO;
}

- (AGNHCPAvailabilityManager *)availabilityManager {
    
    if (!_availabilityManager){
        _availabilityManager = [[AGNHCPAvailabilityManager alloc] initWithAddress:self];
    }
    
    return _availabilityManager;
}

-(void)resetAvailabilityManager{
    _availabilityManager = [[AGNHCPAvailabilityManager alloc] initWithAddress:self];
}

- (void)saveAvailabilityManager {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    [df setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    [df setDateFormat:@"h:mm a"];
    [df setLenient:NO];
    
    [self setUndoRepresentation];
    
    self.mondayOpenTime = [df stringFromDate:self.availabilityManager.monday.startTime];
    self.mondayCloseTime = [df stringFromDate:self.availabilityManager.monday.endTime];
    self.tuesdayOpenTime = [df stringFromDate:self.availabilityManager.tuesday.startTime];
    self.tuesdayCloseTime = [df stringFromDate:self.availabilityManager.tuesday.endTime];
    self.wednesdayOpenTime = [df stringFromDate:self.availabilityManager.wednesday.startTime];
    self.wednesdayCloseTime = [df stringFromDate:self.availabilityManager.wednesday.endTime];
    self.thursdayOpenTime = [df stringFromDate:self.availabilityManager.thursday.startTime];
    self.thursdayCloseTime = [df stringFromDate:self.availabilityManager.thursday.endTime];
    self.fridayOpenTime = [df stringFromDate:self.availabilityManager.friday.startTime];
    self.fridayCloseTime = [df stringFromDate:self.availabilityManager.friday.endTime];
}

-(NSString *)description{
    return [NSString stringWithFormat:@"Address: %@|%@, %@ (HCP: %@) ",self.salesForceId,self.guid,self.line1, self.account.salesForceId];
}

@end
