//
//  AGNODRReason.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/3/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNODRReason.h"


@implementation AGNODRReason

@dynamic label;
@dynamic value;


@end
