//
//  AGNSampleInventoryTransaction.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"


static NSString *kInboundTransferType = @"Inbound Transfer";
static NSString *kOutboundTransferType = @"Outbound Transfer";
static NSString *kReturnType = @"Returns";
static NSString *kShipmentType = @"Shipments";
static NSString *kInventoryCountType = @"Inventory Count";

static NSString *kInventoryCountSubtype = @"Interim (Rc Only)";

static NSString *kOpenStatusType = @"Open";
static NSString *kReceivedStatusType = @"Received";
static NSString *kCompleteStatusType = @"Complete";

@class AGNCall, AGNSalesRep, AGNSampleDrop, AGNSampleInventoryTransaction, AGNSampleInventoryTransactionLine, AGNStorageUnit;



@interface AGNSampleInventoryTransaction : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * acceptedBySalesForceId;
@property (nonatomic, retain) NSDate * actualReceivedDate;
@property (nonatomic, retain) NSDate * expectedReceiveDate;
@property (nonatomic, retain) NSString * fromSalesForceId;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSDate * inventoryDate;
@property (nonatomic, retain) NSDate * mobileCreateTimestamp;
@property (nonatomic, retain) NSDate * mobileLastUpdateTimestamp;
@property (nonatomic, retain) NSString * returnTo;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * salesTeamId;
@property (nonatomic, retain) NSDate * sfdcCreatedDate;
@property (nonatomic, retain) NSDate * shipmentDate;
@property (nonatomic, retain) NSString * shipmentId;
@property (nonatomic, retain) NSString * status;
@property (nonatomic, retain) NSString * territoryName;
@property (nonatomic, retain) NSString * toSalesForceId;
@property (nonatomic, retain) NSString * trackingNumber;
@property (nonatomic, retain) NSString * trackingReason;
@property (nonatomic, retain) NSString * transactionType;
@property (nonatomic, retain) NSString * transactionSubtype;
@property (nonatomic, retain) NSString * transferAuthorizationNumber;
@property (nonatomic, retain) NSDate * returnDate;

@property (nonatomic, retain) AGNSalesRep *from;
@property (nonatomic, retain) AGNSalesRep *acceptedBy;
@property (nonatomic, retain) NSSet *sampleInventoryTransactionLines;
@property (nonatomic, retain) AGNSalesRep *to;

@property (nonatomic, strong) NSString *undoJSONRepresentation;
@property (nonatomic, assign) BOOL deleteOnRevert;

- (BOOL) isOutboundTransfer;
- (BOOL) isInboundTransfer;
- (BOOL) isReturn;
- (BOOL) isIncomingShipment;
- (BOOL) isDraft;
- (NSString *)toRepDisplayString;
- (NSString *)fromRepDisplayString;
- (BOOL)isOpen;
- (NSDate *)createdDate;
- (void)deleteDraft;

@end

@interface AGNSampleInventoryTransaction (CoreDataGeneratedAccessors)

- (void)addSampleDropsObject:(AGNSampleDrop *)value;
- (void)removeSampleDropsObject:(AGNSampleDrop *)value;
- (void)addSampleDrops:(NSSet *)values;
- (void)removeSampleDrops:(NSSet *)values;

- (void)addSampleInventoryTransactionLinesObject:(AGNSampleInventoryTransactionLine *)value;
- (void)removeSampleInventoryTransactionLinesObject:(AGNSampleInventoryTransactionLine *)value;
- (void)addSampleInventoryTransactionLines:(NSSet *)values;
- (void)removeSampleInventoryTransactionLines:(NSSet *)values;

@end
