//
//  AGNTimeOffTerritory.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"
#import "AGNScheduleEntry.h"

@interface AGNTimeOffTerritory : AGNScheduleEntry <AGNModelProtocol>

@property (nonatomic, retain) NSString * activityType;
@property (nonatomic, retain) NSNumber * allDay;
@property (nonatomic, retain) NSString * comments;
@property (nonatomic, retain) NSDate * endDate;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSDate * startDate;
@property (nonatomic, retain) AGNSalesRep *salesRep;

@end
