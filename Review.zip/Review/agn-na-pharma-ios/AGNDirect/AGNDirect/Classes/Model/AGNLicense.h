//
//  AGNLicense.h
//  AGNDirect
//
//  Created by Mark Wells on 8/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNAccount;

@interface AGNLicense : NSManagedObject  <AGNModelProtocol>

@property (nonatomic, retain) NSNumber * active;
@property (nonatomic, retain) NSNumber * canSample;
@property (nonatomic, retain) NSDate * expirationDate;
@property (nonatomic, retain) NSString * licenseNumber;
@property (nonatomic, retain) NSString * salesForceAccountId;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * usState;
@property (nonatomic, retain) AGNAccount *account;
-(BOOL) isValid;
-(BOOL) permitsSampling;
@end
