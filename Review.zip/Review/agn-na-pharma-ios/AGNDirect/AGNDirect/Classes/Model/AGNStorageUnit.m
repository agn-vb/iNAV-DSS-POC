//
//  AGNStorageUnit.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNStorageUnit.h"
#import "AGNSampleInventoryLine.h"
#import "AGNSampleInventoryTransaction.h"


@implementation AGNStorageUnit

@dynamic name;
@dynamic salesForceId;
@dynamic unit;
@dynamic salesRep;
@dynamic sampleInventoryLines;
@dynamic sampleInventoryTransactions;

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    return YES;
}


- (void)initWithDictionary:(NSDictionary *)dict {
    
}

@end
