//
//  AGNSampleInventoryTransactionLine.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSampleInventoryTransactionLine.h"
#import "AGNProductSKU.h"
#import "AGNSampleInventoryLine.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNSampleInventoryTransactionLine.h"
#import "NSManagedObjectContext+DDSFExtensions.h"


@interface AGNSampleInventoryTransactionLine (PrimitiveAccessors)
- (void)setPrimitiveProduct:(AGNProductSKU *)newProduct;
- (void)setPrimitiveSampleInventoryTransaction: (AGNSampleInventoryTransaction *)newSIT;
- (void)setPrimitiveSampleInventoryLine: (AGNSampleInventoryLine *)newSIL;
@end

@implementation AGNSampleInventoryTransactionLine

static NSDictionary *fieldMapping = nil;


@dynamic actualQuantity;
@dynamic availableQuantity;
@dynamic expectedQuantity;
@dynamic expirationDate;
@dynamic guid;
@dynamic isAccepted;
@dynamic itemCode;
@dynamic lotNumber;
@dynamic mobileCreateTimestamp;
@dynamic mobileLastUpdateTimestamp;
@dynamic salesForceId;
@dynamic productSalesForceId;
@dynamic sampleInventoryLineSalesForceId;
@dynamic sampleInventoryTransactionSalesForceId;
@dynamic product;
@dynamic productCode;
@dynamic productDescription;
@dynamic sampleInventoryLine;
@dynamic sampleInventoryTransaction;
@dynamic shipmentDate;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+ (void)initialize {
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"Accepted" : @"isAccepted",
    @"Actual_Quantity_Received" : @"actualQuantity",
    @"Available_quantity" : @"availableQuantity",
    @"Expected_Quantity" :@"expectedQuantity",
    @"Expiration_Date": @"expirationDate",
    @"GUID" : @"guid",
    @"Lot_Number" : @"lotNumber",
    @"MobileCreatedDate" : @"mobileCreateTimestamp",
    @"MobileLastModifiedDate" : @"mobileLastUpdateTimestamp",
    @"Item_Code" : @"itemCode",
    @"Product_SKU":@"productSalesForceId",
    @"Product_Code" : @"productCode",
    @"Product_Description" : @"productDescription",
    @"Sample_Inventory_Line":@"sampleInventoryLineSalesForceId",
    @"SampleInventoryTransaction":@"sampleInventoryTransactionSalesForceId"
    };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Custom Accessors/Modifiers
//------------------------------------------------------------------------------

- (void)setProduct:(AGNProductSKU *)newProductSKU {
    [self willChangeValueForKey:@"product"];
    [self setPrimitiveProduct:newProductSKU];
    if (newProductSKU) {
        self.productSalesForceId = newProductSKU.salesForceId;
    }
    [self didChangeValueForKey:@"product"];
}

- (void)setSampleInventoryTransaction:(AGNSampleInventoryTransaction *)newSIT {
    [self willChangeValueForKey:@"sampleInventoryTransaction"];
    [self setPrimitiveSampleInventoryTransaction:newSIT];
    if (newSIT) {
        self.sampleInventoryTransactionSalesForceId = newSIT.salesForceId;
    }
    [self didChangeValueForKey:@"sampleInventoryTransaction"];
}

- (void)setSampleInventoryLine:(AGNSampleInventoryLine *)newSIL {
    [self willChangeValueForKey:@"sampleInventoryLine"];
    [self setPrimitiveSampleInventoryLine:newSIL];
    if (newSIL) {
        self.sampleInventoryLineSalesForceId = newSIL.salesForceId;
    }
    [self didChangeValueForKey:@"sampleInventoryLine"];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------
   
+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = [dict copy]; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    self.actualQuantity = nil;
    self.expectedQuantity = nil;
    self.availableQuantity = nil;
    for(NSString *key in objectDict){
        NSString *objectKey = fieldMapping[key];
        if([key isEqualToString:@"Expiration_Date"]) {
            self.expirationDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else if([key isEqualToString:@"Actual_Quantity_Received"]) {
            if(dict[key]!=[NSNull null])
                self.actualQuantity = [objectDict[key] isEqual:[NSNull null]]?nil:[NSNumber numberWithInt:[(NSString *)objectDict[key] integerValue]];
        }
        else if([key isEqualToString:@"Expected_Quantity"]) {
            if(dict[key]!=[NSNull null])
                self.expectedQuantity = [objectDict[key] isEqual:[NSNull null]]?nil:[NSNumber numberWithInt:[(NSString *)objectDict[key] integerValue]];
        }
        else if([key isEqualToString:@"Available_quantity"]) {
            if(dict[key]!=[NSNull null])
                self.availableQuantity = [objectDict[key] isEqual:[NSNull null]]?nil:[NSNumber numberWithInt:[(NSString *)objectDict[key] integerValue]];
        }
        else if([key isEqualToString:@"MobileLastModifiedDate"]) {
            self.mobileLastUpdateTimestamp = [NSDate agnDateFromRFC3339TimestampString:objectDict[key]];
        }
        else if([key isEqualToString:@"MobileCreatedDate"]) {
            self.mobileCreateTimestamp = [NSDate agnDateFromRFC3339TimestampString:objectDict[key]];
        }
        else if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on SITL to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on SITL to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
    [self buildRelationships];
}

- (void)buildRelationships {
    if (self.productSalesForceId && !self.product) {
        self.product = (AGNProductSKU *)[self.managedObjectContext ddsf_objectOfType:@"AGNProductSKU" forId:self.productSalesForceId];
    }
    if (self.sampleInventoryLineSalesForceId && !self.sampleInventoryLine) {
        self.sampleInventoryLine = (AGNSampleInventoryLine *)[self.managedObjectContext ddsf_objectOfType:@"AGNSampleInventoryLine" forId:self.sampleInventoryLineSalesForceId];
    }
    if (self.sampleInventoryTransactionSalesForceId && !self.sampleInventoryTransaction) {
        self.sampleInventoryTransaction = (AGNSampleInventoryTransaction *)[self.managedObjectContext ddsf_objectOfType:@"AGNSampleInventoryTransaction" forId:self.sampleInventoryTransactionSalesForceId];
    }


    if (!self.product)
        log4Warn(@"Missing product on SITL %@ after sync, productId = %@", self.salesForceId, self.productSalesForceId);

}
 
- (NSString *)jsonRepresentationForUpdate {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
        if ([((NSString *)value) isEqualToString:@"itemCode"]) {
            //This is calculated in the wrapper - do not send
        }
        else if ([((NSString *)value) isEqualToString:@"isAccepted"]) {
            prop = [((NSNumber *)prop) boolValue] ? @"true" : @"false";
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else if ([((NSString *)value) isEqualToString:@"mobileLastUpdateTimestamp"]) {
            if (self.mobileLastUpdateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileLastModifiedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"mobileCreateTimestamp"]) {
            if (self.mobileCreateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileCreatedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if ([prop isKindOfClass:[NSNumber class]]) {
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else {
            if ([((NSString *)value) isEqualToString:@"expirationDate"]) {
                prop = [((NSDate *)prop) agnStringFromDate];
            }
            else if ([prop isKindOfClass:[NSDate class]]) {
                prop = [df stringFromDate:prop];
            }
            if (prop) {
                if ([prop isKindOfClass:[NSString class]]) {
                    [result appendFormat:@"\"%@\": \"%@\",",key, [prop agnEscapedString]];
                }
                else{
                    [result appendFormat:@"\"%@\": \"%@\",",key, prop];
                }            }
        }
    }];
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    return [self initWithDictionary:dict];
}

- (void)revertInventoryQuantityUpdateForTransaction:(AGNSampleInventoryTransaction *)sit {
    // If this is an outgoing sample inventory transaction, increase the inventory by the expectedQuantity.
    // If this is an incoming sample inventory transaction, decrease the inventory by the actualQuantityReceived. If the actualQuantityReceived
    // quantity is the same as the quantity on the SIL, delete the SIL.
    // If this is an inventory count, make no adjustment to inventory.
    // In all cases, the current SITL needs to be deleted.
    
    AGNSampleInventoryLine *sil = [[AGNAppDelegate sharedDelegate].dataManager getSampleInventoryLineForProductSKU:self.product andLotNumber:self.lotNumber];
    if ([sit isOutboundTransfer] || [sit isReturn]) {
        if (!sil) {
            log4Error(@"Error: outbound SITL should have a corresponding SIL");
        }
        else {
            sil.quantity = [NSNumber numberWithInt:(sil.quantity.intValue + self.expectedQuantity.intValue)];
        }
    }
    if ([sit isInboundTransfer] || [sit isIncomingShipment]) {
        if (sil.quantity.intValue == self.actualQuantity.intValue) {
            //Remove the sil altogether
            [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:sil];
        }
        else {
            sil.quantity = [NSNumber numberWithInt:(sil.quantity.intValue - self.actualQuantity.intValue)];
        }
    }
    [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:self];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

- (NSNumber *)variance {
    if(self.expectedQuantity && self.actualQuantity){
        int variance = [self.actualQuantity intValue]-[self.expectedQuantity intValue];
        return [[NSNumber alloc]initWithInt:variance];
    }
    else {
        return nil;
    }
}

- (NSNumber *)varianceForInventoryCount {
    // Inventory Count places the user's entered quantity in the expectedQuantity field
    // and the SIL quantity in the availableQuantity field
    if(self.expectedQuantity && self.availableQuantity){
        int variance = [self.expectedQuantity intValue]-[self.availableQuantity intValue];
        return [[NSNumber alloc]initWithInt:variance];
    }
    else {
        return nil;
    }
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Utility methods
//------------------------------------------------------------------------------

- (void)populateFromSIL:(AGNSampleInventoryLine *)sil {
    self.expectedQuantity = sil.quantity;
    self.lotNumber = sil.lotNumber;
    self.expirationDate = sil.expiration;
    self.product = sil.product;
    self.productSalesForceId = sil.product.salesForceId;
    self.productCode = sil.product.productCode;
    self.productDescription = sil.product.productDescription;
    if (!self.itemCode && self.lotNumber && self.productCode && [AGNAppDelegate sharedDelegate].loggedInSalesRep) {
        self.itemCode = [NSString stringWithFormat:@"%@-%@-%@", [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId, self.productCode, self.lotNumber];
    }
    self.sampleInventoryLine=sil;
}

@end
