//
//  AGNMarketingDisbursement.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/11/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNHCPActivity.h"
#import "AGNMarketingCollateral.h"


@interface AGNMarketingDisbursement : AGNHCPActivity <AGNModelProtocol>

@property (nonatomic, retain) NSSet *marketingCollateral;

@end

@interface AGNMarketingDisbursement (CoreDataGeneratedAccessors)

- (void)addMarketingCollateralObject:(NSManagedObject *)value;
- (void)removeMarketingCollateralObject:(NSManagedObject *)value;
- (void)addMarketingCollateral:(NSSet *)values;
- (void)removeMarketingCollateral:(NSSet *)values;
- (void)populateStampedData;
- (NSMutableAttributedString *)attributedDoctorNameDesignationAndSpecialty;
- (NSString *)doctorNameAndDesignation;
- (NSString *)scheduleDescription;
- (NSAttributedString *)hcpDetailDescription;
@end
