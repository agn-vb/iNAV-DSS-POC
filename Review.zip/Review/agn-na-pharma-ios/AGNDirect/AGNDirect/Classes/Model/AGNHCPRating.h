//
//  AGNHCPRating.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

static NSString *kFrequencyKey = @"FREQ";
static NSString *kRatingKey = @"DECILE";


@interface AGNHCPRating : NSManagedObject  <AGNModelProtocol>


@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * salesForceAccountId;
@property (nonatomic, retain) NSString * salesForceSalesTeamId;
@property (nonatomic, retain) NSString * ratingType;
@property (nonatomic, retain) NSString * ratingValue;
@property (nonatomic, retain) NSString * salesTeamName;

@property (nonatomic, retain) AGNAccount *account;



@end
