//
//  AGNRSS.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/6/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNRequestForm;

@interface AGNRSS : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSSet *forms;
@property (nonatomic, retain) NSNumber * active_flag;
@end

@interface AGNRSS (CoreDataGeneratedAccessors)

- (void)addFormsObject:(AGNRequestForm *)value;
- (void)removeFormsObject:(AGNRequestForm *)value;
- (void)addForms:(NSSet *)values;
- (void)removeForms:(NSSet *)values;

@end
