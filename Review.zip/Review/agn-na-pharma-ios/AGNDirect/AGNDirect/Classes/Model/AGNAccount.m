//
//  AGNAccount.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAccount.h"
#import "AGNAddress.h"
#import "AGNCall.h"
#import "AGNContact.h"
#import "AGNLicense.h"
#import "AGNHCPRating.h"
#import "AGNAppDelegate.h"
#import "AGNTransientRatingFrequencyContainer.h"


@implementation AGNAccount

static NSDictionary *fieldMapping = nil;

@dynamic amdmPhysicianId;
@dynamic doNotMail;
@dynamic email1;
@dynamic email2;
@dynamic email3;
@dynamic fax;
@dynamic firstName;
@dynamic lastName;
@dynamic mdmId;
@dynamic middleName;
@dynamic mobilePhone;
@dynamic nameSuffix;
@dynamic phone;
@dynamic physicianStatus;
@dynamic primarySpecialty;
@dynamic professionalDesignation;
@dynamic recordType;
@dynamic salesForceId;
@dynamic sort_frequency;
@dynamic sort_rating;
@dynamic addresses;
@dynamic calls;
@dynamic contacts;
@dynamic licenses;
@dynamic blacklists;
@dynamic ratings;
@dynamic forms;


@synthesize undoJSONRepresentation=_undoJSONRepresentation;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    fieldMapping =
    @{
    @"AMDM_Physician_ID" : @"amdmPhysicianId",
    @"Do_Not_Mail" : @"doNotMail",
    @"PersonEmail" : @"email1",
    @"Email_2" : @"email2",
    @"Email_3" : @"email3",
    @"Fax" : @"fax",
    @"FirstName" : @"firstName",
    @"Id"  : @"salesForceId",
    @"LastName" : @"lastName",
    @"MDM_ID" : @"mdmId",
    @"Middle_Name" : @"middleName",
    @"Name_Suffix" : @"nameSuffix",
    @"PersonMobilePhone" : @"mobilePhone",
    @"Phone" : @"phone",
    @"Physician_Status" : @"physicianStatus",
    @"Primary_Specialty" : @"primarySpecialty",
    @"Professional_Designation"  : @"professionalDesignation"
    };
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);

        return NO;
    }
    return YES;
}


- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for(NSString *key in objectDict){
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on account to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on account to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerAccount:self];
}

- (NSString *)jsonRepresentationForUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [result appendFormat:@"\"PersonEmail\" : \"%@\",", self.email1 ? [self.email1 agnEscapedString] : @""];
    [result appendFormat:@"\"Email_2__c\" : \"%@\",", self.email2 ? [self.email2 agnEscapedString] : @""];
    [result appendFormat:@"\"Email_3__c\" : \"%@\",", self.email3 ? [self.email3 agnEscapedString] : @""];
    [result appendFormat:@"\"Phone\" : \"%@\",", self.phone  ? [self.phone agnEscapedString] : @""];
    [result appendFormat:@"\"PersonMobilePhone\" : \"%@\",", self.mobilePhone ? [self.mobilePhone agnEscapedString] : @""];
    [result appendFormat:@"\"Fax\" : \"%@\",", self.fax  ? [self.fax agnEscapedString] : @""];
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (void)setUndoRepresentation {
    self.undoJSONRepresentation = [self jsonRepresentationForUndo];
}

- (void)clearUndoRepresentation {
    self.undoJSONRepresentation = nil;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    return [self initWithDictionary:dict];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

- (NSMutableSet *)liveContacts {
    NSMutableSet *result = [self.contacts mutableCopy];
    NSArray * allContacts = [self.contacts allObjects];
    [allContacts enumerateObjectsUsingBlock:^(id obj, NSUInteger ix, BOOL *stop) {
        if (((AGNContact *)obj).toBeDeletedFlag.boolValue) {
            [result removeObject:obj];
        }
    }];
    return result;
}


- (AGNAddress *)primaryAddress; {
    for (AGNAddress *address in self.addresses) {
        if (address.primary.intValue == 1) {
            return address;
        }
    }
    
    return nil;
}

- (NSString *)formattedName {
    
    NSString *name = self.lastName ? [self.lastName uppercaseString] : @"UNKNOWN";
    if (self.firstName) {
        name = [name stringByAppendingFormat:@", %@", [self.firstName uppercaseString]];
    }
    
    return name;
}

- (NSString *)doctorNameAndDesignation {
    NSString *doctorNameAndDesignation = [self formattedName];
    if (self.professionalDesignation) {
        doctorNameAndDesignation = [doctorNameAndDesignation stringByAppendingFormat:@" - %@", [self.professionalDesignation uppercaseString]];
    }
    return doctorNameAndDesignation;
}

-(NSAttributedString *)callClosureDoctorNameAndDesignation{
    
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    NSString *name = [NSString stringWithFormat:@"%@, %@",self.lastName?[self.lastName uppercaseString]:@"",self.firstName?[self.firstName uppercaseString]:@""];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:name attributes:heavyAttributes]];
    NSString *role = [NSString stringWithFormat:@" - %@", self.professionalDesignation];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:role attributes:romanAttributes]];
    
    return formattedString;

}

- (NSMutableAttributedString *)attributedDoctorNameAndDesignation {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    
    NSAttributedString *doctorName = [[NSAttributedString alloc] initWithString:[self formattedName] attributes:heavyAttributes];
    
    [formattedString appendAttributedString:doctorName];

    if(self.professionalDesignation){
        NSAttributedString *designation = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" - %@", [self.professionalDesignation uppercaseString]] attributes:romanAttributes];

        [formattedString appendAttributedString:designation];
    }
    
    return formattedString;
}

- (NSAttributedString *)attributedPhone:(NSString *)phone withLabel:(NSString *)label {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    
    NSAttributedString *phoneString = [[NSAttributedString alloc] initWithString:phone attributes:heavyAttributes];
    
    [formattedString appendAttributedString:phoneString];
    NSAttributedString *labelString = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" (%@)", label] attributes:romanAttributes];
    [formattedString appendAttributedString:labelString];
    
    return formattedString;
}

-(NSAttributedString  *)attributedPhone{
    return [self attributedPhone:self.phone withLabel:NSLocalizedString(@"Main", @"Label for main phone number on account")];
}

-(NSAttributedString  *)attributedFax{
    return [self attributedPhone:self.fax withLabel:NSLocalizedString(@"FAX", @"Label for fax phone number on account")];
}

-(NSAttributedString  *)attributedMobile{
    return [self attributedPhone:self.mobilePhone withLabel:NSLocalizedString(@"Mobile", @"Label for mobile phone number on account")];
}
- (NSMutableAttributedString *)attributedDoctorNameDesignationAndSpecialty {

    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    
    NSMutableAttributedString *formattedString = [self attributedDoctorNameAndDesignation];
    
    if(self.primarySpecialty){
        NSAttributedString *specialty = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" - %@ ", [self.primarySpecialty uppercaseString]] attributes:romanAttributes];
        
        [formattedString appendAttributedString:specialty];
    }
    return formattedString;
}


-(AGNLicense *)samplingLicenseForAddress:(AGNAddress *) address{
    for(AGNLicense *license in self.licenses){
        if([license.usState isEqualToString:address.usState]){
            if([license permitsSampling]){
                log4Debug(@"Found a valid license in %@ ",license.usState);
                return license;
            }
            else{
                log4Debug(@"License for %@ expired on %@",license.usState,license.expirationDate);
            }
        }
    }
    log4Debug(@"Unable to locate a valid license for  %@",address.usState);
    return nil;
}

- (BOOL) canSampleAtAddress:(AGNAddress *) address{
    if(![[address.addressType uppercaseString] isEqualToString:[kOfficeAddressType uppercaseString]])
        return NO;
    return [self samplingLicenseForAddress:address]!=nil;
}

- (NSSet *) blacklistProducts{
    NSMutableSet *products = [[NSMutableSet alloc]initWithCapacity:[self.blacklists count]];
    NSLog(@"Blacklist count %u",[self.blacklists count]);
    for(AGNDetailBlacklist *db in self.blacklists){
        NSLog(@"Blacklist item %@",db.product.salesForceId);
        if(db.product && db.product.salesForceId)  //Barathan 10/7/2014
        //if(db.salesForceProductId != nil)
        {
            [products addObject:db.product.salesForceId];
            //[products addObject:db.salesForceProductId];
            NSLog(@"Blacklist item %@",db.salesForceProductId);
        }
    }
    return products;
}



- (void)removeCallsObject:(AGNCall *)draftCallToDelete {
    NSMutableSet *ms = [self mutableSetValueForKey:@"calls"];
    [ms removeObject:draftCallToDelete];
}


- (BOOL) addEmailIfPossible:(NSString*) email{
    if(!email ||email.length<1)
        return NO;
    // don't add if we've already got this one
    if([email isEqualToString:self.email1]||[email isEqualToString:self.email2]||[email isEqualToString:self.email3])
        return NO;
    if(!self.email1){
        self.email1 = email;
        return YES;
    }
    if(!self.email2){
        self.email2 = email;
        return YES;
    }
    if(!self.email3){
        self.email3 = email;
        return YES;
    }
    return NO;
}

- (NSString *)defaultEmailAddress{
    if(self.email1)
        return self.email1;
    if(self.email2)
        return self.email2;
    if(self.email3)
        return self.email3;
    return nil;
}

- (NSArray *)visibleAddresses{
    NSMutableArray *results = [[NSMutableArray alloc]init];
    for(AGNAddress * address in self.addresses){
        if(![address isHidden]){
            [results addObject:address];
        }
    }
    return results;
}

- (NSDictionary *)ratingsToDisplay{
    NSMutableDictionary *results = [[NSMutableDictionary alloc]init];
    for(AGNHCPRating * rating in self.ratings){
        if([rating.ratingType isEqualToString:kRatingKey]){
            NSString * salesTeam = rating.salesTeamName;
            AGNTransientRatingFrequencyContainer *rf = results[salesTeam];
            if(!rf){
                rf = [[AGNTransientRatingFrequencyContainer alloc]init];
                results[salesTeam]=rf;
            }
            rf.rating=rating.ratingValue;
            rf.salesTeamName=salesTeam;
        }
        if([rating.ratingType isEqualToString:kFrequencyKey]){
            NSString * salesTeam = rating.salesTeamName;
            AGNTransientRatingFrequencyContainer *rf = results[salesTeam];
            if(!rf){
                rf = [[AGNTransientRatingFrequencyContainer alloc]init];
                results[salesTeam]=rf;
            }
            rf.frequency=rating.ratingValue;
            rf.salesTeamName=salesTeam;
        }
    }
    return results;
}

- (NSString *)description {
    return [NSString stringWithFormat:@" %@ %@ - %@ ",self.lastName,self.firstName,self.professionalDesignation];
}

- (NSAttributedString *)nameAddressLabel:(AGNAddress *)address {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightObliqueFont = [UIFont fontWithName:@"Avenir-LightOblique" size:16];
    UIFont *mediumFont = [UIFont fontWithName:@"Avenir-Medium" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightObliqueAttributes = @{ NSFontAttributeName : lightObliqueFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *mediumAttributes = @{ NSFontAttributeName : mediumFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:[self formattedName] attributes:boldAttributes];
    if (self.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)", self.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:lightObliqueAttributes]];
    }
    NSString *addressString = [NSString stringWithFormat:@"\n%@",address.singleLineStreetString];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:addressString attributes:mediumAttributes]];
    NSString *cityStateZipString = [NSString stringWithFormat:@"\n%@",address.cityStateZipFormattedString];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:cityStateZipString attributes:mediumAttributes]];
    return formattedString;
}

- (NSAttributedString *)licenseLabel:(AGNAddress *)address {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightFont = [UIFont fontWithName:@"Avenir-Light" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightAttributes = @{ NSFontAttributeName : lightFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    AGNLicense *license = [self samplingLicenseForAddress:address];
    if (license) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"LICENSE:" attributes:lightAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:license.licenseNumber attributes:boldAttributes]];
        NSDate *licenseExpDate = license.expirationDate;
        if (licenseExpDate) {
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"  EXPIRES:" attributes:lightAttributes]];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[licenseExpDate agnFormattedDateString] attributes:boldAttributes]];
        }
    }
    return formattedString;
}

@end
