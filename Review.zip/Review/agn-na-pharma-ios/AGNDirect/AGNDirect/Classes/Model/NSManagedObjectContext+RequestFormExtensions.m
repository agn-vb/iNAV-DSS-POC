//
//  NSManagedObjectContext+RequestFormExtensions.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/7/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "NSManagedObjectContext+RequestFormExtensions.h"

@implementation NSManagedObjectContext (RequestFormExtensions)

-(NSArray *) AGNProductsForFilterString:(NSString *)filterString  {
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                                initWithKey:@"productDescription" ascending:YES];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNRequestFormProduct" inManagedObjectContext:self];
    [request setEntity:entity];
    if(filterString){
        NSString *wildCardFilterString = [NSString stringWithFormat:@"*%@*", filterString];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"productDescription like[c] %@ ",  wildCardFilterString];
        [request setPredicate:predicate];
    }
    [request setSortDescriptors:@[sortDescriptor]];

    NSError *error = nil;
    NSArray *objects = [self executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching Products matching %@ - %@",filterString,error);
    return objects;

}

-(NSArray *) AGNAllActiveRSS  {
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"name" ascending:YES];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNRSS" inManagedObjectContext:self];
    [request setEntity:entity];
    NSPredicate *active = [NSPredicate predicateWithFormat:@"active_flag == YES"];
    [request setPredicate:active];
    [request setSortDescriptors:@[sortDescriptor]];

    NSError *error = nil;
    NSArray *objects = [self executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching RSS %@",error.userInfo);
    return objects;

}

-(NSArray * )AGNAllODRReason{
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"label" ascending:YES];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNODRReason" inManagedObjectContext:self];
    [request setEntity:entity];
    [request setSortDescriptors:@[sortDescriptor]];

    NSError *error = nil;
    NSArray *objects = [self executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching ODRReason %@",error.userInfo);
    return objects;
}

-(NSArray *)AGNAllAPC:(NSArray *)sortDescriptors{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];

    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNAPC" inManagedObjectContext:self];
    [request setEntity:entity];
    if(sortDescriptors)
        [request setSortDescriptors:sortDescriptors];
    else{
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                            initWithKey:@"apcCode" ascending:YES];
        [request setSortDescriptors:@[sortDescriptor]];
    }

    NSError *error = nil;
    NSArray *objects = [self executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching AGNAPC %@",error.userInfo);
    return objects;

}


-(NSArray *)AGNValidAPCs:(NSArray *)sortDescriptors {
    NSFetchRequest *request = [[NSFetchRequest alloc] init];

    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNAPC" inManagedObjectContext:self];
    [request setEntity:entity];


    NSDate * today = [NSDate date];
    NSPredicate *active =  [NSPredicate predicateWithFormat:@"endDate >= %@  AND effectiveDate <= %@",today,today] ;
   
    [request setPredicate:active];


    if(sortDescriptors)
        [request setSortDescriptors:sortDescriptors];
    else{
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                            initWithKey:@"apcCode" ascending:YES];
        [request setSortDescriptors:@[sortDescriptor]];
    }

    NSError *error = nil;
    NSArray *objects = [self executeFetchRequest:request error:&error];
    if(error)
        log4Error(@"Error fetching AGNAPC %@",error.userInfo);
    return objects;
    
}

@end
