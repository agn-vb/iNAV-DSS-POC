//
//  AGNSuppressedAddress.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/11/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSuppressedAddress.h"
#import "AGNAccount.h"
#import "AGNAddress.h"
#import "AGNSalesRep.h"


@implementation AGNSuppressedAddress

@dynamic salesForceAddressId;
@dynamic salesForceSalesRepId;
@dynamic salesForceHCPId;
@dynamic salesRep;

@end
