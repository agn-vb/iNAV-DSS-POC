//
//  AGNMarketingCollateral.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/11/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AGNMarketingDisbursement;

@interface AGNMarketingCollateral : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * apcRemoteId;
@property (nonatomic, retain) NSString * apcCode;
@property (nonatomic, retain) NSString * apcProductName;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSString * apcJobName;
@property (nonatomic, retain) NSNumber * quantity;
@property (nonatomic, retain) AGNMarketingDisbursement *disbursement;
@property (nonatomic, retain) NSString * disbursementRemoteId;
// transient
@property (nonatomic, strong) NSNumber * apcValue;

@end
