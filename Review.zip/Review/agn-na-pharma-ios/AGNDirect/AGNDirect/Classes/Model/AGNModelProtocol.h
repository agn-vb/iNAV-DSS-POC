//
//  AGNModelProtocol.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AGNModelProtocol <NSObject>

/**
 * Answers whether the supplied dictionary contains enough information to initialize 
 * an instance of the model object.
 */
+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict;

/**
 * Initializes the model object from the supplied dictionary. If this is an existing
 * object, fields not present in the dictionary will not be overwritten. 
 *
 * If the dictionary contains nested objects, these should be processed as well - if
 * the nested object exists already in CoreData, it should be retrieved and sent the 
 * initWithDictionary: message passing in the nested dictionary. If not, a new instance
 * should be created in CoreData and then initialized from the nested dictionary.
 * Implementors should take care to build any relationships necessary.
 * 
 * Note: Assumes that operations take place on the main thread in the default MOC
 * associated with the app delegate.
 *
 */
- (void)initWithDictionary:(NSDictionary *)dict;

@optional

/**
 * Answers the JSON representation of the model object suitable for updating SFDC through
 * either the ReST API or through a wrapper service. Only a small subset of model objects
 * are actually updatable from the iPad.
 *
 * If there are nested model objects that are updatable in SFDC, these should be 
 * represented as nested JSON. 
 *
 */
- (NSString *)jsonRepresentationForUpdate;

/**
 * When new objects are inserted into SFDC from the iPad, they initially do not have
 * salesForceIds, since these are assigned by SFDC when the objects are created in SFDC.
 * Wrapper services should be built to return SFDC IDs mapped to iPad-generated GUIDs.
 *
 * Note: Assumes that operations take place on the main thread in the default MOC
 * associated with the app delegate.
 */
- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict;

/**
 * Answer whether the object is marked toBeDeleted. This is needed in order to be able
 * to know that we need to recreate the object in CoreData in case of a reversion after
 * a failed transaction in SFDC.
 */
- (BOOL)isToBeDeleted;

/**
 * Create model object relationships based on SFDC IDs.
 *
 * Note: Assumes that operations take place on the main thread in the default MOC
 * associated with the app delegate.
 */
- (void)buildRelationships;

/*
 * UNDO BEHAVIOR
 *
 * When an update transaction fails to save to SFDC, (and is removed from the update queue)
 * we need to undo the changes made locally in order to maintain consistency between the 
 * two. The jsonRepresentationForUndo and undoWithDictionary: methods on model objects
 * provide a representation in key:value format that the revert method on AGNUpdateTransaction
 * uses to bring the object back to its initial state.
 * 
 * The model object should store (transiently) current undo state in an NSString property 
 * called undoJSONRepresentation. Only top-level objects that are being modified should 
 * store the undo representation. 
 *
 * When the jsonRepresentationForUndo gets called depends on the circumstances. When there is
 * a single model object that can be updated by a VC, the VC will set the undoRepresentation
 * on the object typically in viewWillAppear: or whenever the model is set for that VC. Where 
 * there can be multiple, the model object undo representation needs to be set as soon as the 
 * object becomes modifiable (but not yet modified).
 *  
 */


/**
 * Sets the undoJSONRepresentation property of the model object to what is returned from 
 * the jsonRepresentationForUndo method call.
 */
- (void)setUndoRepresentation;

/**
 * Sets the undoJSONRepresentation property of the model object to nil.
 */
- (void)clearUndoRepresentation;

/**
 * Answers the JSON representation of the model object suitable for undoing changes 
 * locally on the device if the SFDC update fails and is removed from the update queue.
 *
 * If there are nested model objects that need to be undone, these should be
 * represented as nested JSON.
 *
 */
- (NSString *)jsonRepresentationForUndo;

/**
 * Update the model object from the supplied dictionary, which should be generated
 * from the JSON string returned by jsonRepresentationForUndo.
 *
 * If the dictionary contains nested objects, these should be processed as well - if
 * the nested object exists already in CoreData, they should be retrieved and sent the
 * undoWithDictionary: message passing in the nested dictionary. If not, a new instance
 * should be created in CoreData and then initialized from the nested dictionary.
 * Implementors should take care to build any relationships necessary.
 *
 * Note: Assumes that operations take place on the main thread in the default MOC
 * associated with the app delegate.
 *
 */
- (void)undoWithDictionary:(NSDictionary *)dict;


@end
