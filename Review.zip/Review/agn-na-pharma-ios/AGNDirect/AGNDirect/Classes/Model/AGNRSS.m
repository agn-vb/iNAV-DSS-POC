//
//  AGNRSS.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/6/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNRSS.h"
#import "AGNRequestForm.h"


@implementation AGNRSS

@dynamic email;
@dynamic name;
@dynamic salesForceId;
@dynamic forms;
@dynamic active_flag;


static NSDictionary *fieldMapping = nil;

+(void)initialize{
    fieldMapping =
    @{
      @"Id"         : @"salesForceId",
      @"Email__c"    :@"email",
      @"Active__c" :@"active_flag",
      @"Name"   :   @"name"
      };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *  objectDict = dict;
    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict{
    NSDictionary * objectDict = dict;
    for(NSString *key in objectDict){
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }
        NSString *objectKey = fieldMapping[key];
        if([key isEqualToString:@"Active__c"]) {
            self.active_flag=value;
        }
        else if(objectKey)
            [self setValue:value forKey:objectKey];
    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerRSS:self];
}


@end
