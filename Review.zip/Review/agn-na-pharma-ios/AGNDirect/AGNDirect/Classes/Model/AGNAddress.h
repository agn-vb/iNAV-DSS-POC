//
//  AGNAddress.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"
#import "AGNHCPAvailabilityManager.h"

@class AGNAccount, AGNCall;

static NSString *const kMailingAddressType=@"Mailing";
static NSString *const kOfficeAddressType=@"Office";

@interface AGNAddress : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSNumber * active;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * deaNumber;
@property (nonatomic, retain) NSString * faxPhone;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSString * line1;
@property (nonatomic, retain) NSString * line2;
@property (nonatomic, retain) NSString * line3;
@property (nonatomic, retain) NSString * addressType;

@property (nonatomic, retain) NSDate * mobileCreateTimestamp;
@property (nonatomic, retain) NSDate * mobileLastUpdateTimestamp;

@property (nonatomic, retain) NSString * mobilePhone;
@property (nonatomic, retain) NSString * officePhone;
@property (nonatomic, retain) NSNumber * primary;
@property (nonatomic, retain) NSString * salesForceAccountId;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * usState;
@property (nonatomic, retain) NSString * zip;
@property (nonatomic, retain) AGNAccount *account;
@property (nonatomic, retain) NSSet *calls;

// Modeling the office hours this way to match what is in SF
@property (nonatomic, retain) NSString *mondayOpenTime;
@property (nonatomic, retain) NSString *mondayCloseTime;
@property (nonatomic, retain) NSString *tuesdayOpenTime;
@property (nonatomic, retain) NSString *tuesdayCloseTime;
@property (nonatomic, retain) NSString *wednesdayOpenTime;
@property (nonatomic, retain) NSString *wednesdayCloseTime;
@property (nonatomic, retain) NSString *thursdayOpenTime;
@property (nonatomic, retain) NSString *thursdayCloseTime;
@property (nonatomic, retain) NSString *fridayOpenTime;
@property (nonatomic, retain) NSString *fridayCloseTime;

@property BOOL notSynced;

@property (strong, nonatomic) AGNHCPAvailabilityManager *availabilityManager;
@property (nonatomic, strong) NSString *undoJSONRepresentation;


-(void)resetAvailabilityManager;
- (NSString *)singleLineStreetString;
- (NSString *)cityStateZipFormattedString;
- (NSString *)singleLineFormattedString;
- (NSString *)doubleLineFormattedString;
- (NSString *)multiLineFormattedStringWithPhone;
- (int)numberOfLinesInMultiLineFormattedString;
- (int)numberOfLinesMissingInMultiLineFormattedString;

- (BOOL)canSample;
- (NSString *)canSampleTag;
-(BOOL) isHidden;
- (void)saveAvailabilityManager;
- (NSString *)jsonRepresentationForAvailabilityUpdate;

@end
