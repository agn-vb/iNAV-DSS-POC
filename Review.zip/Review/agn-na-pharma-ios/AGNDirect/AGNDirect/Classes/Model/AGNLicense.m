//
//  AGNLicense.m
//  AGNDirect
//
//  Created by Mark Wells on 8/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNLicense.h"
#import "AGNAccount.h"


@implementation AGNLicense

@dynamic active;
@dynamic canSample;
@dynamic expirationDate;
@dynamic licenseNumber;
@dynamic salesForceAccountId;
@dynamic salesForceId;
@dynamic usState;
@dynamic account;

static NSDictionary *fieldMapping = nil;

+(void)initialize{
    fieldMapping =
    @{
    @"Id"     : @"salesForceId",
    @"Expiration_Date" : @"expirationDate",
    @"License_Number" : @"licenseNumber",
    @"License_State"    : @"usState",
    @"HCP": @"salesForceAccountId",
    @"Status" : @"active",
    @"Sample_Flag" : @"canSample"
    };
}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}


- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    for(NSString *key in objectDict){
        log4Trace(@"key %@",key);
        id value = [objectDict[key] isEqual:[NSNull null] ]?nil:objectDict[key];
        if([key isEqualToString:@"Expiration_Date"]) {
            if(objectDict[key]!=[NSNull null]){
                NSDateFormatter *df = [[NSDateFormatter alloc] init];
                [df setDateFormat:@"yyyy-MM-dd"];
                NSDate *myDate = [df dateFromString: objectDict[key]];
                self.expirationDate = myDate;
            }
        }
        else if ([key isEqualToString:@"Sample_Flag"]) {
            if(value)
                self.canSample=value;
        }
        else if ([key isEqualToString:@"Status"]) {
            if(value)
                self.active=@YES;
        }
        else {
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on license to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on license to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }
    if (self.salesForceAccountId && !self.account)
        self.account = [[AGNAppDelegate sharedDelegate].syncManager.sync accountBySFDCID:self.salesForceAccountId];
}

- (NSString *)description {
    return [NSString stringWithFormat:@"License %@, expires - %@ ",self.salesForceId,self.expirationDate];
}

-(BOOL) isValid{
    if(self.active && ([self.active boolValue]==NO))
        return false;
    
    if([self.expirationDate isExpired])
        return false;
    return true;
}

-(BOOL) permitsSampling{
    return [self isValid] && [self.canSample boolValue];
}

@end
