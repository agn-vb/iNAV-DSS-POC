//
//  AGNMarketingDisbursement.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/11/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNMarketingDisbursement.h"
#import "NSManagedObjectContext+DDSFExtensions.h"


@implementation AGNMarketingDisbursement

@dynamic marketingCollateral;

static NSDictionary *fieldMapping = nil;



+ (void)initialize {
    fieldMapping =
    @{
      @"Id"         : @"salesForceId",
      @"Rep__c":    @"salesForceRepId",
      @"GUID__c"    : @"guid",
      @"Account__c"     : @"salesForceAccountId",
      @"Address__c" : @"salesForceAddressId",
      @"Disbursement_Date__c"   : @"startDate",
      @"Rep_First_Name__c":@"repFirstName",
      @"Rep_Last_Name__c":@"repLastName",
      @"MobileCreatedDate__c":@"mobileCreateTimestamp",
      @"MobileLastModifiedDate__c":@"mobileLastUpdateTimestamp"
        };
    
    
}

- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict {
    NSString *guid =  [[jsonDict valueForKey:@"MarketingDisbursementGUID"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"MarketingDisbursementGUID"];
    NSString *mcdId = [[jsonDict valueForKey:@"MarketingDisbursementId"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"MarketingDisbursementId"];
    NSString *callStatusCode = [[jsonDict valueForKey:@"StatusCode"]isEqual:[NSNull null]]?nil:(NSString *)[jsonDict valueForKey:@"StatusCode"];
    if ([callStatusCode isEqualToString:@"SUCCESS"]) {
        if ([self.guid isEqualToString:guid] && mcdId && mcdId.length>0) {
            self.salesForceId = mcdId;
        }
        if ([jsonDict valueForKey:@"Marketing_Contents"] != [NSNull null]) {
            NSArray *contents = (NSArray *)[jsonDict valueForKey:@"Marketing_Contents"];
            for (NSDictionary *dict in contents) {
                NSString *contentGUID = [[dict valueForKey:@"GUID"]isEqual:[NSNull null]]?nil:(NSString *)[dict valueForKey:@"GUID"];
                NSString *contentId = [[dict valueForKey:@"Id"]isEqual:[NSNull null]]?nil:(NSString *)[dict valueForKey:@"Id"];
                NSString *contentStatus =  [[dict valueForKey:@"StatusCode"]isEqual:[NSNull null]]?nil:(NSString *)[dict valueForKey:@"StatusCode"];
                if ([contentStatus isEqualToString:@"SUCCESS"]) {
                    [self.marketingCollateral enumerateObjectsUsingBlock:^(id obj, BOOL*stop) {
                        AGNMarketingCollateral *content = (AGNMarketingCollateral *)obj;
                        content.disbursementRemoteId = mcdId;
                        if ([content.guid isEqualToString:contentGUID]) {
                            if (contentId) {
                                content.salesForceId = contentId;
                            }
                            *stop = YES;
                        }
                    }];
                }
            }
        }
    }
}


- (void)buildRelationships {
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;

    if (sync) {
        if (self.salesForceAccountId && !self.account) {
            self.account = [sync accountBySFDCID:self.salesForceAccountId];
        }
        if (self.salesForceAddressId && !self.address) {
            self.address = [sync addressBySFDCID:self.salesForceAddressId];
        }
        if (self.salesForceRepId && !self.salesRep) {
            self.salesRep = [sync salesRepBySFDCID:self.salesForceRepId];
        }
    }
    else {
        if (self.salesForceAccountId && !self.account) {
            self.account = [self.managedObjectContext ddsf_objectOfType:@"AGNAccount" forId:self.salesForceAccountId];
        }
        if (self.salesForceAddressId && !self.address) {
            self.address = [self.managedObjectContext ddsf_objectOfType:@"AGNAddress" forId:self.salesForceAddressId];
        }
        if (self.salesForceRepId && !self.salesRep) {
            self.salesRep = [self.managedObjectContext ddsf_objectOfType:@"AGNSalesRep" forId:self.salesForceRepId];
        }
    }

    if (!self.account)
        log4Warn(@"Missing account on call %@ after sync, accountId = %@", self.salesForceId, self.salesForceAccountId);

    if (!self.salesRep)
        log4Debug(@"Missing sales rep on call %@ after sync, salesRepId = %@", self.salesForceId, self.salesForceRepId);

}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *  objectDict = dict;
    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

- (void)initWithDictionary:(NSDictionary *)dict{
    NSDictionary * objectDict = dict;
    for(NSString *key in objectDict){
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }
        NSString *objectKey = fieldMapping[key];
        if(objectKey){
            if([key isEqualToString:@"MobileLastModifiedDate__c"]) {
                self.mobileLastUpdateTimestamp = [NSDate agnDateFromString:value];
            }
            else if([key isEqualToString:@"MobileCreatedDate__c"]){
                self.mobileCreateTimestamp = [NSDate agnDateFromString:value];
            }
            else if([key isEqualToString:@"Disbursement_Date__c"]){
                self.startDate = [NSDate agnDateFromString:value];
            }
            else{
                [self setValue:value forKey:objectKey];
            }
        }

    }
    [[AGNAppDelegate sharedDelegate].syncManager.sync registerMarketingDisbursement:self];
    [self buildRelationships];
//    log4Info(@"Disbursement : %@",self);
}


-(void)populateStampedData{
    AGNSalesRep *rep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    if(rep){
        self.repFirstName = [rep.firstName copy];
        self.repLastName = [rep.lastName copy];
        self.repMiddleName = [rep.middleName copy];
        self.stampRepManagerName = [rep.managerName copy];
        self.stampSalesTeam = [[AGNAppDelegate sharedDelegate].loggedInSalesRep.salesTeamName copy];
        self.stampTerritory = [[AGNAppDelegate sharedDelegate].loggedInSalesRep.territoryName copy];

    }
    if (self.address) {
        self.stampAddressLine1 = [self.address.line1 copy];
        self.stampAddressLine2 = [self.address.line2 copy];
        self.stampAddressLine3 = [self.address.line3 copy];
        self.stampAddressCity = [self.address.city copy];
        self.stampAddressCountry = @"USA";
        self.stampAddressState = [self.address.usState copy];
        self.stampAddressZip = [self.address.zip copy];
    }
    if (self.account) {
        self.stampHCPFirstName = [self.account.firstName copy];
        self.stampHCPLastName = [self.account.lastName copy];
        self.stampHCPMiddleName = [self.account.middleName copy];
        self.stampHCPMDMID = [self.account.mdmId copy];
        self.stampPhysicianSpecialty = [self.account.primarySpecialty copy];
        self.stampProfessionalDesignation = [self.account.professionalDesignation copy];
        AGNLicense *license = [self.account samplingLicenseForAddress:self.address];
        if (license) {
            self.stampLicenseExpirationDate = [license.expirationDate copy];
            self.stampLicenseState = [license.usState copy];
            self.stampLicenseNumber = [license.licenseNumber copy];
        }
    }

}


- (NSString *)jsonRepresentationForUpdate {
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop

        if (!prop || [prop isEqual:[NSNull null]]) {
            prop = @"";
        }
        if ([prop isKindOfClass:[NSString class]]) {
            [result appendFormat:@"\"%@\": \"%@\",",[key upsertKey], [prop agnEscapedString]];
        }
        else{
            [result appendFormat:@"\"%@\": \"%@\",",[key upsertKey], prop];
        }


    }];
    if ([self.marketingCollateral count] > 0) {
        [result appendString:@"\"Contents\" : ["];
        for (AGNMarketingCollateral *cd in [self marketingCollateral]) {
                [result appendFormat:@" %@,", [cd jsonRepresentationForUpdate]];
            }

        result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
        [result appendString:@"],"];
    }

    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (NSMutableAttributedString *)attributedDoctorNameDesignationAndSpecialty {

    if(self.account)
        return [self.account attributedDoctorNameDesignationAndSpecialty];

    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [self attributedDoctorNameAndDesignation];

    if(self.stampPhysicianSpecialty){
        NSAttributedString *specialty = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" - %@ ", [self.stampPhysicianSpecialty uppercaseString]] attributes:romanAttributes];

        [formattedString appendAttributedString:specialty];
    }
    return formattedString;
}

- (NSMutableAttributedString *)attributedDoctorNameAndDesignation {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];

    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];


    NSAttributedString *doctorName = [[NSAttributedString alloc] initWithString:[self.account formattedName] attributes:heavyAttributes];

    [formattedString appendAttributedString:doctorName];

    if(self.account.professionalDesignation){
        NSAttributedString *designation = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" - %@", [self.account.professionalDesignation uppercaseString]] attributes:romanAttributes];

        [formattedString appendAttributedString:designation];
    }

    return formattedString;
}

- (NSString *)doctorNameAndDesignation {
    NSString *doctorNameAndDesignation = [self.account formattedName];
    if (self.account.professionalDesignation) {
        doctorNameAndDesignation = [doctorNameAndDesignation stringByAppendingFormat:@" - %@", [self.account.professionalDesignation uppercaseString]];
    }
    return doctorNameAndDesignation;
}

-(NSString *)scheduleDescription{
    NSMutableString * mutableString = [[NSMutableString alloc]init];
    for(AGNMarketingCollateral * content in self.marketingCollateral){

        [mutableString appendString:content.apcCode];
        [mutableString appendString:@", "];
    }
    return  [mutableString stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] ;
}

- (NSAttributedString *)hcpDetailDescription {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];

    NSDictionary * heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    NSDictionary * romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };


    NSMutableAttributedString * formattedString = [[NSMutableAttributedString alloc] initWithString:@"Reprint: " attributes:heavyAttributes];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:self.scheduleDescription attributes:romanAttributes]];


    return formattedString;
}

- (BOOL)activeEntry{
    return NO;
}

@end
