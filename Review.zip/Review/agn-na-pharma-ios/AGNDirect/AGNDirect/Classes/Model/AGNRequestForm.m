//
//  AGNRequestForm.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/24/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNRequestForm.h"
#import "AGNAccount.h"
#import "AGNAddress.h"
#import "AGNProductBrand.h"
#import "AGNSalesRep.h"
#import "AGNRequestFormItem.h"
#import "NSManagedObjectContext+DDSFExtensions.h"


NSString * const kAGNRequestFormTypeMIR = @"MIR";
NSString * const kAGNRequestFormTypeODR = @"ODR";

NSString * const kAGNRequestFormTitleMIR = @"Medical Information Request";
NSString * const kAGNRequestFormTitleODR = @"On Demand Request";


NSString * const kAGNRequestFormStatusNew = @"NEW";
NSString * const kAGNRequestFormStatusOpen = @"Open";

NSString * const kAGNRequestFormDeliveryMethodEmail = @"E-Mail";
NSString * const kAGNRequestFormDeliveryMethodMail = @"Mail";
NSString * const kAGNRequestFormDeliveryMethodFax = @"Fax";
NSString * const kAGNRequestFormDeliveryMethodPhone = @"Telephone";


@implementation AGNRequestForm

@dynamic assignedTo;
@dynamic status;
@dynamic email;
@dynamic fax;
@dynamic phone;
@dynamic odrReason;
@dynamic deliveryMethod;
@dynamic closeDate;
@dynamic address;
@dynamic account;
@dynamic salesRep;
@dynamic type;
@dynamic  items;
@dynamic rss;
@dynamic stampRssName;
@dynamic salesForceRSSId;

@synthesize signatureJSON=_signatureJSON;
@synthesize undoJSONRepresentation=_undoJSONRepresentation;


static NSDictionary *fieldMapping = nil;

+ (void)initialize {
    fieldMapping =
    @{
      @"Id"         : @"salesForceId",
      @"Type__c"    :@"type",
      @"RSS__c":    @"salesForceRSSId",
      @"Rep__c":    @"salesForceRepId",
      @"GUID__c"    : @"guid",
      @"HCP__c"     : @"salesForceAccountId",
      @"Address_Lookup__c" : @"salesForceAddressId",
      @"Email__c"   : @"email",
      @"Phone__c"   : @"phone",
      @"Fax__c"    : @"fax",
//      @"Employee_Id__c",
      @"Close_Date__c" : @"submitDate",
      @"ODR_Reason__c" : @"odrReason",
      @"RSS_Name__c" : @"stampRssName",
      @"Assigned_To__c" : @"assignedTo",
      @"Status__c" : @"status",
      @"Delivery_Method__c" : @"deliveryMethod",
      @"CreatedDate" : @"createdDate",
      @"Signature_Time_GMT__c" :@"signatureCaptureDate",
      @"Rep_First_Name__c":@"repFirstName",
      @"Rep_Last_Name__c":@"repLastName"
//      @"Product_1__c" : ,
//      @"Product_2__c",
//      @"Product_3__c",
//      @"Product_4__c",
//      @"Product_5__c",
//      @"Product_6__c",
//      @"Product_7__c",
//      @"Product_8__c",
//      @"Product_9__c",
//      @"Product_10__c",
//      @"Question__c",
//      @"Question_2__c",
//      @"Question_3__c",
//      @"Question_4__c",
//      @"Question_5__c",
//      @"Question_6__c",
//      @"Question_7__c",
//      @"Question_8__c",
//      @"Question_9__c",
//      @"Question_10__c

      };


   }




+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *  objectDict = dict;
    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}


- (void)buildRelationships {
    AGNDownstreamSync * sync = [AGNAppDelegate sharedDelegate].syncManager.sync;

    if (sync) {
        if (self.salesForceAccountId && !self.account) {
            self.account = [sync accountBySFDCID:self.salesForceAccountId];
        }
        if (self.salesForceAddressId && !self.address) {
            self.address = [sync addressBySFDCID:self.salesForceAddressId];
        }
        if (self.salesForceRepId && !self.salesRep) {
            self.salesRep = [sync salesRepBySFDCID:self.salesForceRepId];
        }
        if (self.salesForceRSSId && !self.rss){
            self.rss = [sync rssBySFDCID:self.salesForceRSSId];
        }

    }
    else {
        if (self.salesForceAccountId && !self.account) {
            self.account = [self.managedObjectContext ddsf_objectOfType:@"AGNAccount" forId:self.salesForceAccountId];
        }
        if (self.salesForceAddressId && !self.address) {
            self.address = [self.managedObjectContext ddsf_objectOfType:@"AGNAddress" forId:self.salesForceAddressId];
        }
        if (self.salesForceRepId && !self.salesRep) {
            self.salesRep = [self.managedObjectContext ddsf_objectOfType:@"AGNSalesRep" forId:self.salesForceRepId];
        }
        if (self.salesForceRSSId && !self.rss) {
            self.rss = [self.managedObjectContext ddsf_objectOfType:@"AGNRSS" forId:self.salesForceRSSId];
        }

    }

    if (!self.account)
        log4Warn(@"Missing account on form %@ after sync, accountId = %@", self.salesForceId, self.salesForceAccountId);

    if (!self.salesRep)
        log4Warn(@"Missing sales rep on form %@ after sync, salesRepId = %@", self.salesForceId, self.salesForceRepId);

}


- (NSString *)jsonRepresentationForUpdate {

    //Signature_Time_GMT
    NSMutableDictionary * dict = [[NSMutableDictionary alloc]init];
    if(self.salesForceId)
        dict[@"Id"]=self.salesForceId;
    if(self.guid)
        dict[@"GUID"]=self.guid;
    if(self.account)
        dict[@"HCPid"]=self.account.salesForceId;
//    if(self.address && self.address.salesForceId)
//        dict[@"Address"]=self.address.salesForceId;
    if(self.address && self.address.salesForceId)
        dict[@"addressid"]=self.address.salesForceId;
    if(self.address && self.address.guid)
        dict[@"address_GUID"]=self.address.guid;
    if(self.deliveryMethod)
        dict[@"Delivery_Method"]=self.deliveryMethod;
    if(self.email)
        dict[@"Email"]=self.email;
    if(self.fax)
        dict[@"Fax"]=self.fax;
    if(self.phone)
        dict[@"Phone"]=self.phone;
    if(self.odrReason)
        dict[@"ODR_Reason"]=self.odrReason;
    if(self.salesForceRSSId)
        dict[@"RSSid"]=self.salesForceRSSId;
    if(self.salesForceRepId)
        dict[@"Repid"]=self.salesForceRepId;
    if(self.status)
        dict[@"Status"]=self.status;
    if(self.type)
        dict[@"Type"] = dict[@"recordtypename"] = self.type;
    if(self.signatureJSON)
        dict[@"HCPsignature"]=self.signatureJSON;
    if(self.mobileCreateTimestamp)
        dict[@"MobileCreateDate"] =[self.mobileCreateTimestamp agnUpsertTimestampString];
    if(self.mobileLastUpdateTimestamp)
        dict[@"MobileLastModifiedDate"] =[self.mobileLastUpdateTimestamp agnUpsertTimestampString];
    if(self.signatureCaptureDate)
        dict[@"Signature_Time_GMT"]=[self.signatureCaptureDate agnUpsertTimestampString];

    // Compliance Fields
    if(self.stampHCPFirstName)
        dict[@"First_Name"]=self.stampHCPFirstName;

    if(self.stampHCPLastName)
        dict[@"Last_Name"]=self.stampHCPLastName;

    if(self.stampProfessionalDesignation)
        dict[@"Professional_Designation1"]=self.stampProfessionalDesignation;

    if(self.stampHCPMDMID)
        dict[@"HCP_MDM_ID"]=self.stampHCPMDMID;
    
    if(self.stampPhysicianSpecialty)
        dict[@"Specialty1"]=self.stampPhysicianSpecialty;

    if(self.stampAddressCity)
        dict[@"City"]=self.stampAddressCity;

    if(self.stampAddressState)
        dict[@"State"]=self.stampAddressState;

    if(self.stampAddressZip)
        dict[@"Zip_Code"]=self.stampAddressZip;

    if(self.stampSalesTeam)
        dict[@"Sales_Team"]=self.stampSalesTeam;

    if(self.stampTerritory)
        dict[@"Territory"]=self.stampTerritory;

    if(self.stampRepManagerName)
        dict[@"Rep_Manager"]=self.stampRepManagerName;

    if(self.stampRssName)
        dict[@"RSS_Name"]=self.stampRssName;

    if(self.repFirstName)
        dict[@"Rep_First_Name"]=self.repFirstName;

    if(self.repLastName)
        dict[@"Rep_Last_Name"]=self.repLastName;

    if(self.repMiddleName)
        dict[@"Rep_Middle_Name"]=self.repMiddleName;

    if(self.stampAddressLine1)
        dict[@"Address_Line_1"]=self.stampAddressLine1;

    if(self.stampAddressLine2)
        dict[@"Address_Line_2"]=self.stampAddressLine2;



    int maxItemIndexForUpdate=10;
    for(int i=1; i <=maxItemIndexForUpdate; i++ ){
        AGNRequestFormItem * item = [self itemForOrdinal:i];
        if(item){
            NSString *productString = [self upsertProductKeyForIndex:i];
            NSString *questionString = [self upsertQuestionKeyForIndex:i];
            dict[productString] = item.productName;
            dict[questionString] = item.question;
        }
    }

  

    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];

    if (! jsonData) {
        log4Error(@"Unexpected error generationg Request Form JSON %@",[error userInfo]);
        return nil;
    }
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}



-(AGNRequestFormItem *)itemForOrdinal:(int)index{
    for(AGNRequestFormItem * item in self.items){
        if(item.ordinal.intValue==index)
            return item;
    }
    return nil;
}

- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict {
    NSString *formId =  [[jsonDict valueForKey:@"SFDCID"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"SFDCID"];
    NSString *status =  [[jsonDict valueForKey:@"status"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"status"];
    NSNumber *success =  [[jsonDict valueForKey:@"issuccess"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"issuccess"];
    if ([success boolValue]) {
        if (!self.salesForceId && formId) {
            self.salesForceId = formId;
        }
        if(status)
            self.status = status;
    }

}


- (void)initWithDictionary:(NSDictionary *)dict{
    NSDictionary * objectDict = dict;
    for(NSString *key in objectDict){
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }

        if([key isEqualToString:@"Close_Date__c"]) {
            self.closeDate = [NSDate agnDateFromRFC3339TimestampString:value];
        }
        else if([key isEqualToString:@"CreatedDate"]) {
            self.startDate = [NSDate agnDateFromRFC3339TimestampString:value];
        }else if([key isEqualToString:@"Mobile_Last_Modified_Date__c"]) {
            if (value && ![value isEqual:[NSNull null]]) {
                self.mobileLastUpdateTimestamp = [NSDate agnDateFromRFC3339TimestampString:value];
            }
        }
        else if([key isEqualToString:@"Mobile_Created_Date__c"]) {
            if (value && ![value isEqual:[NSNull null]]) {
                self.mobileCreateTimestamp = [NSDate agnDateFromRFC3339TimestampString:value];
            }
        }
        else if([key isEqualToString:@"Signature_Time_GMT__c"]) {
            if (value && ![value isEqual:[NSNull null]]) {
                self.signatureCaptureDate = [NSDate agnDateFromTimestampString:value];
            }
        }
        else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on call to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on call to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }

    int ordinal=1;

    [self.items removeAllObjects];

    for(int i=1; i <=10; i++){
        AGNRequestFormItem * item = [self itemForIndex:i withMoc:self.managedObjectContext andDictionary:objectDict];
        if(item){
            item.ordinal=[NSNumber numberWithInt:ordinal];
            ordinal++;
            item.form=self;
        }
    }
    [self buildRelationships];
}



- (AGNRequestFormItem *)itemForIndex:(int)index withMoc:(NSManagedObjectContext*)moc andDictionary:(NSDictionary*) dict{
    AGNRequestFormItem * item = nil;
    NSString * product = dict[[self productKeyForIndex:index]]!=[NSNull null]?dict[[self productKeyForIndex:index]]:nil;
    NSString * question = dict[[self questionKeyForIndex:index]]!=[NSNull null]?dict[[self questionKeyForIndex:index]]:nil;

    if(product && question){
        item = (AGNRequestFormItem *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNRequestFormItem" inManagedObjectContext:moc];
        item.question = question;
        item.productName = product;
    }
    return item;
}

-(NSString *) productKeyForIndex:(int)index{
    return [NSString stringWithFormat:@"Product_Name_%d__c",index];
}

-(NSString *) questionKeyForIndex:(int)index{
    if(index==1)
        return @"Question__c";
    return [NSString stringWithFormat:@"Question_%d__c",index];
}

-(NSString *) upsertProductKeyForIndex:(int)index{
    return [NSString stringWithFormat:@"Product_Name_%d",index];
}

-(NSString *) upsertQuestionKeyForIndex:(int)index{
    if(index==1)
        return @"Question";
    return [NSString stringWithFormat:@"Question_%d",index];
}

- (BOOL)activeEntry{
    return NO;
}

-(BOOL)hasNewStatus{
    return [self.status isEqualToString:kAGNRequestFormStatusNew];
}

-(NSString*)rssName{
    if(self.assignedTo)
        return self.assignedTo;
    if(self.stampRssName)
        return self.stampRssName;
    if(self.rss)
        return self.rss.name;
    return nil;

}


- (NSString*)statusString {
    if (self.status) {
        NSMutableString * result = [self.status mutableCopy];
        if ([self isODR] && self.rssName) {
            [result appendString:@" ("];
            [result appendString:self.rssName];
            [result appendString:@")"];
        }
        return result;
    }
    else
        return @"Unknown Status";
}

- (NSString*)formTitle {
    if ([kAGNRequestFormTypeMIR isEqualToString:self.type])
        return [kAGNRequestFormTitleMIR uppercaseString];
    
    if ([kAGNRequestFormTypeODR isEqualToString:self.type])
        return [kAGNRequestFormTitleODR uppercaseString];
    
    return @"UNKNOWN FORM TYPE";
}

-(BOOL)isMIR{
    return [self.type isEqualToString:kAGNRequestFormTypeMIR];
}


-(BOOL)isODR{
    return [self.type isEqualToString:kAGNRequestFormTypeODR];
}

- (NSAttributedString *)formattedTypeAndStatus {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    
    NSDictionary * heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    NSDictionary * romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    NSString * type = self.type;
    if (!type)
        self.type = @"???";
    
    
    NSMutableAttributedString * formattedString = [[NSMutableAttributedString alloc] initWithString:self.type attributes:heavyAttributes];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@" - " attributes:romanAttributes]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:self.statusString attributes:romanAttributes]];
    
    return formattedString;
}


- (NSString *)formattedRepName {
    if(self.salesRep){
        NSString * result = self.salesRep.formattedName;
        return result ? result : @"UNKNOWN";
    }
    else
        return [self formattedRepNameStamped];
    
}

- (NSString *)formattedRepNameStamped {

    NSString *repName = self.repLastName ? [self.repLastName uppercaseString] : @"UNKNOWN";
    if (self.repFirstName) {
        repName = [repName stringByAppendingFormat:@", %@", [self.repFirstName uppercaseString]];
    }

    return repName;
}
- (void)stampComplianceFields {
    AGNSalesRep *rep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    if(rep){
        self.repFirstName = [rep.firstName copy];
        self.repLastName = [rep.lastName copy];
        self.repMiddleName = [rep.middleName copy];
        self.stampRepManagerName = [rep.managerName copy];
        self.stampSalesTeam = [[AGNAppDelegate sharedDelegate].loggedInSalesRep.salesTeamName copy];
        self.stampTerritory = [[AGNAppDelegate sharedDelegate].loggedInSalesRep.territoryName copy];

    }
    if (self.address) {
        self.stampAddressLine1 = [self.address.line1 copy];
        self.stampAddressLine2 = [self.address.line2 copy];
        self.stampAddressLine3 = [self.address.line3 copy];
        self.stampAddressCity = [self.address.city copy];
        self.stampAddressCountry = @"USA";
        self.stampAddressState = [self.address.usState copy];
        self.stampAddressZip = [self.address.zip copy];
    }
    if (self.account) {
        self.stampHCPFirstName = [self.account.firstName copy];
        self.stampHCPLastName = [self.account.lastName copy];
        self.stampHCPMiddleName = [self.account.middleName copy];
        self.stampHCPMDMID = [self.account.mdmId copy];
        self.stampPhysicianSpecialty = [self.account.primarySpecialty copy];
        self.stampProfessionalDesignation = [self.account.professionalDesignation copy];
        AGNLicense *license = [self.account samplingLicenseForAddress:self.address];
        if (license) {
            self.stampLicenseExpirationDate = [license.expirationDate copy];
            self.stampLicenseState = [license.usState copy];
            self.stampLicenseNumber = [license.licenseNumber copy];
        }
    }
    if(self.rss)
        self.stampRssName=self.rss.name;
    
}

-(NSString *)description{
    return [NSString stringWithFormat:@"RequestForm(%@,%@) SFDCID:%@ GUID:%@",self.type,self.status,self.salesForceId,self.guid];
}

-(NSString *)singleLineStreetString{
    if(self.address){
        return [self.address singleLineStreetString];
    }
    return [self singleLineStreetStringStamped];
}

- (NSString *)singleLineStreetStringStamped {
    NSMutableString *str = [[NSMutableString alloc] initWithString:(self.stampAddressLine1 ? self.stampAddressLine1 : @"")];
    if (self.stampAddressLine2.length > 0) {
        [str appendFormat:@", %@", self.stampAddressLine2];
    }
    if (self.stampAddressLine3.length > 0) {
        [str appendFormat:@", %@", self.stampAddressLine3];
    }
    return str;
}

-(NSString *)cityStateZipFormattedString{
    if(self.address){
        return [self.address cityStateZipFormattedString];
    }
    return [self cityStateZipFormattedStringStamped];
}

- (NSString *)cityStateZipFormattedStringStamped {
    NSMutableString *str = [[NSMutableString alloc] init];
    if (self.stampAddressCity || self.stampAddressState || self.stampAddressZip) {
        [self appendCityStateZipStringTo:str];
    }
    return str;
}


- (void)appendCityStateZipStringTo:(NSMutableString *)str {
    if (self.stampAddressCity.length > 0) {
        [str appendFormat:@"%@, ", self.stampAddressCity];
    }
    if (self.stampAddressState.length > 0) {
        [str appendFormat:@"%@ ", self.stampAddressState];
    }
    if (self.stampAddressZip.length > 0) {
        [str appendFormat:@"%@", self.stampAddressZip];
    }
}

-(NSString *)formattedName{
    if(self.account){
        return [self.account formattedName];
    }
    return [self formattedNameStamped];
}

- (NSString *)formattedNameStamped {

    NSString *name = self.stampHCPLastName ? [self.stampHCPLastName uppercaseString] : @"UNKNOWN";
    if (self.stampHCPFirstName) {
        name = [name stringByAppendingFormat:@", %@", [self.stampHCPFirstName uppercaseString]];
    }

    return name;
}

-(NSString *)professionalDesignation{
    if(self.account){
        return [self.account professionalDesignation];
    }
    return self.stampProfessionalDesignation;
}

- (NSAttributedString *)nameAddressLabel{
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightObliqueFont = [UIFont fontWithName:@"Avenir-LightOblique" size:16];
    UIFont *mediumFont = [UIFont fontWithName:@"Avenir-Medium" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *lightObliqueAttributes = @{ NSFontAttributeName : lightObliqueFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *mediumAttributes = @{ NSFontAttributeName : mediumFont, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:[self formattedName] attributes:boldAttributes];
    if ([self professionalDesignation ].length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)",[self  professionalDesignation]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:lightObliqueAttributes]];
    }
    NSString *addressString = [NSString stringWithFormat:@"\n%@",[self singleLineStreetString ]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString: addressString attributes:mediumAttributes]];
    NSString *cityStateZipString = [NSString stringWithFormat:@"\n%@",[self cityStateZipFormattedString]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:cityStateZipString attributes:mediumAttributes]];
    return formattedString;
}

- (NSString *)singleLineFormattedAddressString {
    if(self.address)
        return self.address.singleLineFormattedString;
    
    NSMutableString *str = [[NSMutableString alloc] initWithString:(self.stampAddressLine1 ? self.stampAddressLine1 : @"")];
    if (self.stampAddressLine2.length > 0) {
        [str appendFormat:@", %@", self.stampAddressLine2];
    }
    if (self.stampAddressLine3.length > 0) {
        [str appendFormat:@", %@", self.stampAddressLine3];
    }
    if (self.stampAddressCity || self.stampAddressState || self.stampAddressZip) {
        [str appendString:@", "];
        [self appendCityStateZipStringTo:str];
    }
    return str;
}

- (NSMutableAttributedString *)attributedDoctorNameDesignationAndSpecialty {

    if(self.account)
        return [self.account attributedDoctorNameDesignationAndSpecialty];

    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [self attributedDoctorNameAndDesignation];

    if(self.stampPhysicianSpecialty){
        NSAttributedString *specialty = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" - %@ ", [self.stampPhysicianSpecialty uppercaseString]] attributes:romanAttributes];

        [formattedString appendAttributedString:specialty];
    }
    return formattedString;
}

- (NSMutableAttributedString *)attributedDoctorNameAndDesignation {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];

    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };

    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];


    NSAttributedString *doctorName = [[NSAttributedString alloc] initWithString:[self formattedName] attributes:heavyAttributes];

    [formattedString appendAttributedString:doctorName];

    if(self.professionalDesignation){
        NSAttributedString *designation = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" - %@", [self.professionalDesignation uppercaseString]] attributes:romanAttributes];

        [formattedString appendAttributedString:designation];
    }

    return formattedString;
}

- (NSString *)doctorNameAndDesignation {
    NSString *doctorNameAndDesignation = [self formattedName];
    if (self.professionalDesignation) {
        doctorNameAndDesignation = [doctorNameAndDesignation stringByAppendingFormat:@" - %@", [self.professionalDesignation uppercaseString]];
    }
    return doctorNameAndDesignation;
}

- (NSAttributedString *)hcpDetailDescription {
    return [self formattedTypeAndStatus];
}


@end
