//
//  AGNCallDetail.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNCall;

@interface AGNCallDetail : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * callSalesForceId;
@property (nonatomic, retain) NSString * detailPositionSalesForceId;
@property (nonatomic, retain) NSNumber * position;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * guid;
@property (nonatomic, retain) NSString * productDetailed;
@property (nonatomic, retain) AGNCall *call;
@property (nonatomic, retain) AGNDetailPosition *detailPosition;
@property (nonatomic, retain) NSNumber * toBeDeletedFlag;

// This property is not set locally, only comes down the pipe
// It should be used for display purposes if we fail to establish relation to AGNDetailPosition
@property (nonatomic, retain) NSString * brand; 

-(void)decrementPosition;
-(void)incrementPosition;
-(NSString *)displayString;

- (void)stampComplianceFields;

-(BOOL)isValidForDate:(NSDate *)date;

@end
