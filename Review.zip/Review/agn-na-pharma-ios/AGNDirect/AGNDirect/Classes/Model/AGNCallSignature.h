//
//  AGNCallSignature.h
//  AGNDirect
//
//  Created by Mark Wells on 10/17/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface AGNCallSignature : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSString * base64EncodedImage;
@property (nonatomic, retain) NSString * callSalesForceId;
@property (nonatomic, retain) NSString * guid;

@end
