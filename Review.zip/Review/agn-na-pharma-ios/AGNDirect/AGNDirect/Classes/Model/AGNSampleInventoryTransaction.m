//
//  AGNSampleInventoryTransaction.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSampleInventoryTransaction.h"
#import "AGNSampleInventoryTransactionLine.h"
#import "AGNCategoryHeaders.h"
#import "NSManagedObjectContext+DDSFExtensions.h"

//AGN_LOG_LEVEL(AGNSampleInventoryTransaction, DEBUG_INT)

@implementation AGNSampleInventoryTransaction

static NSDictionary *fieldMapping = nil;

@dynamic acceptedBy;
@dynamic acceptedBySalesForceId;
@dynamic actualReceivedDate;
@dynamic expectedReceiveDate;
@dynamic from;
@dynamic fromSalesForceId;
@dynamic guid;
@dynamic inventoryDate;
@dynamic mobileCreateTimestamp;
@dynamic mobileLastUpdateTimestamp;
@dynamic returnTo;
@dynamic salesForceId;
@dynamic salesTeamId;
@dynamic sampleInventoryTransactionLines;
@dynamic sfdcCreatedDate;
@dynamic shipmentDate;
@dynamic shipmentId;
@dynamic status;
@dynamic territoryName;
@dynamic to;
@dynamic toSalesForceId;
@dynamic trackingReason;
@dynamic trackingNumber;
@dynamic transactionType;
@dynamic transactionSubtype;
@dynamic transferAuthorizationNumber;
@dynamic returnDate;

@synthesize undoJSONRepresentation=_undoJSONRepresentation;
@synthesize deleteOnRevert;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Class initialization
//------------------------------------------------------------------------------

+(void)initialize{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"LastModifiedDate" : @"returnDate",
    @"Accepted_By" : @"acceptedBySalesForceId",
    @"Act_Rec_Date" : @"actualReceivedDate",
    @"CreatedDate" : @"sfdcCreatedDate",
    @"Exp_Rec_Date" : @"expectedReceiveDate",
    @"userSFDCId" : @"fromSalesForceId",
    @"GUID" : @"guid",
    @"Inventory_Date" : @"inventoryDate",
    @"Transaction_Type" : @"transactionType",
    @"Transaction_Subtype" : @"transactionSubtype",
    @"Sales_Team" : @"salesTeamId",
    @"Shipment_Date" : @"shipmentDate",
    @"Shipment_ID" : @"shipmentId",
    @"Status" : @"status",
    @"To" : @"toSalesForceId",
    @"Tracking_Number" : @"trackingNumber",
    @"Tracking_Reason" : @"trackingReason",
    @"Transfer_Authorization" : @"transferAuthorizationNumber",
    @"Return_To" : @"returnTo",
    @"MobileLastModifiedDate" : @"mobileLastUpdateTimestamp",
    @"MobileCreatedDate" : @"mobileCreateTimestamp"
    };
    
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark AGNModelProtocol methods
//------------------------------------------------------------------------------

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}
- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }
    objectDict = [AGNSyncManager dictionaryWithStandardizedKeysFrom:objectDict];
    self.acceptedBy = nil;
    self.acceptedBySalesForceId = nil;
    self.actualReceivedDate = nil;
    for(NSString *key in objectDict){
        if([key isEqualToString:@"Act_Rec_Date"]) {
            self.actualReceivedDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else if([key isEqualToString:@"LastModifiedDate"]) {
            self.returnDate = [NSDate agnDateFromRFC3339TimestampString:objectDict[key]];
        }
        else if([key isEqualToString:@"Exp_Rec_Date"]) {
            self.expectedReceiveDate = [NSDate agnDateFromString:objectDict[key]];
        } 
        else if([key isEqualToString:@"Inventory_Date"]) {
            self.inventoryDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else if([key isEqualToString:@"Shipment_Date"]) {
            self.shipmentDate = [NSDate agnDateFromString:objectDict[key]];
        }
        else if ([key isEqualToString:@"From"]) {
            self.fromSalesForceId = [objectDict[key] isEqual:[NSNull null]]?nil:objectDict[key];
        }
        else if([key isEqualToString:@"CreatedDate"]) {
            self.sfdcCreatedDate = [NSDate agnDateFromRFC3339TimestampString:objectDict[key]];
        }
        else if([key isEqualToString:@"MobileLastModifiedDate"]) {
            self.mobileLastUpdateTimestamp = [NSDate agnDateFromRFC3339TimestampString:objectDict[key]];
        }
        else if([key isEqualToString:@"MobileCreatedDate"]) {
            self.mobileCreateTimestamp = [NSDate agnDateFromRFC3339TimestampString:objectDict[key]];
        }
        else if([key isEqualToString:@"SampleInventoryTransaction_Lines"]) {
            NSArray *sitlJSONArray = [objectDict[key] isEqual:[NSNull null]]?nil:(NSArray *)objectDict[key];
            for (NSDictionary *sitlDict in sitlJSONArray) {
                AGNSampleInventoryTransactionLine *sitl;
                NSString *sitlID;
                // Get either the SFDC ID or GUID of the object
                sitlID = [[sitlDict objectForKey:@"Id"] isEqual:[NSNull null]]?nil:[sitlDict objectForKey:@"Id"];
                if (sitlID) {
                    // Try to find the corresponding object in CoreData by it's salesForceId
                    sitl = (AGNSampleInventoryTransactionLine *)[self.managedObjectContext ddsf_objectOfType:@"AGNSampleInventoryTransactionLine" forId:sitlID];
                }
                else {
                    sitlID = [sitlDict objectForKey:@"GUID"];
                    // Try to find the corresponding object in CoreData by it's GUID
                    if (sitlID) {
                        sitl = (AGNSampleInventoryTransactionLine *)[self.managedObjectContext ddsf_objectOfType:@"AGNSampleInventoryTransactionLine" forGuid:sitlID];
                    }
                }
                // If not there, create it
                if (!sitl) {
                    sitl = (AGNSampleInventoryTransactionLine *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryTransactionLine" inManagedObjectContext:self.managedObjectContext];
                }
                // Initialize (or update) the object from the dictionary
                [sitl initWithDictionary:sitlDict];
                // Update the object with it's owning Call
                sitl.sampleInventoryTransaction = self;
                sitl.sampleInventoryTransactionSalesForceId = self.salesForceId;
            }
        }
        else{
            NSString *objectKey = fieldMapping[key];
            if(objectKey) // if unexpected field, skip it
            {
                if ([objectDict[key] isEqual:[NSNull null]]) {
                    log4Trace(@"Setting %@ on SIT to nil",objectKey);
                    [self setValue:nil forKey:objectKey];
                }
                else {
                    log4Trace(@"Setting %@ on SIT to %@",objectKey,objectDict[key]);
                    [self setValue:objectDict[key] forKey:objectKey];
                }
            }
        }
    }
    if (self.returnDate) {
        if (self.mobileLastUpdateTimestamp) {
            self.returnDate = self.mobileLastUpdateTimestamp;
        }
    }
    if (self.mobileLastUpdateTimestamp) {
        self.sfdcCreatedDate = self.mobileLastUpdateTimestamp;
    }
    [self buildRelationships];
}

- (void)buildRelationships {
    if (self.acceptedBySalesForceId && !self.acceptedBy) {
        self.acceptedBy = (AGNSalesRep *)[self.managedObjectContext ddsf_objectOfType:@"AGNSalesRep" forId:self.acceptedBySalesForceId];
    }
    if (self.fromSalesForceId && !self.from) {
        self.from = (AGNSalesRep *)[self.managedObjectContext ddsf_objectOfType:@"AGNSalesRep" forId:self.fromSalesForceId];
    }
    if (self.toSalesForceId && !self.to) {
        self.to= (AGNSalesRep *)[self.managedObjectContext ddsf_objectOfType:@"AGNSalesRep" forId:self.toSalesForceId];
    }
}

- (NSString *)jsonRepresentationForUpdate {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSMutableString *result = [NSMutableString stringWithString:@"{"];
//    [result appendFormat:@"\"toBeDeleted\": %@,", [self.toBeDeletedFlag boolValue] ? @"true" : @"false"];
    [fieldMapping enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL*stop) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        id prop = [self performSelector:sel_getUid([((NSString *)value) cStringUsingEncoding:NSUTF8StringEncoding])];
#pragma clang diagnostic pop
        if ([((NSString *)value) isEqualToString:@"toSalesForceId"] && [self isInboundTransfer]) {
            // Avoids a restriction in SFDC that does not permit the To
            // field to be the same as the logged in user (which of course
            // it is on an inbound transfer) - do not send
        }
        else if ([((NSString *)value) isEqualToString:@"returnDate"]) {
            // ignore - this is not a field in SFDC
        }
        else if ([((NSString *)value) isEqualToString:@"expectedReceiveDate"]) {
            if (self.expectedReceiveDate) {
                [result appendFormat:@"\"%@\":\"%@\",",key, [self.expectedReceiveDate agnStringFromDate]];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"actualReceivedDate"]) {
            if (self.actualReceivedDate) {
                [result appendFormat:@"\"%@\":\"%@\",",key, [self.actualReceivedDate agnStringFromDate]];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"transferAuthorizationNumber"]) {
            if (self.transferAuthorizationNumber) {
                [result appendFormat:@"\"%@\":\"%@\",",key, [[self.transferAuthorizationNumber uppercaseString] agnEscapedString]];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"inventoryDate"]) {
            if (self.inventoryDate) {
                [result appendFormat:@"\"%@\":\"%@\",",key, [self.inventoryDate agnStringFromDate]];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"mobileLastUpdateTimestamp"]) {
            if (self.mobileLastUpdateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileLastModifiedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if ([((NSString *)value) isEqualToString:@"mobileCreateTimestamp"]) {
            if (self.mobileCreateTimestamp) {
                NSTimeZone *local = [df timeZone];
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [df setTimeZone:gmt];
                NSString *timeStamp = [df stringFromDate:prop];
                [result appendFormat:@"\"MobileCreatedDate\": \"%@\",", timeStamp];
                [df setTimeZone:local];
            }
        }
        else if ([prop isKindOfClass:[NSNumber class]]) {
            [result appendFormat:@"\"%@\": %@,",key, prop];
        }
        else if ([prop isKindOfClass:[NSString class]]) {
            [result appendFormat:@"\"%@\": \"%@\",",key, [prop agnEscapedString]];
        }
        else {
            if (prop) {
                [result appendFormat:@"\"%@\": \"%@\",",key, prop];
            }
        }
    }];
    if ([self.sampleInventoryTransactionLines count] > 0) {
        [result appendString:@"\"SampleInventoryTransaction_Lines\" : ["];
        for (AGNSampleInventoryTransactionLine *sitl in self.sampleInventoryTransactionLines) {
            [result appendFormat:@" %@,", [sitl jsonRepresentationForUpdate]];
        }
        result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
        [result appendString:@"],"];
    }
    result = [[result stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@", "]] mutableCopy];
    [result appendString:@"}"];
    return result;
}

- (void)updateSFDCIDsFromJSON:(NSDictionary *)jsonDict {
    NSString *sitGUID =  [[jsonDict valueForKey:@"GUID"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"GUID"];
    NSString *sitId =  [[jsonDict valueForKey:@"Id"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"Id"];
    if ([self.guid isEqualToString:sitGUID]) {
        if (!self.salesForceId && (id)sitId != [NSNull null]) {
            self.salesForceId = sitId;
        }
    }
    if ([jsonDict valueForKey:@"SampleInventoryTransaction_Lines"] != [NSNull null]) {
        NSArray *sitls =  [[jsonDict valueForKey:@"SampleInventoryTransaction_Lines"]isEqual:[NSNull null]]?nil:[jsonDict valueForKey:@"SampleInventoryTransaction_Lines"];
        for (NSDictionary *dict in sitls) {
            NSString *sitlGUID =  [[dict valueForKey:@"GUID"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"GUID"];     
            NSString *sitlId =  [[dict valueForKey:@"Id"]isEqual:[NSNull null]]?nil:[dict valueForKey:@"Id"];
            [self.sampleInventoryTransactionLines enumerateObjectsUsingBlock:^(id obj, BOOL*stop) {
                AGNSampleInventoryTransactionLine *sitl = (AGNSampleInventoryTransactionLine *)obj;
                if ([sitl.guid isEqualToString:sitlGUID]) {
                    if (!sitl.salesForceId && (id)sitlId != [NSNull null]) {
                        sitl.salesForceId = sitlId;
                    }
                    *stop = YES;
                }
            }];
        }
    }
}

- (void)setUndoRepresentation {
    self.undoJSONRepresentation = [self jsonRepresentationForUndo];
}

- (void)clearUndoRepresentation {
    self.undoJSONRepresentation = nil;
}

- (NSString *)jsonRepresentationForUndo {
    return [self jsonRepresentationForUpdate];
}

- (void)undoWithDictionary:(NSDictionary *)dict {
    [self.sampleInventoryTransactionLines enumerateObjectsUsingBlock:^(id obj, BOOL *stop) {
        AGNSampleInventoryTransactionLine *sitl = (AGNSampleInventoryTransactionLine *)obj;
        [sitl revertInventoryQuantityUpdateForTransaction:self];
    }];
    [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:self];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public methods
//------------------------------------------------------------------------------

- (BOOL)isOutboundTransfer{
    return [self.transactionType isEqualToString:kOutboundTransferType];
}

-(BOOL) isInboundTransfer{
    return [self.transactionType isEqualToString:kInboundTransferType];
}

-(BOOL) isReturn {
    return [self.transactionType isEqualToString:kReturnType];
}

-(BOOL) isIncomingShipment{
    return [self.transactionType isEqualToString:kShipmentType];
}

-(BOOL) isMonthlyCount{
    return [self.transactionType isEqualToString:kInventoryCountType];
}

-(BOOL) isOpen{
    return [self.status isEqualToString:kOpenStatusType];
}

- (BOOL)isDraft {
    return ([self isOpen] && ([self isOutboundTransfer] || [self isReturn] || [self isMonthlyCount]));
}

-(NSString *)toRepDisplayString{
    if(!self.to)
        return NSLocalizedString(@"UNKNOWN",@"Display string on inventory landing if transfer to rep is null");
    return [NSString stringWithFormat:@"%@, %@",[self.to.lastName uppercaseString],[self.to.firstName uppercaseString]];
}

-(NSString *)fromRepDisplayString{
    if(!self.from)
        return NSLocalizedString(@"UNKNOWN",@"Display string on inventory landing if transfer from rep is null");
    if (self.from.firstName.length > 0) {
        return [NSString stringWithFormat:@"%@, %@",[self.from.lastName uppercaseString],[self.from.firstName uppercaseString]];
    } else {
        return self.from.lastName.uppercaseString;
    }
}

- (void)deleteDraft {
    if (![self.status isEqualToString:kOpenStatusType]) {
        log4Error(@"Cannot remove inventory transaction not in status Open: %@", self);
        return;
    }
    
    if (![self.transactionType isEqualToString:kReturnType] && ![self.transactionType isEqualToString:kOutboundTransferType]) {
        log4Error(@"Cannot remove inventory transaction that are not returns or outbound transfers: %@", self);
        return;        
    }
    
    NSManagedObjectContext * ctx = self.managedObjectContext;
 
    for (AGNSampleInventoryTransactionLine * line in self.sampleInventoryTransactionLines) {
        [ctx deleteObject:line];
    }
    
    [ctx deleteObject:self];
    
    NSError * error = nil;
    [ctx save:&error];
    if (error)
        log4Error(@"Got error deleting an inventory transaction: %@", error);
}

- (NSDate *)createdDate {
    return (self.mobileCreateTimestamp) ? self.mobileCreateTimestamp : self.sfdcCreatedDate;
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Utility methods
//------------------------------------------------------------------------------

- (BOOL)isInboundTransaction {
    return [self.transactionType isEqualToString:kInboundTransferType] || [self.transactionType isEqualToString:kShipmentType];
}

- (BOOL)isOutboundTransaction {
    return [self.transactionType isEqualToString:kOutboundTransferType] || [self.transactionType isEqualToString:kReturnType];
}

@end
