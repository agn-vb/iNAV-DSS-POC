//
//  AGNSampleInventoryLine.h
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNModelProtocol.h"

@class AGNProductSKU, AGNSalesRep, AGNSampleDrop, AGNSampleInventoryTransactionLine, AGNStorageUnit;

@interface AGNSampleInventoryLine : NSManagedObject <AGNModelProtocol>

@property (nonatomic, retain) NSDate * expiration;
@property (nonatomic, retain) NSString * lotNumber;
@property (nonatomic, retain) NSNumber * quantity;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSString * productSalesForceId;
@property (nonatomic, retain) NSString * salesRepSalesForceId;
@property (nonatomic, retain) NSString * storageUnitSalesForceId;
@property (nonatomic, retain) AGNProductSKU *product;
@property (nonatomic, retain) AGNSalesRep *salesRep;
@property (nonatomic, retain) NSSet *sampleDrops;
@property (nonatomic, retain) NSSet *sampleInventoryTransactionLines;
@property (nonatomic, retain) AGNStorageUnit *storageUnit;

- (BOOL)isExpired;
- (BOOL)canSample;
- (BOOL)canShip;
- (BOOL) hasSamplePermission;
@end

@interface AGNSampleInventoryLine (CoreDataGeneratedAccessors)


- (void)addSampleDropsObject:(AGNSampleDrop *)value;
- (void)removeSampleDropsObject:(AGNSampleDrop *)value;
- (void)addSampleDrops:(NSSet *)values;
- (void)removeSampleDrops:(NSSet *)values;

- (void)addSampleInventoryTransactionLinesObject:(AGNSampleInventoryTransactionLine *)value;
- (void)removeSampleInventoryTransactionLinesObject:(AGNSampleInventoryTransactionLine *)value;
- (void)addSampleInventoryTransactionLines:(NSSet *)values;
- (void)removeSampleInventoryTransactionLines:(NSSet *)values;


@end
