//
//  AGNSamplePermission.m
//  AGNDirect
//
//  Created by Mark Wells on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSamplePermission.h"
#import "AGNProductSKU.h"


@implementation AGNSamplePermission

static NSDictionary *fieldMapping = nil;

@dynamic salesForceId;
@dynamic salesForceProductId;
@dynamic salesForceSalesTeamId;
@dynamic salesForceSalesRepId;
@dynamic product;
@dynamic salesRep;


+(void)initialize{
    fieldMapping =
    @{
    @"Id" : @"salesForceId",
    @"Product__c" : @"salesForceProductId",
    @"Sales_Team__c": @"salesForceSalesTeamId",
    @"OwnerId": @"salesForceSalesRepId"
    };
}


+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}


- (void)initWithDictionary:(NSDictionary *)dict {
    NSDictionary *objectDict = [dict objectForKey:@"sobjectDetails"];
    if ([objectDict count] == 0) {
        objectDict = dict; //Handle initializing coming from revert operations in the update queue manager
    }

    for(NSString *key in objectDict){
        
        NSString *objectKey = fieldMapping[key];
        if(objectKey) // if unexpected field, skip it
        {
            id value = objectDict[key];
            BOOL isNull = [value isEqual:[NSNull null]];
            if ([key isEqualToString:@"Sales_Team__c"] &&!isNull && ![objectDict[key] isEqualToString:[[AGNAppDelegate sharedDelegate].loggedInSalesRep salesForceSalesTeamId]]) {
                //TODO: properly handle the error
                log4Error(@"A sample permission with ID %@ has a different sales to the current logged in user's (%@)  Sales Team SFDC ID", objectDict[@"Id"], [AGNAppDelegate sharedDelegate].loggedInSalesRep);
            }
            if ([objectDict[key] isEqual:[NSNull null]]) {
                log4Trace(@"Setting %@ on sample permission to nil",objectKey);
                [self setValue:nil forKey:objectKey];
            }
            else {
                log4Trace(@"Setting %@ on sample permission to %@",objectKey,objectDict[key]);
                [self setValue:objectDict[key] forKey:objectKey];
            }
        }
    }
}

@end
