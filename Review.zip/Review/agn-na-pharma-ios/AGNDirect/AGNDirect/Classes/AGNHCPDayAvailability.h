//
//  AGNHCPDayAvailability.h
//  TestApp
//
//  Created by Adam McLain on 10/18/12.
//  Copyright (c) 2012 AdamMcLain. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGNHCPDayAvailability : NSObject

@property (strong, nonatomic) NSDate *startTime;
@property (strong, nonatomic) NSDate *endTime;
@property (strong, nonatomic) NSString *day;

- (BOOL)isUnavailable;
- (void)setUnavailable;

@end
