//
//  AGNCurrentInventoryViewController.h
//  AGNDirect
//
//  Created by Paul Gambill on 8/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNViewController.h"

@interface AGNCurrentInventoryViewController : AGNViewController
@property (nonatomic, strong) AGNSalesRep *salesRep;
@property (weak, nonatomic) IBOutlet UILabel *sampleNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *expirationLabel;
@property (weak, nonatomic) IBOutlet UIImageView *sampleNameImage;
@property (weak, nonatomic) IBOutlet UIImageView *expiresImage;
@property (weak, nonatomic) IBOutlet UILabel *quantityLabel;
@property (weak, nonatomic) IBOutlet UIImageView *quantityImage;

@property (weak, nonatomic) IBOutlet UIButton *monthlyCountButton;

@end
