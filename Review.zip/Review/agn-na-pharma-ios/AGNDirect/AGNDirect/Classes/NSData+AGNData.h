//
//  NSData+AGNData.h
//  AGNDirect
//
//  Created by Mark Wells on 10/19/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (AGNData)

- (NSString *)agnBase64EncodedString;

@end
