//
//  AGNAddAddressViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNAddAddressViewController.h"
#import "AGNTableView.h"
#import "AGNTextFieldCell.h"
#import "AGNTableViewHeader.H"
#import "AGNAccount.h"
#import "AGNAddress.h"
#import "AGNChooseStateCell.h"
#import "AGNZipCode.h"
#import "AGNTransientStateWrapper.h"
#import "UITextField+NSIndexPath.h"

#define MAX_LEN    128

@interface AGNAddAddressViewController ()

@property (nonatomic, strong, readwrite) AGNTableView *tableView;
@property (nonatomic, strong) NSMutableArray *values;
@property (nonatomic, strong) NSMutableArray *textFields;
@property (nonatomic, strong) UITextField *lastActiveTextField;
@property (nonatomic, strong) UITextField *addressTypeTextField;
@property (nonatomic, strong) UITextField *stateTextField;

@property (nonatomic, strong) AGNSimplePopoverTableViewController *addressTypePopover;
@property (nonatomic, strong) AGNSimplePopoverTableViewController *statePopover;
@property (nonatomic, strong) NSArray * states;

@property CGFloat keyboardHeight;

@end

@implementation AGNAddAddressViewController
static NSArray *headerNames;
static NSArray *addressTypes;
@synthesize values=_values;
@synthesize textFields=_textFields;
@synthesize keyboardHeight=_keyboardHeight;
@synthesize states=_states;


static const int kHeight=144;



enum Sections {
    TypeSection = 0,
    OfficePhoneSection,
    Line1Section ,
    Line2Section,
    CitySection,
    StateSection,
    ZipSection,
    TotalSections
};

+(void)initialize{
    headerNames = @[@"Address Type",@"Office Phone",@"Address Line One",@"Address Line Two",@"City",@"State",@"Zip"];
    addressTypes = @[@"Office",@"Mailing",@"Other"];
}



- (NSMutableArray *)values{
    if(!_values){
        _values=  [[NSMutableArray alloc]initWithCapacity:TotalSections];
        for(int i=0; i < TotalSections; i ++){
            _values[i]=[NSNull null];
        }
    }
    return _values;
}

- (NSMutableArray *)textFields{
    if(!_textFields){
        _textFields=  [[NSMutableArray alloc]initWithCapacity:TotalSections];
        for(int i=0; i < TotalSections; i ++){
            _textFields[i]=[NSNull null];
        }
    }
    return _textFields;
}

- (id)init;
{
    AGNTableView *table = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    //table.tableFooterView = [[UIView alloc] init];
    self = [super init];
    if (self) {
        self.view = table;
        self.title = @"Add Address";
        table.delegate = self;
        table.dataSource = self;
        self.tableView = table;
        
        UIImage *normal = [[UIImage imageNamed:@"btn-smblue"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 4.0f, 2.0f)];
        UIImage *highlighted = [[UIImage imageNamed:@"btn-smblue-hi"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 3.0f, 2.0f)];
        
        UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(done:)];
        [done setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        [done setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
        
        UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancel:)];
        [cancel setBackgroundImage:normal forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        [cancel setBackgroundImage:highlighted forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
        
        [self.navigationItem setLeftBarButtonItem:cancel];
        [self.navigationItem setRightBarButtonItem:done];
        self.tableView.scrollEnabled = YES;
    }
    return self;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    if(!self.address.addressType)
        [self.textFields[0] becomeFirstResponder];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];

}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
     
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                 name:UIKeyboardDidHideNotification object:nil];

}

- (BOOL)validateValue:(id)value named:(NSString*)name required:(BOOL)required maxLen:(int)maxLen {
    if (value == [NSNull null]) {
        if (!required) {
            return YES;
        }
        else {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Missing Required Fields" message:[NSString stringWithFormat:@"%@ is Required", name] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
    }
    else {
        NSString * text = value;
        if (required && text.length == 0) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Missing Required Fields" message:[NSString stringWithFormat:@"%@ is Required", name] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
        else if (maxLen > 0 && text.length > maxLen) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Value Too Long" message:[NSString stringWithFormat:@"%@ may not exceed 128 characters", name] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
    }
    return YES;
}

//------------------------------------------------------------------------------
// MARK: - Bar Button Item Mehtods
//------------------------------------------------------------------------------
- (void)done:(id)sender {
    
    // Copy the latest values from controls
    for (int i = 0; i < self.textFields.count; i++) {
        NSString * value = ((UITextField*)self.textFields[i]).text;
        self.values[i] = value ? [value agnTrim] : [NSNull null];
    }
   
    
    if (![self validateValue:self.values[TypeSection] named:@"Type" required:YES maxLen:MAX_LEN]) {
        return;
    }
    
    if (![self validateValue:self.values[Line1Section] named:@"Line 1" required:YES maxLen:MAX_LEN]) {
        [self.textFields[Line1Section] becomeFirstResponder];
        return;
    }

    if (![self validateValue:self.values[Line2Section] named:@"Line 2" required:NO maxLen:MAX_LEN]) {
        [self.textFields[Line2Section] becomeFirstResponder];
        return;
    }
    
    if (![self validateValue:self.values[OfficePhoneSection] named:@"Office Phone" required:NO maxLen:MAX_LEN]) {
        [self.textFields[OfficePhoneSection] becomeFirstResponder];
        return;
    }

    if (![self validateValue:self.values[CitySection] named:@"City" required:YES maxLen:MAX_LEN]) {
        [self.textFields[CitySection] becomeFirstResponder];
        return;
    }
    
    if (![self validateValue:self.values[StateSection] named:@"State" required:YES maxLen:0]) {
        [self.textFields[StateSection] becomeFirstResponder];
        return;
    }
    
    if (![self validateValue:self.values[CitySection] named:@"Zip Code" required:YES maxLen:0]) {
        [self.textFields[ZipSection] becomeFirstResponder];
        return;
    }
    
    NSString * zip = self.values[ZipSection];
    NSArray *matchingZips = [[AGNDataManager defaultInstance]zipCodeRecordForZip:zip andState:self.values[StateSection]];
    if(!matchingZips || matchingZips.count < 1){
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Invalid Zip" message:@"Zip Code Not Recognized." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];
        [self.textFields[ZipSection]becomeFirstResponder];
        return;
    }
 
    [self saveAddress];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)cancel:(id)sender {
    log4Info(@"Cancelling address edit");
    [self.navigationController popViewControllerAnimated:YES];
}


//------------------------------------------------------------------------------
// MARK: - TableView Data Source
//------------------------------------------------------------------------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return TotalSections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *SingleFilterCellIdentifier = @"AGNTextFieldCell";
    
    AGNTextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:SingleFilterCellIdentifier];
    if (cell == nil) {
        cell = [[AGNTextFieldCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:SingleFilterCellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textField.delegate = self;
    cell.textField.keyboardType = UIKeyboardTypeDefault;
    cell.textField.indexPath = indexPath;
    if(indexPath.section==TotalSections-1){
        cell.textField.returnKeyType = UIReturnKeyDone;
    }else{
        cell.textField.returnKeyType = UIReturnKeyNext;
    }
    cell.textField.clearButtonMode = UITextFieldViewModeNever;
    cell.textField.text = [self convertNull:self.values[indexPath.section]];
    self.textFields[indexPath.section]=cell.textField;
    if(indexPath.section==TypeSection){
        self.addressTypeTextField=cell.textField;
    }
    if(indexPath.section==StateSection){
        self.stateTextField=cell.textField;
        if(!self.address){
            self.stateTextField.text = [self getDefaultState];
        }
    }
    
    if(indexPath.section==ZipSection || indexPath.section == OfficePhoneSection){
        cell.textField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    }
    
    return cell;
}

-(void)setAddress:(AGNAddress *)address{
    _address=address;
    self.title=NSLocalizedString(@"Edit Address", @"Add/Edit contacts title for edit");
    self.values[Line1Section]=[self convertNull:address.line1];
    self.values[Line2Section]=[self convertNull:address.line2];
    self.values[TypeSection]=[self convertNull:address.addressType];
    self.values[OfficePhoneSection]=[self convertNull:address.officePhone];
    self.values[CitySection]=[self convertNull:address.city];
    self.values[StateSection]=[self convertNull:address.usState];
    self.values[ZipSection]=[self convertNull:address.zip];

}


-(void)saveAddress{
    AGNAddress * address = self.address;
    if(!address){
        NSManagedObjectContext *moc = [AGNAppDelegate sharedDelegate].managedObjectContext;
        address  = (AGNAddress *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNAddress" inManagedObjectContext:moc];
        address.guid = [[NSUUID UUID] UUIDString];
        address.salesForceAccountId = self.account.salesForceId;
        address.account = self.account;
        [self.account addAddressesObject:address];
        address.notSynced=YES;
    }
    address.line1 =  [self convertNull:self.values[Line1Section]];
    address.line2 = [self convertNull:self.values[Line2Section]];
    address.officePhone = [self convertNull:self.values[OfficePhoneSection]];
    address.city = [self convertNull:self.values[CitySection]];
    address.usState = [self convertNull:self.values[StateSection]];
    address.zip = [[self convertNull:self.values[ZipSection]]agnTrim];
    address.addressType = [self convertNull:self.values[TypeSection]];
    log4Info(@"Saved address %@",address);
}

-(id)convertNull:id{
    if(id==[NSNull null])
        return nil;
    if(id==nil)
        return [NSNull null];
    else return id;
}

//-------------------------------------n-----------------------------------------
// MARK: - text field delegate
//------------------------------------------------------------------------------

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField==self.textFields[TypeSection]){
        [self.lastActiveTextField resignFirstResponder];
        [self showAddressTypePopover];
        return NO;
    }else if(textField==self.textFields[StateSection]){
        [self.lastActiveTextField resignFirstResponder];
        [self showStatePopover];
        return NO;
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    // so you can catch the contents on done without leaving the field
    self.lastActiveTextField = textField;
    if(self.keyboardHeight>0)
        [self keyboardWasShown:nil];
}

- (int)indexOfTextField:(UITextField *)textField{
    for(int i=0; i < [self.textFields count]; i++){
        if(textField==self.textFields[i])
            return i;
    }
    return -1;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    NSString *text = textField.text;
    int index = [self indexOfTextField:textField];
    if(index >= 0 && index < [self.values count]){
        self.values[index]=text;
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if(textField==self.addressTypeTextField)
        return NO;

        if(textField==self.textFields[OfficePhoneSection]){
            NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
            newString = [self stripCharecters:newString];
            
            NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
            [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
            
            NSNumber *phoneNumber;
            
            range = NSMakeRange(0, newString.length);
            
            [numberFormatter getObjectValue:&phoneNumber forString:newString range:&range error:nil];
            
            if ((newString.length > 0) && (phoneNumber == nil || range.length < newString.length)) {
                return NO;
            }
            
            NSString *strippedPhoneString = [self formatNumber:newString];
            
            if ([self stripCharecters:textField.text].length == 10 && strippedPhoneString.length == 10) {
                return NO;
            }
            
            textField.text = [self formatPhoneNumber:strippedPhoneString];
            
            return NO;
        }
    

    return YES;
}

//------------------------------------------------------------------------------
-(NSString *)formatPhoneNumber:(NSString *)strippedPhoneString {
    
    int length = strippedPhoneString.length;
    
    NSMutableString *formattedString = [[NSMutableString alloc] init];
    
    if (length <= 3) {
        [formattedString appendFormat:@"%@", strippedPhoneString];
    }
    
    if(length > 3)
    {
        [formattedString appendFormat:@"(%@)",[strippedPhoneString  substringToIndex:3]];
    }
    
    if (length > 3 && length < 6) {
        NSRange newRange = NSMakeRange(3, strippedPhoneString.length - 3);
        [formattedString appendFormat:@" %@", [strippedPhoneString substringWithRange:newRange]];
    }
    
    if(length >= 6)
    {
        NSRange newRange = NSMakeRange(3, 3);
        [formattedString appendFormat:@" %@", [strippedPhoneString substringWithRange:newRange]];
    }
    
    
    if (length > 6 && length <= 10) {
        NSRange newRange = NSMakeRange(6, strippedPhoneString.length - 6);
        [formattedString appendFormat:@"-%@", [strippedPhoneString substringWithRange:newRange]];
    }
    
    return formattedString;
}

-(NSString*)formatNumber:(NSString*)mobileNumber
{
    mobileNumber = [self stripCharecters:mobileNumber];
    
    int length = [mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
    }
    
    return mobileNumber;
}

-(NSString *)stripCharecters:(NSString*)mobileNumber
{
    static NSArray *forbiddenCharecters;
    if (!forbiddenCharecters) {
        forbiddenCharecters = @[@"(", @")", @" ", @"-", @"+"];
    }
    
    for (NSString *letter in forbiddenCharecters) {
        mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:letter withString:@""];
    }
    
    return mobileNumber;
}

//-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
//    return YES;
//}

-(BOOL)textFieldShouldReturn:(UITextField*)textField;
{
    int section = [self indexOfTextField:textField];
    if(section < 0)
        return YES;
    if(section>=TotalSections-1){
        [textField resignFirstResponder];
        [self done:nil];
        return YES;
    }else{
        UITextField *nextTextField = self.textFields[section+1];
        [nextTextField becomeFirstResponder];
        [textField resignFirstResponder];
    }
    return YES;
}





//------------------------------------------------------------------------------
// MARK: - Address Type Popover
//------------------------------------------------------------------------------



- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    if (self.addressTypePopover.popoverVisible) {
        [self.addressTypePopover dismissPopoverAnimated:NO];
        [self showAddressTypePopover];
    }
    
    if(self.statePopover.popoverVisible){
        [self.statePopover dismissPopoverAnimated:NO];
        [self showStatePopover];
    }
}

-(void)objectSelected:(NSInteger)selected {
    if(self.statePopover){
        AGNTransientStateWrapper *state = [self.states objectAtIndex:selected];
        self.values[StateSection] = state.abbreviation;
        self.stateTextField.text = state.abbreviation;
        [self setDefaultState:state.abbreviation];
        [self.statePopover dismissPopoverAnimated:YES];
        [self.stateTextField resignFirstResponder];
        [self.textFields[ZipSection] becomeFirstResponder];
        self.statePopover=nil;
        
    }else if(self.addressTypePopover){
        NSString * selectedType = [addressTypes objectAtIndex:selected];
        self.values[TypeSection] = selectedType;
        self.addressTypeTextField.text = selectedType;
        [self.addressTypePopover dismissPopoverAnimated:YES];
        [self.addressTypeTextField resignFirstResponder];
        [self.textFields[OfficePhoneSection] becomeFirstResponder];
        self.addressTypePopover=nil;
    }
}

- (void)showAddressTypePopover {
        self.addressTypePopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:@"Address Type"];
        self.addressTypePopover.viewController.modalInPopover = NO;
        self.addressTypePopover.viewController.modalPresentationStyle = UIModalPresentationCurrentContext;
        self.addressTypePopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"CellIdentifier";
            
            UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            [cell agnSetStyledSelectedBackground];
            
            UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
            NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNGreyMatter] };
            NSString *content = [addressTypes objectAtIndex:indexPath.row];;
            NSAttributedString * attributedContent = [[NSAttributedString alloc] initWithString:content attributes:heavyAttributes];

            cell.textLabel.attributedText = attributedContent;
            return cell;
        };
        
    
    self.addressTypePopover.objectArray = addressTypes;
    
    CGRect presentingRect = [self.tableView rectForHeaderInSection:1];
    presentingRect.origin.y -= presentingRect.size.height / 2;
    [self.addressTypePopover presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    
}

-(NSArray *)states{
    if(!_states){
        _states = [[AGNDataManager defaultInstance]getStates];
    }
    return _states;
}

-(int)rowForDefaultState{
    NSString * defaultState = [self getDefaultState];
    if(defaultState){
        for(int index=0; index < [self.states count]; index++){
            AGNTransientStateWrapper *state = self.states[index];
            if([state.abbreviation isEqualToString:defaultState])
                return index;
        }
    }
    return -1;
}

-(NSString *)getDefaultState{
   return [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultStateRestoreKey];
}

-(void)setDefaultState:(NSString *)state{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults setObject:state forKey:kDefaultStateRestoreKey];
}

- (void)showStatePopover {
    self.statePopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:@"Choose State"];
    self.statePopover.viewController.modalInPopover = NO;
    self.statePopover.viewController.modalPresentationStyle = UIModalPresentationCurrentContext;
    __weak typeof(self) weakSelf = self;

    self.statePopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        static NSString *CellIdentifier = @"StateCellIdentifier";
        
        AGNChooseStateCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[AGNChooseStateCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        [cell agnSetStyledSelectedBackground];
        
        AGNTransientStateWrapper *state = weakSelf.states[indexPath.row];
        cell.rightLabel.text = state.abbreviation;
        cell.leftLabel.text = state.fullName;
        return cell;
    };
    
    self.statePopover.objectArray = self.states;
    
    CGRect presentingRect = [self.tableView rectForHeaderInSection:StateSection];
    //presentingRect.origin.y -= presentingRect.size.height / 2;
    [self.statePopover presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    int row = [self rowForDefaultState];
    if(row>=0){
        NSIndexPath * indexPath = [NSIndexPath indexPathForRow:row inSection:0];
        [self.statePopover.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
    }
}


//------------------------------------------------------------------------------
// MARK: - TableView Delegate
//------------------------------------------------------------------------------

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    AGNTableViewHeader *header = [[AGNTableViewHeader alloc] init];
    header.leftLabel.text = [headerNames[section] uppercaseString];
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kAGNTableViewHeaderHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if(section==TotalSections-1)
        return 80.0f;
    else
        return 0.0f;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
  
    return [[UIView alloc]init];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.textFields[indexPath.section] becomeFirstResponder];
}

//------------------------------------------------------------------------------
// MARK: - KEYBOARD SCROLLING
//------------------------------------------------------------------------------

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:self.lastActiveTextField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        if(!info)
            keyboardHeight = self.keyboardHeight;
        else{
            keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
            self.keyboardHeight = keyboardHeight;
        }
    }
    else {
        if(!info)
            keyboardHeight = self.keyboardHeight;
        else{
            keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
            self.keyboardHeight = keyboardHeight;
        }
    }
    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardHeight-kHeight, 0.0);
    self.tableView.contentInset = contentInsets;
    self.tableView.scrollIndicatorInsets = contentInsets;
    
    
    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.tableView.frame;
    aRect.size.height -= (keyboardHeight+kHeight);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

-(NSIndexPath *)firstVisibleRow{
    NSArray* indexPaths = [self.tableView indexPathsForVisibleRows];
    NSArray* sortedIndexPaths = [indexPaths sortedArrayUsingSelector:@selector(compare:)];
    return (NSIndexPath*)[sortedIndexPaths objectAtIndex:0];
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    self.lastActiveTextField = nil;
    self.keyboardHeight=0.0;
    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];

    if(!self.statePopover){
        [UIView animateWithDuration:[animationTime doubleValue] animations:^{
            UIEdgeInsets contentInsets = UIEdgeInsetsZero;
            self.tableView.contentInset = contentInsets;
            self.tableView.scrollIndicatorInsets = contentInsets;
        }];
    }
    
}

-(void)setKeyboardHeight:(CGFloat)keyboardHeight{
    _keyboardHeight=keyboardHeight;
}

-(CGFloat)keyboardHeight{
    return _keyboardHeight;
}


@end
