//
//  UIColor+AGNColor.m
//  AGNDirect
//
//  Created by Adam McLain on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "UIColor+AGNColor.h"

@implementation UIColor (AGNColor)

+ (UIColor *)AGNColorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue; {
    return [UIColor colorWithRed:red/255.0f green:green/255.0f blue:blue/255.0f alpha:1.0f];
}

+ (UIColor *)AGNCobalt {
    return [UIColor AGNColorWithRed:131.0f green:142.0f blue:160.0f];
}

+ (UIColor *)AGNNorilskSneg {
    return [UIColor AGNColorWithRed:242.0f green:242.0f blue:242.0f];
}

+ (UIColor *)AGNSilberLining {
    return [UIColor AGNColorWithRed:230.0f green:230.0f blue:230.0f];
}

+ (UIColor *)AGNSecondGrayd {
    return [UIColor AGNColorWithRed:153.0f green:153.0f blue:153.0f];
}

+ (UIColor *)AGNDarkGray {
    return [UIColor AGNColorWithRed:178.0f green:178.0f blue:178.0f];
}

+ (UIColor *)AGNGreyMatter {
    return [UIColor AGNColorWithRed:102.0f green:102.0f blue:102.0f];
}

+ (UIColor *)AGNOrange {
    return [UIColor AGNColorWithRed:226.0f green:136.0f blue:66.0f];
}

+ (UIColor *)AGNNavbarChar {
    return [UIColor AGNColorWithRed:28.0f green:28.f blue:28.0f];
}

+ (UIColor *)AGNWAwawa {
    return [UIColor AGNColorWithRed:131.0f green:142.0f blue:160.0f];
}

+ (UIColor *)AGNPresentime {
    return [UIColor AGNColorWithRed:211.0f green:221.0f blue:229.0f];
}

+ (UIColor *)AGNEleventhHour {
    return [UIColor AGNColorWithRed:58.0f green:69.0f blue:97.0f];
}

+ (UIColor *)AGNHighliteWhite {
    return [UIColor whiteColor];
}

+ (UIColor *)AGNDropShadow {
    return [UIColor AGNColorWithRed:217.0f green:217.0f blue:217.0f];
}

+ (UIColor *)AGNWarny {
    return [UIColor AGNColorWithRed:223.0f green:0.0f blue:0.0f];
}

+ (UIColor *)AGNTangelo {
    return [UIColor AGNColorWithRed:226.0f green:136.0f blue:66.0f];
}


@end
