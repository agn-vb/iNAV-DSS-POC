//
//  AGNSyncStatusViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/15/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSyncStatusViewController.h"
#import "UIColor+AGNColor.h"
#import "UIFont+AGNFont.h"
#import "AGNGreyButton.h"
#import "AGNSyncManager.h"
#import "DDSFDownstreamSync.h"

@interface AGNSyncStatusViewController ()

@property (nonatomic, strong) UILabel * warningLabel;
@property (nonatomic, strong) UILabel * syncingLabel;
@end

static const int kHeight=140;
//static const float kWidthPercentage=.95;


@implementation AGNSyncStatusViewController

@synthesize progressView=_progressView;

- (void)setSyncStage:(AGNSyncStage)syncStage {    
    switch (syncStage) {
        case kAGNSyncStageUpsync:
            self.syncingLabel.text = NSLocalizedString(@"Sending changes...", @"Title for sending changes");
            self.cancelButton.hidden = NO;
            self.warningLabel.hidden = YES;
            break;

        case kAGNSyncStageReceive:
            self.syncingLabel.text = NSLocalizedString(@"Receiving data...", @"Title for receiving data");
            self.cancelButton.hidden = NO;
            self.warningLabel.hidden = YES;
            break;
            
        case kAGNSyncStageProcess:
            self.syncingLabel.text = NSLocalizedString(@"Processing data...", @"Title for processing data");
            self.cancelButton.hidden = YES;
            self.warningLabel.hidden = NO;
            break;
            
        case kAGNSyncStageRelate:
            self.syncingLabel.text = NSLocalizedString(@"Finalizing...", @"Title for building relationships");
            self.cancelButton.hidden = YES;
            self.warningLabel.hidden = NO;
            break;
    }
    
    self.progressView.progress = 0.0f;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

//-(int)modalWidth{
//    return (int)self.view.bounds.size.width*kWidthPercentage;
//}

-(int)modalHeight{
    return kHeight;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

    self.view.backgroundColor=[UIColor whiteColor];
    
    UIImageView * bar = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bar-bigblue"]];
    bar.translatesAutoresizingMaskIntoConstraints = NO;
    bar.contentMode = UIViewContentModeScaleToFill;
    [self.view addSubview:bar];

    self.syncingLabel = [[UILabel alloc] init]; 
    _syncingLabel.backgroundColor = [UIColor clearColor];
    _syncingLabel.translatesAutoresizingMaskIntoConstraints = NO;

    NSAttributedString *labelText = [[NSAttributedString alloc]initWithString:NSLocalizedString(@"Syncing...",@"Syncing...")];
    _syncingLabel.textColor = [UIColor whiteColor];
    _syncingLabel.attributedText = labelText;
    _syncingLabel.textAlignment = NSTextAlignmentCenter;
    _syncingLabel.font = [UIFont AGNAvenirHeavyFontWithSize:18];
    
    [self.view addSubview:_syncingLabel];
    
    self.progressView = [[UIProgressView alloc]initWithProgressViewStyle:UIProgressViewStyleDefault];
    self.progressView.translatesAutoresizingMaskIntoConstraints = NO;
    self.progressView.trackTintColor = [UIColor lightGrayColor];
    self.progressView.progressTintColor = [UIColor AGNOrange];
    self.progressView.progress = 0.0f;
    [self.view addSubview:self.progressView];

    self.cancelButton = [[AGNGreyButton alloc] init];
    self.cancelButton.translatesAutoresizingMaskIntoConstraints = NO;
    self.cancelButton.contentEdgeInsets = UIEdgeInsetsMake(0, 18, 0, 18);
    self.cancelButton.titleLabel.font = [UIFont AGNHelveticaNeueBold16];
    self.cancelButton.titleLabel.shadowOffset = CGSizeMake(0,-1);
    self.cancelButton.titleLabel.shadowColor = [UIColor blackColor];
    [self.cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
    [self.cancelButton addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.cancelButton];


    self.warningLabel = [[UILabel alloc] init];
    _warningLabel.backgroundColor = [UIColor clearColor];
    _warningLabel.translatesAutoresizingMaskIntoConstraints = NO;

    NSAttributedString *warningText = [[NSAttributedString alloc]initWithString:NSLocalizedString(@"IMPORTANT!  Do not interrupt until processing is complete.",@"Sync warning.")];
    _warningLabel.textColor = [UIColor AGNWarny];
    _warningLabel.attributedText = warningText;
    _warningLabel.textAlignment = NSTextAlignmentCenter;
    _warningLabel.font = [UIFont AGNAvenirHeavyFontWithSize:16];
    self.warningLabel.hidden = YES;
    [self.view addSubview:self.warningLabel];



    NSDictionary *constraintsViewsDictionary = @{ @"titleBar" : bar , @"title" : self.syncingLabel , @"progressBar" : self.progressView, @"cancel" : self.cancelButton , @"warning" :self.warningLabel};
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[titleBar]|" options:0 metrics:nil views:constraintsViewsDictionary]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-[title]-|" options:0 metrics:nil views:constraintsViewsDictionary]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.syncingLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:bar attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-20-[progressBar]-20-|" options:0 metrics:nil views:constraintsViewsDictionary]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[titleBar(==44)]-25-[progressBar]-14-[cancel(==28)]" options:0 metrics:nil views:constraintsViewsDictionary]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[titleBar(==44)]-25-[progressBar]-14-[warning(==28)]" options:0 metrics:nil views:constraintsViewsDictionary]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.cancelButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.warningLabel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];

    
    [self setTasksComplete:0 outOf:5];
}

-(void)viewWillAppear:(BOOL)animated{
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    [super viewWillAppear:animated];
    
    // Add notification listeners
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSyncProgress:) name:kDDSFNotificationSyncStageUpdated object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSyncProgress:) name:kDDSFNotificationSyncProgressUpdated object:nil];
    
}

- (void)viewDidDisappear:(BOOL)animated  {
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)updateSyncProgress:(NSNotification *)notification {
    DDSFDownstreamSync * sync = notification.sync;
    [self setSyncStage:sync.stage];
    [self setCompletionPercentage:sync.progress];
}

-(void)reset {
    [self setStatusText:NSLocalizedString(@"Preparing to sync..",@"Preparing to sync...")];
    self.warningLabel.hidden=YES;
    [self setCompletionPercentage:0];
}

-(void)setStatusText:(NSString *)statusText {
    NSAttributedString *attributedText = [[NSAttributedString alloc]initWithString:statusText];
    self.statusLabel.attributedText = attributedText;
}

-(void)setCompletionPercentage:(float)completion {
    [self.progressView setProgress:completion];
}

-(void)setTasksComplete:(int)tasksComplete outOf:(int)total {
    NSString *message = [NSString stringWithFormat:@"%@ %d %@ %d...", NSLocalizedString(@"Receiving",@"Receiving"),tasksComplete, NSLocalizedString(@"of", @"of"),total];
    [self setStatusText:message];
    [self setCompletionPercentage:((float)tasksComplete/(float)total)];
}

- (void)cancel:(id)sender {
    log4Info(@"SYNC CANCELED BY USER");
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNAbortSyncNotificationKey object:nil];
}

@end
