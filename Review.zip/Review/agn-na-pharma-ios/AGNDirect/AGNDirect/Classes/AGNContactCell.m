//
//  AGNContactCell.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNContactCell.h"

@implementation AGNContactCell

#define kContactCellMarginWidth 44.0f
#define kContactCellMarginHeight 7.0f

+ (CGFloat)heightForAttributedString:(NSAttributedString *)string withWidth:(CGFloat)width {
    CGFloat adjustedWidth = width - kContactCellMarginWidth * 2;
    CGSize maxSize = CGSizeMake(adjustedWidth, CGFLOAT_MAX);
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.numberOfLines = 0;
    label.attributedText = string;
    CGSize attributedRect = [label sizeThatFits:maxSize];
    
    return 17.0f + attributedRect.height + 3 * kContactCellMarginHeight +1.0f;
}

+ (CGFloat)heightForString:(NSString *)string withWidth:(CGFloat)width {
    CGFloat adjustedWidth = width - kContactCellMarginWidth * 2;
    CGSize maxSize = CGSizeMake(adjustedWidth, CGFLOAT_MAX);
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.numberOfLines = 0;
    label.text = string;
    CGSize attributedRect = [label sizeThatFits:maxSize];
    
    return 17.0f + attributedRect.height + 3 * kContactCellMarginHeight +1.0f;
}

@end
