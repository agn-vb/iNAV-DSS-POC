//
//  AGNSignatureImageTableViewCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/20/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNSignatureImageTableViewCell.h"

@implementation AGNSignatureImageTableViewCell

-(void)setClosedCallSignatureAcceptedMode:(NSString *)dateString{
    self.signatureDisplayView.hidden=YES;
    self.dottedLineLabel.hidden=NO;
    self.signatureAcceptedDateLabel.hidden=NO;
    self.signatureAcceptedLabel.hidden=NO;
    self.signatureAcceptedDateLabel.text=dateString;
}

-(void)setClosedCallNoSignatureMode{
    self.signatureDisplayView.hidden=YES;
    self.dottedLineLabel.hidden=YES;
    self.signatureAcceptedDateLabel.hidden=YES;
    self.signatureAcceptedLabel.hidden=YES;
}


-(void)setSignatureAcceptedMode:(UIImage *)image{
    [self setSignaturePendingMode];
    self.signatureDisplayView.image=image;
}

-(void)setSignaturePendingMode{
    self.signatureDisplayView.hidden=NO;
    self.dottedLineLabel.hidden=YES;
    self.signatureAcceptedDateLabel.hidden=YES;
    self.signatureAcceptedLabel.hidden=YES;
}


-(void)setSignatureCaptureMode{
    self.signatureDisplayView.hidden=YES;
    self.dottedLineLabel.hidden=YES;
    self.signatureAcceptedDateLabel.hidden=YES;
    self.signatureAcceptedLabel.hidden=YES;
}

@end
