//
//  UIFont+AGNFont.m
//  AGNDirect
//
//  Created by Adam McLain on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "UIFont+AGNFont.h"

@implementation UIFont (AGNFont)

+ (UIFont *)AGNAvenirHeavyFontWithSize:(CGFloat)size; {
    return [UIFont fontWithName:@"Avenir-Heavy" size:size];
}

+ (UIFont *)AGNAvenirBlackFontWithSize:(CGFloat)size; {
    return [UIFont fontWithName:@"Avenir-Black" size:size];
}

+ (UIFont *)AGNAvenirRomanFontWithSize:(CGFloat)size {
    return [UIFont fontWithName:@"Avenir-Roman" size:size];
}

+ (UIFont *)AGNAvenirLightFontWithSize:(CGFloat)size {
    return [UIFont fontWithName:@"Avenir-LightOblique" size:size];
}

+ (UIFont *)AGNHelveticaNeueBoldFontWithSize:(CGFloat)size {
    return [UIFont fontWithName:@"HelveticaNeue-Bold" size:size];
}

+ (UIFont *)AGNAvenirMedium16 {
    return [UIFont fontWithName:@"Avenir-Medium" size:16];
}

+ (UIFont *)AGNAvenirMedium21 {
    return [UIFont fontWithName:@"Avenir-Medium" size:21];
}

+ (UIFont *)AGNAvenirBlack21 {
    return [UIFont fontWithName:@"Avenir-Black" size:21];
}

+ (UIFont *)AGNAvenirBlack16 {
    return [UIFont fontWithName:@"Avenir-Black" size:16];
}

+ (UIFont *)AGNAvenirHeavy16 {
    return [UIFont fontWithName:@"Avenir-Heavy" size:16];
}

+ (UIFont *)AGNAvenirHeavy14 {
    return [UIFont fontWithName:@"Avenir-Heavy" size:14];
}

+ (UIFont *)AGNAvenirRoman16 {
    return [UIFont fontWithName:@"Avenir-Roman" size:16];
}

+ (UIFont *)AGNAvenirRoman13 {
    return [UIFont fontWithName:@"Avenir-Roman" size:13];
}

+ (UIFont *)AGNHelveticaNeueBold16 {
    return [UIFont fontWithName:@"HelveticaNeue-Bold" size:16];
}

+ (UIFont *)AGNHelveticaNeueBold12 {
    return [UIFont fontWithName:@"HelveticaNeue-Bold" size:12];
}


@end
