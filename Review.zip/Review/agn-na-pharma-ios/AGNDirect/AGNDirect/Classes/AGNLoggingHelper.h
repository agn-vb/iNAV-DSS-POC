//
//  AGNLoggingHelper.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/2/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGNL4ProtectedRollingFileAppender.h"
#import <objc/message.h>



//------------------------------------------------------------------------------
// MARK: - Convenience Macros
//------------------------------------------------------------------------------


//  Example Usage:

//  AGN_LOG_LEVEL(AGNCallsViewController, INFO_INT)  - set logging for AGNCallsViewController to info level
//  AGN_LOG_GROUP_LEVEL(Controllers, INFO_INT)  - set logging for the named log group "Controllers" to info level
//  AGN_LOG_GROUP(AGNCallsViewController, Controllers) - add the class AGNCallsViewController to the named log group "Controllers"

//  To log a statement use log4Debug, log4Info, etc. declated in L4Logging.h


// macros to set log levels at load time : http://gcc.gnu.org/onlinedocs/gcc/Function-Attributes.html


#define AGN_LOG_GROUP(Class, Group) \
/* usage: AGN_LOG_GROUP(AGNCallsViewController, Controllers) */ \
__attribute__((constructor)) \
static void _class_ ## Class ## _add_to_log_group() { \
    [AGNLoggingHelper addClass:NSClassFromString(@#Class) \
                      toLogGroup:@#Group]; \
}

#define AGN_LOG_GROUP_LEVEL(Group, Level) \
/* usage: AGN_LOG_GROUP_LEVEL(Controllers, INFO_INT) */ \
__attribute__((constructor)) \
static void _group_ ## Group ## _set_group_level() { \
    [AGNLoggingHelper setLevel:[L4Level levelWithInt:Level] forLogGroup:@#Group]; \
}


#define AGN_LOG_LEVEL(Class, Level) \
/* usage: AGN_LOG_LEVEL(AGNCallsViewController, INFO_INT) */ \
__attribute__((constructor)) \
static void _class_ ## Class ## _set_class_level() { \
    [AGNLoggingHelper setLevel:[L4Level levelWithInt:Level] forClass:NSClassFromString(@#Class)]; \
}

#define log4Audit(message, ...)  log4LogAudit(L4_LOG([L4Level info], nil), message, ##__VA_ARGS__)

LOG4COCOA_EXTERN void log4LogAudit(id object, int line, const char *file, const char *method, SEL sel, L4Level *level, BOOL isAssertion,
                              BOOL assertion, id exception, id message, ...);



@interface AGNLoggingHelper : NSObject

+(void)setUpLogging;
+(NSString *)logsDirectory; 
+(void)setLevel:(L4Level *)level forClass:(Class)theClass;
+(void)addClass:(Class)theClass toLogGroup:(NSString *)groupName;
+(void)setLevel:(L4Level *)level forLogGroup:groupName;
+(NSString*)contentsOfLogs;
+(L4Logger*)auditLogger;

@end
