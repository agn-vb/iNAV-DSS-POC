//
//  AGNUpdateQueueManager.m
//  AGNDirect
//
//  Created by Mark Wells on 9/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  This is the class which handles sending local changes up to SFDC

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "AGNUpdateQueueManager.h"
#import "SFRestAPI.h"
#import "SFRestAPI+Blocks.h"
#import "RKRequestSerialization.h"
#import "AGNAppDelegate.h"


#define kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES 0
#define kAGN_DEBUG_FORCE_RETRY 0

#define kAGN_MAX_UPSYNC_RETRIES 5
#define kAGN_BASE_RETRY_INTERVAL 1 // 1 second

#define UNAUTHORIZED 401

// TODO: Document design - single threaded singleton queue manager
// Assumes running on the main thread (using app delegate moc)

@interface AGNUpdateQueueManager ()

@property (strong, nonatomic) NSMutableArray *queue;
@property (strong, nonatomic) AGNUpdateTransaction *transactionInProcess;
@property (assign, nonatomic) BOOL isProcessing; // This is for one transaction
@property (assign, nonatomic) BOOL isSyncing; // This is overall.
@property (strong, nonatomic) NSDictionary *targetEntityDescriptionMapping;
@property (assign, nonatomic) int retryCount;
@property (strong, nonatomic) NSTimer * mockTimer;

@end

@implementation AGNUpdateQueueManager

@synthesize queue = _queue;
@synthesize transactionInProcess = _transactionInProcess;
@synthesize isProcessing = _isProcessing;
@synthesize targetEntityDescriptionMapping = _targetEntityDescriptionMapping;
@synthesize retryCount = _retryCount;


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Initialization
//------------------------------------------------------------------------------

+ (AGNUpdateQueueManager *)defaultManager {
	static id singleton = nil;
	static dispatch_once_t pred;

	dispatch_once(
                  &pred,
                  ^{ singleton = [[self alloc] init]; }
                  );

	return singleton;
}

- (id)init {
    if (self = [super init]) {
        self.targetEntityDescriptionMapping = @{
                                                [NSNumber numberWithInt:AGNApexWrapperManageCall] : @"AGNCall",
                                                [NSNumber numberWithInt:AGNApexWrapperUpsertRequestForm] : @"AGNRequestForm",
                                                [NSNumber numberWithInt:AGNApexWrapperManageInventory] : @"AGNSampleInventoryTransaction",
                                                [NSNumber numberWithInt:AGNApexWrapperUpsertContact] : @"AGNContact",
                                                [NSNumber numberWithInt:AGNApexWrapperInsertAddress] : @"AGNAddress",
                                                [NSNumber numberWithInt:AGNApexWrapperUpsertSyncRecord] : @"AGNSalesRep",
                                                [NSNumber numberWithInt:AGNApexWrapperUpdateAddress] : @"AGNAddress",
                                                [NSNumber numberWithInt:AGNApexWrapperUpsertReprint] : @"AGNMarketingDisbursement"
                                                };
        self.isProcessing = NO;
        self.isSyncing = NO;

        // Load persisted transactions
        [self refreshTransactions];
        [UIApplication sharedApplication].applicationIconBadgeNumber = self.queue.count;
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateQueueCountChangedNotificationKey object:nil];

        log4Debug(@"Update queue - isProcessing=%d", self.isProcessing);

        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(processQueue)
                                                     name:RKReachabilityDidChangeNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(processQueue)
                                                     name:AGNUserLoginSucceededNotificationKey
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(processQueue)
                                                     name:AGNLoggedInUserSetNotificationKey
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(processQueue)
                                                     name:AGNUserLogoutSucceededNotificationKey
                                                   object:nil];

        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(processQueue)
                                                     name:UIApplicationDidBecomeActiveNotification
                                                   object:nil];

    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Manage queue
//------------------------------------------------------------------------------

- (NSUInteger)pendingUpdateCount {
    return self.queue.count;
}

- (void)clearQueue {
    [self.queue removeAllObjects];
    [[AGNAppDelegate sharedDelegate] saveContext];
}

- (BOOL)appendTransactions:(NSArray *)transactions {
    [self refreshTransactions];

    //Do not process the queue until all transactions appended
    if ([transactions count] > 1) {
        for (int i = 0; i < [transactions count]-1; i++) {
            if (![self primAppendTransaction:transactions[i]]) {
                [[AGNAppDelegate sharedDelegate].managedObjectContext rollback];
                return NO;
            }
        }
    }
    if ([transactions count] > 0) {
        if (![self primAppendTransaction:[transactions lastObject]]) {
            [[AGNAppDelegate sharedDelegate].managedObjectContext rollback];
            return NO;
        }
    }
    BOOL success = [[AGNAppDelegate sharedDelegate] saveContext];
    [self refreshTransactions];
    if (success) {
        [self processQueue];
    }
    else {
        //TODO: handle error
        log4Error(@"Failed to save update transactions to CoreData");
        [[AGNAppDelegate sharedDelegate].managedObjectContext rollback];
    }
    return success;
}

- (BOOL)primAppendTransaction:(AGNUpdateTransactionValueHolder *)transaction {
    //Determine whether this is an update to an existing (not in process) transaction - update if so
    AGNUpdateTransaction *existingTxn = [self existingTransactionMatching:transaction];
    if (existingTxn) {
        if (![existingTxn updateFrom:transaction]) {
            log4Error(@"Unable to update an existing transaction from a newer one. Existing: %@ | New: %@", existingTxn, transaction);
            return NO;
        }
    }
    else {
        //If new, insert in CoreData
        AGNUpdateTransaction *newTxn = (AGNUpdateTransaction *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNUpdateTransaction" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
        [newTxn initFrom:transaction];
        log4Trace(@"Appending NEW transaction to the update queue: %@", transaction);
    }
    return YES;
}

- (void)refreshTransactions {
    if (!self.isProcessing) {
        NSManagedObjectContext* context = [AGNAppDelegate sharedDelegate].managedObjectContext;
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGNUpdateTransaction" inManagedObjectContext:context];
        [request setEntity:entity];
        [request setSortDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"createTimestamp" ascending:NO]]];
        NSError *error = nil;
        NSMutableArray *objects = [[context executeFetchRequest:request error:&error] mutableCopy];
        if (error)
            log4Error(@"Error fetching update transactions %@ ",error);
        self.queue = objects;
    }
}

- (AGNUpdateTransaction *)existingTransactionMatching:(AGNUpdateTransactionValueHolder *)transaction {
    __block AGNUpdateTransaction *result;
    [self.queue enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        AGNUpdateTransaction *inObj = (AGNUpdateTransaction *)obj;
        if ([inObj matches:transaction]) {
            result = inObj;
        }
    }];
    if (result && result != self.transactionInProcess) {
        return result;
    }
    return nil;
}

- (void)removeTransactionInProcessFromQueue {
    [self.queue removeObject:self.transactionInProcess];
    [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:self.transactionInProcess];
    [[AGNAppDelegate sharedDelegate] saveContext];
    self.transactionInProcess = nil;
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Process queue
//------------------------------------------------------------------------------

// This is the main entry into processing next item if any.  The other method (processNextTransactionInQueue) should not be
// called by anything other than this method.
- (void)processQueue {
    [self refreshTransactions];
    //First, update the application icon
    [UIApplication sharedApplication].applicationIconBadgeNumber = self.queue.count;
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateQueueCountChangedNotificationKey object:nil];

    // We only process anything if we're online and authenticated
    if (![self isNetworkConnectedAndLoggedIn]) {
        return;
    }

    // Should we be syncing now (batch window management)
    if (![[AGNAppDelegate sharedDelegate] shouldSyncNow]) {
        // No, we should not

        self.isSyncing = NO;

        // Let's post the stop notification in case down sync is blocked on upsync.  Maybe a little excessive for some cases, but that shouldn't hurt.
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpsyncStoppedNotificationKey object:nil];

        return;
    }

    // Queue will be processed serially, so we kick off the next request
    // only if we are not already processing the queue, then each request
    // will kick off the next until the queue is empty (or we go offline)

    //TODO: How do we handle if the app goes into background? use the extra 10s to complete I assume.
    if (!self.isProcessing && [self.queue count] > 0) {
        if (!self.isSyncing) {
            self.isSyncing = YES;
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpsyncInProgressNotificationKey object:nil];

        //TODO: Send out a queue-processing-began notification
        self.isProcessing = YES;
        log4Trace(@"Update queue - isProcessing=%d", self.isProcessing);
        [self processNextTransactionInQueue];
    }
    else if (self.queue.count == 0) {
        if (self.isSyncing) {
            self.isSyncing = NO;
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpsyncStoppedNotificationKey object:nil];
        }
    }
}

- (BOOL)isNetworkOrHTTPError:(NSError *)error {
    // No need to check for successful HTTP status code (domain = NSURLErrorDomain and status code is in
    // the 200 range (successful), because the SFRestAPI will not have sent the error in the first place.
    return [error.domain isEqualToString:@"NSURLErrorDomain"] ||
    ([error.domain isEqualToString:RKRestKitErrorDomain] &&
     (error.code == RKRequestBaseURLOfflineError ||
      error.code == RKRequestConnectionTimeoutError));
}

- (void)performAccountUpdateWithJSONData:(NSData *)jsonData {
    NSError *error;
    NSDictionary *jsonDict = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];

    [[SFRestAPI sharedInstance] performUpdateWithObjectType:@"Account"
                                                   objectId:self.transactionInProcess.salesForceId
                                                     fields:jsonDict
                                                  failBlock:^(NSError *e) {
                                                      if ([self isNetworkOrHTTPError:e]) {
                                                          [self retry];
                                                      }
                                                      else {
                                                          log4Info  (@"Update Account failed with error: %@", e);
                                                          [self alertFailedSync:[e.userInfo objectForKey:@"message"]];
                                                      }
                                                  }
                                              completeBlock:^(NSDictionary *responseDict) {
                                                  if (kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES) {
                                                      log4Info(@"Update Account failed with DEBUG_FORCED_ERROR");
                                                      [self alertFailedSync:@"Forced error for retry debug purposes"];
                                                  }
                                                  else {
                                                      log4Info (@"Update Account succeeded with response: %@", responseDict);
                                                      [self removeTransactionAndProcessQueue];
                                                  }
                                              }];
}

- (void)removeTransactionAndProcessQueue {
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionSuccessfulNotificationKey object:nil];
    [self removeTransactionInProcessFromQueue];
    self.isProcessing = NO;
    [self processQueue];
}

- (void)performContactUpsertWithJSONData:(NSData *)jsonData {
    NSError *error;
    NSDictionary *jsonDict = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
    NSString * toBeDeleted = jsonDict[@"toBeDeleted"];

    if(toBeDeleted && [toBeDeleted boolValue]) {
        [[SFRestAPI sharedInstance] performDeleteWithObjectType:@"Contact"
                                                       objectId:self.transactionInProcess.salesForceId
                                                      failBlock:^(NSError *e) {
                                                          if ([self isNetworkOrHTTPError:e]) {
                                                              [self retry];
                                                          }
                                                          else {
                                                              log4Info(@"Delete Contact failed with error: %@", e);
                                                              NSString *errorCode = [e.userInfo objectForKey:@"errorCode"];
                                                              if ([errorCode isEqualToString:@"ENTITY_IS_DELETED"] || [errorCode isEqualToString:@"NOT_FOUND"]) {
                                                                  // ignore - object already deleted
                                                                  [self removeTransactionAndProcessQueue];
                                                              }
                                                              else {
                                                                  [self alertFailedSync:[e.userInfo objectForKey:@"message"]];
                                                              }
                                                          }
                                                      }
                                                  completeBlock:^(NSDictionary *responseDict) {
                                                      if (kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES) {
                                                          log4Info(@"Delete Contact failed with DEBUG_FORCED_ERROR");
                                                          [self alertFailedSync:@"Forced error for retry debug purposes"];
                                                      }
                                                      else {
                                                          log4Info(@"Delete Contact succeeded with response: %@", responseDict);
                                                          [self removeTransactionAndProcessQueue];
                                                      }
                                                  }];
    }
    else {
        [[SFRestAPI sharedInstance] performUpsertWithObjectType:@"Contact"
                                                externalIdField:@"GUID__c"
                                                     externalId:self.transactionInProcess.guid
                                                         fields:jsonDict
                                                      failBlock:^(NSError *e) {
                                                          log4Info(@"Upsert Contact failed with error: %@", e);
                                                          if ([self isNetworkOrHTTPError:e]) {
                                                              [self retry];
                                                          }
                                                          else {
                                                              NSString *errorCode = [e.userInfo objectForKey:@"errorCode"];
                                                              if ([errorCode isEqualToString:@"ENTITY_IS_DELETED"]) {
                                                                  // ignore - object already deleted
                                                                  [self removeTransactionAndProcessQueue];
                                                              }
                                                              else {
                                                                  [self alertFailedSync:[e.userInfo objectForKey:@"message"]];
                                                              }
                                                          }
                                                      }
                                                  completeBlock:^(NSDictionary *responseDict) {
                                                      if (kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES) {
                                                          log4Info(@"Upsert Contact failed with DEBUG_FORCED_ERROR");
                                                          [self alertFailedSync:@"Forced error for retry debug purposes"];
                                                      }
                                                      else {
                                                          log4Info (@"Upsert Contact succeeded with response: %@", responseDict);
                                                          [self updateSalesForceIdsFromJSONResponse:responseDict];
                                                          [self removeTransactionAndProcessQueue];
                                                      }
                                                  }];
    }
}

-(void)performSyncUpsertRecordWithJSONData:(NSData *)jsonData{
    NSError *error;
    NSDictionary *jsonDict = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
    [[SFRestAPI sharedInstance] performUpdateWithObjectType:@"User"
                                                   objectId:self.transactionInProcess.salesForceId
                                                     fields:jsonDict
                                                  failBlock:^(NSError *e) {
                                                      if ([self isNetworkOrHTTPError:e]) {
                                                          [self retry];
                                                      }
                                                      else {
                                                          log4Info(@"Sync record upsert failed with error, noncritical, ignoring: %@", e);
                                                          [self removeTransactionAndProcessQueue];
                                                      }
                                                  }
                                              completeBlock:^(NSDictionary *responseDict) {
                                                  log4Info(@"Sync record upsert succeeded with response: %@", responseDict);
                                                  [self removeTransactionAndProcessQueue];
                                              }];
}

- (void)performAddressUpdateWithJSONData:(NSData *)jsonData {
    NSError *error;
    NSDictionary *jsonDict = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
    [[SFRestAPI sharedInstance] performUpdateWithObjectType:@"Address__c"
                                                   objectId:self.transactionInProcess.salesForceId
                                                     fields:jsonDict
                                                  failBlock:^(NSError *e) {
                                                      if ([self isNetworkOrHTTPError:e]) {
                                                          [self retry];
                                                      }
                                                      else {
                                                          log4Info(@"Update Address failed with error: %@", e);
                                                          [self alertFailedSync:[e.userInfo objectForKey:@"message"]];
                                                      }
                                                  }
                                              completeBlock:^(NSDictionary *responseDict) {
                                                  if (kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES) {
                                                      log4Info(@"Update Address failed with DEBUG_FORCED_ERROR");
                                                      [self alertFailedSync:@"Forced error for retry debug purposes"];
                                                  }
                                                  else {
                                                      log4Info(@"Update Address succeeded with response: %@", responseDict);
                                                      [self removeTransactionAndProcessQueue];
                                                  }
                                              }];
}

- (void)performAddressUpsertWithJSONData:(NSData *)jsonData {
    NSError *error;
    NSDictionary *jsonDict = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
    [[SFRestAPI sharedInstance] performUpsertWithObjectType:@"Address__c"
                                            externalIdField:self.transactionInProcess.guid ? @"GUID__c" : @"Id"
                                                 externalId:self.transactionInProcess.guid ? self.transactionInProcess.guid : self.transactionInProcess.salesForceId
                                                     fields:jsonDict
                                                  failBlock:^(NSError *e) {
                                                      if ([self isNetworkOrHTTPError:e]) {
                                                          [self retry];
                                                      }
                                                      else {
                                                          log4Info (@"Upsert Address failed with error: %@", e);
                                                          [self alertFailedSync:[e.userInfo objectForKey:@"message"]];
                                                      }
                                                  }
                                              completeBlock:^(NSDictionary *responseDict) {
                                                  if (kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES) {
                                                      log4Info  (@"Upsert Address failed with DEBUG_FORCED_ERROR");
                                                      [self alertFailedSync:@"Forced error for retry debug purposes"];
                                                  }
                                                  else {
                                                      log4Info (@"Upsert Address succeeded with response: %@", responseDict);
                                                      [self updateSalesForceIdsFromJSONResponse:responseDict];
                                                      [self removeTransactionAndProcessQueue];
                                                  }
                                              }];
}


- (void)mockResponse {
    [self.mockTimer invalidate];
    self.mockTimer = nil;

    // We don't need to do anything, just let everyone know we're done
    self.retryCount = 0; // It was a success
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionSuccessfulNotificationKey object:nil];
    [self removeTransactionInProcessFromQueue];
    self.isProcessing = NO;
    [self processQueue];

}


// IMPORTANT !!!! Only processQueue should call this method, do not call it directly because
// this method only does the processing, but not the gate keeping when processing should happen.
// Gatekeeping happens inside processQueue.
- (void)processNextTransactionInQueue {

    //Testing retry only - see ticket AL-321
    //    if (YES) {
    //        self.transactionInProcess = self.queue.lastObject;
    //        [self requestDidTimeout:nil];
    //        return;
    //    }

    self.transactionInProcess = self.queue.lastObject;

    if ([AGNSyncManager isReplayingMockData]) {
        self.mockTimer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(mockResponse) userInfo:nil repeats:NO];
        log4Info(@"Mocking the following request: %@", self.transactionInProcess.jsonForLogging);
    }
    else {
        SFOAuthCoordinator *coord = [SFRestAPI sharedInstance].coordinator;
        RKClient *restKitClient = [SFRestAPI sharedInstance].rkClient;
        [restKitClient setValue:[NSString stringWithFormat:@"OAuth %@", coord.credentials.accessToken]forHTTPHeaderField:@"Authorization"];

        NSString *jsonString = self.transactionInProcess.currentJSONRepresentation;
        NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        RKRequestSerialization *dat = [RKRequestSerialization serializationWithData:jsonData MIMEType:RKMIMETypeJSON];

        NSString *sigUrlString; //used for signature upsert

        log4Trace(@"Beginning to process the update queue");
        switch ([self.transactionInProcess.apexWrapperServiceId intValue]) {
            case AGNApexWrapperManageCall:

                log4Info (@"About to issue an ManageCall call with jsonString: \n%@", jsonString);
                [restKitClient post:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/ManageCall"] params:dat delegate:self];
                break;

            case AGNApexWrapperManageInventory:
                log4Info(@"About to issue an ManageInventory call with jsonString: \n%@", jsonString);

                //            [restKitClient post:@"http://afternoon-harbor-4495.herokuapp.com/have/fun" params:dat delegate:self];
                [restKitClient post:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/ManageInventory"] params:dat delegate:self];
                break;

            case AGNApexWrapperUpsertRequestForm:
                log4Info (@"About to issue an UpsertRequestForm with json : %@", self.transactionInProcess.jsonForLogging);
                [restKitClient post:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/MIRODR"] params:dat delegate:self];
                break;

            case AGNApexWrapperUpsertReprint:
                log4Info (@"About to issue an UpsertReprint with json : %@", self.transactionInProcess.jsonForLogging);
                [restKitClient post:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/MarketingContent"] params:dat delegate:self];
                break;

            case AGNApexWrapperUpdateAccount:
                log4Info(@"About to issue an UpdateAccount call with jsonString: \n%@", jsonString);
                [self performAccountUpdateWithJSONData:jsonData];
                break;

            case AGNApexWrapperUpsertSignature:
                log4Info(@"About to issue a SignatureUpsert with length %d for call with guid:%@", [jsonString length], self.transactionInProcess.guid);
                if (self.transactionInProcess.guid && jsonString) {
                    dat = [RKRequestSerialization serializationWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding] MIMEType:RKMIMETypeJSON];
                    sigUrlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/SignatureCapture?callId=%@"], self.transactionInProcess.guid];
                    [restKitClient post:sigUrlString params:dat delegate:self];
                }
                break;

            case AGNApexWrapperUpsertContact:
                log4Info(@"About to issue an UpsertContact call with jsonString: \n%@", jsonString);
                [self performContactUpsertWithJSONData:jsonData];
                break;

            case AGNApexWrapperInsertAddress:
                log4Info(@"About to issue an UpsertAddress call with jsonString: \n%@", jsonString);
                [self performAddressUpsertWithJSONData:jsonData];
                break;

            case AGNApexWrapperUpdateAddress:
                log4Info(@"About to issue an UpdateAddress call with jsonString: \n%@", jsonString);
                [self performAddressUpdateWithJSONData:jsonData];
                break;

            case AGNApexWrapperUpsertSyncRecord:
                log4Info(@"About to issue a SyncRecord upsert with jsonString: \n%@", jsonString);
                [self performSyncUpsertRecordWithJSONData:jsonData];
                break;


            default:
                self.isProcessing = false;
                log4Trace(@"Update queue - isProcessing=%d", self.isProcessing);
                break;
        }
    }
}


- (id)jsonFromJsonResponse:(id)jsonResponse {
    id json;

    NSString *body = [[NSString alloc] initWithData:[jsonResponse body] encoding:NSUTF8StringEncoding];
    log4Trace(@"body=%@", body);
    NSData * jsonData = [body dataUsingEncoding:NSUTF8StringEncoding];

    if (jsonData) {
        NSError *error;
        json = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        if (!json) {
            log4Error(@"Invalid json response parsing: %@", jsonData);
        }
        else {
            log4Trace(@"json=%@", json);
        }
    }
    else {
        log4Error(@"JSONResponse contained no body that could be encoded. Body=%@", body);
    }
    return json;
}

- (void)updateSalesForceIdsFromJSONResponse:(id)json {
    // It was successful - see if we need to update SFDC IDs in the returned objects
    // This section is occurring in the main (appdelegate) moc
    id<AGNModelProtocol> modelObject = nil;
    NSString *targetEntityDescriptionName = (NSString *)[self.targetEntityDescriptionMapping objectForKey:self.transactionInProcess.apexWrapperServiceId];
    if (targetEntityDescriptionName) {
        if (self.transactionInProcess.salesForceId) {
            modelObject = (id<AGNModelProtocol>)[[AGNAppDelegate sharedDelegate].dataManager undeletedObjectOfType:targetEntityDescriptionName forId:self.transactionInProcess.salesForceId];
        }
        else {
            modelObject = (id<AGNModelProtocol>)[[AGNAppDelegate sharedDelegate].dataManager undeletedObjectOfType:targetEntityDescriptionName forGuid:self.transactionInProcess.guid];
        }
        [modelObject updateSFDCIDsFromJSON:json];
        [[AGNAppDelegate sharedDelegate] saveContext]; //TODO: need error checking here

    }
}

- (void)request:(RKRequest *)request didLoadResponse:(id)jsonResponse {

    if (kAGN_DEBUG_ALWAYS_FAIL_SFDC_UPDATES) {
        log4Info (@"Update Account failed with DEBUG_FORCED_ERROR");
        [self alertFailedSync:@"Forced error for retry debug purposes"];
        return;
    }

    // make sure we're on the main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        RKResponse *httpResponse = (RKResponse *)jsonResponse;
        if (![httpResponse isOK]) {
            log4Warn(@"Received HTTP error code: %d", httpResponse.statusCode);
            if(httpResponse.statusCode==UNAUTHORIZED){
                log4Info(@"Was UNAUTHORIZED, logging in ");
                self.isProcessing = NO;
                [[AGNAppDelegate sharedDelegate] login];
                return;
            }else{
                [self retry];
                id json = [self jsonFromJsonResponse:jsonResponse];
                log4Warn(@"Got response %@",json);
                log4Warn(@"Retrying request with body %@", self.transactionInProcess.jsonForLogging );
                return;
            }
        }

        id json = [self jsonFromJsonResponse:jsonResponse];

        NSString *errorString;
        NSString *messageString;

        // TODO: take this out now that we have real detection of batch running error message?
        if ([[NSUserDefaults standardUserDefaults] boolForKey:@"simulate_batch_running"]) {
            self.isProcessing = NO;
            [[AGNAppDelegate sharedDelegate] deferSync];
            [self processQueue]; // This will send out necessary notifications
            return;
        }

        //TODO: This is a hack needed because the service layer is not consistent in how errors are presented.
        if ([json isKindOfClass:[NSArray class]] && [((NSArray *)json) count] > 0 &&
            [json[0] isKindOfClass:[NSDictionary class]] && ((NSString *)[json[0] valueForKey:@"errorCode"]).length > 0) {
            errorString = (NSString *)[json[0] valueForKey:@"errorCode"];
            messageString = (NSString *)[json[0] valueForKey:@"message"];
        }
        else {
            errorString = (NSString *)[json valueForKey:@"StatusCode"];
            if (errorString == nil) {
                errorString = (NSString *)[json valueForKey:@"errorCode"];
                messageString = (NSString *)[json valueForKey:@"message"];

            }
            else {
                if ([errorString isEqualToString:@"ERROR"] || [errorString isEqualToString:@"FAIL"] || [errorString isEqualToString:@"BATCH_IS_RUNNING"]) {
                    messageString = (NSString *)[json valueForKey:@"StatusMessage"];
                }
                else {
                    errorString = nil;
                }
            }
        }
        if (errorString) {
            if ([errorString isEqualToString:@"BATCH_IS_RUNNING"]) {
                log4Warn(@"Got BATCH_IS_RUNNING message, alerting user and defering sync");
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Temporarily unable to sync" message:messageString delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alertView show];
                self.isProcessing = NO;
                [[AGNAppDelegate sharedDelegate] deferSync];
                [self processQueue]; // This will send out necessary notifications
                return;
            }

            if ([errorString isEqualToString:@"INVALID_SESSION_ID"] || [errorString isEqualToString:@"invalid_grant"]) {
                log4Info(@"Got invalid session: %@ - logging back in", errorString);
                // Our session has expired - re-login and stop processing the queue
                self.isProcessing = NO;
                [[AGNAppDelegate sharedDelegate] login];
                return;
            }
            if ([messageString rangeOfString:@"ENTITY_IS_DELETED"].location != NSNotFound) {
                log4Info(@"Got an ENTITY_IS_DELETED message - skip transaction");
                // we tried to delete an entity that is already deleted in SFDC - ignore
                [self removeTransactionAndProcessQueue];
                return;
            }
            log4Error(@"Upstream sync Failed with error: %@. Message: %@", errorString, messageString);
            log4Error(@"Body of response : %@",json);
            [self alertFailedSync:messageString];
            return;
        }
        log4Info(@"transaction succeeded with json response %@ ",json);
        self.retryCount = 0;


        [self updateSalesForceIdsFromJSONResponse:json];

        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionSuccessfulNotificationKey object:nil];

        if (!kAGN_DEBUG_FORCE_RETRY) {
            [self removeTransactionInProcessFromQueue];
        }
        self.isProcessing = NO;
        [self processQueue];
    });
}

- (void)request:(RKRequest *)request didFailLoadWithError:(NSError*)error {
    log4Warn (@"request:didFailLoadWithError: %@", error);
    log4Warn(@"TransactionInProcess: %@ ",self.transactionInProcess.guid );
    [self retry];
}

- (void)requestDidCancelLoad:(RKRequest *)request {
    //TODO: I don't see that a cancel could happen, but if it does we would not want to remove it from the queue
    log4Warn(@"requestDidCancelLoad: %@", request);
    log4Warn(@"TransactionInProcess: %@ ",self.transactionInProcess.guid );
    self.isProcessing = NO;
    [self processQueue];
}

- (void)requestDidTimeout:(RKRequest *)request {
    log4Warn(@"requestDidTimeout: %@", request);
    log4Warn(@"TransactionInProcess: %@ ",self.transactionInProcess.guid);

    [self retry];
}

- (void)alertFailedSync:(NSString *)messageString {
    if ([self.transactionInProcess mustSucceed].boolValue) {
        [self handleFailedMustSucceedTransaction:messageString];
    }
    else {
        log4Error(@"Transaction %@ failed, reverting. ",self.transactionInProcess.guid );
        log4Error(@"body of transaction: %@ ",self.transactionInProcess.jsonForLogging );


        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failed To Sync"
                                                        message:messageString
                                                       delegate:nil
                                              cancelButtonTitle:NSLocalizedString(@"OK", @"OK")
                                              otherButtonTitles:nil];
        [alert show];

        //Here we need to revert the object (using the undo state) and send out a notification to interested VCs
        [self.transactionInProcess revert];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionRevertedNotificationKey object:nil];

        self.isProcessing = NO;
        self.retryCount = 0;

        [self removeTransactionInProcessFromQueue];
        [self processQueue];
    }
}

- (void)handleFailedMustSucceedTransaction:(NSString *)messageString {
    // As long as the conflict resolution rules are working correctly on the SFDC side this should
    // never happen. We are not doing any special to overcome the error (e.g. writing the call and signature
    // up to a separate table. We need, however, to inform the user that a critical update has failed.
    log4Error(@"Must Succeed Transaction failed, removing it from the queue. ",self.transactionInProcess.guid );

    if(self.transactionInProcess.apexWrapperServiceId.intValue == AGNApexWrapperUpsertSignature){
        NSString * sfdcId = self.transactionInProcess.salesForceId;
        NSString * guid = self.transactionInProcess.guid;

        AGNCall * call = (AGNCall*)[[AGNDataManager defaultInstance]objectOfType:@"AGNCall" forId:sfdcId];
        if(!call){
            call = (AGNCall*)[[AGNDataManager defaultInstance]objectOfType:@"AGNCall" forGuid:guid];
        }
        if(call){
            log4Error(@"Failed to upsert signature, replacing it on the call %@ object!!",call);

            NSError *error;
            NSData * jsonData = [self.transactionInProcess.currentJSONRepresentation dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary * json = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
            NSString * imageString = json[@"encodedSignature"];
            NSData * signatureData = [NSData dataFromBase64String:imageString];
            call.signatureImage = [[UIImage alloc]initWithData:signatureData ];
            [[AGNAppDelegate sharedDelegate] saveContext];

        }

    }else{
        log4Error(@"body of transaction: %@ ",self.transactionInProcess.jsonForLogging );
    }


    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Critical Failure To Sync"
                                                    message:[NSString stringWithFormat:@"Closed call with signature will be lost due to unrecoverable error:\n%@", messageString]
                                                   delegate:nil
                                          cancelButtonTitle:NSLocalizedString(@"OK", @"OK")
                                          otherButtonTitles:nil];
    [alert show];

    self.isProcessing = NO;
    self.retryCount = 0;

    [self removeTransactionInProcessFromQueue];
    [self processQueue];
}

- (void)retry {
    self.isProcessing = NO;
    self.retryCount = self.retryCount + 1;
    log4Info(@"RetryCount=%d",self.retryCount);
    //increase the delay exponentially with each retry until max retries is reached - then keep retrying at that same interval
    [self performSelector:@selector(processQueue) withObject:nil afterDelay:(kAGN_BASE_RETRY_INTERVAL * (pow(2, self.retryCount < kAGN_MAX_UPSYNC_RETRIES ? self.retryCount : kAGN_MAX_UPSYNC_RETRIES)))];
}

- (BOOL)isNetworkConnectedAndLoggedIn {
    // We only process anything if we're online and authenticated
    if ([AGNSyncManager isReplayingMockData])
        return YES;

    if (!([AGNAppDelegate sharedDelegate].reachabilityObserver.networkStatus  >= RKReachabilityReachableViaWiFi)) {
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpsyncStoppedNotificationKey object:nil];
        return NO;
    }

    // Have we established the session?
    if (![AGNAppDelegate sharedDelegate].isAuthenticated) {
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpsyncStoppedNotificationKey object:nil];
        return NO;
    }

    // Do we know the user?
    if (![AGNAppDelegate sharedDelegate].isLoggedIn && ![AGNAppDelegate sharedDelegate].syncManager.syncInProgress) {
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpsyncStoppedNotificationKey object:nil];
        return NO;
    }

    return YES;
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Test methods
//------------------------------------------------------------------------------

- (void)testInsertNewAddress {
    AGNAccount *acct = [[[AGNAppDelegate sharedDelegate].dataManager getHCPSWithNameMatching:@"FLEMING"] lastObject];
    if (acct) {
        AGNAddress *addr = [NSEntityDescription insertNewObjectForEntityForName:@"AGNAddress" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
        addr.line1 = @"1234 Main Street";
        addr.line2 = @"Apt 2B";
        addr.city = @"Seattle";
        addr.usState = @"WA";
        addr.zip = @"98103";
        addr.deaNumber = @"123345567";
        addr.guid = [[NSUUID UUID] UUIDString];
        addr.active = @YES;
        addr.salesForceAccountId = acct.salesForceId;
        addr.officePhone = @"2062993344";
        addr.faxPhone = @"2062993345";
        addr.mobilePhone = @"2065466666";
        addr.mobileCreateTimestamp = [NSDate date];
        addr.mobileCreateTimestamp = [NSDate date];
        addr.mondayOpenTime = @"7:00 am";
        addr.mondayCloseTime = @"5:00 pm";
        addr.tuesdayOpenTime = @"9:00 am";
        addr.tuesdayCloseTime = @"5:00 pm";
        addr.wednesdayOpenTime = @"9:00 am";
        addr.wednesdayCloseTime = @"4:00 pm";
        addr.thursdayOpenTime = @"9:00 am";
        addr.thursdayCloseTime = @"5:00 pm";
        addr.fridayOpenTime = @"10:00 am";
        addr.fridayCloseTime = @"3:00 pm";

        AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init];
        upTxn.createTimestamp = [NSDate date];
        upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperInsertAddress];
        upTxn.undoJSONRepresentation = nil;
        upTxn.currentJSONRepresentation = [addr jsonRepresentationForUpdate];
        upTxn.deleteModelObjectOnRevert = @YES;
        upTxn.guid = addr.guid;
        upTxn.modelClassName = @"AGNAddress";
        upTxn.salesForceId = addr.salesForceId;
        
        BOOL addedSuccessfully = [self appendTransactions:@[upTxn]];
        log4Info(@"TestInsertNewAddress - appendUpdateTransaction %@.", addedSuccessfully ? @"succeeded" : @"failed");
    }
    
}


@end
