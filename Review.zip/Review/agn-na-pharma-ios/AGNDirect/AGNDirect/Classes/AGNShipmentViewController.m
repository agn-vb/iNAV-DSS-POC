//
//  AGNShipmentViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/13/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNShipmentViewController.h"
#import "AGNInventoryTransactionLineCell.h"

static const int kHeight=44;

@interface AGNShipmentViewController ()

@property (strong,nonatomic) NSArray *lines;
@property (strong, nonatomic) UITextField *activeField;
@property (strong, nonatomic) NSIndexPath *returnToIndexPath;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;

@end

@implementation AGNShipmentViewController

@synthesize transaction=_transaction;
@synthesize lines=_lines;
@synthesize topHeaderViewConstraint;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self setupHeaderView];
    self.shipmentManifestTableView.tableFooterView = [[UIView alloc] init];
    self.acceptAllButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.acceptAllButton.titleLabel.textAlignment = NSTextAlignmentCenter;
   /* if (self.transaction)
    {
      if ([self.transaction isInboundTransfer]) self.shipmentManifestTableView.rowHeight = 42;
     
    }*/
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self loadData];
    if(self.transaction)
        [self.transaction setUndoRepresentation];

    if(self.transaction){
        log4Info(@"Loaded inventory transaction %@|%@ of type %@ and status %@",self.transaction.salesForceId,self.transaction.guid, self.transaction.transactionType, self.transaction.status);
    }
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(cellBeganEditing:)
                                                 name:AGNTransferCellDidBeginEditing object:nil];

}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNTransferCellDidBeginEditing object:nil];
    
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.shipmentManifestTableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.shipmentManifestTableView.contentSize = newContentSize;

    if(self.activeField && [self.activeField isFirstResponder]){
        [self.activeField resignFirstResponder];
        [self.activeField becomeFirstResponder];
    }
}

-(void)loadData{
    if(self.transaction){
        if([self.transaction isInboundTransfer]){
            [self.acceptShipmentButton setTitle:NSLocalizedString(@"Accept Transfer", @"accept button text for incoming transfer") forState:UIControlStateNormal] ;
            NSString *labelText = NSLocalizedString(@"Transfer %@ from %@", @"Header label for incoming transfer");
            self.shipmentManifestLabel.text =[NSString stringWithFormat:labelText,self.transaction.transferAuthorizationNumber,[self.transaction fromRepDisplayString ]];
        }
        self.shippedDateLabel.text = self.transaction.shipmentDate?[self.transaction.shipmentDate agnFormattedDateString]:@"";
        self.acceptedDateLabel.text = self.transaction.actualReceivedDate?[self.transaction.actualReceivedDate agnFormattedDateString]:@"";
        if ([self.transaction isInboundTransfer])
            self.orderNumberLabel.text = self.transaction.transferAuthorizationNumber;
        else
            self.orderNumberLabel.text = self.transaction.shipmentId;
        self.trackingNumberLabel.text = self.transaction.trackingNumber;
        self.lines =[[self.transaction.sampleInventoryTransactionLines allObjects]  sortedArrayUsingComparator: ^(AGNSampleInventoryTransactionLine *obj1, AGNSampleInventoryTransactionLine *obj2) {
            return [obj1.expirationDate compare:obj2.expirationDate];
        }];
        if(![self.transaction isOpen]){
            self.acceptAllButton.hidden = YES;
            self.acceptShipmentButton.hidden = YES;
        }
    }
    [self setButtonEnablement];
   
}

-(void)reloadContent{
    [self loadData];
}

-(void) setupHeaderView{
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
    
    UIView *headerView = self.headerView;
    headerView.backgroundColor = [UIColor AGNEleventhHour];

    
    UILabel *header1 = [self styledHeaderLabelWithText:@"Shipped"];
    self.shippedDateLabel = [self styledBodyLabelWithText:@"06/18/1900"];
    UIView *view1 = [self viewWithHeader:header1 andBody:self.shippedDateLabel];
    [headerView addSubview:view1];
    
    UILabel *header2 = [self styledHeaderLabelWithText:@"Accepted"];
    self.acceptedDateLabel = [self styledBodyLabelWithText:@"06/18/1900"];
    UIView *view2 = [self viewWithHeader:header2 andBody:self.acceptedDateLabel];
    [headerView addSubview:view2];

    NSString * orderLabelValue = @"Shipment";
    if ([self.transaction isInboundTransfer])
        orderLabelValue = @"Transfer";
    
    UILabel *header3 = [self styledHeaderLabelWithText:orderLabelValue];
    self.orderNumberLabel = [self styledBodyLabelWithText:@"FAKEORDER#"];
    UIView *view3 = [self viewWithHeader:header3 andBody:self.orderNumberLabel];
    [headerView addSubview:view3];
    
    UILabel *header4 = [self styledHeaderLabelWithText:@"Tracking"];
    self.trackingNumberLabel = [self styledBodyLabelWithText:@"1234567890"];
    UIView *view4 = [self viewWithHeader:header4 andBody:self.trackingNumberLabel];
    [headerView addSubview:view4];
    [headerView setTranslatesAutoresizingMaskIntoConstraints:NO];
    NSDictionary *dict = NSDictionaryOfVariableBindings(headerView,view1,view2,view3,view4);
    
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view1]|" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view2]|" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view3]|" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view4]|" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-[view1]-[view2]-[view3]-[view4]-|" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[view1(==view2)]" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[view2(==view3)]" options:0 metrics:nil views:dict]];
    [headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[view3(==view4)]" options:0 metrics:nil views:dict]];
 
}

-(UIView *)viewWithHeader:(UILabel *)headerLabel andBody:(UILabel *)bodyLabel{
    UIView *view = [[UIView alloc]init];
    [view setTranslatesAutoresizingMaskIntoConstraints:NO];
    [view addSubview:headerLabel];
    [view addSubview:bodyLabel];
    NSDictionary *dict1 = NSDictionaryOfVariableBindings(view,headerLabel,bodyLabel);
    [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-8-[headerLabel]-[bodyLabel]-8-|" options:0 metrics:nil views:dict1]];
    [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-[headerLabel]-|" options:0 metrics:nil views:dict1]];
    [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-[bodyLabel]-|" options:0 metrics:nil views:dict1]];
    view.backgroundColor = [UIColor AGNEleventhHour];
    return view;
}

-(UILabel *) styledHeaderLabelWithText:(NSString *)labelString{
    UILabel *label = [[UILabel alloc] init];
    [label setTranslatesAutoresizingMaskIntoConstraints:NO];
    label.font = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    label.textColor = [UIColor AGNNorilskSneg];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = labelString;
    return label;
}

-(UILabel *) styledBodyLabelWithText:(NSString *)bodyString{
    UILabel *label = [[UILabel alloc] init];
    [label setTranslatesAutoresizingMaskIntoConstraints:NO];
    label.font = [UIFont AGNAvenirLightFontWithSize:14.0f];
    label.textColor = [UIColor AGNNorilskSneg];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = bodyString;
    return label;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)acceptShipmentButtonClicked:(id)sender {
    if([self allQuantitiesSelected]){
        self.transaction.status = kReceivedStatusType;
        self.transaction.actualReceivedDate = [NSDate date];
        self.transaction.acceptedBy = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
        self.transaction.acceptedBySalesForceId = [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId;
        self.transaction.mobileLastUpdateTimestamp = [NSDate date];
        self.transaction.sfdcCreatedDate = [NSDate date];

        [self.transaction.sampleInventoryTransactionLines enumerateObjectsUsingBlock:^(id obj, BOOL *stop) {
            ((AGNSampleInventoryTransactionLine *)obj).isAccepted = [NSNumber numberWithBool:YES];
            ((AGNSampleInventoryTransactionLine *)obj).mobileLastUpdateTimestamp = [NSDate date];
            [self updateSILFromSITL:(AGNSampleInventoryTransactionLine *)obj];
        }];
        [self addManageInventoryUpdateTransactionForSIT:self.transaction];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
}

- (void)addManageInventoryUpdateTransactionForSIT:(AGNSampleInventoryTransaction *)aSIT {
    NSString *currentJSONRepresentation = [aSIT jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageInventory];
    upTxn.undoJSONRepresentation = aSIT.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.modelClassName = @"AGNSampleInventoryTransaction";
    upTxn.guid = aSIT.guid;
    upTxn.salesForceId = aSIT.salesForceId;
    
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:@[upTxn]]) {
        //TODO: error handling - display alert and refresh UI
        log4Error(@"Failed to save inventory transfer to core data");
    }
}

- (void)updateSILFromSITL:(AGNSampleInventoryTransactionLine *)sitl {
    // If there is a SIL relationship already on the SITL, update the quantity, otherwise
    // search for SIL by product SKU / lot # combination. If there is no existing SIL
    // create a new one. Update quantity based on actual amount in the SITL
    AGNSampleInventoryLine *sil = sitl.sampleInventoryLine;
    if (!sil) {
        sil = [[AGNAppDelegate sharedDelegate].dataManager getSampleInventoryLineForProductSKU:sitl.product andLotNumber:sitl.lotNumber];
        if (!sil) {
            sil = [NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryLine" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
            sil.lotNumber = sitl.lotNumber;
            sil.product = sitl.product;
            sil.productSalesForceId = sitl.product.salesForceId;
            sil.expiration = sitl.expirationDate;
            sil.salesRep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
            sil.salesRepSalesForceId = sil.salesRep.salesForceId;
            //Don't set the SIT on the SITL - SFDC triggers should do that
        }
    }
    sil.quantity = [NSNumber numberWithInt:(sil.quantity.intValue + sitl.actualQuantity.intValue)];
}

-(void)setButtonEnablement{
    if([self allQuantitiesSelected]) {
        self.acceptShipmentButton.enabled=YES;
        self.acceptShipmentButton.alpha=1.0;
        self.acceptAllButton.enabled=NO;
        self.acceptAllButton.alpha=.5;
    }
    else {
        self.acceptShipmentButton.enabled=NO;
        self.acceptShipmentButton.alpha=.5;
        self.acceptAllButton.enabled=YES;
        self.acceptAllButton.alpha=1.0;
        if([self anyQuantitySelected])
            self.acceptAllButton.titleLabel.text = NSLocalizedString(@"Accept Remaining", @"Accept quantities button when none are set.");
        else
            self.acceptAllButton.titleLabel.text = NSLocalizedString(@"Accept All", @"Accept quantities button when none are set.");
    }
    
    //barathanv :07252014
    if(self.transaction){
        if([self.transaction isInboundTransfer]){
            //[self.shipmentManifestTableView reloadData];
            //[self.shipmentManifestTableView setNeedsDisplay];
            CGSize contentSize = self.shipmentManifestTableView.contentSize;
            contentSize.width = self.shipmentManifestTableView.bounds.size.width;
            self.shipmentManifestTableView.contentSize = contentSize;
        }
    }

}

-(BOOL)anyQuantitySelected {
    for(AGNSampleInventoryTransactionLine * line in self.lines){
        if(line.actualQuantity)
            return YES;
    }
    return NO;
}

-(BOOL) allQuantitiesSelected{
    for(AGNSampleInventoryTransactionLine *line in self.transaction.sampleInventoryTransactionLines){
        if((!line.actualQuantity) || [line.actualQuantity intValue] < 0 ){
            return NO;
        }
    }
    return YES;
    
}

-(void)presentValidationError{
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
                                                                    message:NSLocalizedString(@"Please set all quantities before accepting shipment.", @"Message to show when a user presses accept shipment without setting all quantities.")
                                                                   delegate:self
                                                          cancelButtonTitle:NSLocalizedString(@"OK", @"OK")
                                                          otherButtonTitles:nil];
                [alertView show];

}
//------------------------------------------------------------------------------
// MARK: - TableView Data Source
//------------------------------------------------------------------------------

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *ShipmentLineCellIdentifier = @"ShipmentLineItemCell";
    AGNShipmentItemCell *cell = [tableView dequeueReusableCellWithIdentifier:ShipmentLineCellIdentifier forIndexPath:indexPath];
    AGNSampleInventoryTransactionLine *line = self.lines[indexPath.row];
    cell.accepted = self.transaction.actualReceivedDate ? YES : NO;
    cell.line = line;
    cell.delegate=self;
    
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.lines count];
}

- (IBAction)acceptAllButtonClicked:(id)sender {
    
    // this will force the didEndEditing event to fire prior to setting the quantities in the case that editing is active
    // https://ubermind.jira.com/browse/AL-277
    
    [self.shipmentManifestTableView reloadData];
    
    for(AGNSampleInventoryTransactionLine *line in [self.transaction.sampleInventoryTransactionLines objectEnumerator]){
        if(!line.actualQuantity){
            log4Info(@"Accept all clicked, setting quantity of %@ to %@ from %@",line.productDescription,line.expectedQuantity,line.actualQuantity?line.actualQuantity:@"Not Set");
            line.actualQuantity = line.expectedQuantity;
        }else{
            log4Info(@"Accept all clicked, quantity of %@ already set.",line.productDescription);
        }
    }
    [self.shipmentManifestTableView reloadData];
    [self setButtonEnablement];
    
}

-(void)quantitySelected{
    [self setButtonEnablement];
}

//------------------------------------------------------------------------------
// MARK: - scroll above keyboard
//------------------------------------------------------------------------------

-(void)cellBeganEditing:(NSNotification *)notification{
    self.activeField=((UITextField *)notification.object);
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    
    UITableViewCell *cell = (UITableViewCell *)[[self.activeField superview] superview];
    NSIndexPath *indexPath = [self.shipmentManifestTableView indexPathForCell:cell];
    if(!indexPath)
        return;
    
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
    }
    else {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
    }
    
    
    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardHeight-kHeight, 0.0);
    self.shipmentManifestTableView.contentInset = contentInsets;
    self.shipmentManifestTableView.scrollIndicatorInsets = contentInsets;
    
    
    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.shipmentManifestTableView.frame;
    aRect.size.height -= (keyboardHeight+kHeight);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        self.returnToIndexPath=[self firstVisibleRow];
        [self.shipmentManifestTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

-(NSIndexPath *)firstVisibleRow{
    NSArray* indexPaths = [self.shipmentManifestTableView indexPathsForVisibleRows];
    NSArray* sortedIndexPaths = [indexPaths sortedArrayUsingSelector:@selector(compare:)];
    return (NSIndexPath*)[sortedIndexPaths objectAtIndex:0];
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    // for some reason getting a UIKeyboardDidHideNotification on rotation even though the keyboard stays up
    // so hold on to the previous active field.
    //self.activeField = nil;
    
    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:[animationTime doubleValue] animations:^{
        UIEdgeInsets contentInsets = UIEdgeInsetsZero;
        self.shipmentManifestTableView.contentInset = contentInsets;
        self.shipmentManifestTableView.scrollIndicatorInsets = contentInsets;
    }];
    if(self.returnToIndexPath){
        [self.shipmentManifestTableView scrollToRowAtIndexPath:self.returnToIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
        self.returnToIndexPath=nil;
    }
    
}

@end
