//
//  UITableView+AGNTableView.h
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (AGNTableView)

@end
