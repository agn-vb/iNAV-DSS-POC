//
//  L4ProtectedFileAppender.m
//  Log4CocoaDebug
//
//  Created by Rebecca Gutterman on 8/9/12.
//  Copyright (c) 2012 Rebecca Gutterman. All rights reserved.
//

#import "AGNL4ProtectedRollingFileAppender.h"
#import "L4LogLog.h"

@implementation AGNL4ProtectedRollingFileAppender

- (BOOL) checkEntryConditions
{
    if( ![[UIApplication sharedApplication] isProtectedDataAvailable ]){
        // in case background tasks are running/logging while the device is locked, check status before attempting the write
        return NO;
    }
    else
        return [super checkEntryConditions];
}

- (void)setupFile
{
	NSFileManager*	fileManager = nil;
    
	@synchronized(self) {
        if (fileName == nil || [fileName length] <= 0) {
            [self closeFile];
            fileName = nil;
            [self setFileHandle:nil];
        } else {
            
            fileManager = [NSFileManager defaultManager];
            
            // if file doesn't exist, try to create the file
            if (![fileManager fileExistsAtPath:fileName]) {
                NSDictionary *dictionary = @{ NSFileProtectionKey : NSFileProtectionComplete };

                // if the we cannot create the file, raise a FileNotFoundException
                if (![fileManager createFileAtPath:fileName contents:nil attributes:dictionary]) {
                    [NSException raise:@"FileNotFoundException" format:@"Couldn't create a file at %@", fileName];
                }
            }
            
            // if we had a previous file name, close it and release the file handle
            if (fileName != nil) {
                [self closeFile];
            }
            
            // open a file handle to the file
            [self setFileHandle:[NSFileHandle fileHandleForWritingAtPath:fileName]];
            
            // check the append option
            if (append) {
                [fileHandle seekToEndOfFile];
            } else {
                [fileHandle truncateFileAtOffset:0];
            }
        }
    }
}

@end
