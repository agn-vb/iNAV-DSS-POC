//
//  AGNCallProductDetailCell.h
//  AGNDirect
//
//  Created by Mark Wells on 8/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNCallProductDetailCell : UITableViewCell

@property (strong, nonatomic) UILabel *label;
@property (strong, nonatomic) UILabel *errorLabel;
@property (strong, nonatomic) AGNCallDetail *model;
@end
