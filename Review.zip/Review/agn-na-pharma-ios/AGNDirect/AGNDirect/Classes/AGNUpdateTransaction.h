//
//  AGNUpdateTransaction.h
//  AGNDirect
//
//  Created by Mark Wells on 9/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AGNUpdateTransactionValueHolder.h"


@interface AGNUpdateTransaction : NSManagedObject


// GUID of the primary object being updated
@property (nonatomic, retain) NSString * guid;

// SFDC ID of the primary object being updated
@property (nonatomic, retain) NSString * salesForceId;

// undo (before image) state of the object graph being updated
@property (nonatomic, retain) NSString * undoJSONRepresentation;

// current state of the object graph being updated
@property (nonatomic, retain) NSString * currentJSONRepresentation;

// number of times this transaction has been tried
@property (nonatomic, retain) NSNumber * retryCount;

// class name of the object being updated
@property (nonatomic, retain) NSString * modelClassName;

// enum value for the ID of the APEX wrapper service that should eb used to update this object
@property (nonatomic, retain) NSNumber * apexWrapperServiceId;

// timestamp when this updateTransaction was first created
@property (nonatomic, retain) NSDate * createTimestamp;

// indicator that this is an insert, rather than an update - on revert the object must be deleted
@property (nonatomic, retain) NSNumber * deleteModelObjectOnRevert;

// indicator that this transaction has to succeed
@property (nonatomic, retain) NSNumber * mustSucceed;

@property (nonatomic,readonly) NSString * jsonForLogging;

- (void)initFrom:(AGNUpdateTransactionValueHolder *)transientTxn;
- (BOOL)updateFrom:(AGNUpdateTransactionValueHolder *)transientTxn;
- (BOOL)matches:(AGNUpdateTransactionValueHolder *)txn;
- (BOOL)isValid;
- (void)revert;

@end
