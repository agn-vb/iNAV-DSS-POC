//
//  AGNInventoryCell.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNInventoryCell.h"

@implementation AGNInventoryCell

@synthesize sampleLabel;
@synthesize lotTitle;
@synthesize lotNumber;
@synthesize expirationTitle;
@synthesize expirationDate;
@synthesize quantityTitle;
@synthesize quantityLabel;
@synthesize varianceTitle;
@synthesize varianceLabel;
@synthesize actualQuantityTextField=_actualQuantityTextField;
@synthesize line=_line;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.textFieldActiveBlock(textField);
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    if([textField.text length]==0){
        self.line.expectedQuantity=nil;
    }else{
        NSNumberFormatter *nf = [[NSNumberFormatter alloc]init];
        self.line.expectedQuantity = [nf numberFromString:textField.text];
        textField.text = self.line.expectedQuantity ? self.line.expectedQuantity.stringValue : @"";
    }
    [self setQuantityFields];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNMonthlyCountsQuantityChangedNotificationKey object:nil];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];

    NSNumber *inventoryNumber;

    NSString *inventoryString = [textField.text stringByReplacingCharactersInRange:range withString:string];

    range = NSMakeRange(0, [inventoryString length]);

    [numberFormatter getObjectValue:&inventoryNumber forString:inventoryString range:&range error:nil];

    if (([inventoryString length] > 0) && (inventoryNumber == nil || range.length < [inventoryString length])) {
        return NO;
    } else {
        return YES;
    }
}

-(void)setQuantityFields{
    if(self.line.expectedQuantity){
        self.actualQuantityTextField.text = [self.line.expectedQuantity stringValue];
        if([self.line varianceForInventoryCount])
            self.varianceLabel.text = [[self.line varianceForInventoryCount]stringValue];
        else
            self.varianceLabel.text  =  @"---";
    }else{
        self.varianceLabel.text  =  @"---";
        self.actualQuantityTextField.text = nil;
    }
    [self updateValidationState];
}


- (BOOL)isValid {
    
    if ([self.line.expectedQuantity intValue]<0)
        return NO;
    else
        return YES;
}


- (void)updateValidationState {
    
    if (self.isValid) {
        self.actualQuantityTextField.backgroundColor = [UIColor whiteColor];
        self.actualQuantityTextField.textColor = [UIColor AGNGreyMatter];
    }
    else {
        self.actualQuantityTextField.backgroundColor = [UIColor AGNWarny];
        self.actualQuantityTextField.textColor = [UIColor whiteColor];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)setLine:(AGNSampleInventoryTransactionLine *)txnLine{
    _line=txnLine;
    self.actualQuantityTextField.delegate=self;
    [self setQuantityFields];
}

@end
