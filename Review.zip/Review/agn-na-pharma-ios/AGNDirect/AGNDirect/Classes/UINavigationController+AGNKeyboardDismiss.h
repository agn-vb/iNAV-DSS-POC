//
//  UINavigationController+AGNKeyboardDismiss.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/31/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//




//   ALLOWS DISMISSAL OF KEYBOARD WITH UIModalPresentationFormSheet
//   http://stackoverflow.com/questions/3372333/ipad-keyboard-will-not-dismiss-if-modal-view-controller-presentation-style-is-ui/3386768#3386768

#import <UIKit/UIKit.h>

@interface UINavigationController (AGNKeyboardDismiss)


- (BOOL)disablesAutomaticKeyboardDismissal;


@end
