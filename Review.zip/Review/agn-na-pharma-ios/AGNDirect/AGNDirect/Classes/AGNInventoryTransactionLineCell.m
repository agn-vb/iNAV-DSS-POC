//
//  AGNInventoryTransactionLineCell.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNInventoryTransactionLineCell.h"
#import "UIColor+AGNColor.h"

@implementation AGNInventoryTransactionLineCell {
    BOOL _configured;
}

- (void)setEditable:(BOOL)editable {
    _editable = editable;
    
    if (_editable) {
        self.backgroundColor = [UIColor clearColor];
        self.quantityTextField.borderStyle = UITextBorderStyleRoundedRect;
        self.quantityTextField.backgroundColor = [UIColor whiteColor];
        self.availableQuantity.hidden = NO;
        self.quantityTextField.enabled = YES;
        self.quantityTextField.textAlignment = NSTextAlignmentRight;
    }
    else {
        self.quantityTextField.enabled = NO;
        self.quantityTextField.borderStyle = UITextBorderStyleNone;
        self.quantityTextField.backgroundColor = [UIColor clearColor];
        self.backgroundColor = [UIColor clearColor];
        self.availableQuantity.hidden = YES;
        self.quantityTextField.textAlignment = NSTextAlignmentLeft;
    }
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.label = [[UILabel alloc] init];
        self.label.font = [UIFont AGNAvenirHeavy14];
        self.label.textColor = [UIColor AGNGreyMatter];
        [self.label setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.label.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.label];
        
        self.quantityLabel = [[UILabel alloc] init];
        self.quantityLabel.font = [UIFont AGNAvenirHeavy14];
        self.quantityLabel.textColor = [UIColor AGNGreyMatter];
        self.quantityLabel.text = @"QTY:";
        self.quantityLabel.backgroundColor = [UIColor clearColor];
        [self.quantityLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.quantityLabel];
        
        self.quantityTextField = [[UITextField alloc] init];
        self.quantityTextField.borderStyle = UITextBorderStyleRoundedRect;
        self.quantityTextField.font = [UIFont AGNAvenirHeavy14];
        self.quantityTextField.textColor = [UIColor AGNGreyMatter];
        self.quantityTextField.delegate = self;
        self.quantityTextField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        self.quantityTextField.returnKeyType = UIReturnKeyDone;
        self.quantityTextField.adjustsFontSizeToFitWidth = YES;
        [self.quantityTextField setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.quantityTextField];

        self.availableQuantity = [[UILabel alloc] init];
        self.availableQuantity.font = [UIFont AGNAvenirHeavy14];
        self.availableQuantity.textColor = [UIColor AGNGreyMatter];
        self.availableQuantity.text = @"QTY:";
        self.availableQuantity.backgroundColor = [UIColor clearColor];
        self.availableQuantity.text = @"";
        self.availableQuantity.adjustsFontSizeToFitWidth = YES;
        [self.availableQuantity setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.availableQuantity sizeToFit];
        [self.contentView addSubview:self.availableQuantity];
      
        
        NSDictionary *constraintsViewsDictionary = @{ @"label" : self.label , @"qtyLabel" : self.quantityLabel , @"qtyTextField" : self.quantityTextField, @"availableQty" : self.availableQuantity };
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[label(>=100)]->=20-[qtyLabel]-[qtyTextField(==62)]-[availableQty(==50)]-22-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[qtyTextField(==24)]" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.label attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.quantityLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.quantityTextField attribute:NSLayoutAttributeBaseline relatedBy:NSLayoutRelationEqual toItem:self.quantityLabel attribute:NSLayoutAttributeBaseline multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.availableQuantity attribute:NSLayoutAttributeBaseline relatedBy:NSLayoutRelationEqual toItem:self.quantityLabel attribute:NSLayoutAttributeBaseline multiplier:1.0 constant:0]];
    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];

    self.model = nil;
    self.label.text = nil;
    self.quantityTextField.text = nil;
    self.editing = NO;
}

- (void)setSku:(AGNProductSKU *)sku {
    _sku = sku;
    if (_sku) {
        if (_model)
            self.label.text = [NSString stringWithFormat:@"%@ - %@", sku.productDescription, self.model.lotNumber];
        else
            self.label.text = sku.productDescription;
    }
    else
        self.label.text = @"";
}

- (void)updateValidationState {
    if (!_editable)
        return;
    
    if (self.isValid) {
        self.quantityTextField.backgroundColor = [UIColor whiteColor];
        self.quantityTextField.textColor = [UIColor AGNGreyMatter];
    }
    else {
        self.quantityTextField.backgroundColor = [UIColor AGNWarny];
        self.quantityTextField.textColor = [UIColor whiteColor];
    }
}

- (void)setModel:(AGNSampleInventoryTransactionLine *)model {
    _model = model;
    if (model == nil)
        return;
    
    AGNProductSKU *sku = _model.product;
    self.sku = sku;
    self.quantityTextField.text = _model.expectedQuantity.stringValue;
    self.availableQuantity.text = [NSString stringWithFormat:@"/ %@", _model.availableQuantity.stringValue];
    [self updateValidationState];
}

- (BOOL)isValid {
    if (!_editable)
        return YES;
    
    if ([self.model.expectedQuantity intValue] > [self.model.sampleInventoryLine.quantity intValue])
        return NO;
    else if ([self.model.expectedQuantity intValue]<1)
        return NO;
    else
        return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferCellDidBeginEditing object:textField];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    NSNumberFormatter *nf = [[NSNumberFormatter alloc]init];
    self.model.expectedQuantity = [nf numberFromString:textField.text];
    textField.text = self.model.expectedQuantity? self.model.expectedQuantity.stringValue:@"";
    [self updateValidationState];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferLineQuantityChangedNotificationKey object:nil];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    
    NSNumber *inventoryNumber;
    
    NSString *inventoryString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    range = NSMakeRange(0, [inventoryString length]);
    
    [numberFormatter getObjectValue:&inventoryNumber forString:inventoryString range:&range error:nil];
    
    self.model.expectedQuantity = inventoryNumber;
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferLineQuantityChangedNotificationKey object:self];
    
    if (([inventoryString length] > 0) && (inventoryNumber == nil || range.length < [inventoryString length])) {
        return NO;
    } else {
        return YES;
    }
}





@end
