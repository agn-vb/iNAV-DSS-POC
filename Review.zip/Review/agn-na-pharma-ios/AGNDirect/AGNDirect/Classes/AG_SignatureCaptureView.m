//
//  AG_SignatureCaptureView.m
//
//  Created by Ben Gottlieb on 10/11/10.
//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  THIS IS THE VIEW FOR CAPTURING SIGNATURE - Used by the AGNCaptureSignatureViewController

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AG_SignatureCaptureView.h"
#import <QuartzCore/QuartzCore.h>

@interface AG_SignatureCaptureView()

@property CGFloat minY;
@property CGFloat maxY;
@property CGFloat minX;
@property CGFloat maxX;

@end

@implementation AG_SignatureCaptureView
@synthesize delegate, clearButton, existingSignatureImage = _existingSignatureImage;

static const int kMinPointsForSignature=10;
static const float kMinWidth=50.0;
static const float kMinHeight=10.0;

- (id) initWithCoder: (NSCoder *)aDecoder {
    if (self = [super initWithCoder: aDecoder]) {
		self.userInteractionEnabled = YES;
		self.lines = [[NSMutableArray alloc] init];
        self.points = [[NSMutableArray alloc] init];
		
		
//		self.clearButton = [UIButton buttonWithType: UIButtonTypeCustom];
//		[self.clearButton setImage: [UIImage imageNamed: @"clear_image.png"] forState: UIControlStateNormal];
//		self.clearButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin;
//		self.clearButton.alpha = 0.0;
//		self.clearButton.showsTouchWhenHighlighted = YES;
//		[self.clearButton addTarget: self action: @selector(clear) forControlEvents: UIControlEventTouchUpInside];
//		[self addSubview: self.clearButton];
	}
	return self;
}

- (void) touchesBegan: (NSSet *)touches withEvent: (UIEvent *)event {
	
	self.points = [NSMutableArray array];
	[self.lines addObject: self.points];
	[super touchesBegan: touches withEvent: event];
}

- (void) touchesMoved: (NSSet *)touches withEvent: (UIEvent *)event {
	[self.points addObject: [NSValue valueWithCGPoint: [[touches anyObject] locationInView: self]]];

	if (self.lines.count == 1 && self.points.count == 2) {
		[UIView animateWithDuration: 0.2 animations: ^{
			self.clearButton.alpha = 1.0;
		}];
	}
	
	[self setNeedsDisplay];
}

- (void) touchesEnded: (NSSet *)touches withEvent: (UIEvent *)event {
	if ([self.delegate respondsToSelector:@selector(signatureCaptureViewTouchesEnded:)]) {
        [self.delegate signatureCaptureViewTouchesEnded:self];
    }
    
    if ([self.delegate respondsToSelector: @selector(signatureCaptureViewHasValidSignature:)]) {
        if (self.points.count > kMinPointsForSignature  && [self height] >= kMinHeight && [self width] >= kMinWidth) {
            [self.delegate signatureCaptureViewHasValidSignature:YES];
        }else{
            log4Debug(@"Points %d Width %f Height %f",self.points.count,[self width],[self height]);
        }
    }
}


- (void) setExistingSignatureImage: (UIImage *) image {
	_existingSignatureImage = image;
	if (image) self.clearButton.alpha = 1.0;
	[self setNeedsDisplay];
}

- (void) clear {
    [self resetValidation];
	[self.lines removeAllObjects];
	[UIView animateWithDuration: 0.2 animations: ^{
		self.clearButton.alpha = 0.0;
		if ([self.delegate respondsToSelector: @selector(signatureCaptureViewHasValidSignature:)]) [self.delegate signatureCaptureViewHasValidSignature:NO];
	}];
	self.existingSignatureImage = nil;
	[self setNeedsDisplay];
}

-(void)resetValidation{
    self.minX=MAXFLOAT;
    self.minY=MAXFLOAT;
    self.maxX=0;
    self.maxY=0;
}

-(void)updateY:(CGFloat)y{
    if(y>self.maxY)
        self.maxY=y;
    if(y<self.minY)
        self.minY=y;
}

-(void)updateX:(CGFloat)x{
    if(x>self.maxX)
        self.maxX=x;
    if(x<self.minX)
        self.minX=x;
}

-(float)width{
    float width= self.maxX-self.minX;
    log4Debug(@"Width is %f",width);
    return width;
}

-(float)height{
    float height =  self.maxY-self.minY;
    log4Debug(@"Height is %f",height);
    return height;
}

- (void) drawRect: (CGRect)rect {
	if (self.existingSignatureImage) {
		[self.existingSignatureImage drawInRect: self.bounds];
		return;
	}
	CGContextRef context = UIGraphicsGetCurrentContext();
    UIColor *darkGray = [UIColor AGNDarkGray];

	CGContextSaveGState(context);
    float margin = 20.0f;
    [darkGray set];
    NSString *sign = NSLocalizedString(@"SIGN HERE:", @"sign string");
    CGPoint signPoint = CGPointMake(margin, self.bounds.size.height * 0.66);
    CGSize stringSize = [sign drawAtPoint:signPoint withFont:[UIFont AGNHelveticaNeueBoldFontWithSize:16.0f]];
	UIRectFrame(CGRectMake(margin *2 + stringSize.width, signPoint.y + stringSize.height -5.0f, self.bounds.size.width - (margin *3 + stringSize.width), 1.0f));
	CGContextRestoreGState(context);
	
	CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
	CGContextSetLineWidth(context, 3);
	
	for (NSArray *array in self.lines) {
		if (array.count < 2) continue;
		
		CGContextBeginPath(context);
		CGContextMoveToPoint(context, [[array objectAtIndex: 0] CGPointValue].x, [[array objectAtIndex: 0] CGPointValue].y);
		for (int i = 1; i < array.count; i++) {
			CGPoint					point = [[array objectAtIndex: i] CGPointValue];
            [self updateX:point.x];
            [self updateY:point.y];
			CGContextAddLineToPoint(context, point.x, point.y);
		}
		CGContextStrokePath(context);
	}
    
}

- (UIImage *) signatureImage {
	self.clearButton.hidden = YES;
	
	if (self.lines.count == 0) return nil;
    
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, self.opaque, 0.0);
    [self.layer renderInContext:UIGraphicsGetCurrentContext()];
	
	UIImage	*image = UIGraphicsGetImageFromCurrentImageContext();
//	
//#if TARGET_IPHONE_SIMULATOR
//    NSArray *pathArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsDirectory = [pathArray objectAtIndex:0];
//    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"sig.png"];
//    [UIImagePNGRepresentation(image) writeToFile:path atomically: YES];
//#endif
	
	self.clearButton.hidden = NO;
	
	return image;
}

@end
