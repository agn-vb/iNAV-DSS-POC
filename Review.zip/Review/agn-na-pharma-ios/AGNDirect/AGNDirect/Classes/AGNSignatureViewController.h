//
//  AGNSignatureViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/18/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNViewController.h"
#import "AGNRequestForm.h"

static NSString * const AGNSignatureCapturedNotification = @"AGNSignatureCapturedNotification";


@interface AGNSignatureViewController : AGNViewController

@property (strong, nonatomic) AGNCall *call;
@property (readonly, nonatomic) AGNAccount *account;
@property (readonly, nonatomic) AGNAddress *address;
@property (strong, nonatomic) AGNRequestForm *requestForm;
@property NSManagedObjectContext *moc;

@end
