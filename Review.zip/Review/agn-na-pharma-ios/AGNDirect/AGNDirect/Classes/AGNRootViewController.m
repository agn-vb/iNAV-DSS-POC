//
//  AGNViewController.m
//  AGNDirect
//
//  Created by Mark Wells on 7/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //    THIS IS THE CLASS WHICH HANDLES PRIMARY NAVIGATION (LEFT SIDE TAB BAR, ETC)
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "AGNRootViewController.h"
#import "AGNCallHistoryViewController.h"
#import "AGNHCPDetailViewController.h"
#import "AGNSyncStatusView.h"
#import "AGNAppDelegate.h"
#import "AGNUpdateQueueManager.h"

@interface AGNRootViewController ()
@property (strong, nonatomic, readwrite) UIViewController *currentViewController;
@property (strong, nonatomic) IBOutlet UIView *navigationToolbar;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (strong, nonatomic) IBOutlet UIButton *backButton;
@property (strong, nonatomic) IBOutlet UIButton *callsButton;
@property (strong, nonatomic) IBOutlet UIButton *inventoryButton;
@property (strong, nonatomic) IBOutlet UIButton *inavButton;
@property (strong, nonatomic) IBOutlet UIButton *settingsButton;
@property (strong, nonatomic) IBOutlet AGNSyncStatusView * syncView;
@property (strong, nonatomic) UIAlertView *killView;
@property (strong, nonatomic) UIAlertView *syncInterruptedAlert;
@property (weak, nonatomic) IBOutlet UIView *tabBar;

@property (weak, nonatomic) IBOutlet UILabel *trainingLabel1;

@property (weak, nonatomic) IBOutlet UILabel *trainingLabel2;

@property (strong, nonatomic) UINavigationController *callsNavController;
@property (strong, nonatomic) UINavigationController *inventoryNavController;
@property  SEL thwartedRequest;

@property (strong, nonatomic) UIImageView * curtainView;
@property (nonatomic, copy) void (^syncDismissCompletionBlock)(void);

@property (nonatomic) BOOL triggerSync;

- (IBAction)callsButtonPressed:(UIButton *)sender;
- (IBAction)inventoryButtonPressed:(UIButton *)sender;
- (IBAction)inavButtonPressed:(UIButton *)sender;
- (IBAction)settingsButtonPressed:(UIButton *)sender;

@end

@implementation AGNRootViewController
@synthesize backButton = _backButton;
@synthesize callsButton = _callsButton;
@synthesize inventoryButton = _inventoryButton;
@synthesize settingsButton = _settingsButton;
@synthesize callsNavController;
@synthesize inventoryNavController;
@synthesize thwartedRequest=_thwartedRequest;
BOOL _syncViewVisible;
BOOL _haveOutstandingDismissRequest;
BOOL _syncViewComingUp;

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (void)dealoc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (BOOL)isSyncing {
    return _syncViewComingUp || _syncViewVisible;
}

- (void)lowerCurtain:(BOOL)animated {
    [self lowerCurtain:animated completion:nil];
}

- (void)lowerCurtain:(BOOL)animated completion:(void (^)(void))completion {
    if (!self.curtainView) {
        void (^completionBlock)(void) = [completion copy];
        
        self.curtainView = [[UIImageView alloc] initWithFrame:self.view.bounds];
        self.curtainView.backgroundColor = [UIColor AGNColorWithRed:242 green:242 blue:242];
        self.curtainView.image = [UIImage imageNamed:@"curtain-centerpiece"];
        self.curtainView.contentMode = UIViewContentModeCenter;
        self.curtainView.translatesAutoresizingMaskIntoConstraints = YES;
        self.curtainView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        self.curtainView.userInteractionEnabled = YES;
        
        UIActivityIndicatorView * spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.translatesAutoresizingMaskIntoConstraints = NO;
        [self.curtainView addSubview:spinner];
        [spinner startAnimating];
        
        [self.curtainView addConstraint:[NSLayoutConstraint constraintWithItem:spinner attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.curtainView attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
        [self.curtainView addConstraint:[NSLayoutConstraint constraintWithItem:spinner attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.curtainView attribute:NSLayoutAttributeCenterY multiplier:1 constant:50]];
        
        [self.view addSubview:self.curtainView];
        
        if (animated) {
            self.curtainView.alpha = 0.0f;
            [UIView animateWithDuration:0.3f animations:^{
                self.curtainView.alpha = 1.0f;
            }
             completion:^(BOOL finished) {
                 if (completionBlock)
                     completionBlock();
             }];
        }
    }
}


- (void)raiseCurtain:(BOOL)animated {
    if (self.curtainView) {
        
        if (animated) {
            [UIView animateWithDuration:0.3f
                             animations:^{
                                 self.curtainView.alpha = 0.0f;
                             } completion:^(BOOL finished) {
                                 [self.curtainView removeFromSuperview];
                                 self.curtainView = nil;
                             }];
        }
        else {
            [self.curtainView removeFromSuperview];
            self.curtainView = nil;
        }
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    log4Info(@"loading Root View Controller, setting _syncViewVisible to NO");


#if TRAINING
    self.tabBar.backgroundColor=[UIColor redColor];
    self.trainingLabel1.hidden=NO;
    self.trainingLabel2.hidden=NO;

#endif

    _syncViewVisible=NO;
    _haveOutstandingDismissRequest=NO;
    self.backButton.hidden = YES;
    UIImage *navbar = [[UIImage imageNamed:@"navbar"] resizableImageWithCapInsets:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
    self.navBarBackground.image = navbar;
    [self callsButtonPressed:self.callsButton];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(viewControllerPushed) name:AGNViewControllerPushedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(viewControllerPopped:) name:AGNViewControllerPoppedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelNavigationRequest:) name:AGNCancelNavigationRequestNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSyncView:) name:AGNUpdateQueueCountChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncStarted:) name:AGNUpsyncInProgressNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncStopped:) name:AGNUpsyncStoppedNotificationKey object:nil];
    [self lowerCurtain:NO];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [[AGNAppDelegate sharedDelegate] rootViewControllerDidAppear];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Actions
//------------------------------------------------------------------------------

- (IBAction)callsButtonPressed:(id)sender {
    if(![self canLeaveCurrentScreen]){
        // they need to respond to an alert dialog, will honor the request once they do
        self.thwartedRequest = @selector(navigateToCallsTab);
        return;
    }
    [self navigateToCallsTab];
    
}

-(void) navigateToCallsTab{
    [self deselectButtons];
    if (!self.callsViewController) {
        self.callsViewController = [[self storyboard] instantiateViewControllerWithIdentifier:@"CallsViewController"];
        self.callsNavController = [[UINavigationController alloc] initWithRootViewController:self.callsViewController];
        self.callsNavController.delegate=self;
        self.callsNavController.navigationBarHidden = YES;
        [self replaceCurrentViewControllerWithViewController:self.callsNavController];
    }
    [self transitionToViewController:self.callsNavController];
    self.callsButton.selected = YES;
}

- (IBAction)inventoryButtonPressed:(id)sender {
    if(![self canLeaveCurrentScreen]){
        // they need to respond to an alert dialog, will honor the request once they do
        self.thwartedRequest = @selector(navigateToInventoryTab);
        return;
    }
    [self navigateToInventoryTab];
}

-(void)navigateToInventoryTab{
    [self deselectButtons];
    if (!self.inventoryViewController) {
        self.inventoryViewController = [[self storyboard] instantiateViewControllerWithIdentifier:@"InventoryViewController"];
        self.inventoryNavController = [[UINavigationController alloc] initWithRootViewController:self.inventoryViewController];
        self.inventoryNavController.delegate=self;
        self.inventoryNavController.navigationBarHidden = YES;
        [self replaceCurrentViewControllerWithViewController:self.inventoryNavController];
    }
    [self transitionToViewController:self.inventoryNavController];
    self.inventoryButton.selected = YES;
}

- (IBAction)inavButtonPressed:(UIButton *)sender {
    NSURL *url = [NSURL URLWithString:[AGNAppDelegate sharedDelegate].homeUrl];
    [self navigateToExternalURL:url];
}

- (void)navigateToExternalURL:(NSURL *)url {
    if ([AGNSyncManager isReplayingMockData] ||
        [AGNAppDelegate sharedDelegate].reachabilityObserver.networkStatus < RKReachabilityReachableViaWiFi) {
        log4Info(@"iNAV button pressed when offline, ignoring");
        // Just ignore the click
    }
    else {
        log4Info(@"iNAV button pressed, opening URL %@",url);

        [[UIApplication sharedApplication] openURL:url];
    }
}

- (IBAction)settingsButtonPressed:(id)sender {
    if(![self canLeaveCurrentScreen]){
        // they need to respond to an alert dialog, will honor the request once they do
        self.thwartedRequest=@selector(navigateToSettingsTab);
        return;
    }
    [self navigateToSettingsTab];
}

-(void)navigateToSettingsTab{
    [self deselectButtons];
    if (!self.settingsViewController) {
        self.settingsViewController = [[self storyboard] instantiateViewControllerWithIdentifier:@"SettingsViewController"];
        [self replaceCurrentViewControllerWithViewController:self.settingsViewController];
    }
    [self transitionToViewController:self.settingsViewController];
    self.settingsButton.selected = YES;
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Switch View Controllers
//------------------------------------------------------------------------------

- (void)replaceCurrentViewControllerWithViewController:(UIViewController *)newViewController {
    [self addChildViewController:newViewController];
    if (self.currentViewController) {
        [self.currentViewController.view removeFromSuperview];
    }
    [self.contentView addSubview:newViewController.view];
    [newViewController.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self setupBoundsConstraintsForView:newViewController.view];
    self.currentViewController = newViewController;
}

-(void)disableNavigation{
    self.callsButton.enabled=NO;
    self.inventoryButton.enabled=NO;
    self.settingsButton.enabled=NO;
}

-(void)enableNavigation{
    self.callsButton.enabled=YES;
    self.inventoryButton.enabled=YES;
    self.settingsButton.enabled=YES;
    
}

- (void)transitionToViewController:(UIViewController *)vc {
    self.backButton.hidden = YES;
    self.thwartedRequest=nil;
    if(self.currentViewController){
        if ([vc isKindOfClass:[UINavigationController class]]) {
            UINavigationController *navController = (UINavigationController*)vc;
            if (navController.viewControllers.count > 1) {
                self.backButton.hidden = NO;
            }
        }
    }
    
    if (self.currentViewController && self.currentViewController != vc) {
        // prevent button presses while we're animating the transition
        [self disableNavigation];
        [self transitionFromViewController:self.currentViewController
                          toViewController:vc
                                  duration:0.1 options:UIViewAnimationOptionTransitionCrossDissolve
                                animations:^{[self setupBoundsConstraintsForView:vc.view];}
                                completion:^(BOOL completion) {
                                    [vc didMoveToParentViewController:self];
                                    self.currentViewController = vc;
                                    [self enableNavigation];
                                }];
    }
}

- (void)setupBoundsConstraintsForView:(UIView *)aContentView {
    //Set up layout constraints
    NSDictionary *viewsDict = @{ @"view" : aContentView };
    NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[view]|" options:0 metrics:nil views:viewsDict];
    [self.contentView addConstraints:constraints];
    constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:viewsDict];
    [self.contentView addConstraints:constraints];
    
    [self.contentView setNeedsUpdateConstraints];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Sync management
//------------------------------------------------------------------------------

-(AGNSyncStatusViewController *)syncStatusViewController{
    if(!_syncStatusViewController)
        _syncStatusViewController = [[AGNSyncStatusViewController alloc]init];
    return _syncStatusViewController;
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)syncingStarted   {
    
    self.triggerSync = NO; // Make sure we clear it out when a sync starts
    
    if(!_syncViewVisible && !_syncViewComingUp) {
        self.syncStatusViewController.modalPresentationStyle = UIModalPresentationFormSheet;
        self.syncStatusViewController.progressView.progress = 0.0f;
        _syncViewComingUp = YES;
        log4Info(@"syncing started, setting _syncViewVisible to YES");

        [self.syncStatusViewController reset];
        
        [self presentViewController:self.syncStatusViewController
                           animated:YES
                         completion:^(void){
                             log4Debug(@"sync view completed");
                             _syncViewVisible = YES;
                             _syncViewComingUp = NO;
                             if(_haveOutstandingDismissRequest)
                                 [self syncingStopped];
                         }];
        
        self.syncStatusViewController.view.superview.bounds =
        CGRectMake(0, 0, self.syncStatusViewController.view.bounds.size.width, [self.syncStatusViewController modalHeight]);
        NSLog(@"Sync rect %@",NSStringFromCGRect(self.syncStatusViewController.view.superview.bounds));
    }
    else {
        // Reset progress
        self.syncStatusViewController.progressView.progress = 0.0f;
    }
}

-(void)syncingStopped {
    [self syncingStopped:nil];
}
- (void)syncingStopped:(void (^)(void))completion {
    if (completion) // Only override if completion block has not been provided yet
        self.syncDismissCompletionBlock = completion;
    
    if(!_syncViewVisible && _syncViewComingUp){
        log4Debug(@"sync dismiss requested but view not visible");
        _haveOutstandingDismissRequest=YES;
        return;
    }
    _haveOutstandingDismissRequest=NO;
    log4Info(@"Syncing stopped, will set _syncViewVisible to NO in dismiss completion");
    [self.syncStatusViewController dismissViewControllerAnimated:YES completion:^(void){
        log4Info(@"sync status view controller dismiss completed, setting _syncViewVisible to NO now");
        _syncViewVisible=NO;
        if (self.syncDismissCompletionBlock) {
            self.syncDismissCompletionBlock();
            self.syncDismissCompletionBlock = nil;
        }
    }];
}

-(void)setTasksComplete:(int)complete outOf:(int)total{
    [self.syncStatusViewController setTasksComplete:complete outOf:total];
}


- (void)updateSyncView:(NSNotification*)notification {
    self.syncView.badgeCount = [[AGNUpdateQueueManager defaultManager] pendingUpdateCount];
}

- (void)syncStarted:(NSNotification*)notification {
    self.syncView.isSyncing = YES;
}

- (void)syncStopped:(NSNotification*)notification {
    self.syncView.isSyncing = NO;
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Utility
//------------------------------------------------------------------------------

- (void)deselectButtons; {
    self.callsButton.selected = NO;
    self.inventoryButton.selected = NO;
    self.settingsButton.selected = NO;
}

//
//  This method used to trigger save/discard alert on the Call screen if the user attempts to navigate away from a modified call
//

- (BOOL)canLeaveCurrentScreen{
    UIViewController *vc = self.currentViewController;
    
    if ([vc isKindOfClass:[UINavigationController class]]) {
        
        UINavigationController *navController = (UINavigationController*)vc;
        UIViewController *topViewController = [navController topViewController];
        if([topViewController respondsToSelector:@selector(canDismiss)]){
            return (BOOL)[topViewController performSelector:@selector(canDismiss)];
        }
    }
    return YES;
}
 
- (void)doTriggerSync {
    AGNAppDelegate * delegate = [AGNAppDelegate sharedDelegate];
                                 
    // We only really trigger it if we are online and have authenticated. Otherwise, authentication success trigger will do the sync instead
    if (delegate.isAuthenticated && delegate.reachabilityObserver.networkStatus >= RKReachabilityReachableViaWiFi) {
        
        if (delegate.loginTriggered) {
            log4Info(@"logging in, then we'll sync");
            delegate.initiateSyncAfterAuthScreenIsDissmissed = YES;
            delegate.loginTriggered = NO;
        }
        else
            [delegate.syncManager performSync:NO];
        
        // Kill the thwarted request - we don't care about it after syncing
        self.thwartedRequest = nil;
    }else{
        log4Info(@"Tried to trigger sync but couldn't, networks status %@ authenticated %@",delegate.reachabilityObserver.networkStatus>= RKReachabilityReachableViaWiFi?@"Online":@"Offline", delegate.isAuthenticated?@"Y":@"N");
    }
    
    // However, we clear the flag - we don't want to trigger the sync twice
    self.triggerSync = NO;   
}

//------------------------------------------------------------------------------
// MARK: - Back Button
//------------------------------------------------------------------------------
- (IBAction)backButtonPressed:(id)sender {
    UIViewController *vc = self.currentViewController;
    
    if ([vc isKindOfClass:[UINavigationController class]]) {
        if(![self canLeaveCurrentScreen])
            return;
        [self viewControllerPopped:sender];
    }
}

-(void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    self.backButton.enabled=YES;
}

// response to AGNViewControllerPoppedNotificationKey
// allows view controllers to dismiss themselves - e.g. call detail after save
- (IBAction)viewControllerPopped:(id)sender {
    UIViewController *vc = self.currentViewController;
    BOOL poppedToTopLevel = NO;
    
    if ([vc isKindOfClass:[UINavigationController class]]) {
        UINavigationController *navController = (UINavigationController*)vc;
        if (navController.viewControllers.count == 2) {
            self.backButton.hidden = YES;
            poppedToTopLevel = YES;
        }
        self.backButton.enabled=NO;
        [navController popViewControllerAnimated:YES];
    }
    
    // Do we need to trigger sync?
    if (self.triggerSync && poppedToTopLevel) {
        [self doTriggerSync];
    }
    
    // if the user tried to navigate and was stopped (e.g. to save a modified call)
    // we should honor that request once the alert is dismissed
    if (self.thwartedRequest) {
        // Surpress warning about returning a potentially retained object.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [self performSelector:_thwartedRequest];
#pragma clang diagnostic pop
        self.thwartedRequest=nil;
    }
}

- (void)cancelNavigationRequest:(id)sender {
    self.thwartedRequest=nil;
}

- (void)viewControllerPushed {
    self.backButton.hidden = NO;
}

- (BOOL)canSync {
    // We can sync if we're not down into some detail view controller. That is if the currently selected tab is settings, or we're on top level view controllers for calls and inventory
    if (self.currentViewController == self.callsNavController) {
        log4Info(@"Checking if can sync, calls tab with count %d",self.callsNavController.viewControllers.count);
        return self.callsNavController.viewControllers.count <= 1;
    }
    else if (self.currentViewController == self.inventoryNavController) {
        log4Info(@"Checking if can sync, inventory tab with count %d",self.callsNavController.viewControllers.count);
        return self.inventoryNavController.viewControllers.count <= 1;
    }
    else
        return YES; // We can sync when on settings
}


- (BOOL)triggerDownstreamSync {
    if(self.syncInterruptedAlert && [self.syncInterruptedAlert isVisible]){
        [self.syncInterruptedAlert dismissWithClickedButtonIndex:0 animated:YES];
        self.syncInterruptedAlert=nil;
    }
    log4Info(@"========== DOWNSTREAM SYNC TRIGGERED ============");
    
    if (_syncViewVisible){
        log4Info(@"Triggered downstream sync but sync view is already visible, do nothing.");
        return YES; // We are already syncing
    }
    
    if ([self canSync]) {
        [self doTriggerSync];
        return YES;
    }
    else {
        log4Info(@"downstream sync trigger but can't sync right now, set the flag");
        self.triggerSync = YES;
        
        if ([[NSUserDefaults standardUserDefaults] boolForKey:@"simulate_time_to_sync"]) {
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Debug" message:@"Downstream sync flagged" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alert show];
        }
        return NO;
    }
}

-(void)dismissIfVisibleAppVersionForcedUpgradeNotice{
    if(self.killView && self.killView.isVisible){
        [self.killView dismissWithClickedButtonIndex:0 animated:YES];
        self.killView=nil;
    }
}

-(void)showAppVersionForcedUpgradeNotice{
    NSString *message = [[NSUserDefaults standardUserDefaults] objectForKey:kAGNKillSwitchMessage];
    self.killView = [[UIAlertView alloc] initWithTitle:@"Expired Application Version" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    [self.killView show];
}

-(void)showSyncInterruptedAlert{
    NSString *message = NSLocalizedString(@"Previous sync interrupted, your data may be in an inconsistent state. You must go online and perform a full sync before resuming use of the application.", @"Sync Interrupted Message");
    log4Warn(message);
    self.syncInterruptedAlert = [[UIAlertView alloc] initWithTitle:@"Interrupted Sync" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    [self.syncInterruptedAlert show];
}


@end
