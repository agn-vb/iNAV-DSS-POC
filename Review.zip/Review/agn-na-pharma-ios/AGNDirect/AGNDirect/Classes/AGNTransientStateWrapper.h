//
//  AGNTransientStateWrapper.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/6/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGNTransientStateWrapper : NSObject

@property (strong, nonatomic) NSString * abbreviation;
@property (strong, nonatomic) NSString * fullName;

@end
