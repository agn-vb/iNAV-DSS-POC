/*
 *  CGGeometry+UberUIKitExtensions.h
 *  UberUIKit
 *
 *  Created by Bryan Hansen on 2/12/10.
 *  Copyright 2010 Übermind, Inc. All rights reserved.
 *
 */

#import <UIKit/UIKit.h>

/**
 * Returns \a rect expanded \a value pixels in the direction of the specified
 * edge.
 */
CGRect UberCGRectGrow(CGRect rect, CGFloat value, CGRectEdge edge);


/**
 * Horizontally centers \a rectToCenter upon the center position of
 * \a parentRect. Vertical coordinates are not considered. It is considered
 * valid for \a rectToCenter to be larger than \a parentRect.
 *
 * Note that older usages of this function (before it was included within this
 * framework) are more similar to CGRectHorizontallyCenteredInSize().
 */
CGRect UberCGRectHorizontallyCenteredInRect(CGRect rectToCenter, CGRect parentRect);

/**
 * Vertically centers \a rectToCenter upon the center position of \a parentRect.
 * Horizontal coordinates are not considered. It is considered valid for
 * \a rectToCenter to be larger than \a parentRect.
 *
 * Note that older usages of this function (before it was included within this
 * framework) are more similar to CGRectVerticallyCenteredInSize().
 */
CGRect UberCGRectVerticallyCenteredInRect(CGRect rectToCenter, CGRect parentRect);

/**
 * Rounds the dimensions of \a sz up to the nearest integer values, dropping any
 * fractional portion, and returns the new size.
 *
 * @note Rounding is done in a manner consistent with \c CGRectIntegral().
 */
CGSize UberCGSizeIntegral(CGSize sz);

/** @} */
