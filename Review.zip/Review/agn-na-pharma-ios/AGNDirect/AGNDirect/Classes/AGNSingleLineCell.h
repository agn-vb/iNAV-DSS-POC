//
//  AGNSingleLineCell.h
//  AGNDirect
//
//  Created by Adam McLain on 9/10/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNSingleLineCell : UITableViewCell
@property (nonatomic, strong) UILabel *mainLabel;
@end
