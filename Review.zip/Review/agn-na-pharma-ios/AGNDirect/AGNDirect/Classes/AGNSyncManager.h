//
//  AGNSyncManager.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGNContact.h"
#import "Restkit.h"
#import "SFRestAPI.h"
#import "AGNAddress.h"
#import "AGNLicense.h"
#import "AGNAccount.h"
#import "AGNSalesRep.h"
#import "AGNCall.h"
#import "AGNDataManager.h"
#import "AGNCallDetail.h"
#import "AGNDetailPosition.h"
#import "AGNProductBrand.h"
#import "AGNSampleDrop.h"
#import "AGNTimeOffTerritory.h"
#import "AGNSampleInventoryLine.h"
#import "AGNProductSKU.h"
#import "AGNSampleInventoryTransactionLine.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNSamplePermission.h"
#import "AGNDetailBlacklist.h"
#import "AGNHCPRating.h"
#import "AGNSalesRep.h"
#import "AGNDownstreamSync.h"

typedef enum {
    AGNTimestampSyncGroup = 0,
	AGNUserSyncGroup,
	AGNInventorySyncGroup,
    AGNFullAccountsSync,
    AGNFullLicensesSync,
    AGNFullAddressesSync,
    AGNFullContactsSync,
	AGNAccountSyncGroup,
    AGNAccountIdsSyncGroup,
    AGNAccountsAndCallsForIdsSyncGroup,
    AGNSalesTeamSyncGroup,
	AGNCallSyncGroup,
    AGNSalesRepSyncGroup,
    AGNZipCodesSyncGroup,
    AGNFullZipCodesSync
} AGNSyncGrouping;

typedef void(^VersionWarningBlock)(void);

extern NSString * const AGNAbortSyncNotificationKey;

@interface AGNSyncManager : NSObject <RKRequestDelegate, SFRestDelegate, UIAlertViewDelegate, DDSFRequestDelegate>

- (void)syncLoggedInUser;
- (void)performSync:(BOOL)forceFullSync;


// for unit tests only
//-(id)initWithManagedObjectContext:(NSManagedObjectContext *)context;

@property (strong, nonatomic) NSDate *utcLastCompleteSyncTimestamp; // This is the timestamp of the last successful sync (start time), in server time, persisted
@property (strong, nonatomic) NSDate *utcCurrentSyncTimestamp; // This is the server timestamp for the current sync, in server time
@property (strong, nonatomic) NSDate *localSyncStartedTimestamp; // This is when the current sync began, in device time
@property (strong, nonatomic) NSDate *localLastSyncStartedTimestamp; // this is the timestamp of when the last successful sync began, in device time, persisted

@property (assign, nonatomic) BOOL needFullSync;

@property (assign, nonatomic) BOOL syncInProgress;
@property (assign, nonatomic) BOOL fullSyncRequested;

@property (strong, nonatomic) DDSFRequest *userRequest;


@property (assign, nonatomic) BOOL incrementalSync;
@property (assign, nonatomic) BOOL testingSFRestAPICall;
@property (strong, nonatomic) NSDate *utcCurrentSyncLastTimestamp;
@property (nonatomic) int pendingChanges;
@property (nonatomic) BOOL syncAborted;
@property (strong, nonatomic) UIAlertView *userNotConfiguredAlertView;
@property (strong, nonatomic) UIAlertView *versionWarningAlertView;
@property (nonatomic, copy) VersionWarningBlock versionWarningBlock;

/**
 * Downstream JSON representations from Salseforce have custom field names suffixed with
 * '__c'. Upstream do not. This method is a utility method to create a new dictionary 
 * with key names that do not include the '__c' suffix, so that we can treat upstream and
 * downstream similarly, and so that reverts (which use the JSON generated for an upstream
 * sync) can use the same <AGNModelProtocol>initWithDictionary: method as the downstream 
 * sync does.
 */
+ (NSDictionary *)dictionaryWithStandardizedKeysFrom:(NSDictionary *)dict;

- (void)upsertSyncRecord;
- (void)completeDownstreamSync;
- (void)cleanUpAfterPartialSync;

+ (BOOL)isReplayingMockData;

@property (nonatomic, strong) AGNDownstreamSync * sync;

@end
