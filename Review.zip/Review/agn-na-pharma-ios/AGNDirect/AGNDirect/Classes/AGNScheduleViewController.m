//
//  AGNScheduleViewController.m
//  AGNDirect
//
//  Created by Mark Wells on 8/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//   SCHEDULE VIEW, LEFT PANE

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNScheduleViewController.h"
#import "AGNScheduleCell.h"
#import "AGNHCPDetailViewController.h"
#import "AGNCall.h"
#import "AGNCallsViewController.h"
#import "AGNTableViewHeader.h"
#import "AGNCallHistoryViewController.h"
#import "AGNTableView.h"
#import "AGNCategoryHeaders.h"
#import "AGNScheduleEntry.h"
#import "AGNTOTCell.h"
#import "AGNCategoryHeaders.h"
#import "Kal.h"
#import "objc/runtime.h"
#import "AGNRequestForm.h"
#import "AGNScheduleFormCell.h"
#import "AGNFormDetailViewController.h"
#import "AGNReprintDetailViewController.h"

static char kAGNHeaderSectionKey;
static NSString *const kScrollPositionRestoreStateKey = @"ScheduleScrollPositionRestoreStateKey";
static NSString *const kScrollPositionSavedDateKey = @"kScrollPositionSavedDateKey";


@interface AGNScheduleViewController ()

@property (weak, nonatomic) IBOutlet AGNTableView *tableView;
@property (strong, nonatomic) NSIndexPath *currentlySelectedCell;
@property (strong, nonatomic) UIPopoverController *calendarPopover;
@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbar;
@property BOOL showPlaceholder;
@property BOOL callsOnly;
@property (strong, nonatomic) KalViewController *calendar;
@property (strong, nonatomic) IBOutlet UIButton *callsOnlyButton;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;

@end

@implementation AGNScheduleViewController
@synthesize tableView;
@synthesize topHeaderViewConstraint;


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.tableFooterView = [[UIView alloc] init];
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
           self.topHeaderViewConstraint.constant=20.0f;
    }
}

//-(NSDate *)today{
//
//    NSDate *now = [NSDate date];
//    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
//    NSDateComponents *components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit fromDate:now];
//    [components setHour:0];
//    return [calendar dateFromComponents:components];
//    
//}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(callDeleted)
                                                 name:AGNScheduleCallDeletedKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(displayScheduleView)
                                                 name:AGNLoggedInUserSetNotificationKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadContent:) name:kDDSFNotificationSyncEnded object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncStarted:) name:kDDSFNotificationSyncStarted object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadContent:) name:AGNUpdateTransactionRevertedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadContent:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [self loadData];


}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:AGNScheduleCallDeletedKey object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:AGNLoggedInUserSetNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:kDDSFNotificationSyncStarted object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:kDDSFNotificationSyncEnded object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:AGNUpdateTransactionRevertedNotificationKey object:nil];

}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self persistScrollPosition];
}

-(void)loadData{
    NSError *error = nil;
    
    
    self.fetchedResultsController = [[AGNDataManager defaultInstance] scheduleViewFetchedResultsController:(_callsOnly)];
	if (![self.fetchedResultsController performFetch:&error]) {
        log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
	}
    if([[self.fetchedResultsController sections]count]==0)
        self.showPlaceholder=YES;
    else
        self.showPlaceholder=NO;
    [self displayScheduleView];

}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
     self.currentlySelectedCell = [NSIndexPath indexPathForRow:-1 inSection:-1];
}

-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    [self persistScrollPosition];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.tableView.contentSize = newContentSize;
    [self.tableView reloadData];
    [self restoreScrollPosition];
}

-(void)callDeleted{
    [self loadData];
}

-(void)scrollToToday{
    log4Info(@"Scroll to today");
    [self scrollToDate:[NSDate date]];
    if (self.calendarPopover) {
        [self.calendarPopover dismissPopoverAnimated:YES];
    }
}

-(void)scrollToDate:(NSDate *)date{
    log4Info(@"Scrolling to date %@",date);
    AGNScheduleEntry * call = [[AGNDataManager defaultInstance] firstScheduleEntryForDate:date];
    if (call) {
        NSIndexPath * indexPath = [self.fetchedResultsController indexPathForObject:call];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)displayScheduleView {
    log4Info(@"Displaying schedule");
//    AGNSalesRep *loggedInRep = [[AGNAppDelegate sharedDelegate] loggedInSalesRep];
//    self.calls =[[loggedInRep.calls allObjects]  sortedArrayUsingComparator: ^(AGNCall *obj1, AGNCall *obj2) {
//        return [obj1.startDate compare:obj2.startDate];
//    }];
//    NSMutableSet *dateSet = [[NSMutableSet alloc] init];
//    for (AGNCall *call in self.calls) {
//        if(!call.startDate)
//            continue;
//        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
//        NSDateComponents *components = [calendar components:( NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit ) fromDate:call.startDate];
//        [dateSet addObject:[calendar dateFromComponents:components]];
//    }
//    
//    self.uniqueDates = [dateSet.allObjects sortedArrayUsingSelector:@selector(compare:)];
    [self.tableView reloadData];
    [self restoreScrollPosition];
}

-(void)persistScrollPosition{
    log4Info(@"Saving scroll position");
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    CGFloat offsetY = self.tableView.contentOffset.y;
    [standardUserDefaults setFloat:offsetY forKey:kScrollPositionRestoreStateKey];
    [standardUserDefaults setObject:[NSDate date] forKey:kScrollPositionSavedDateKey];
}

-(void)clearScrollPosition{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:kScrollPositionRestoreStateKey];
    [standardUserDefaults removeObjectForKey:kScrollPositionSavedDateKey];
}

-(void)restoreScrollPosition{
    NSDate * date = (NSDate*) [[NSUserDefaults standardUserDefaults] objectForKey:kScrollPositionSavedDateKey];
    CGFloat offsetY = [[NSUserDefaults standardUserDefaults] floatForKey:kScrollPositionRestoreStateKey];
    
    if(!date || ![date isSameDay:[NSDate date]]){
        log4Info(@"Saved scroll position is old (%@), not using",date);
        offsetY=0;
    }
    if (offsetY==0) {
        [self scrollToToday];
    }
    else if (offsetY > (self.tableView.contentSize.height) - self.tableView.bounds.size.height) {
        log4Info(@"Scrolling to saved scroll position");
       
        offsetY = (self.tableView.contentSize.height) - self.tableView.bounds.size.height;
        
        CGPoint contentOffset = CGPointMake(self.tableView.contentOffset.x, offsetY);
        if (offsetY>0.0f) {
            [self.tableView setContentOffset:contentOffset];
        }
    }
}

- (IBAction)scheduleButtonTapped:(UIButton *)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNHCPFilterEnteredKey object:self];
}

-(IBAction)callsOnlyTapped:(UIButton *)sender{
    _callsOnly=!_callsOnly;
    if(_callsOnly){
        [self.callsOnlyButton setTitle:@"Show All Activity" forState:UIControlStateNormal];
    }else{
        [self.callsOnlyButton setTitle:@"Show Calls Only" forState:UIControlStateNormal];
    }
    [self loadData];
    [self.tableView reloadData];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.showPlaceholder) {
        AGNScheduleEntry *entry = [self.fetchedResultsController objectAtIndexPath:indexPath];
        UIColor * textColor = [UIColor AGNDarkGray];
        UIColor * backgroundColor = [UIColor AGNNorilskSneg];
        UIColor * dateColor = [UIColor AGNDarkGray];

        if ([entry activeEntry]) {
            textColor = [UIColor AGNGreyMatter];
            backgroundColor = [UIColor whiteColor];
            dateColor = [UIColor AGNWAwawa];
        }
        
        if ([cell isKindOfClass:[AGNScheduleCell class]]) {
            AGNScheduleCell *schedCell = (AGNScheduleCell *)cell;
            schedCell.nameLabel.textColor=textColor;
            schedCell.backgroundColor=backgroundColor;
            schedCell.timeLabel.textColor=dateColor;
        }
        
        else if ([cell isKindOfClass:[AGNTOTCell class]]) {
            AGNTOTCell *schedCell = (AGNTOTCell *)cell;
            schedCell.nameLabel.textColor=textColor;
            schedCell.backgroundColor=backgroundColor;
            schedCell.startTime.textColor=dateColor;
            schedCell.endTime.textColor=dateColor;
            schedCell.endDate.textColor=dateColor;
        }
        else { // Form cell
            AGNScheduleFormCell * formCell = (AGNScheduleFormCell *)cell;
            formCell.nameLabel.textColor=textColor;
            formCell.backgroundColor=backgroundColor;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * ScheduleCellIdentifier = @"ScheduleCell";
    static NSString * TOTCellIdentifier = @"TOTCell";
    static NSString * ScheduleFormCellIdentifier = @"ScheduleFormCell";
    
    if (self.showPlaceholder) {
        AGNScheduleCell *cell = [self.tableView dequeueReusableCellWithIdentifier:ScheduleCellIdentifier];
        [cell agnSetStyledSelectedBackground];
        cell.nameLabel.text = AGNPlaceholderText;
        cell.addressLabel.text = @"";
        cell.timeLabel.text = @"";
        cell.nameLabel.textColor = [UIColor AGNGreyMatter];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    
    AGNScheduleEntry *entry = [self.fetchedResultsController objectAtIndexPath:indexPath];
    
    if ([entry isKindOfClass:[AGNRequestForm class]]) {
        AGNScheduleFormCell * cell = [self.tableView dequeueReusableCellWithIdentifier:ScheduleFormCellIdentifier];
        [cell agnSetStyledSelectedBackground];
        
        AGNRequestForm * form = (AGNRequestForm*)entry;
        
        if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))
            cell.nameLabel.attributedText = [form attributedDoctorNameDesignationAndSpecialty];
        else
            cell.nameLabel.text = form.doctorNameAndDesignation;
        
        cell.statusLabel.text = [form statusString];
        cell.userInteractionEnabled = YES;
        NSString * iconName = [NSString stringWithFormat:@"%@_icon3", form.type];
        log4Debug(@"Icon name = %@, form = %@", iconName, form);
        cell.icon.image = [UIImage imageNamed:iconName];
        return cell;
    }
    else if ([entry isKindOfClass:[AGNMarketingDisbursement class]]) {
        AGNScheduleFormCell * cell = [self.tableView dequeueReusableCellWithIdentifier:ScheduleFormCellIdentifier];
        [cell agnSetStyledSelectedBackground];

        AGNMarketingDisbursement * reprint = (AGNMarketingDisbursement*)entry;

        if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))
            cell.nameLabel.attributedText = [reprint attributedDoctorNameDesignationAndSpecialty];
        else
            cell.nameLabel.text = reprint.doctorNameAndDesignation;

        cell.statusLabel.text =  [reprint scheduleDescription];
        cell.userInteractionEnabled = YES;
        NSString * iconName = [NSString stringWithFormat:@"%@_icon", @"MC"];
        cell.icon.image = [UIImage imageNamed:iconName];
        return cell;


    }
    else {
        static NSDateFormatter *dateFormatter;
        if (!dateFormatter) {
            dateFormatter = [[NSDateFormatter alloc] init];
            NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
            [dateFormatter setLocale:usLocale];
            [dateFormatter setAMSymbol:@"A"];
            [dateFormatter setPMSymbol:@"P"];
            [dateFormatter setDateFormat:@"h:mma"];
        }
         
        if([entry isKindOfClass:[AGNCall class]]) {
            AGNScheduleCell *cell = [self.tableView dequeueReusableCellWithIdentifier:ScheduleCellIdentifier];
            [cell agnSetStyledSelectedBackground];
            cell.timeLabel.text = [dateFormatter stringFromDate:entry.startDate];
            AGNCall * call = (AGNCall *)entry;
            if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]))
                cell.nameLabel.attributedText = [call.account attributedDoctorNameDesignationAndSpecialty];
            else
                cell.nameLabel.text = call.account.doctorNameAndDesignation;
            
            cell.addressLabel.text = call.address.singleLineFormattedString;
            cell.userInteractionEnabled = YES;
            return cell;
        }
        else {
            AGNTOTCell *cell = [self.tableView dequeueReusableCellWithIdentifier:TOTCellIdentifier];
            [cell agnSetStyledSelectedBackground];
            cell.startTime.text = [dateFormatter stringFromDate:entry.startDate];
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
            [df setTimeZone:[NSTimeZone localTimeZone]];
            [df setLocale:usLocale];
            [df setDateFormat:@"MM/dd/yyyy"];
            
            cell.endDate.text = [df stringFromDate:entry.endDate];
            cell.endTime.text = [dateFormatter stringFromDate:entry.endDate];
            if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
                cell.nameLabel.text = @"TIME OFF TERRITORY";
            }
            else {
                cell.nameLabel.text = @"TOT";
            }
            
            cell.userInteractionEnabled = NO;
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    // shouldn't happen
    return nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView
{
    if(self.showPlaceholder){
        return 1;
    }
    NSInteger count = [[self.fetchedResultsController sections] count];
	return count;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section
{
    if(self.showPlaceholder){
        return 1;
    }
    id <NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
    
	NSInteger count = [sectionInfo numberOfObjects];
	return count;
    
}

- (CGFloat)tableView:(UITableView *)aTableView heightForHeaderInSection:(NSInteger)section {
    if(self.showPlaceholder)
        return 0.0f;
    return 28.0f;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.showPlaceholder) {
        AGNScheduleEntry *entry = [self.fetchedResultsController objectAtIndexPath:indexPath];
        if ([entry isKindOfClass:[AGNCall class]] || [entry isKindOfClass:[AGNRequestForm class]] || [entry isKindOfClass:[AGNMarketingDisbursement class]])
            return self.tableView.rowHeight;
    }
    return 34.0f;
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [self persistScrollPosition];
}

- (NSDate *)dateFromSectionName:(NSString *)sectionName{
    return [NSDate agnDateFromString:sectionName];
}

- (UIView *)tableView:(UITableView *)aTableView viewForHeaderInSection:(NSInteger)section {
    if(self.showPlaceholder){
        return nil;
    }

    AGNTableViewHeader *header = [[AGNTableViewHeader alloc] init];
    id <NSFetchedResultsSectionInfo> theSection = [[self.fetchedResultsController sections] objectAtIndex:section];

    NSString * sectionName = [theSection name];
    NSDate *headerDate = [self dateFromSectionName:sectionName];

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormatter setLocale:usLocale];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    header.rightLabel.text = [[dateFormatter stringFromDate:headerDate] uppercaseString];
    [dateFormatter setDateFormat:@"EEEE"];
    header.leftLabel.text = [[dateFormatter stringFromDate:headerDate] uppercaseString];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headerTapped:)];
    [header addGestureRecognizer:tap];
    
	objc_setAssociatedObject(header, &kAGNHeaderSectionKey, [NSNumber numberWithInt:section], OBJC_ASSOCIATION_RETAIN);
    
    return header;
}

//------------------------------------------------------------------------------
#pragma mark - Calendar Popover
//------------------------------------------------------------------------------
- (void)headerTapped:(id)sender {
    
    if(self.showPlaceholder)
        return;
    
    // return if called by non-AGNTableViewHeader
    CGRect presentingRect = CGRectZero;
    if (![[sender view] isKindOfClass:[AGNTableViewHeader class]]) {
        return;
    }
    AGNTableViewHeader *header = (AGNTableViewHeader *)[sender view];
    NSNumber *section = objc_getAssociatedObject(header, &kAGNHeaderSectionKey);
    int sectionIndex = [section intValue];
    NSString  *sectionDateString = [[self.fetchedResultsController sections] [sectionIndex]name];
    
    NSDate *sectionDate = [self dateFromSectionName:sectionDateString];

    
    // do not present calendar if header is not at the top of the tableview
    CGFloat headerPosition = self.tableView.contentOffset.y - header.frame.origin.y;
    if (headerPosition != 0.0f) {
        return;
    }
    
    CGRect labelFrame = header.rightLabel.frame;
    
    presentingRect = [self.tableView convertRect:labelFrame fromView:header];

    _calendar = [[KalViewController alloc] initWithSelectedDate:sectionDate];
    _calendar.view.backgroundColor = [UIColor whiteColor];
    _calendar.dataSource = self;
    [_calendar reloadData];
    _calendar.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Today" style:UIBarButtonItemStylePlain target:self action:@selector(scrollToToday)];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:_calendar];
    
    
    UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:nav];
    self.calendarPopover = popover;
    log4Info(@"Launching calendar popover");
    [popover presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}

- (void)dismissCaledar {
    log4Info(@"Dismissing calendar popover");
    [self.calendarPopover dismissPopoverAnimated:YES];
}

//------------------------------------------------------------------------------
#pragma mark - KAL Delegate Method
//------------------------------------------------------------------------------
- (void)presentingDatesFrom:(NSDate *)fromDate to:(NSDate *)toDate delegate:(id<KalDataSourceCallbacks>)delegate; {
    
    [delegate loadedDataSource:self];
    
}

- (NSArray *)markedDatesFrom:(NSDate *)fromDate to:(NSDate *)toDate {
    NSArray * activities = [[AGNDataManager defaultInstance]calendarEntriesFrom:fromDate to:toDate];
    return [activities valueForKeyPath:@"@unionOfObjects.startDate"];
}

- (void)removeAllItems {
    
}

- (void)loadItemsFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate {
    
    // Dismiss calendar , only if its not sliding
    KalView *kView=(KalView *) _calendar.view;
    if (![kView isSliding]) {
        
        NSCalendar * calendar = [NSCalendar currentCalendar];
        
        NSUInteger components = NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit;
        NSDateComponents * fromDateComponents = [calendar components:components fromDate:fromDate];
        
        AGNScheduleEntry * firstCall = [[AGNDataManager defaultInstance] firstScheduleEntryForDate:fromDate];
        
        if ([firstCall isKindOfClass:[AGNHCPActivity class]]) {
            AGNHCPActivity *aCall = (id)firstCall;
            if (aCall.account) {
                NSDate *firstCallStartDate = aCall.startDate;
                NSDateComponents *firstCallStartDateComponents = [calendar components:components fromDate:firstCallStartDate];
                
                NSDate *date1 = [calendar dateFromComponents:firstCallStartDateComponents];
                NSDate *date2 = [calendar dateFromComponents:fromDateComponents];
                
                if ([date1 isEqualToDate:date2]) {
                    
                    [self scrollToDate:date1];
                    
                    [self dismissCaledar];
                }
            }
        }
    }
}


- (NSIndexPath *)tableView:(UITableView *)aTableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(self.showPlaceholder){
        return indexPath;
    }
    UITableViewCell *cell = [aTableView cellForRowAtIndexPath:indexPath];
    if (cell.selected) {
        self.currentlySelectedCell = indexPath;
    }
    
    return indexPath;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(self.showPlaceholder){
        return;
    }

    id entity = [self.fetchedResultsController objectAtIndexPath:indexPath];
    
    if ([entity isKindOfClass:[AGNCall class]])
        [self navigateToCall:entity];
    else if([entity isKindOfClass:[AGNRequestForm class]])
        [self navigateToForm:entity];
    else if ([entity isKindOfClass:[AGNMarketingDisbursement class]])
        [self navigateToMCD:entity];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([sender isKindOfClass:[AGNCall class]]) {
        AGNCallDetailViewController * callDetailVC = [segue destinationViewController];
        callDetailVC.call = sender;
    }
    else {
        AGNFormDetailViewController * formDetailVC = [segue destinationViewController];
        formDetailVC.requestForm = sender;
    }
    
    //back button
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

- (void)navigateToCall:(AGNCall *)call {
    [self performSegueWithIdentifier:@"CreateCallSegue" sender:call];
}

- (void)navigateToForm:(AGNRequestForm *)form {
    [self performSegueWithIdentifier:@"OpenFormSeque" sender:form];
}

- (void)navigateToMCD:(AGNMarketingDisbursement *)mcd {
    AGNReprintDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNReprintDetailViewController"];
    detailVC.marketingDisbursement = mcd;
    [self.navigationController pushViewController:detailVC animated:YES];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

-(void)syncStarted:(NSNotification*)notification {
    self.fetchedResultsController=nil;
}

- (void)reloadContent:(NSNotification*)notification {
    [self loadData];
}

@end
