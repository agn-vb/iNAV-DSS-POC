//
//  AGNTransientRatingFrequencyContainer.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTransientRatingFrequencyContainer.h"

@implementation AGNTransientRatingFrequencyContainer

@end
