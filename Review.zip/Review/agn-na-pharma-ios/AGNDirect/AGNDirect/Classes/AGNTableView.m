//
//  AGNTableView.m
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTableView.h"
#import "AGNCategoryHeaders.h"

@implementation AGNTableView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self AGNStyleTableView];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self AGNStyleTableView];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    self = [super initWithFrame:frame style:style];
    if (self) {
        [self AGNStyleTableView];
    }
    
    return self;
}

- (void)AGNStyleTableView {
    self.backgroundColor = [UIColor AGNNorilskSneg];
    self.separatorColor = [UIColor whiteColor];
    NSLog(@"--------> Tableview row height : %f", self.rowHeight);
    if (self.rowHeight == -1.0)
        self.rowHeight = 44;
}

 

@end
