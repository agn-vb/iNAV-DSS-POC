//
//  AGNAvailableSampleCell.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNAvailableSampleCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel * label;

@end
