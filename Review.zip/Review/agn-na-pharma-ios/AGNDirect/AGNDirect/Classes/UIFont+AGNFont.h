//
//  UIFont+AGNFont.h
//  AGNDirect
//
//  Created by Adam McLain on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (AGNFont)

+ (UIFont *)AGNAvenirBlackFontWithSize:(CGFloat)size;
+ (UIFont *)AGNAvenirHeavyFontWithSize:(CGFloat)size;
+ (UIFont *)AGNAvenirRomanFontWithSize:(CGFloat)size;
+ (UIFont *)AGNAvenirLightFontWithSize:(CGFloat)size;
+ (UIFont *)AGNHelveticaNeueBoldFontWithSize:(CGFloat)size;

+ (UIFont *)AGNAvenirMedium16;
+ (UIFont *)AGNAvenirMedium21;
+ (UIFont *)AGNAvenirBlack21;
+ (UIFont *)AGNAvenirBlack16;
+ (UIFont *)AGNAvenirHeavy16;
+ (UIFont *)AGNAvenirHeavy14;
+ (UIFont *)AGNAvenirRoman16;
+ (UIFont *)AGNAvenirRoman13;
+ (UIFont *)AGNHelveticaNeueBold16;
+ (UIFont *)AGNHelveticaNeueBold12;


@end
