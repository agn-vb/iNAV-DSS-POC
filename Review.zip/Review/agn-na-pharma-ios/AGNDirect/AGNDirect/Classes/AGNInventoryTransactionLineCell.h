//
//  AGNInventoryTransactionLineCell.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *AGNTransferLineQuantityChangedNotificationKey = @"AGNTransferLineQuantityChangedNotificationKey";
static NSString * const AGNTransferCellDidBeginEditing = @"AGNTransferCellDidBeginEditing";


@interface AGNInventoryTransactionLineCell : UITableViewCell <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel * label;
@property (strong, nonatomic) IBOutlet UILabel * quantityLabel;
@property (strong, nonatomic) IBOutlet UITextField * quantityTextField;
@property (strong, nonatomic) IBOutlet UILabel * availableQuantity;
@property (nonatomic, readonly) BOOL isValid;

@property (strong, nonatomic) AGNSampleInventoryTransactionLine * model;
@property (strong, nonatomic) AGNProductSKU * sku;

@property (nonatomic) BOOL editable;

@end
