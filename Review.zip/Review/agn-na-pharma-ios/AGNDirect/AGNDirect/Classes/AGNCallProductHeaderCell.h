//
//  AGNCallProductHeaderCell.h
//  AGNDirect
//
//  Created by Mark Wells on 8/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNCallProductHeaderCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIButton *editButton;

@end
