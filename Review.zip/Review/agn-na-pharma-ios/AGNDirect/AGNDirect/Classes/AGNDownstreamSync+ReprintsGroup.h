//
//  AGNDownstreamSync+ReprintsGroup.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/10/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNDownstreamSync.h"

@interface AGNDownstreamSync (ReprintsGroup)

- (DDSFSyncItem*)reprintsGroup;
- (DDSFSyncItem*)reprintsReferenceGroup;

@end
