//
//  NSDate+AGNDate.m
//  AGNDirect
//
//  Created by Adam McLain on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "NSDate+AGNDate.h"

@implementation NSDate (AGNDate)

static const int kSecondsInThirtyMinutes = 30 * 60;

-(BOOL)isSameDay:(NSDate *)date{

    static NSCalendar *calendar;
    if (!calendar) {
        calendar = [NSCalendar currentCalendar];
    }
    NSDateComponents *myComponents =  [calendar components:(  NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit ) fromDate:self];
    NSDateComponents *compareComponents = [calendar components:(  NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit ) fromDate:date];
    return [myComponents isEqual:compareComponents];
}

- (NSString *)agnFormattedDateString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM/dd/yy"];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormatter setLocale:usLocale];
    return [dateFormatter stringFromDate:self];
}

- (NSString *)agnFormattedTimestampString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM/dd/yy h:mm a"];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormatter setLocale:usLocale];
    NSTimeZone *tz = [NSTimeZone localTimeZone];
    dateFormatter.timeZone=tz;
    return [dateFormatter stringFromDate:self];
}

- (NSString *)agnRFC3339FormattedTimestampString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'.'SSSZ"];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormatter setLocale:usLocale];
    return [dateFormatter stringFromDate:self];
}

- (NSString *)agnUpsertTimestampString{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *local = [df timeZone];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [df setTimeZone:gmt];
    NSString *timeStamp = [df stringFromDate:self];
    [df setTimeZone:local];
    return  timeStamp;
}

+ (NSDate *)agnDateFromString:(NSString *)dateString {
    if([dateString isEqual:[NSNull null]] || dateString.length < 1){
        return nil;
    }
    static NSDateFormatter *df;
    if (!df) {
        df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"yyyy-MM-dd"];
        [df setLocale:[NSLocale currentLocale]];
        [df setLenient:YES];
    }
    static NSMutableDictionary *dateDict;
    if (!dateDict) {
        dateDict = [[NSMutableDictionary alloc] init];
    }
    
    if ([dateDict.allKeys containsObject:dateString]) {
        return [dateDict valueForKey:dateString];
    } else {
        NSDate *date = [df dateFromString:dateString];
        if (date != nil)
            [dateDict setObject:date forKey:dateString];
        return date;
    }
    
}

+ (NSDate *)agnGMTDateFromString:(NSString *)dateString {
    if([dateString isEqual:[NSNull null]] || dateString.length < 1){
        return nil;
    }
    static NSDateFormatter *df;
    if (!df) {
        df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"yyyy-MM-dd"];
        [df setLocale:[NSLocale currentLocale]];
        [df setLenient:YES];
        [df setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    }
    static NSMutableDictionary *dateDict;
    if (!dateDict) {
        dateDict = [[NSMutableDictionary alloc] init];
    }
    
    if ([dateDict.allKeys containsObject:dateString]) {
        return [dateDict valueForKey:dateString];
    } else {
        NSDate *date = [df dateFromString:dateString];
        if (date != nil)
            [dateDict setObject:date forKey:dateString];
        return date;
    }
    
}

+ (NSDate *)agnDateTimeFromString:(NSString *)dateString {
    if([dateString isEqual:[NSNull null]]){
        return nil;
    }
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd h:mm"];
    [df setLenient:YES];
    return [df dateFromString: dateString];
}

+ (NSDate *)agnDateFromDateTimeComponents:(NSString *)dateString :(NSString *)timeString{
    static NSCalendar *cal;
    if (!cal){
        cal = [NSCalendar currentCalendar];
    }
    
    static NSDateFormatter *dateFormatter;
    if (!dateFormatter) {
        dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd h:mm a"];
        [dateFormatter setLenient:YES];
        [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [dateFormatter setLocale:usLocale];
    }

    NSString *dateTimeString = [NSString stringWithFormat:@"%@ %@",dateString,timeString];
    NSDate *date = [dateFormatter dateFromString: dateTimeString];
    return date;
}

+ (NSDate *)agnDateRoundedDownToThirtyMinutes:(NSDate *)date {
    // Strip miliseconds by converting to int
    int referenceTimeInterval = (int)[date timeIntervalSinceReferenceDate];
    
    int remainingSeconds = referenceTimeInterval % kSecondsInThirtyMinutes;
    int timeRoundedDownToMinutes = referenceTimeInterval - remainingSeconds;
    
    NSDate *roundedDownDate = [NSDate dateWithTimeIntervalSinceReferenceDate:(NSTimeInterval)timeRoundedDownToMinutes];
    
    return roundedDownDate;
}

+ (NSDate *)agnDateRoundedUpToThirtyMinutes:(NSDate *)date {
    int interval = (int)[date timeIntervalSinceReferenceDate];
    int secondsAfterBoundary = interval % kSecondsInThirtyMinutes;
    if (secondsAfterBoundary == 0) {
        return date;
    }
    interval += (kSecondsInThirtyMinutes - secondsAfterBoundary);
    return [NSDate dateWithTimeIntervalSinceReferenceDate:interval];
}

+ (NSDate *)agnDateFromRFC3339TimestampString:(NSString *)dateString {
    if([dateString isEqual:[NSNull null]]){
        return nil;
    }
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'.'SSSZ"];
    return [dateFormatter dateFromString:dateString];
}

+ (NSDate *)agnDateFromTimestampString:(NSString *)dateString {
    if([dateString isEqual:[NSNull null]]){
        return nil;
    }
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    return [dateFormatter dateFromString:dateString];
}

+ (NSDate *)dateFromAddressAvailabilityString:(NSString *)string {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    [df setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    [df setDateFormat:@"h:mm a"];
    [df setLenient:YES];
    NSDate *tempDate = [df dateFromString:string];
    if (!tempDate) {
        [df setDateFormat:@"h a"];
        [df setLenient:YES];
        tempDate = [df dateFromString:string];
    }
    
    return tempDate;
}

- (NSString *)agnStringFromDate {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd"];
    return [df stringFromDate:self];
}

- (NSString *)agnGMTStringFromDate {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd"];
    [df setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    return [df stringFromDate:self];
}

- (NSString *)agnStringFromDateTime {
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    return [df stringFromDate:self];
}

- (NSString *)agnStringFromRFC3339Timestamp {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'.'SSSZ"];
    return [dateFormatter stringFromDate:self];
}

- (NSString *)agnSfdcDateComponentString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    return [dateFormatter stringFromDate:self];
}

- (NSString *)agnSfdcTimeComponentString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    [dateFormatter setDateFormat:@"h:mm a"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    return [dateFormatter stringFromDate:self];
}

- (NSString *)agnAvailabilityString {
    static NSCalendar *calendar;
    if (!calendar) {
        calendar = [NSCalendar currentCalendar];
        calendar.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    }
    NSDateComponents *components = [calendar components:NSMinuteCalendarUnit fromDate:self];
    NSInteger minutes = [components minute];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    if (minutes == 0) {
        [dateFormatter setDateFormat:@"h a"];
    } else {
        [dateFormatter setTimeStyle:NSDateFormatterShortStyle];
    }
    
    return [dateFormatter stringFromDate:self];
}

- (NSString*)agnLocalTimeString {
    NSDateFormatter * df = [[NSDateFormatter alloc] init];
    [df setTimeZone:[NSTimeZone localTimeZone]];
    [df setTimeStyle:kCFDateFormatterShortStyle];
    [df setDateStyle:kCFDateFormatterNoStyle];
    return [df stringFromDate:self];
}

- (NSDate*)agnMidnightEastCoast {
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents * components = [gregorian components:(NSYearCalendarUnit |
                                                           NSMonthCalendarUnit |
                                                           NSDayCalendarUnit | NSTimeZoneCalendarUnit)
                                                 fromDate:self];
    // Minutes since midnight are based off east coast time, taking into account dailight savings
    NSTimeZone * eastCoast = nil;
    if (components.timeZone.isDaylightSavingTime)
        eastCoast = [NSTimeZone timeZoneWithAbbreviation:@"EDT"];
    else
        eastCoast = [NSTimeZone timeZoneWithAbbreviation:@"EST"];
    components.timeZone = eastCoast;
    
    return [gregorian dateFromComponents:components];
}

-(BOOL)isExpired{
    //comparing just the day, so that products that expire on today's date don't show as expired
    unsigned int flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSDateComponents *expirationDateComponents = [calendar components:flags fromDate:self];
    NSDateComponents *currentDateComponents = [calendar components:flags fromDate:[NSDate date]];
    
    NSDate *expiredDay = [calendar dateFromComponents:expirationDateComponents];
    NSDate *todayDay = [calendar dateFromComponents:currentDateComponents];
    
    NSComparisonResult result = [expiredDay compare:todayDay];
    if (result == NSOrderedAscending) {
        return YES;
    }
    return NO;
}

+(NSDate *)agnUTCDateFromDateString:(NSString *)dateString andTimeString:(NSString *)timeString {
    NSDate *dateSent = [NSDate agnDateFromDateTimeComponents:dateString :timeString];
    
    // SFDC gives us the start date in the timezone for the user on the server
    // We need to convert it to GMT so we can display it in the device timezone
    // On upsert we're expected to send GMT
    NSTimeZone* userTimeZone = [AGNAppDelegate sharedDelegate].loggedInSalesRep.userTimeZone;
    NSInteger gmtOffset = [userTimeZone secondsFromGMTForDate:dateSent];
    return  [dateSent dateByAddingTimeInterval:-1*gmtOffset];
}

@end
