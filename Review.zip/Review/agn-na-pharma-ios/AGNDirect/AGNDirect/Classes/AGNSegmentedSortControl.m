//
//  AGNSegmentedSortControl.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/17/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.

// Keeps track of the sorting in the HCP Filter view - we do a stable sort

#import "AGNSegmentedSortControl.h"

@implementation AGNSegmentedSortControl

@synthesize segmentToSortDescriptorMapping=_segmentToSortDescriptorMapping;
@synthesize currentSortOrder=_currentSort;

// want to be notified of change even if segment stays the same, as this means our sort order reversed
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    int current = self.selectedSegmentIndex;
    [super touchesBegan:touches withEvent:event];
    if(current==self.selectedSegmentIndex)
        [self sendActionsForControlEvents:UIControlEventValueChanged];
}

-(void)setupMapping:(NSMutableDictionary *)dictionary andSortOrder:(NSArray *)order{
    _currentSort=order;
    _segmentToSortDescriptorMapping=dictionary;
}

-(void) addToMap:(NSNumber *)index :(NSSortDescriptor *)sortDescriptor{
    self.segmentToSortDescriptorMapping[index]=sortDescriptor;
}

-(NSMutableDictionary *)segmentToSortDescriptorMapping{
   if(!_segmentToSortDescriptorMapping)
       _segmentToSortDescriptorMapping = [[NSMutableDictionary alloc]init];
    return _segmentToSortDescriptorMapping;
}

-(NSArray *)currentSortOrder{
    if(!_currentSort)
        _currentSort = [[NSMutableArray alloc]init];
    return _currentSort;
}

-(int)primarySortOrder{
    if([self.currentSortOrder count]>0)
        return [self.currentSortOrder[0] intValue];
    return -1;
}

-(BOOL)updateCurrentSortOrder:(NSNumber *)selectedSegmentIndex{
    // we didn't have to change anything.  return false to indicate we should flip ascending flag instead
    if([self primarySortOrder]==[selectedSegmentIndex intValue])
        [self flipOrderAtIndex:selectedSegmentIndex];
    // put the new order in front and preserve the previous sorts beyond it
    NSMutableArray *newSort = [[NSMutableArray alloc]initWithCapacity:[self.currentSortOrder count]];
    newSort[0]=selectedSegmentIndex;
    int i=1;
    for(NSNumber *num in self.currentSortOrder){
        if([num intValue]!=[selectedSegmentIndex intValue]){
            newSort[i]=num;
            i++;
        }
    }
    _currentSort=newSort;
    return YES;
}

-(void)flipOrderAtIndex:(NSNumber *)selectedSegmentIndex{
    NSSortDescriptor *selectedDescriptor = (NSSortDescriptor *)self.segmentToSortDescriptorMapping[selectedSegmentIndex];
    if(selectedDescriptor.ascending)
        selectedDescriptor = [NSSortDescriptor sortDescriptorWithKey:selectedDescriptor.key ascending:NO selector:@selector(caseInsensitiveCompare:)];
    else
        selectedDescriptor = [NSSortDescriptor sortDescriptorWithKey:selectedDescriptor.key ascending:YES selector:@selector(caseInsensitiveCompare:)];
    self.segmentToSortDescriptorMapping[selectedSegmentIndex]=selectedDescriptor;
}

-(NSArray *)getSortDescriptorsForSortIndex:(NSNumber *)selectedSegmentIndex{
    [self updateCurrentSortOrder:selectedSegmentIndex];
    
    NSMutableArray *sortDescriptors = [[NSMutableArray alloc]initWithCapacity:[self.currentSortOrder count]];
    for(NSNumber *num in self.currentSortOrder){
        [sortDescriptors addObject:self.segmentToSortDescriptorMapping[num]];
    }
    
    return sortDescriptors;
}

-(NSArray *)getCurrentSortDescriptors{
    NSMutableArray *sortDescriptors = [[NSMutableArray alloc]initWithCapacity:[self.currentSortOrder count]];
    for(NSNumber *num in self.currentSortOrder){
        [sortDescriptors addObject:self.segmentToSortDescriptorMapping[num]];
    }
    return sortDescriptors;
}

@end
