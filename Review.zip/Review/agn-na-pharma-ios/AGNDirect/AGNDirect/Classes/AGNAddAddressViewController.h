//
//  AGNAddAddressViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSimplePopoverTableViewController.h"
#import "UINavigationController+AGNKeyboardDismiss.h"


static NSString *const kDefaultStateRestoreKey = @"DefaultStateRestoreKey";


@interface AGNAddAddressViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, AGNPopoverDelegate>

@property (strong, nonatomic) AGNAccount *account;
@property (nonatomic, strong) AGNAddress *address;


@end
