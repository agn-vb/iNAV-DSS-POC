//
//  AGNLoggingHelper.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/2/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNLoggingHelper.h"


//------------------------------------------------------------------------------
// MARK: - Constants
//------------------------------------------------------------------------------


#ifdef DEBUG
static const int kLogLevel = INFO_INT;
#else
static const int kLogLevel = INFO_INT;
#endif

NSString * const kLogDirectory = @"logs";
// as files roll over, previous file will become basename.1.extension, e.g. AGN-iPad-Log.1.txt
NSString * const kLogFileName = @"AGN-iPad-Log.txt";
static const int  kMaxFileSize=500*1024;
static const int kMaxBackupIndex=2;
static const int kFileAppenderThreshold = INFO_INT;
NSString * const kAGNAuditLoggerName = @"audit";


// Level(p) Date(d) File(F) LineNumber(L) Method(M) Message(m)
// Options described in L4PatternLayout.h 
NSString* const kLayoutPattern =  @"%p - %d %M:%L <> - %m";




void log4LogAudit(id object, int line, const char *file, const char *method, SEL sel, L4Level *level, BOOL isAssertion, BOOL assertion,  id exception, id message, ...)
{
	NSString *combinedMessage;
	if ( [message isKindOfClass:[NSString class]] ) {
		va_list args;
		va_start(args, message);
		combinedMessage = [[NSString alloc] initWithFormat:message arguments:args];
		va_end(args);
	}

	if ( isAssertion ) {
		objc_msgSend([AGNLoggingHelper auditLogger], sel, line, file, method, assertion, combinedMessage);
	} else {
		objc_msgSend([AGNLoggingHelper auditLogger], sel, line, file, method, combinedMessage, level, exception);
	}
    
}



@implementation AGNLoggingHelper



+(NSString*)logsDirectory{
    NSString *docsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    return [docsDirectory stringByAppendingPathComponent:kLogDirectory];
}


//------------------------------------------------------------------------------
// MARK: - Configure levels for individual classes and groups
//------------------------------------------------------------------------------

//  Examples:
//
//  [AGNLoggingHelper setLevel:[L4Level info] forClass:self.class];
//  [AGNLoggingHelper addClass:self.class toLogGroup:@"Controllers"];
//  [AGNLoggingHelper setLevel:[L4Level info] forLogGroup:@"Controllers"];

+(void)setLevel:(L4Level *)level forClass:(Class)theClass{
    [[L4Logger loggerForClass:theClass] setLevel:level];
}

+(void)addClass:(Class)theClass toLogGroup:(NSString *)groupName{
    [[L4Logger loggerForClass:theClass] setParent:[L4Logger loggerForName:groupName]];
}

+(void)setLevel:(L4Level *)level forLogGroup:groupName{
    [[L4Logger loggerForName:groupName] setLevel:level];
}


//------------------------------------------------------------------------------
// MARK: - Setup Tasks
//------------------------------------------------------------------------------


+(L4Layout *)layout{
    return [[L4PatternLayout alloc] initWithConversionPattern:kLayoutPattern];
}

+(void)setUpLogging{
    [[L4Logger rootLogger] setLevel:[L4Level levelWithInt:kLogLevel]];
    [self configureConsoleLogging];
    [self configureFileLogging];
}

+(void)configureConsoleLogging{
    [[L4Logger rootLogger] addAppender:[[L4ConsoleAppender alloc] initTarget:YES
                                                                  withLayout:[self layout]]];
}

+(void)configureFileLogging{
    //**  Set up file logger **/
    NSString *logDirectory = [self logsDirectory];
    // create a directory for the log files if it doesn't already exist
    NSError *error=nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:logDirectory])
        [[NSFileManager defaultManager] createDirectoryAtPath:logDirectory withIntermediateDirectories:YES attributes:nil error:&error];
    
    if(error){
        log4Error(@"Unable to create directory for log file %@", error);
    }else{
        // if we were able to create a log directory, set up our file appender
        NSString *filePath = [logDirectory stringByAppendingPathComponent:kLogFileName];
//        NSString *auditLogPath = [logDirectory stringByAppendingPathComponent:@"TransactionLog.txt"];

        AGNL4ProtectedRollingFileAppender *fileAppender =  [[AGNL4ProtectedRollingFileAppender alloc] initWithLayout:[self layout]
                                                                                    fileName:filePath
                                                                                      append:YES];
//        AGNL4ProtectedRollingFileAppender *auditLogFileAppender =  [[AGNL4ProtectedRollingFileAppender alloc] initWithLayout:[self layout]
//                                                                                                            fileName:auditLogPath
//                                                                                                              append:YES];

        [fileAppender setMaximumFileSize:kMaxFileSize];
        [fileAppender setMaxBackupIndex:kMaxBackupIndex];
        [[L4Logger rootLogger] addAppender:fileAppender];

//        L4Logger * auditLogger = [L4Logger loggerForName:kAGNAuditLoggerName];
//        [auditLogger setLevel:[L4Level levelWithInt:INFO_INT]];
//
//        [auditLogger addAppender:auditLogFileAppender];
//        // prevents the audit messages from being sent to the root logger
//        auditLogger.additivity=NO;


//        log4Audit(@"Sending audit messages here: %@",auditLogPath);
//        log4Info(@"Set up Audit Log at %@",auditLogPath);
    }
    
}

+(L4Logger*)auditLogger{
    L4Logger * logger =  [L4Logger loggerForName:kAGNAuditLoggerName];
    
    return logger;
}

//------------------------------------------------------------------------------
// MARK: - Get Contents
//------------------------------------------------------------------------------


+(NSString *) contentsOfLogs {
    NSString *contents = [self contentsOf:2 logFilesInDirectory:[self logsDirectory]];
    // reverse will put most recent events at the top
    return [self reverseLines:contents];
}

+(NSString *)reverseLines:(NSString *)input{
    NSMutableArray *lineArray = [[NSMutableArray alloc]init];
    [input enumerateLinesUsingBlock:^(NSString *line, BOOL *stop) {
        [lineArray addObject:line];
    }];
    NSMutableString *output = [[NSMutableString alloc] init];
    for(int index=[lineArray count]-1; index>=0; index--){
        [output appendString:[NSString stringWithFormat:@"%@\r\n", lineArray[index]]];
    }
    return output;
}

// Will concat contents of most recent log files with most recent events at the bottom

+(NSString*)contentsOf:(int)count logFilesInDirectory:(NSString*)directory{
    NSDirectoryEnumerator *directoryEnumerator = [[NSFileManager defaultManager] enumeratorAtPath:directory];
    [directoryEnumerator skipDescendants];
    NSMutableDictionary *fileList = [[NSMutableDictionary alloc] init];
    // get a list of files in the logs directory
    for (NSString *path in directoryEnumerator) {
        NSDictionary *attributes = [directoryEnumerator fileAttributes];
        NSDate *lastModificationDate = [attributes objectForKey:NSFileModificationDate];
        [fileList setObject:lastModificationDate    forKey:path];
    }
    // sort them so most recent is first
    NSEnumerator *enumerator = [[fileList keysSortedByValueUsingSelector:@selector(compare:)] reverseObjectEnumerator];
    NSMutableArray *files = [[NSMutableArray alloc] init];
    int index=0;
    // create an array of the most recent file paths, up to count files
    for(NSString *fileName in enumerator){
        NSString *filePath = [directory stringByAppendingPathComponent:fileName];
        index++;
        if(index>count)
            break;
        [files addObject:filePath];
    }
    
    int numFiles = [files count];
    index=numFiles-1;
    NSMutableString *result = [[NSMutableString alloc] init];
    
    // iterate from the end of the array - most recent events at bottom of contents so need to append older files first
    while (index>=0){
        NSError *error=nil;
        NSString *filePath = files[index];
        NSString *str = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
        if(error)
            log4Error(@"Error retrieving contents of log file %@ - %@",filePath,error);
        else{
            log4Debug(@"Appending contents of file %@",filePath);
            [result appendString:str];
        }
        index--;
    }
    
    return result;
}

@end
