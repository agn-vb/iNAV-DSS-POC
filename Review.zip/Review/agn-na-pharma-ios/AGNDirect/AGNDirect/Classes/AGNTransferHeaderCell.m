//
//  AGNTransferHeaderCell.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTransferHeaderCell.h"

@implementation AGNTransferHeaderCell


@end
