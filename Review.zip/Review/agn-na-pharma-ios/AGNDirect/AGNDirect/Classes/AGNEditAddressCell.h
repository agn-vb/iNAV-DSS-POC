//
//  AGNEditAddressCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kEditAddressCellHeight 116.0f

static NSString *AGNAddressModifiedNotificationKey = @"AGNAddressModifiedNotificationKey";

@interface AGNEditAddressCell : UITableViewCell

@property (strong, nonatomic) AGNAddress *address;
@property (assign, nonatomic) BOOL isSelected;
@property (strong, nonatomic) IBOutlet UIView *addressView;
@property (strong, nonatomic) IBOutlet UILabel *addressLabel;
@property (strong, nonatomic) IBOutlet UILabel *eligibilityLabel;
@property (strong, nonatomic) IBOutlet UIImageView *eligibilityImageView;
@property (strong, nonatomic) IBOutlet UIView *officeHoursView;
@property (strong, nonatomic) IBOutlet UIView *officeHoursEditView;

@property BOOL editMode;


@end
