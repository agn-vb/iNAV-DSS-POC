//
//  AGNHourSelectionCell.m
//  AGNDirect
//
//  Created by Adam McLain on 10/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNHourSelectionCell.h"

@interface AGNHourSelectionCell ()
@property (strong, nonatomic, readwrite) UILabel *day;
@property (strong, nonatomic, readwrite) AGNDualSlider *hourSlider;
@property (strong, nonatomic, readwrite) UISwitch *inOutSwitch;
@end

@implementation AGNHourSelectionCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UILabel *label = self.day = [[UILabel alloc] initWithFrame:CGRectZero];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor AGNWAwawa];
        label.font = [UIFont AGNAvenirHeavy14];
        AGNDualSlider *slider = self.hourSlider = [[AGNDualSlider alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 357.0f, 30.0f)];
        slider.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        UISwitch *aSwitch = self.inOutSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
        aSwitch.on = YES;
        aSwitch.onImage = [UIImage imageNamed:@"UI-switch-in"];
        aSwitch.offImage = [UIImage imageNamed:@"UI-switch-out"];
        aSwitch.onTintColor = [UIColor AGNTangelo];
        
        UIView *parentView = self.contentView;
        NSDictionary *views = NSDictionaryOfVariableBindings(label, slider, aSwitch);
        
        for (UIView *view in views.allValues) {
            [parentView addSubview:view];
            [view setTranslatesAutoresizingMaskIntoConstraints:NO];
        }
        
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[label(==46)]-[slider]-[aSwitch]-22-|" options:0 metrics:nil views:views]];
//        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[label]|" options:0 metrics:nil views:views]];
        [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[slider]|" options:0 metrics:nil views:views]];
        [parentView addConstraint:[NSLayoutConstraint constraintWithItem:label attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:parentView attribute:NSLayoutAttributeCenterY multiplier:1.0f constant:0.0f]];
        [parentView addConstraint:[NSLayoutConstraint constraintWithItem:aSwitch attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:parentView attribute:NSLayoutAttributeCenterY multiplier:1.0f constant:0.0f]];
        [parentView addConstraint:[NSLayoutConstraint constraintWithItem:slider attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:parentView attribute:NSLayoutAttributeCenterY multiplier:1.0f constant:0.0f]];
        
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    return self;
}

- (void)setAvailability:(AGNHCPDayAvailability *)availability {
    _availability = availability;
    
    if([availability isUnavailable]){
        self.hourSlider.enabled = NO;
        self.inOutSwitch.on = NO;
    } else {
        
    }
    self.day.text = availability.day;
    self.hourSlider.minimumLabelText = [availability.startTime agnAvailabilityString];
    self.hourSlider.maximumLabelText = [availability.endTime agnAvailabilityString];
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.availability = nil;
    self.day.text = nil;
    self.inOutSwitch.on = YES;
    [self.hourSlider removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
    self.hourSlider.enabled = YES;
    self.hourSlider.selectedMinimumValue = self.hourSlider.minimumValue;
    self.hourSlider.selectedMaximumValue = self.hourSlider.maximumValue;
}

@end
