//
//  AGNChooseStateCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/6/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNChooseStateCell.h"

@implementation AGNChooseStateCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self agnSetStyledSelectedBackground];
        
        UILabel *leftLabel = [[UILabel alloc] init];
        [leftLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        leftLabel.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
        leftLabel.textColor = [UIColor AGNGreyMatter];
        leftLabel.backgroundColor = [UIColor clearColor];

        UILabel *rightLabel = [[UILabel alloc] init];
        [rightLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        rightLabel.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
        rightLabel.textColor = [UIColor AGNGreyMatter];
        rightLabel.backgroundColor = [UIColor clearColor];
        
        [self.contentView addSubview:leftLabel];
        [self.contentView addSubview:rightLabel];
        NSDictionary *views = NSDictionaryOfVariableBindings(leftLabel,rightLabel);
        
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[leftLabel][rightLabel(==50)]-22-|" options:0 metrics:nil views:views]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[rightLabel]|" options:0 metrics:nil views:views]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[leftLabel]|" options:0 metrics:nil views:views]];
        
        self.leftLabel = leftLabel;
        self.rightLabel = rightLabel;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
