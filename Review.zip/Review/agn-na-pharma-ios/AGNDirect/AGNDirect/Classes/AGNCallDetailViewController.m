
//
//  AGNCallDetailViewController.m
//  AGNDirect
//
//  Created by Mark Wells on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  THIS IS THE CONTAINER/PARENT  CLASS FOR EDITING A CALL  //

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "AGNCallDetailViewController.h"
#import "AGNHCPDetailViewController.h"
#import "AGNCallNameAddressLicenseCell.h"
#import "AGNCallProductHeaderCell.h"
#import "AGNCallProductDetailCell.h"
#import "AGNCallProductSampleCell.h"
#import "AGNCall.h"
#import "AGNSampleInventoryLine.h"
#import "AGNDetailPosition.h"
#import "AGNCallDetail.h"
#import "AGNSignatureViewController.h"
#import "AGNGetSignatureFooterCell.h"
#import "AGNCallDetailDetailsViewController.h"
#import "AGNClosureModalViewController.h"
#import "AGNSingleLineCell.h"
#import "AGNAddressCell.h"
#import "AGNReceiptSelectionCell.h"
#import "AGNAccountAddressPopover.h"


@interface AGNCallDetailViewController ()

@property (weak, nonatomic) IBOutlet UILabel *hcpNameAddressLabel;
@property (strong, nonatomic) IBOutlet UIButton *addToScheduleButton;

@property (strong, nonatomic) UIDatePicker *datePicker;
@property (strong, nonatomic) UIPopoverController *datePickerPopover;

@property (weak, nonatomic) IBOutlet UIImageView *centerBar;
@property (strong, nonatomic) AGNSignatureViewController *signatureViewController;
@property (strong, nonatomic) AGNCallDetailDetailsViewController *detailsViewController;
@property (strong, nonatomic) NSMutableArray *filteredHCPs;
@property (strong, nonatomic) AGNCall *deletedCall;
@property (strong, nonatomic) AGNCall *originalCall;
@property (strong, nonatomic) AGNAccount *switchToHCP;
@property (strong, nonatomic) AGNAddress *switchToAddress;
@property (strong, nonatomic) AGNEligibilityHelper *eligibilityHelper;
@property (strong, nonatomic) NSString * salesForceId;
@property (strong, nonatomic) NSString * guid;
@property (strong, nonatomic) AGNUpdateTransactionValueHolder *updateAccountTransaction;

@property (strong, nonatomic) NSArray *rightViewConstraints;
@property (strong, nonatomic) NSArray *viewConstraints;

@property (nonatomic, strong) NSString *undoJSONRepresentation; //transient


@property (assign, nonatomic) BOOL isClosingCallWithSignature;

@property (strong, nonatomic) AGNAccountAddressPopover * accountAddressPopover;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;

@end

@implementation AGNCallDetailViewController

@synthesize hcpNameAddressLabel;
@synthesize closeCallButton;
@synthesize hcp;
@synthesize hcpAddress;
@synthesize datePickerPopover;
@synthesize datePicker;
@synthesize signatureViewController=_signatureViewController;
@synthesize detailsViewController=_detailsViewController;
@synthesize filteredHCPs=_filteredHCPs;
@synthesize eligibilityHelper=_eligibilityHelper;
@synthesize updateAccountTransaction=_updateAccountTransaction;
@synthesize undoJSONRepresentation=_undoJSONRepresentation;
@synthesize topHeaderViewConstraint;


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
    [self.closeCallButton setBackgroundImage:[[UIImage imageNamed:@"btn-bigblue"] stretchableImageWithLeftCapWidth:3 topCapHeight:0]forState:UIControlStateNormal];

    self.detailsViewController = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNCallDetailDetailsViewController"];
    self.signatureViewController = [[self storyboard] instantiateViewControllerWithIdentifier:@"SignatureViewController"];
    [self addChildViewController:self.detailsViewController];
    [self.leftView addSubview:self.detailsViewController.view];
}

-(void)reloadContent{

    AGNCall *refreshedCall = nil;
    if(self.salesForceId){
        refreshedCall = (AGNCall *)[[AGNDataManager defaultInstance]undeletedObjectOfType:@"AGNCall" forId:self.salesForceId];
    }
    if(!refreshedCall && self.guid){
        refreshedCall = (AGNCall *)[[AGNDataManager defaultInstance]undeletedObjectOfType:@"AGNCall" forGuid:self.guid];
    }
    if(!refreshedCall){
        [self.eligibilityHelper clearCurrentCallInfo];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
    }
    else{
        self.call = refreshedCall;
        self.hcp = self.call.account;
        self.hcpAddress = self.call.address;
        self.originalCall=self.call;
        self.eligibilityHelper = [[AGNEligibilityHelper alloc]initWithCall:self.call];
        [self configureView];
    }

    
}

-(void)setCall:(AGNCall *)call  {
    log4Info(@"Setting call object on AGNCallDetailViewController");
    _call=call;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setButtonEnablement) name:AGNCheckCloseButtonNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(signatureCaptured:) name:AGNSignatureCapturedNotification object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accountModified:) name:AGNAccountModifiedNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleUpdateTransactionRevert:)
                                                 name:AGNUpdateTransactionRevertedNotificationKey
                                               object:nil];
    if(!self.call){
        [self initNewCall];
        log4Info(@"Created new call with guid: %@",self.call);

    }
    else{
        if(self.call.isToBeDeleted){
            self.call.toBeDeletedFlag= @NO;
            log4Warn(@"Somehow we opened a call that was marked deleted, flipping off the deleted flag... %@",self.call);
        }
        log4Info(@"Opened call: %@",self.call );
        if(self.call.signatureCaptureDate && !self.call.signatureImage && ![self.call isClosed]){
            log4Error(@"Opened Draft Call with signature Capture Date %@, but no signature image: %@ ",self.call.signatureCaptureDate,self.call);
            log4Error(@"Showing alert and setting signature capture date to null");
            self.call.signatureCaptureDate=nil;
            UIAlertView *mustCloseAlertView = [[UIAlertView alloc] initWithTitle:@"No Signature" message:@"The signature for this call appears to have been lost.  Call is being reset to a draft state.  Please contact support." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [mustCloseAlertView show];

        }
        self.hcp = self.call.account;
        self.hcpAddress = self.call.address;
        [self.call setUndoRepresentation];
    }
    self.salesForceId=self.call.salesForceId;
    self.guid=self.call.guid;
    [self.eligibilityHelper persistCurrentCallInfo];
    if((![self.call isClosed]) && (!self.call.signatureCaptureDate)){
        // silently remove any details or samples which are now ineligible
        [self.eligibilityHelper deleteIneligibleDrops];
        [self.eligibilityHelper deleteIneligibleDetails];
    }
    self.originalCall=self.call;
    if(!self.undoJSONRepresentation){
        self.undoJSONRepresentation= self.call.undoJSONRepresentation;
    }
    [self configureView];
}

-(AGNEligibilityHelper *)eligibilityHelper{
    if(!_eligibilityHelper){
        _eligibilityHelper = [[AGNEligibilityHelper alloc]initWithCall:self.call];
    }
    return _eligibilityHelper;
}

-(void) configureView{
    
    self.detailsViewController.call = self.call;
    self.signatureViewController.call = self.call;
    [self setButtonEnablement];
    
    [self.detailsViewController.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    NSDictionary *leftViewDictionary = @{ @"view" : self.detailsViewController.view };
    NSArray *leftPaneConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[view]|" options:0 metrics:nil views:leftViewDictionary];
    [self.leftView addConstraints:leftPaneConstraints];
    leftPaneConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:leftViewDictionary];
    [self.leftView addConstraints:leftPaneConstraints];
    [self.leftView setNeedsUpdateConstraints];
    
    [self addChildViewController:self.signatureViewController];
    

    if([self.eligibilityHelper hasSignaturePane]){
        log4Info(@"Signature pane visible for call %@",self.call);
        [self showSignatureView];
    }
    else {

        log4Info(@"Hiding signature pane for call %@",self.call);
        [self hideSignatureView];
    }
    
    [self configureHCPLabel];
   
    
}


-(NSAttributedString *)attrStringHCPLabel{
    
    UIFont *black21 = [UIFont AGNAvenirBlack21];
    UIFont *medium21 = [UIFont AGNAvenirMedium21];
    UIFont *medium16 = [UIFont AGNAvenirMedium16];
    
    NSDictionary *blackAttributes = @{ NSFontAttributeName : black21, NSForegroundColorAttributeName : [UIColor whiteColor] };
    NSDictionary *med21Attributes = @{ NSFontAttributeName : medium21, NSForegroundColorAttributeName : [UIColor whiteColor] };
    NSDictionary *med16Attributes = @{ NSFontAttributeName : medium16, NSForegroundColorAttributeName : [UIColor whiteColor] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    NSString *name = [NSString stringWithFormat:@"%@ %@ ", [hcp.firstName uppercaseString], [hcp.lastName uppercaseString]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:name attributes:blackAttributes]];
    NSString *profDesig = [NSString stringWithFormat:@" - %@   ",[hcp.professionalDesignation uppercaseString]];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profDesig attributes:med21Attributes]];
    if (self.hcpAddress) {
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[self.hcpAddress singleLineFormattedString] attributes:med16Attributes]];
    }
    return formattedString;
}

-(void)configureHCPLabel{
    self.hcp = self.call.account;
    self.hcpAddress = self.call.address;
//    NSMutableString *str = [[NSMutableString alloc] initWithString: [NSMutableString stringWithFormat:@"%@ %@ (%@)", [hcp.firstName uppercaseString], [hcp.lastName uppercaseString], [hcp.professionalDesignation uppercaseString]]];
//    if (self.hcpAddress) {
//        [str appendFormat:@" - %@", [self.hcpAddress singleLineFormattedString]];
//    }
    hcpNameAddressLabel.attributedText = [self attrStringHCPLabel];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    if (self.datePickerPopover.popoverVisible) {
        [self.datePickerPopover dismissPopoverAnimated:NO];
        [self selectCallStartDate:self.addToScheduleButton];
    }

//  This doesn't quite work - for some reason sometimes the content is lost
//    if (self.accountAddressPopover) {
//        CGRect rect = self.switchHCPButton.frame;
//        rect = [self.view convertRect:rect fromView:self.switchHCPButton.superview];
//        [self.accountAddressPopover presentPopoverFromRect:rect
//                                                    inView:self.view
//                                  permittedArrowDirections:UIPopoverArrowDirectionUp
//                                                  animated:YES];
//    }    
}


//------------------------------------------------------------------------------
// MARK: - Dealing w/ possibility of new call that we don't want to save
//------------------------------------------------------------------------------


-(AGNSalesRep *)loggedInSalesRep{
    return (AGNSalesRep *)[AGNAppDelegate sharedDelegate].loggedInSalesRep;
}

-(void) initNewCall{
    self.call = (AGNCall *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNCall" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
    self.call.mobileCreateTimestamp = [NSDate date];
    self.call.mobileLastUpdateTimestamp = [NSDate date];
    self.call.account = hcp;
    self.call.address = hcpAddress;
    if ([AGNAppDelegate sharedDelegate].loggedInSalesRep) {
        self.call.salesRep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    }
    self.call.closed = [NSNumber numberWithBool:NO];
    self.call.salesForceAccountId = hcp.salesForceId;
    self.call.salesForceAddressId = hcpAddress.salesForceId;
    self.call.salesForceRepId = self.call.salesRep.salesForceId;
    self.call.guid = [[NSUUID UUID] UUIDString];
    [self.call clearUndoRepresentation];
}

// When we switch HCP, we must delete the prior call object and create a new one
-(AGNCall *)copyCallToHCP:(AGNAccount *) account atAddress:(AGNAddress *)address {
    AGNCall *call = (AGNCall *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNCall" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
    call.mobileCreateTimestamp = [NSDate date];
    call.mobileLastUpdateTimestamp = [NSDate date];
    call.account = account;
    call.address = address;
    if ([AGNAppDelegate sharedDelegate].loggedInSalesRep) {
        call.salesRep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    }
    call.closed = [NSNumber numberWithBool:NO];
    call.salesForceAccountId = account.salesForceId;
    call.salesForceAddressId = address.salesForceId;
    call.salesForceRepId = call.salesRep.salesForceId;
    call.guid = [[NSUUID UUID] UUIDString];
    call.startDate = self.call.startDate;
    call.receiptEmailAddress = nil;
    call.emailReceiptRequested = NO;
    call.mailReceiptRequested = NO;
    
    // can't switch HCP once you've captured signature so don't need closure details
    NSArray * details = [AGNEligibilityHelper filteredDetailsForHCP:account fromDetails:[self.call liveCallDetails]];
    NSArray * samples = [AGNEligibilityHelper filteredSamplesForHCP:account fromSamples:[self.call liveSampleDrops] atAddress:address];
    
    for(AGNCallDetail * detail in details){
        AGNCallDetail *cd = (AGNCallDetail *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNCallDetail" inManagedObjectContext: [AGNAppDelegate sharedDelegate].managedObjectContext];
        cd.detailPosition = detail.detailPosition;
        cd.guid = [[NSUUID UUID] UUIDString];
        [call addDetail:cd];
    }
    
    for(AGNSampleDrop *drop in samples){
        AGNSampleDrop *sd = (AGNSampleDrop *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleDrop" inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
        sd.guid = [[NSUUID UUID] UUIDString];
        sd.quantity = drop.quantity;
        sd.sampleInventoryLine = drop.sampleInventoryLine;
        sd.call = call;
    }
    
    return call;
}


//------------------------------------------------------------------------------
// MARK: - Adjusting constraints for Detail Only
//------------------------------------------------------------------------------


-(void)hideSignatureView {
    [self.view removeConstraint:self.equalWidthsConstraint];
    if(self.viewConstraints)
        [self.view removeConstraints:self.viewConstraints];
    
    [self.signatureViewController.view removeFromSuperview];
    

    NSDictionary *viewsDictionary =  @{ @"view" : self.view, @"rightView" : self.rightView, @"leftView" :self.leftView };
    self.rightViewConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"[rightView(==0)]" options:0 metrics:nil views:viewsDictionary];
    NSMutableArray *constraints = [[NSMutableArray alloc]initWithArray:[NSLayoutConstraint constraintsWithVisualFormat:@"[leftView(==view)]" options:0 metrics:nil views:viewsDictionary]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"[leftView]" options:0 metrics:nil views:viewsDictionary]];
    self.viewConstraints = constraints;
    [self.view addConstraints:self.viewConstraints];
    [self.rightView addConstraints:self.rightViewConstraints];
    [self.view addConstraints:self.viewConstraints];
    self.centerBar.hidden = YES;

}

-(void)showSignatureView{
    [self.view removeConstraint:self.equalWidthsConstraint];
    if(self.rightViewConstraints)
        [self.rightView removeConstraints:self.rightViewConstraints];
    if(self.viewConstraints)
        [self.view removeConstraints:self.viewConstraints];
    
    
    [self.view addSubview:self.rightView];
    [self.rightView addSubview:self.signatureViewController.view];
    [self.signatureViewController.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    NSDictionary *rightViewDictionary = @{ @"view" : self.signatureViewController.view };
    NSArray *rightPaneConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[view]|" options:0 metrics:nil views:rightViewDictionary];
    [self.rightView addConstraints:rightPaneConstraints];
    rightPaneConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:rightViewDictionary];
    [self.rightView addConstraints:rightPaneConstraints];
    [self.rightView setNeedsUpdateConstraints];

    NSDictionary *viewsDictionary =  @{ @"view" : self.view, @"rightView" : self.rightView, @"leftView" :self.leftView };
    NSMutableArray *constraints = [[NSMutableArray alloc]initWithArray:[NSLayoutConstraint constraintsWithVisualFormat:@"[leftView(==rightView)]" options:0 metrics:nil views:viewsDictionary]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"[leftView][rightView]" options:0 metrics:nil views:viewsDictionary]];
    self.viewConstraints = constraints;
    [self.view addConstraints:self.viewConstraints];

    self.centerBar.hidden = NO;
}



- (int)numSamples {
    return [self.call.liveSampleDrops count];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Utility
//------------------------------------------------------------------------------

- (NSAttributedString *)nameAddressLicenseLabel {
    UIFont *boldFont = [UIFont AGNAvenirHeavyFontWithSize:16];
    UIFont *lightObliqueFont = [UIFont fontWithName:@"Avenir-LightOblique" size:16];
    UIFont *lightFont = [UIFont fontWithName:@"Avenir-Light" size:16];
    UIFont *mediumFont = [UIFont fontWithName:@"Avenir-Medium" size:16];
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    NSDictionary *lightObliqueAttributes = @{ NSFontAttributeName : lightObliqueFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    NSDictionary *lightAttributes = @{ NSFontAttributeName : lightFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    NSDictionary *mediumAttributes = @{ NSFontAttributeName : mediumFont, NSForegroundColorAttributeName : [UIColor blackColor] };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:[self.hcp formattedName] attributes:boldAttributes];
    if (self.hcp.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" (%@)", self.hcp.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:lightObliqueAttributes]];
    }
    NSString *addressString = [NSString stringWithFormat:@"\n%@",self.hcpAddress.singleLineFormattedString];
    [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:addressString attributes:mediumAttributes]];
    if ([self.hcp.licenses count] > 0) {
        AGNLicense *license = [self.call.account samplingLicenseForAddress:self.call.address];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\nLICENSE:" attributes:lightAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:license.licenseNumber attributes:boldAttributes]];
        NSDate *licenseExpDate = license.expirationDate;
        if (licenseExpDate) {
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"  EXPIRES:" attributes:lightAttributes]];
            [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:[licenseExpDate agnFormattedDateString] attributes:boldAttributes]];
        }
    }
    
    return formattedString;
}


- (IBAction)closeCallButtonTapped:(UIButton *)sender
{
    log4Info(@"Call closed button tapped");
    if([self.call isClosed]){

     // call is already closed, so we are merely saving the call (may have changed receipt fields).
        self.call.mobileLastUpdateTimestamp = [NSDate date];
        NSArray *txns =  [self createManageCallUpdateTransactions];
        log4Info(@"Modifying closed call %@ ", self.call);
        [self saveAndEnqueueTransactions:txns];
        [self.eligibilityHelper clearCurrentCallInfo];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
    
    }else{
        if(![self.eligibilityHelper hasValidAddress])
            return;

        AGNClosureModalViewController *closureVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNClosureModalViewController"];
        closureVC.delegate=self;
        closureVC.call=self.call;
        closureVC.modalPresentationStyle=UIModalPresentationFormSheet;
        [self presentViewController:closureVC animated:YES completion:nil];
    }

}

- (void)closeCallModalDismissed
{
    NSMutableArray *txns = [NSMutableArray array];
    self.call.mobileLastUpdateTimestamp = [NSDate date];

    if (self.call.signatureCaptureDate) {
        log4Info(@"Closing call WITH signature, %@ with closure date %@", self.call, self.call.callClosedTimestamp);

        self.isClosingCallWithSignature = YES;
        [txns addObjectsFromArray:[self createManageCallUpdateTransactions]];
        [txns addObject:[self createSignatureUpdateTransaction]];
        self.isClosingCallWithSignature = NO;
    }
    else {
        log4Info(@"Closing call without signature, %@ with closure date %@", self.call, self.call.callClosedTimestamp);
        self.isClosingCallWithSignature = NO;
        [txns addObjectsFromArray:[self createManageCallUpdateTransactions]];
    }

    [self saveAndEnqueueTransactions:txns];
}

- (void)setButtonEnablement {
    if ([self.call canClose]) {
        self.closeCallButton.enabled = YES;

    }
    else {
        self.closeCallButton.enabled = NO;
    }
    
    if([self.call startDate]){
        [self.addToScheduleButton setTitle:NSLocalizedString(@"UPDATE DRAFT",@"Update Draft button title on call detail view when start date already set") forState:UIControlStateNormal];
    }else{
        [self.addToScheduleButton setTitle:NSLocalizedString(@"ADD TO SCHEDULE",@"Update Draft button title on call detail view when start date not set") forState:UIControlStateNormal];

    }
    
    if([self.call canSchedule]){
        self.addToScheduleButton.enabled = YES;
    }else{
        self.addToScheduleButton.enabled = NO;
    }
    
    if(self.call.signatureCaptureDate || self.call.isClosed || self.call.isDSSCall ){
        self.switchHCPButton.enabled = NO;
        self.switchHCPButton.alpha = .5;

    }else{
        self.switchHCPButton.enabled = YES;
        self.switchHCPButton.alpha = 1.0;
    }
    
    if([self.call isClosed]){
        self.addToScheduleButton.hidden=YES;
        [self.addToScheduleButton setEnabled:NO];
        [self.switchHCPButton setEnabled:NO];
        self.switchHCPButton.hidden=YES;
        if([[self.call liveSampleDrops]count]>0){
            [self.closeCallButton setTitle:NSLocalizedString(@"SAVE",@"Save button for closed call") forState:UIControlStateNormal];
            if([self callIsModified]){
                self.closeCallButton.enabled=YES;
                self.closeCallButton.alpha = 1.0;
            }else{
                self.closeCallButton.enabled=NO;
                self.closeCallButton.alpha = 0.5;
                
            }
        }
        else
            self.closeCallButton.hidden=YES;
    }
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Signature button state and sig modal segue
//------------------------------------------------------------------------------




- (void)reloadTableViews {
    [self.detailsViewController reloadData];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"Closure Modal Segue"]) {
        AGNClosureModalViewController *destinationVC = [segue destinationViewController];
        destinationVC.call = self.call;
        destinationVC.delegate = self;
        
    }
}

-(void)signatureCaptured:(NSNotification *)notification {
    [self setButtonEnablement];
}

-(void)accountModified:(NSNotification *)notification{
    self.updateAccountTransaction=notification.object;
}

-(BOOL)callIsModified{
    if(![self.call hasBeenUpserted])
        return YES;
    if(self.undoJSONRepresentation && [self.undoJSONRepresentation isEqualToString:self.call.jsonRepresentationForUndo])
        return NO;
    return YES;
}

//------------------------------------------------------------------------------
// MARK: - Saving the call
//------------------------------------------------------------------------------


//  Called by the RootViewController in response to Back Button, other Navigation requests
//  If the call has not been modified, return Yes to allow the view to be dismissed.
//  If the call HAS been modified, prompt the user to save or discard changes.
-(BOOL)canDismiss{
    
    if(![self.call isClosed] && [self.call signatureCaptureDate]){
        // Have to close before dismissal
        UIAlertView *mustCloseAlertView = [[UIAlertView alloc] initWithTitle:@"Please Close Call" message:@"Once signature is captured you must close call before leaving this screen" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [mustCloseAlertView show];
        
        return NO;
    }
    
    if(![self callIsModified]){
        [self.eligibilityHelper clearCurrentCallInfo];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
        log4Info(@"Dismissing view, no changes to call %@",self.call);
        return YES;
    }else{
        // logging to troubleshoot situations in which we're prompted to save when we don't think we should be
        NSSet * updatedObjects = [[self.call managedObjectContext] updatedObjects];
        NSSet * insertedObjects = [[self.call managedObjectContext] insertedObjects];
        NSSet * deletedObjects = [[self.call managedObjectContext] deletedObjects];
        log4Debug(@"Update Objects %@",updatedObjects);
        log4Debug(@"Inserted Objects %@",insertedObjects);
        log4Debug(@"Deleted Objects %@",deletedObjects);
    }

    log4Info(@"Prompting user to save call %@",self.call );

    UIAlertView *canDismissAlertView = [[UIAlertView alloc]init];
    canDismissAlertView.delegate = self;
    canDismissAlertView.title = NSLocalizedString(@"Changes Made", @"Title on action sheet when dismissing call view controller without saving");
    [canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Discard Changes",@"When dismissing call view, indicates changes won't be saved") ];
    if(self.call.startDate){
        if([self.call isClosed]){
            [canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Update Call",@"When dismissing call view, indicates changes will be saved") ];
            
        }else{
        [canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Update Draft",@"When dismissing call view, indicates changes will be saved") ];
        }
    }else{
        [canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Add To Schedule",@"When dismissing call view, indicates user will be prompted for start time")];
    }
    [canDismissAlertView addButtonWithTitle:NSLocalizedString(@"Continue Editing",@"When dismissing call view, indicates cancle will be dismissed so editing may continue")];
    [canDismissAlertView show ];
    
    // just refuse to dismiss, and we'll request dismissal in UIActionSheet delegate methods
    return NO;
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{

    switch(buttonIndex){
        case 0: // discard changes - just pop the view controller
            log4Info(@"Discarding changes to existing draft %@",self.call);
            [[AGNAppDelegate sharedDelegate].managedObjectContext rollback];

            if(![self.call hasBeenUpserted]){
                [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:self.call];
                [[AGNAppDelegate sharedDelegate] saveContext];
                log4Info(@"Deleting call, which user never requested to save ");
            }
            [self.eligibilityHelper clearCurrentCallInfo];
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];

            break;
        case 1:
            if(self.call.startDate){
                // update draft - save & pop
                self.call.mobileLastUpdateTimestamp = [NSDate date];
                if(![self.eligibilityHelper isValidForUpsert])
                    return;

                log4Info(@"Updating draft call %@",self.call );

                [self saveAndEnqueueTransactions:[self createManageCallUpdateTransactions]];
                [self.eligibilityHelper clearCurrentCallInfo];
                [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];

            }
            else{
                // prompt to add to schedule
                log4Info(@"Prompting to add to schedule %@",self.call );
                [self selectCallStartDate:self.addToScheduleButton];
            }
            break;
        default:
            // continue editing - cancel any outstanding navigation request
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNCancelNavigationRequestNotificationKey object:nil];
            break;
    }
}




//------------------------------------------------------------------------------
// MARK: - Call Date Popover
//------------------------------------------------------------------------------

-(void)cancelScheduleCall{
    [self.datePickerPopover dismissPopoverAnimated:NO];
}

- (IBAction)selectCallStartDate:(id)sender {
    if (!self.datePicker) {
        self.datePicker = [[UIDatePicker alloc] init];
        self.datePicker.minuteInterval = 30;
        
        UIViewController *aVC = [[UIViewController alloc] init];
        [aVC.view addSubview:self.datePicker];
        if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
            // Load resources for iOS 6.1 or earlier
            aVC.contentSizeForViewInPopover = self.datePicker.frame.size;
            
        } else {
            // Load resources for iOS 7 or later
            aVC.preferredContentSize = self.datePicker.frame.size;
        }        aVC.title = @"Date and Time";
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:aVC];
        UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(scheduleCall)];
        [aVC.navigationItem setRightBarButtonItem:done];
        UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelScheduleCall)];
        [aVC.navigationItem setLeftBarButtonItem:cancel];

        navController.modalInPopover = YES;
        navController.modalPresentationStyle = UIModalPresentationCurrentContext;

        self.datePickerPopover = [[UIPopoverController alloc] initWithContentViewController:navController];
        self.datePickerPopover.delegate = self;
    }
    
    if (self.call.startDate) {
        self.datePicker.date = self.call.startDate;
    } else {
        self.datePicker.date = [NSDate agnDateRoundedDownToThirtyMinutes:[NSDate date]];
    }
    
    UIView *button = (UIView *)sender;
    CGRect presentingRect = [self.view convertRect:button.frame fromView:button.superview];
    log4Info(@"Schedule call - launching date picker popover");
    [self.datePickerPopover presentPopoverFromRect:presentingRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
}

- (void)saveAndEnqueueTransactions:(NSArray *)updateTransactions {
    //Appending the transactions saves the context, including data model changes.
    //If it fails, it does a rollback - we need to inform user and refresh the interface.
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:updateTransactions]) {
        //TODO: notify user of fail and refresh interface
        log4Error(@"Failed to save call - either appendTransactions failed or MOC save failed");
    }
}


// These are the update statements we'll send to SFDC
- (NSArray *)createManageCallUpdateTransactions {
    if (self.deletedCall) {

        // we have done a swap and have to delete the call under the old HCP
        // and create a new call with the new HCP
        // since we have no way to tie these transactions together, we can't really revert
        // hence leave the undo JSON representation empty
        
        // deleted call - has tobedeleted flag set

        self.deletedCall.mobileLastUpdateTimestamp = [NSDate date];
        NSString *deleteJSONRepresentation = [self.deletedCall jsonRepresentationForUpdate];
        AGNUpdateTransactionValueHolder *deleteTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
        deleteTxn.createTimestamp = [NSDate date];
        deleteTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageCall];
        deleteTxn.currentJSONRepresentation = deleteJSONRepresentation;
        deleteTxn.deleteModelObjectOnRevert = NO;
        deleteTxn.guid = self.deletedCall.guid;
        deleteTxn.modelClassName = @"AGNCall";
        deleteTxn.salesForceId = self.deletedCall.salesForceId;
    
        self.call.mobileLastUpdateTimestamp = [NSDate date];
        NSString *newObjectJSONRepresentation = [self.call jsonRepresentationForUpdate];
        AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
        upTxn.createTimestamp = [NSDate date];
        upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageCall];
        upTxn.currentJSONRepresentation = newObjectJSONRepresentation;
        upTxn.deleteModelObjectOnRevert = @NO;
        upTxn.guid = self.call.guid;
        upTxn.modelClassName = @"AGNCall";
        upTxn.salesForceId = self.call.salesForceId;
        upTxn.mustSucceed = [NSNumber numberWithBool:self.isClosingCallWithSignature];
        
        if(self.updateAccountTransaction)
            return @[deleteTxn,upTxn,self.updateAccountTransaction];
        return @[deleteTxn,upTxn];
    }
    else {
    
        self.call.mobileLastUpdateTimestamp = [NSDate date];
        NSString *currentJSONRepresentation = [self.call jsonRepresentationForUpdate];
        AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
        upTxn.createTimestamp = [NSDate date];
        upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageCall];
        upTxn.undoJSONRepresentation = self.call.undoJSONRepresentation;
        upTxn.currentJSONRepresentation = currentJSONRepresentation;
        upTxn.deleteModelObjectOnRevert = [NSNumber numberWithBool:(self.call.undoJSONRepresentation == nil)];
        upTxn.guid = self.call.guid;
        upTxn.modelClassName = @"AGNCall";
        upTxn.salesForceId = self.call.salesForceId;
        upTxn.mustSucceed = [NSNumber numberWithBool:self.isClosingCallWithSignature];
        
        if(self.updateAccountTransaction)
            return @[upTxn,self.updateAccountTransaction];
        return @[upTxn];
    }
}

- (AGNUpdateTransactionValueHolder *)createSignatureUpdateTransaction {
    
    if(!self.call.signatureJSON){
        log4Info(@"Signature JSON should not be null here but it is, trying to regenerate from image %@",self.call.signatureImage);
        NSData *imageData = UIImagePNGRepresentation(self.call.signatureImage);
        self.call.signatureJSON = [imageData agnBase64EncodedString];
        log4Info(@"Regenerated signature %@",[self.call.signatureJSON substringToIndex:100]);
    }
    
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init];
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpsertSignature];
    upTxn.undoJSONRepresentation = nil;
    upTxn.currentJSONRepresentation = [NSString stringWithFormat:@"{\"encodedSignature\":\"%@\"}",self.call.signatureJSON];
    upTxn.deleteModelObjectOnRevert = @NO;
    upTxn.guid = self.call.guid;
    upTxn.modelClassName = @"AGNCallSignature";
    upTxn.salesForceId = self.call.salesForceId;
    upTxn.mustSucceed = @YES;
    self.call.signatureImage=nil;
    
    return upTxn;

}

- (void)handleUpdateTransactionRevert:(NSNotification *)notification {
//    [self setOpenDraftButtonEnablement];
//    [self.tableView reloadData];
}

- (void)scheduleCall {
    [self.datePickerPopover dismissPopoverAnimated:NO];
    [self.call setStartDate: datePicker.date duration:30];
    self.call.mobileLastUpdateTimestamp = [NSDate date];
    if(![self.eligibilityHelper isValidForUpsert])
        return;
    log4Info(@"Scheduled call %@ for %@", self.call.guid, self.call.startDate);
    [self saveAndEnqueueTransactions:[self createManageCallUpdateTransactions]];
    [self.eligibilityHelper clearCurrentCallInfo];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
}


//------------------------------------------------------------------------------
// MARK: - Switch HCP
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark SearchBar Delegate
//------------------------------------------------------------------------------

-(void)updateHCP{
    log4Info(@"Before Switch HCP %@",[self.call jsonRepresentationForUpdate]);

    AGNAccount *originalAccount = self.call.account;
    if(![self.call hasBeenUpserted] || self.deletedCall){
        // either self.call has never been saved so we don't have to delete it and make a new one
        // or we've already done switch HPC once, so the original call is set to be deleted and a new one is prepped for save
        // so just update the hcp on the call
        self.call.account = self.switchToHCP;
        self.call.address = self.switchToAddress;
        self.call.salesForceAccountId = self.switchToHCP.salesForceId;
        self.call.salesForceAddressId = self.switchToAddress.salesForceId;
        self.call.emailReceiptRequested = NO;
        self.call.mailReceiptRequested = NO;
        self.call.receiptEmailAddress = nil;

        self.eligibilityHelper.call = self.call;
        [self.eligibilityHelper removeIneligibleDetails];
        [self.eligibilityHelper removeIneligibleDrops];
    }else{
        AGNCall *newCall = [self copyCallToHCP:self.switchToHCP atAddress:self.switchToAddress];
        self.deletedCall=self.originalCall;
        self.deletedCall.toBeDeletedFlag= @YES;
        self.call = newCall;
        log4Info(@"Deleting call after Switch HCP %@",[self.deletedCall jsonRepresentationForUpdate]);

    }
    self.eligibilityHelper.call = self.call;
    [self.eligibilityHelper deleteIneligibleDrops];
    [self.eligibilityHelper deleteIneligibleDetails];
    // if we'd added an email to the previous hcp, that change gets discarded
    if(self.updateAccountTransaction){
        NSError *error = nil;
        NSData * jsonData = [self.updateAccountTransaction.undoJSONRepresentation dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        [originalAccount undoWithDictionary:jsonDict];
        self.updateAccountTransaction=nil;
    }
    log4Info(@"After Switch HCP %@",[self.call jsonRepresentationForUpdate]);

    [self configureView];
    [[NSNotificationCenter defaultCenter]postNotificationName:AGNSwitchHCPNotificationKey object:self.call];

}

-(NSMutableArray *)filteredHCPs{
    if(!_filteredHCPs) {
        _filteredHCPs = [[NSMutableArray alloc]init];
    }
    return _filteredHCPs;
}


-(void) showSwitchHCPPopover {
    __weak AGNCallDetailViewController * _self = self;
    
    self.accountAddressPopover = [[AGNAccountAddressPopover alloc] initWithTitle:NSLocalizedString(@"Switch HCP", @"Switch HCP Popover Title")
                                                                        onSelect:^(AGNAccount *account, AGNAddress *address) {
        _self.switchToHCP = account;
        _self.switchToAddress = address;
        [_self updateHCP];
        [_self.accountAddressPopover dismissPopoverAnimated:YES];
        _self.accountAddressPopover=nil;
    }];
    
    CGRect rect = self.switchHCPButton.frame;
    rect = [self.view convertRect:rect fromView:self.switchHCPButton.superview];
    [self.accountAddressPopover presentPopoverFromRect:rect
                                                inView:self.view
                              permittedArrowDirections:UIPopoverArrowDirectionUp
                                              animated:YES];    
}


- (IBAction)switchHCPTapped:(id)sender {
    log4Info(@"Switch HCP Tapped");

    [self showSwitchHCPPopover];
}
@end
