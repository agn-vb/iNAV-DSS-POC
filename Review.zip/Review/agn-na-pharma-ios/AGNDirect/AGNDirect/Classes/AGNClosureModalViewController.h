//
//  AGNClosureModalViewController.h
//  AGNDirect
//
//  Created by Paul Gambill on 9/27/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@protocol CallDetailDelegate <NSObject>
@required
- (void)closeCallModalDismissed;
@end

@interface AGNClosureModalViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (retain) id <CallDetailDelegate> delegate;
@property (nonatomic, strong) AGNCall *call;

@end
