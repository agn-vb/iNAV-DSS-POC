//
//  AGNSegmentedSortControl.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/17/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNSegmentedSortControl : UISegmentedControl

@property (readonly, strong, nonatomic) NSMutableDictionary *segmentToSortDescriptorMapping;
@property (readonly, strong, nonatomic) NSArray *currentSortOrder;
-(NSArray *)getSortDescriptorsForSortIndex:(NSNumber *)selectedSegmentIndex;
-(NSArray *)getCurrentSortDescriptors;
-(void)setupMapping:(NSMutableDictionary *)dictionary andSortOrder:(NSArray *)order;

@end
