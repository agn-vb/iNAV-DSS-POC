//
//  AGNTableViewHeader.h
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kAGNTableViewHeaderHeight 28.0f

@interface AGNTableViewHeader : UIView
@property (nonatomic, strong, readonly) UILabel *rightLabel;
@property (nonatomic, strong, readonly) UILabel *leftLabel;
@property (nonatomic, strong, readonly) UIButton *button;
@property (nonatomic, strong) UIButton *secondaryButton;
@property (nonatomic, strong) id data;

- (void)setButtonLabelText:(NSString *)text;
- (void)addSecondaryButton:(UIButton *)newButton withTitle:(NSString *)title;
- (void)setSecondaryButtonLabelText:(NSString *)text;
- (void)moveSecondaryToEdge;
@end
