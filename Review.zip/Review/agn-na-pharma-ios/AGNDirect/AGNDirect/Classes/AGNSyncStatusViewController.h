//
//  AGNSyncStatusViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/15/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    kAGNSyncStageUpsync = 0,
    kAGNSyncStageReceive,
    kAGNSyncStageProcess,
    kAGNSyncStageRelate
} AGNSyncStage;

@interface AGNSyncStatusViewController : UIViewController

//-(int)modalWidth;
-(int)modalHeight;

@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic) AGNSyncStage syncStage;
@property (nonatomic, strong) UIButton * cancelButton;


-(void)setStatusText:(NSString *)statusText;
-(void)setCompletionPercentage:(float)completion;
-(void)setTasksComplete:(int)tasksComplete outOf:(int)total;
-(void)reset;
@end
