//
//  AGNReceiptSelectionCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/25/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSimplePopoverTableViewController.h"
#import "AGNEmailReceiptPopoverController.h"

static NSString * const AGNAccountModifiedNotification = @"AGNAccountModifiedNotification";

@interface AGNReceiptSelectionCell : UITableViewCell <AGNEmailPopoverDelegate, UIPopoverControllerDelegate>

@property (weak, nonatomic) IBOutlet UISwitch *mailReceiptSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *emailReceiptSwitch;
@property (strong, nonatomic) AGNCall * call;
@property (strong, nonatomic) AGNEmailReceiptPopoverController *popover;
@property (strong, nonatomic) NSMutableArray *emailAddresses;
@property (weak, nonatomic) UIView *view;
@property (weak, nonatomic) IBOutlet UILabel *emailAddress;
-(int) currentSelection;
-(void)interfaceRotated;
@end
