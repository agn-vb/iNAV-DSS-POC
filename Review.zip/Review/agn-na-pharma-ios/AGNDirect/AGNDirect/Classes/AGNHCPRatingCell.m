//
//  AGNHCPRatingCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNHCPRatingCell.h"
#import "AGNCategoryHeaders.h"


@implementation AGNHCPRatingCell
@synthesize salesTeamLabel=_salesTeamLabel;
@synthesize ratingLabel=_ratingLabel;
@synthesize frequencyLabel=_frequencyLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (!(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        return nil;
    }
    
    [self agnSetStyledSelectedBackground];
    
    
    
    UILabel *teamHeaderLabel = [[UILabel alloc] init];
    teamHeaderLabel.translatesAutoresizingMaskIntoConstraints = NO;
    teamHeaderLabel.font = [UIFont AGNAvenirRoman16];
    [self.contentView addSubview:teamHeaderLabel];
    teamHeaderLabel.textColor = [UIColor AGNGreyMatter];
    teamHeaderLabel.backgroundColor = [UIColor clearColor];
    
    teamHeaderLabel.text= NSLocalizedString(@"TEAM:",@"TEAM");
    
    UILabel *freqHeaderLabel = [[UILabel alloc] init];
    freqHeaderLabel.translatesAutoresizingMaskIntoConstraints = NO;
    freqHeaderLabel.font = [UIFont AGNAvenirRoman16];
    [self.contentView addSubview:freqHeaderLabel];
    freqHeaderLabel.textColor = [UIColor AGNGreyMatter];
    freqHeaderLabel.backgroundColor = [UIColor clearColor];
    

    freqHeaderLabel.text= NSLocalizedString(@"FREQ:",@"FREQ");
    
    UILabel *ratingHeaderLabel = [[UILabel alloc] init];
    ratingHeaderLabel.translatesAutoresizingMaskIntoConstraints = NO;
    ratingHeaderLabel.font = [UIFont AGNAvenirRoman16];
    [self.contentView addSubview:ratingHeaderLabel];
    ratingHeaderLabel.textColor = [UIColor AGNGreyMatter];
    ratingHeaderLabel.backgroundColor = [UIColor clearColor];
    
    ratingHeaderLabel.text= NSLocalizedString(@"RATING:",@"RATING:");

  
    UILabel *salesTeam = [[UILabel alloc] init];
    salesTeam.translatesAutoresizingMaskIntoConstraints = NO;
    salesTeam.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    [self.contentView addSubview:salesTeam];
    salesTeam.textColor = [UIColor AGNGreyMatter];
    salesTeam.backgroundColor = [UIColor clearColor];
    
    UILabel *frequency = [[UILabel alloc] init];
    frequency.translatesAutoresizingMaskIntoConstraints = NO;
    frequency.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    [self.contentView addSubview:frequency];
    frequency.textColor = [UIColor AGNGreyMatter];
    frequency.backgroundColor = [UIColor clearColor];
    
    UILabel *rating = [[UILabel alloc] init];
    rating.translatesAutoresizingMaskIntoConstraints = NO;
    rating.font = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    [self.contentView addSubview:rating];
    rating.textColor = [UIColor AGNGreyMatter];
    rating.backgroundColor = [UIColor clearColor];

    NSDictionary *views = NSDictionaryOfVariableBindings(teamHeaderLabel, freqHeaderLabel,ratingHeaderLabel,salesTeam,frequency,rating);
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[teamHeaderLabel][salesTeam]-13-[freqHeaderLabel][frequency]-13-[ratingHeaderLabel][rating]|" options:0 metrics:nil views:views]];

    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[teamHeaderLabel(==50)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[salesTeam(==65)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[freqHeaderLabel(==50)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[frequency(==30)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[ratingHeaderLabel(==65)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[teamHeaderLabel]|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[freqHeaderLabel]|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[ratingHeaderLabel]|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[frequency]|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[salesTeam]|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[rating]|" options:0 metrics:nil views:views]];
    
    self.salesTeamLabel=salesTeam;
    self.frequencyLabel=frequency;
    self.ratingLabel=rating;
    
    return self;
}


-(void)setPrimarySalesTeam:(BOOL)primary{
    UIColor *color = [UIColor AGNGreyMatter];
    if(primary){
        color = [UIColor AGNOrange];
    }
    self.ratingLabel.textColor = color;
    self.frequencyLabel.textColor = color;
    self.salesTeamLabel.textColor = color;
}
@end
