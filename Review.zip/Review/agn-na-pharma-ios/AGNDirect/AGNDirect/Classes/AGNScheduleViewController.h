//
//  AGNScheduleViewController.h
//  AGNDirect
//
//  Created by Mark Wells on 8/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNCategoryHeaders.h"
#import "AGNCallDetailViewController.h"
#import "Kal.h"

static NSString * const AGNHCPFilterEnteredKey = @"AGNHCPFilterEntered";
static NSString * const AGNScheduleCallDeletedKey = @"AGNScheduleCallDeletedKey";


@interface AGNScheduleViewController : AGNViewController <UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate, KalDataSource, UIScrollViewDelegate>
@end
