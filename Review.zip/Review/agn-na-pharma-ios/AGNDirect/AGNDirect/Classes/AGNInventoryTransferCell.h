//
//  AGNInventoryTransferCell.h
//  AGNDirect
//
//  Created by Adam McLain on 11/4/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNCategoryHeaders.h"
#import "AGNSampleInventoryTransaction.h"

@interface AGNInventoryTransferCell : UITableViewCell
@property (strong, nonatomic, readonly) UILabel *nameLabel;
@property (strong, nonatomic, readonly) UILabel *dateLabel;
@property (strong, nonatomic, readonly) UILabel *transferLabel;
@property (strong, nonatomic, readonly) UILabel *statusLabel;
@property (strong, nonatomic) AGNSampleInventoryTransaction *transaction;

- (void)setActive;
- (void)setPassive;


@end
