//
//  AGNSyncManager.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/9/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  This is the class which handles downstream sync.  
//  Calls to the server are chained - when didLoadResponse:(id)jsonResponse is fired the next request is sent to the server.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "AGNSyncManager.h"
#import "AGNAppDelegate.h"
#import "AGNAccount.h"
#import "AGNCallContact.h"
#import "AGNModelProtocol.h"
#import "AGNUpdateQueueManager.h"
#import "SFRestAPI.h"
#import "RestKit.h"
#import "AGNRootViewController.h"
#import "RKRequestSerialization.h"
#import "AGNSuppressedAddress.h"
#import "JSONKit.h"
#import "UIApplication+UberFoundationExtensions.h"
#import "AGNContactRole.h"
#import "AGNDownstreamSync+UserGroup.h"


#define AGN_FORCE_FULL_SYNC 0
#define AGN_FULL_SYNC_ACCOUNT_THRESHOLD 20
#define AGN_FULL_SYNC_DAYS_THRESHOLD 3
#define AGN_SYNC_TO_FILESYSTEM 1

@implementation AGNSyncManager

static const int kTotalSyncStepsFullSync=12;
static const int kTotalSyncStepsIncrementalSync=9;
static const int kTotalSyncStepsMockSync=6;
static const int kSecondsPerDay = 24 * 60 * 60;

// Do NOT use dash char '-' in filenames! Used as a delimiter

NSString * const AGNAbortSyncNotificationKey = @"AGNAbortSyncNotificationKey";

NSString * const kFilenameUser = @"user";
NSString * const kFilenameZipcodes = @"zipcodes";
NSString * const kFilenameFullZipcodes = @"full_zipcodes";
NSString * const kFilenameInventory = @"inventory";
NSString * const kFilenameFullAccounts = @"full_accounts";
NSString * const kFilenameFullLicenses = @"full_licenses";
NSString * const kFilenameFullAddresses = @"full_addresses";
NSString * const kFilenamePrimaryAddresses = @"primary_addresses";
NSString * const kFilenameFullContacts = @"full_contacts";
NSString * const kFilenameAccountsAndCalls = @"accounts_calls";
NSString * const kFilenameAccounts = @"accounts";
NSString * const kFilenameSalesTeam = @"salesteam";
NSString * const kFilenameSalesRep = @"salesrep";
NSString * const kFilenameCalls = @"calls";
NSString * const kFilenameFullCalls = @"full_calls";

NSString * const kAGNUserDefaultsKeyNeedFullSync = @"kAGNUserDefaultsKeyNeedFullSync";

@synthesize utcLastCompleteSyncTimestamp = _utcLastCompleteSyncTimestamp;

@synthesize userRequest = _userRequest;


@synthesize incrementalSync = _incrementalSync;

@synthesize localLastSyncStartedTimestamp = _localLastSyncStartedTimestamp;

@synthesize testingSFRestAPICall;

@synthesize fullSyncRequested=_fullSyncRequested;

- (void)setNeedFullSync:(BOOL)needFullSync {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[NSNumber numberWithBool:needFullSync] forKey:kAGNUserDefaultsKeyNeedFullSync];
    [defaults synchronize];
}

- (BOOL)needFullSync {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSNumber * result = [defaults objectForKey:kAGNUserDefaultsKeyNeedFullSync];
    return [result boolValue];
}

- (void)setUtcLastCompleteSyncTimestamp:(NSDate *)utcLastCompleteSyncTimestamp {
    _utcLastCompleteSyncTimestamp = utcLastCompleteSyncTimestamp;
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    if (utcLastCompleteSyncTimestamp)
        [defaults setObject:utcLastCompleteSyncTimestamp forKey:AGNLastSyncTimestampKey];
    else
        [defaults removeObjectForKey:AGNLastSyncTimestampKey];
    [defaults synchronize];
}

- (NSDate*)utcLastCompleteSyncTimestamp {
    if (!_utcLastCompleteSyncTimestamp) {
        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        _utcLastCompleteSyncTimestamp = [defaults objectForKey:AGNLastSyncTimestampKey];
    }
    return _utcLastCompleteSyncTimestamp;
}

- (NSDate*)localLastSyncStartedTimestamp {
    if (!_localLastSyncStartedTimestamp) {
        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        _localLastSyncStartedTimestamp = [defaults objectForKey:AGNLastSyncLocalTimestampKey];
    }
    return _localLastSyncStartedTimestamp;    
}

- (void)setLocalLastSyncStartedTimestamp:(NSDate *)localLastSyncStartedTimestamp {
    _localLastSyncStartedTimestamp = localLastSyncStartedTimestamp;
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    if (localLastSyncStartedTimestamp)
        [defaults setObject:localLastSyncStartedTimestamp forKey:AGNLastSyncLocalTimestampKey];
    else
        [defaults removeObjectForKey:AGNLastSyncLocalTimestampKey];
    [defaults synchronize];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Public Utility Methods
//------------------------------------------------------------------------------

+ (NSDictionary *)dictionaryWithStandardizedKeysFrom:(NSDictionary *)dict {
    NSMutableDictionary *sDict = [[NSMutableDictionary alloc] init];
    [dict enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        NSString *sKey = key;
        NSUInteger ix = [((NSString *)key) rangeOfString:@"__c" options:NSCaseInsensitiveSearch].location;
        if (ix != NSNotFound) {
            sKey = [((NSString *)key) substringToIndex:ix];
        }
        [sDict setObject:obj forKey:sKey];
    }];
    return sDict;
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Sync Methods
//------------------------------------------------------------------------------

- (void)syncLoggedInUser {
    self.userRequest = [AGNDownstreamSync userInfoRequest];
    self.userRequest.delegate = self;
    [self.userRequest execute];
}

- (void)cleanUpAfterPartialSync {
    self.sync = nil;
    self.utcCurrentSyncTimestamp = nil;
    self.utcCurrentSyncLastTimestamp = nil;
    self.localSyncStartedTimestamp = nil;

    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateQueueCountChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNAbortSyncNotificationKey object:nil];
}

- (void)handleAbort:(NSNotification*)notification {
    self.syncAborted = YES;
    [self.sync cancel];
    self.sync = nil;
    
    self.utcCurrentSyncTimestamp = nil;
    self.utcCurrentSyncLastTimestamp = nil;
    self.localSyncStartedTimestamp = nil;

    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateQueueCountChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpsyncStoppedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNAbortSyncNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:kDDSFNotificationSyncEnded object:self]];
}

- (void)syncAbortedOnUpsync:(NSNotification*)notification {
    // Only abort if there are still items pending, otherwise we're good
    if ([AGNUpdateQueueManager defaultManager].pendingUpdateCount > 0) {
        [[AGNAppDelegate sharedDelegate] presentBatchIsRunningAlert];
        [self handleAbort:notification];
    }
}

- (void)performSync:(BOOL)forceFullSync {
    if ([[AGNAppDelegate sharedDelegate] syncInterrupted]) {
        log4Info(@"Last sync was interrupted, forcing a full sync");
        forceFullSync=YES;
    }

    if (self.needFullSync) {
        log4Info(@"Permissions changed since last sync, forcing a full sync");
        forceFullSync = YES;
    }

    if (forceFullSync)
        self.fullSyncRequested=YES;

    if (self.fullSyncRequested)
        forceFullSync=YES;
    
    if (!self.sync) {
        
        self.syncAborted = NO;
        self.sync = [[AGNDownstreamSync alloc] init];
        self.sync.syncManager = self;
        if (forceFullSync || [self shouldPerformFullSync])
            self.sync.mode = kDDSFDownstreamSyncModeFull;
        else
            self.sync.mode = kDDSFDownstreamSyncModeIncremental;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleAbort:) name:AGNAbortSyncNotificationKey object:nil];
        [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:kDDSFNotificationSyncStarted object:self]];
        
        [self.sync execute];
    }
}

- (BOOL)shouldPerformFullSync {
    if (AGN_FORCE_FULL_SYNC || !self.utcLastCompleteSyncTimestamp)
        return YES;
    // timeIntervalSinceNow will be negative since timestamp is in the past
    NSTimeInterval intervalSinceSync = fabs([self.utcLastCompleteSyncTimestamp timeIntervalSinceNow]);
    return intervalSinceSync >= ([self maxDaysForIncrementalSync] * kSecondsPerDay);
}



- (void)clearRequests {
    // Cancel and clear out the wrappers
    [self.userRequest cancel];
    dispatch_async(dispatch_get_main_queue(), ^{
        self.userRequest = nil;
    });
}


- (id)jsonFromJsonResponse:(id)jsonResponse {
    id json;
    
    NSString *body = [[NSString alloc] initWithData:[jsonResponse body] encoding:NSUTF8StringEncoding];
    log4Trace(@"body=%@", body);
    NSData * jsonData = [body dataUsingEncoding:NSUTF8StringEncoding];
    
    if (jsonData) {
        NSError *error;
        json = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        if (!json) {
            log4Error(@"Invalid json response parsing: %@", jsonData);
        }
        else {
//            log4Debug(@"json=%@", json);
        }
    }
    else {
        log4Error(@"JSONResponse contained no body that could be encoded. Body=%@", body);
    }
    return json;
}

-(NSString *)requestDescription :(RKRequest*)request{

    NSString *requestInfo = nil;
    if([request isKindOfClass:RKRequest.class]){
        requestInfo = [NSString stringWithFormat:@"RKRequest: %@",request.URLRequest.URL];
    }else{
        if([request isKindOfClass:SFRestRequest.class]){
            SFRestRequest * restRequest = (SFRestRequest*)request;
            requestInfo = [NSString stringWithFormat:@"SFRestRequest: %@ %@",restRequest.path?restRequest.path:@"",restRequest.queryParams?restRequest.queryParams:@""];
        }
    }

    return requestInfo;
}

-(void)upsertSyncRecord{
    NSString * syncType = self.sync.mode == kDDSFDownstreamSyncModeIncremental ? @"Incremental Sync" : @"Full Sync";
    NSString * timestamp = [[NSDate date]agnRFC3339FormattedTimestampString];
    NSString * version = [[AGNAppDelegate sharedDelegate]applicationVersion];
    NSString * guid = [[AGNAppDelegate sharedDelegate]applicationGUID];


    AGNSalesRep *loggedInSalesRep = self.sync.loggedInSalesRep;  
    NSMutableDictionary * upsertDictionary = [[NSMutableDictionary alloc]initWithCapacity:5];
    upsertDictionary[@"Mobile_Last_Sync__c"]=timestamp;
    upsertDictionary[@"Mobile_Last_Sync_Type__c"]=syncType;
    upsertDictionary[@"Mobile_Build_Version__c"]=version;
    upsertDictionary[@"Mobile_Build_GUID__c"]=guid;

    NSString *currentJSONRepresentation = [upsertDictionary JSONString];
    log4Info(@"Sending upsert transaction for sync %@",currentJSONRepresentation);
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpsertSyncRecord];
    upTxn.undoJSONRepresentation = nil;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.deleteModelObjectOnRevert = NO;
    upTxn.modelClassName = @"AGNSalesRep";
    upTxn.salesForceId = loggedInSalesRep.salesForceId;

    NSArray * updateTransactions = [NSArray arrayWithObject:upTxn];

   if (![[AGNUpdateQueueManager defaultManager] appendTransactions:updateTransactions]) {
        //TODO: notify user of fail and refresh interface
        log4Error(@"Failed to upsert record of sync - either appendTransactions failed or MOC save failed");
    }
}

- (void) completeDownstreamSync {
    if (self.sync.mode == kDDSFDownstreamSyncModeFull) {
        // We've just completed a full sync, so we need to clear needFullSync flag.
        self.needFullSync = NO;
    }
    
    self.sync = nil;
    self.fullSyncRequested = NO;
    
    // Stop listening for notifications
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateQueueCountChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpsyncStoppedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNAbortSyncNotificationKey object:nil];
    
    // Post notification that the sync has ended
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:kDDSFNotificationSyncEnded object:self]];
}

- (int)maxDaysForIncrementalSync {
    
    int maxDaysForIncrementalSync = AGN_FULL_SYNC_DAYS_THRESHOLD;
    NSString *userDefaultValue = [[NSUserDefaults standardUserDefaults] objectForKey:AGNIncrementalSyncMaxDaysSinceLastSyncKey];
    if (userDefaultValue) {
        maxDaysForIncrementalSync = [userDefaultValue intValue];
    }
    return maxDaysForIncrementalSync;
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UIAlertViewDelegate
//------------------------------------------------------------------------------

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (alertView == self.userNotConfiguredAlertView) {
        log4Info(@"User not configured warning dismissed, logging out the user.");
        self.userNotConfiguredAlertView = nil;
        self.syncInProgress = NO; // We are no longer syncing
        [AGNAppDelegate sharedDelegate].shouldSyncAfterLogin = YES;
        [[AGNAppDelegate sharedDelegate] logout:YES];
    }else if (alertView == self.versionWarningAlertView){
        log4Info(@"Version warning dismissed");
        self.versionWarningBlock();
    }
}

#pragma mark - 
#pragma mark DDSFRequestDelegate

- (void)requestCompleted:(DDSFRequest *)request withJson:(NSDictionary *)json {
    if (request == self.userRequest) {
        if ([AGNDownstreamSync processPermissions:[AGNAppDelegate sharedDelegate].managedObjectContext
                                     salesRep:[AGNAppDelegate sharedDelegate].loggedInSalesRep
                                         json:json
                                             sync:nil]) {
            
            // If we can proceed (no kill swithc) then update the records
            [AGNDownstreamSync syncUserSyncGroup:json moc:[AGNAppDelegate sharedDelegate].managedObjectContext];
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.userRequest = nil;
        });
    }
}

- (void)request:(DDSFRequest *)request failedWithError:(NSError *)error {
    if (request == self.userRequest) {
        log4Error(@"Received error while synchronizing user: %@", error);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.userRequest = nil;
        });
    }
}

+ (BOOL)isReplayingMockData {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    id value = [defaults objectForKey:kDDSFDownstreamSyncMockModeDefaultsKey];
    if (!value || ![value isKindOfClass:[NSString class]]) // No default value, go with live
        return NO;
    
    if ([value hasPrefix:kDDSFDownstreamSyncMockModeReplayPrefix])
        return YES;
    
    return NO;
}

@end
