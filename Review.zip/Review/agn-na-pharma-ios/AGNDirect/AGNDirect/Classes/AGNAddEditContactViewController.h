//
//  AGNAddEditContactViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/17/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSimplePopoverTableViewController.h"
#import "UINavigationController+AGNKeyboardDismiss.h"

@interface AGNAddEditContactViewController : UIViewController  <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, AGNPopoverDelegate >

@property (strong, nonatomic) AGNContact *contact;
@property (strong, nonatomic) AGNAccount *account;

@end


