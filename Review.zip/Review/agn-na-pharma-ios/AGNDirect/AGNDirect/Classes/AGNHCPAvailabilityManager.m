//
//  AGNHCPAvailabilityManager.m
//  TestApp
//
//  Created by Adam McLain on 10/19/12.
//  Copyright (c) 2012 AdamMcLain. All rights reserved.
//

#import "AGNHCPAvailabilityManager.h"
#import "AGNHCPDayAvailability.h"
#import "AGNAddress.h"

@interface AGNHCPAvailabilityManager ()
@property (strong, nonatomic, readwrite) AGNHCPDayAvailability *monday;
@property (strong, nonatomic, readwrite) AGNHCPDayAvailability *tuesday;
@property (strong, nonatomic, readwrite) AGNHCPDayAvailability *wednesday;
@property (strong, nonatomic, readwrite) AGNHCPDayAvailability *thursday;
@property (strong, nonatomic, readwrite) AGNHCPDayAvailability *friday;
@end

@implementation AGNHCPAvailabilityManager

- (id)initWithAddress:(AGNAddress *)anAddress {
    self = [super init];
    if (self) {        
        AGNHCPDayAvailability *monday = [[AGNHCPDayAvailability alloc] init];
        monday.startTime = [NSDate dateFromAddressAvailabilityString:anAddress.mondayOpenTime];
        monday.endTime = [NSDate dateFromAddressAvailabilityString:anAddress.mondayCloseTime];
        monday.day = @"MON";
        self.monday = monday;
        
        AGNHCPDayAvailability *tuesday = [[AGNHCPDayAvailability alloc] init];
        tuesday.startTime = [NSDate dateFromAddressAvailabilityString:anAddress.tuesdayOpenTime];
        tuesday.endTime = [NSDate dateFromAddressAvailabilityString:anAddress.tuesdayCloseTime];
        tuesday.day = @"TUE";
        self.tuesday = tuesday;
        
        AGNHCPDayAvailability *wednesday = [[AGNHCPDayAvailability alloc] init];
        wednesday.startTime = [NSDate dateFromAddressAvailabilityString:anAddress.wednesdayOpenTime];
        wednesday.endTime = [NSDate dateFromAddressAvailabilityString:anAddress.wednesdayCloseTime];
        wednesday.day = @"WED";
        self.wednesday = wednesday;
        
        AGNHCPDayAvailability *thursday = [[AGNHCPDayAvailability alloc] init];
        thursday.startTime = [NSDate dateFromAddressAvailabilityString:anAddress.thursdayOpenTime];
        thursday.endTime = [NSDate dateFromAddressAvailabilityString:anAddress.thursdayCloseTime];
        thursday.day = @"THU";
        self.thursday = thursday;
        
        AGNHCPDayAvailability *friday = [[AGNHCPDayAvailability alloc] init];
        friday.startTime = [NSDate dateFromAddressAvailabilityString:anAddress.fridayOpenTime];
        friday.endTime = [NSDate dateFromAddressAvailabilityString:anAddress.fridayCloseTime];
        friday.day = @"FRI";
        self.friday = friday;
    }
    
    return self;
}

- (AGNHCPDayAvailability *)dayAvailabiliyForWeekday:(int)weekday {
    switch (weekday) {
        case kAGNWeekdayMonday:
            return self.monday;
        case kAGNWeekdayTuesday:
            return self.tuesday;
        case kAGNWeekdayWednesday:
            return self.wednesday;
        case kAGNWeekdayThursday:
            return self.thursday;
        case kAGNWeekdayFriday:
            return self.friday;
        default:
            return nil;
    }
    
    AGNAddress *anAddress;
    
    AGNHCPDayAvailability *tuesday = [[AGNHCPDayAvailability alloc] init];
    tuesday.startTime = [NSDate dateFromAddressAvailabilityString:anAddress.tuesdayOpenTime];
    tuesday.endTime = [NSDate dateFromAddressAvailabilityString:anAddress.tuesdayCloseTime];
    tuesday.day = @"Tuesday";
    self.tuesday = tuesday;
}

@end
