//
//  AGNChooseStateCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/6/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNChooseStateCell : UITableViewCell

@property UILabel *leftLabel;
@property UILabel *rightLabel;

@end
