//
//  AGNReceiptSelectionCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/25/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNReceiptSelectionCell.h"
#import "NSString+AGNString.h"
#import "AGNCallDetailDetailsViewController.h"

@implementation AGNReceiptSelectionCell
@synthesize call=_call;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)setCall:(AGNCall *)call  {
    _call=call;
    [self setupAddresses];
    [self.emailReceiptSwitch addTarget:self action:@selector(emailToggled) forControlEvents:UIControlEventValueChanged];
    [self.mailReceiptSwitch addTarget:self action:@selector(mailToggled) forControlEvents:UIControlEventValueChanged];
    [self updateDisplay];
   
}

-(void)updateDisplay{
    if(self.call){
        if(!self.call.receiptEmailAddress) {// if we cancelled out w/o populating email address, just turn it back off
            log4Info(@"No email address populated, toggling email receipt flag to %d  ",[self.call.emailReceiptRequested intValue]);

            self.call.emailReceiptRequested = NO;

        }
        if([self.call.emailReceiptRequested boolValue]){
            [self.emailReceiptSwitch setOn:YES ];
            self.emailAddress.text = self.call.receiptEmailAddress;
            self.emailAddress.hidden = NO;

        }else{
            [self.emailReceiptSwitch setOn:NO ];
            self.emailAddress.text = @"";
            self.emailAddress.hidden = YES;

        }
        [self.mailReceiptSwitch setOn:[self.call.mailReceiptRequested boolValue] ];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];

    }
}

-(void)setupAddresses{
    AGNAccount *account = self.call.account;
    self.emailAddresses = [[NSMutableArray alloc]initWithCapacity:4];
    if(account.email1)
        [self.emailAddresses addObject:account.email1];
    if(account.email2)
        [self.emailAddresses addObject:account.email2];
    if(account.email3)
        [self.emailAddresses addObject:account.email3];
    if([self.call.emailReceiptRequested boolValue]){
        NSString * emailAddress = self.call.receiptEmailAddress;
        if(emailAddress){
            self.emailAddress.text=emailAddress;
            UITapGestureRecognizer *tapAddress = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(emailAddressTapped:)];
            [self.emailAddress addGestureRecognizer:tapAddress];

            if(![self.emailAddresses containsObject:emailAddress]){
                [self.emailAddresses addObject:emailAddress];
            }
        }
    }

}


-(int)currentSelection{
    if(self.call.receiptEmailAddress){
        return [self.emailAddresses indexOfObject:self.call.receiptEmailAddress];
    }
    return -1;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)emailAddressTapped:(UILongPressGestureRecognizer *)gestureRecognizer {
    [self showPopover];
}

-(void)emailToggled{
    BOOL emailReceipt = [self.emailReceiptSwitch isOn];
    self.call.emailReceiptRequested = [NSNumber numberWithBool:emailReceipt];
    if(emailReceipt){
        if(!self.call.receiptEmailAddress){
            //per AL-404, default to first available email address
            self.call.receiptEmailAddress = [self.call.account defaultEmailAddress];
        }
        [self showPopover];
    }
    else{
        self.call.receiptEmailAddress=nil;
        self.emailAddress.text=@"";
    }
    [self setupAddresses];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];
    log4Info(@"Toggled email receipt flag to %d",[self.call.emailReceiptRequested intValue]);

}

-(void)mailToggled{
    BOOL mailReceipt = [self.mailReceiptSwitch isOn];
    self.call.mailReceiptRequested = [NSNumber numberWithBool:mailReceipt];
    log4Info(@"Toggled mail receipt flag to %d",[self.call.mailReceiptRequested intValue]);
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNCheckCloseButtonNotification object:self];

}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
    //if there are no email addresses and nothing is added, set the email switch back to off
    if(!self.call.receiptEmailAddress ) {
        [self.emailReceiptSwitch setOn:NO animated:YES];
        self.call.emailReceiptRequested=[NSNumber numberWithBool:NO];
    }
    [self updateDisplay];
}

- (AGNUpdateTransactionValueHolder *)updateAccountTxn
{
    AGNAccount *account = self.call.account;
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init];
    
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperUpdateAccount];
    upTxn.undoJSONRepresentation = account.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = [account jsonRepresentationForUpdate];
    upTxn.deleteModelObjectOnRevert = @NO;
    upTxn.modelClassName = @"AGNAccount";
    upTxn.salesForceId = account.salesForceId;
    
//    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:@[upTxn]]) {
//        log4Error(@"Failed to save account - either appendTransactions failed or MOC save failed");
//    }
    
    return upTxn;
}

//------------------------------------------------------------------------------
// MARK: - AGNPopoverDelegate Protocol
//------------------------------------------------------------------------------

-(void) objectSelected:(NSInteger)selected{
    NSString * selectedEmail = self.emailAddresses[selected];
    self.call.receiptEmailAddress = selectedEmail;
    self.emailAddress.text = selectedEmail;
    self.emailAddress.hidden = NO;
    [self.popover dismissPopoverAnimated:YES];
    self.popover = nil;
    [self updateDisplay];
    log4Info(@"Selected email address %@",selectedEmail);

}


-(void) addNewEmail:(NSString *)email{
    email =  [email stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if(email && [email length]>0){
        if(![email AGNIsValidEmail]){
            NSString * title = NSLocalizedString(@"Invalid Email Address", @"Title for invalid email alert view");
            NSString * message = NSLocalizedString(@"Please enter a valid email address.", @"Message for invalid email alert view");
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alertView show];
            return;
        }

        self.call.receiptEmailAddress = email;
        self.emailAddress.text = email;
        [self.call.account setUndoRepresentation];
        if ([self.call.account addEmailIfPossible:email]) {
            // Added email to account, need to update when call saved
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNAccountModifiedNotification object:[self updateAccountTxn]];
        }
    }
    log4Info(@"Added email address %@",email);

    [self updateDisplay];
    [self setupAddresses];
    [self.popover dismissPopoverAnimated:YES];
    self.popover = nil;
}


//------------------------------------------------------------------------------
// MARK: - Additional popover methods
//------------------------------------------------------------------------------

-(void)interfaceRotated{
    if(![self.popover isPopoverVisible])
        return;
    
    [self.popover dismissPopoverAnimated:NO];
    [self showPopover];
}


-(void) showPopover {
    self.popover = [[AGNEmailReceiptPopoverController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Email Addresses On File", @"Email Addresses Popover Title")];
    self.popover.delegate = self;
   
    self.popover.objectArray = self.emailAddresses;
    CGRect rect = self.emailReceiptSwitch.frame;
    rect = [self.view convertRect:rect fromView:self.emailReceiptSwitch.superview];
    [self.popover presentPopoverFromRect:rect
                                  inView:self.view
                permittedArrowDirections:UIPopoverArrowDirectionAny
                                animated:YES];
}

@end
