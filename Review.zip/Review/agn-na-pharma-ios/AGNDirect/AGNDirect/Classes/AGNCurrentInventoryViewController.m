//
//  AGNCurrentInventoryViewController.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCurrentInventoryViewController.h"
#import "AGNDataManager.h"
#import "AGNInventoryCell.h"
#import "AGNSampleInventoryLine.h"
#import "AGNTableView.h"

#define SORTABLE_ROWS 3

@interface AGNCurrentInventoryViewController ()
@property (strong, nonatomic) IBOutlet AGNTableView *tableView;
@property (strong, nonatomic) NSArray *sampleInventoryLines;
@property (strong, nonatomic) IBOutlet UIView *headerView;
@property (strong, nonatomic) NSMutableArray *currentSortDescriptors;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;

@end

@implementation AGNCurrentInventoryViewController
@synthesize tableView = _tableView;
@synthesize sampleInventoryLines;
@synthesize salesRep;
@synthesize headerView;
@synthesize topHeaderViewConstraint;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.tableFooterView = [[UIView alloc] init];
    [self.monthlyCountButton setBackgroundImage:[[UIImage imageNamed:@"btn-bigblue"] stretchableImageWithLeftCapWidth:3 topCapHeight:0]forState:UIControlStateNormal];
    [self.monthlyCountButton setBackgroundImage:[[UIImage imageNamed:@"btn-bigblue-hi"] stretchableImageWithLeftCapWidth:3 topCapHeight:0]forState:UIControlStateHighlighted];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    log4Info(@"Viewing current inventory");
    
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
    self.currentSortDescriptors=[[NSMutableArray alloc]initWithCapacity:2];
    
    
    UIGestureRecognizer * tapQty = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedQuantity:)];
    self.quantityLabel.userInteractionEnabled=YES;
    [self.quantityLabel addGestureRecognizer:tapQty];
    
    UIGestureRecognizer * tapQty2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedQuantity:)];
    self.quantityImage.userInteractionEnabled=YES;
    [self.quantityImage addGestureRecognizer:tapQty2];
    

    UIGestureRecognizer * tapSampleName = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedSampleName:)];
    self.sampleNameLabel.userInteractionEnabled=YES;
    [self.sampleNameLabel addGestureRecognizer:tapSampleName];

    UIGestureRecognizer * tapExpiration = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedExpiration:)];
    self.expirationLabel.userInteractionEnabled=YES;
    [self.expirationLabel addGestureRecognizer:tapExpiration];
  
    UIGestureRecognizer * tapExpiration2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedExpiration:)];
    self.expiresImage.userInteractionEnabled=YES;
    [self.expiresImage addGestureRecognizer:tapExpiration2];
    
    UIGestureRecognizer * tapSampleName2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedSampleName:)];
    self.sampleNameImage.userInteractionEnabled=YES;
    [self.sampleNameImage addGestureRecognizer:tapSampleName2];
    
    [self initSort];
}

-(void)initSort{
    [self.currentSortDescriptors removeAllObjects];
    [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"product.productDescription" ascending:YES]];
    [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"expiration" ascending:YES]];
    [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"quantity" ascending:YES]];

    self.sampleNameImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
    self.expiresImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.quantityImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    
    self.sampleInventoryLines = [[AGNDataManager defaultInstance] getSampleInventoryLinesWithSortDescriptors:self.currentSortDescriptors];
    [self.tableView reloadData];
}

- (int)indexOfDescriptorForKey:(NSString *)key{
    for(int i=0; i < SORTABLE_ROWS; i++ ){
        NSSortDescriptor *desc = self.currentSortDescriptors[i];
        if([desc.key isEqualToString:key])
            return i;
    }
    return -1;
}

- (void) updateToNewSort:(NSString *)sortKey{
    
    NSSortDescriptor *firstSort = self.currentSortDescriptors[0];

    if([firstSort.key isEqualToString:sortKey]){ // just switch sort order
        BOOL ascending=!firstSort.ascending;
        self.currentSortDescriptors[0]=[NSSortDescriptor sortDescriptorWithKey:sortKey ascending:ascending];

    }else{
        int index = [self indexOfDescriptorForKey:sortKey];
        NSSortDescriptor *existing = self.currentSortDescriptors[index];
        NSSortDescriptor *newDescriptor = [NSSortDescriptor sortDescriptorWithKey:sortKey ascending:!existing.ascending];
        for(int i=index-1; i >=0 ; i--){
            self.currentSortDescriptors[i+1]=self.currentSortDescriptors[i];
        }
        self.currentSortDescriptors[0]=newDescriptor;
    }
    
    [self updateImages];
    self.sampleInventoryLines = [[AGNDataManager defaultInstance] getSampleInventoryLinesWithSortDescriptors:self.currentSortDescriptors];
    [self.tableView reloadData];
    NSLog(@"--------> Tableview row height CurrentInvView : %f", self.tableView.rowHeight);
}

-(void) updateImages{
    self.sampleNameImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.expiresImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.quantityImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];

    for(int i=0; i < SORTABLE_ROWS; i++){
        NSSortDescriptor *sort = self.currentSortDescriptors[i];
        if([sort.key isEqualToString:@"product.productDescription"]){
            if(i==0)
                self.sampleNameImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.sampleNameImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.sampleNameImage setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.sampleNameImage setTransform:rotate];
            }
        }
        if([sort.key isEqualToString:@"expiration"]){
            if(i==0)
                self.expiresImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.expiresImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.expiresImage setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.expiresImage setTransform:rotate];
            }
        }
        if([sort.key isEqualToString:@"quantity"]){
            if(i==0)
                self.quantityImage.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.quantityImage.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.quantityImage setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.quantityImage setTransform:rotate];
            }

        }
    }

    
}

- (void)tappedSampleName:(UITapGestureRecognizer *)sender {
    NSString *sortKey = @"product.productDescription";
    [self updateToNewSort:sortKey];
}

- (void)tappedQuantity:(UITapGestureRecognizer *)sender {
    NSString *sortKey = @"quantity";
    [self updateToNewSort:sortKey];
}

- (void)tappedExpiration:(UITapGestureRecognizer *)sender {
    NSString *sortKey = @"expiration";
    [self updateToNewSort:sortKey];
}

-(void) reloadContent{
    self.sampleInventoryLines = [[AGNDataManager defaultInstance] getSampleInventoryLinesWithSortDescriptors:self.currentSortDescriptors];
    [self.tableView reloadData];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.tableView.contentSize = newContentSize;
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.sampleInventoryLines count]>0?[self.sampleInventoryLines count]:1;
}
/*
-(CGFloat)tableView:(UITableViewCell*)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat result ;
    switch ([indexPath row])
    {
    case 0:
        {
        result = 30;
            break;
        }
    default :
        result = 42;
        
    }
    return result; // whatever
}
 */

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *SampleInventoryCellIdentifier = @"SampleInventoryCell";

    //Sample Inventory Line Cell
    AGNInventoryCell *cell = [tableView dequeueReusableCellWithIdentifier:SampleInventoryCellIdentifier];
    if (cell == nil) {
        cell = [[AGNInventoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SampleInventoryCellIdentifier];
    }
    if([self.sampleInventoryLines count]==0){
        cell.sampleLabel.text = AGNPlaceholderText;
        cell.lotNumber.text = nil;
        cell.expirationDate.text = nil;
        cell.quantityLabel.text = nil;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    AGNSampleInventoryLine *sampleInventoryLine = self.sampleInventoryLines[indexPath.row];
    if ([sampleInventoryLine.product productCode]) {
        cell.sampleLabel.text = UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ?
                [sampleInventoryLine.product fullDescription] :
                [sampleInventoryLine.product productDescription];
    }
    else {
        cell.sampleLabel.text = @"UNKNOWN SAMPLE";
    }
    
    if (sampleInventoryLine.lotNumber) {
        cell.lotNumber.text = sampleInventoryLine.lotNumber;
    }
    else {
        cell.lotNumber.text = @"UNKNOWN";
    }
    
    if (sampleInventoryLine.expiration)  {
        cell.expirationDate.text = [sampleInventoryLine.expiration agnFormattedDateString];
        if([sampleInventoryLine.expiration isExpired]){
            cell.expirationDate.textColor = [UIColor AGNWarny];
        }else{
            cell.expirationDate.textColor = [UIColor AGNGreyMatter];
        }
    }
    else {
        cell.expirationDate.text = @"UNKNOWN";
    }
    
    if ([sampleInventoryLine.quantity stringValue]) {
        int qty = [sampleInventoryLine.quantity intValue];
        cell.quantityLabel.text = [[NSNumber numberWithInt:qty] stringValue];
    }
    else {
        cell.quantityLabel.text = @"---";
    }
     
    
    return cell;
    
}

@end
