//
//  AGNReprintDetailViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/10/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNViewController.h"
#import "AGNMarketingDisbursement.h"

@interface AGNReprintDetailViewController : AGNViewController <UITableViewDataSource,UITableViewDelegate, UIPopoverControllerDelegate>

@property (strong, nonatomic) AGNMarketingDisbursement *marketingDisbursement;
@property (strong, nonatomic) AGNAccount *hcp;
@property (strong, nonatomic) AGNAddress *hcpAddress;

@end
