//
//  UINavigationController+AGNKeyboardDismiss.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/31/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "UINavigationController+AGNKeyboardDismiss.h"

@implementation UINavigationController (AGNKeyboardDismiss)

- (BOOL)disablesAutomaticKeyboardDismissal
{
    return NO;
}

@end
