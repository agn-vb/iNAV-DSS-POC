//
//  AGNBigGreyButton.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 11/7/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNBigGreyButton.h"

@implementation AGNBigGreyButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self styleButton];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)styleButton {
    UIImage *defalut =
    [[UIImage imageNamed:@"btn-big-grey-unsel"]  resizableImageWithCapInsets:
     UIEdgeInsetsMake(47.0f, 2.0f, 47.0f, 2.0f)];
    // {top, left, bottom, right};
    UIImage *highlighted = [[UIImage imageNamed:@"btn-big-grey-sel"] resizableImageWithCapInsets:
                            UIEdgeInsetsMake(47.0f, 2.0f, 47.0f, 2.0f)];


    
    [self setBackgroundImage:defalut forState:UIControlStateNormal];
    [self setBackgroundImage:highlighted forState:UIControlStateSelected];
    [self setBackgroundImage:highlighted forState:UIControlStateHighlighted];
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.titleLabel.font = [UIFont AGNHelveticaNeueBold16];}
@end
