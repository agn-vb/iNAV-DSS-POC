//
//  AGNViewController.h
//  AGNDirect
//
//  Created by Mark Wells on 9/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNUpdateQueueManager.h"
#import "AGNUpdateTransactionValueHolder.h"

@interface AGNViewController : UIViewController

@property (strong, nonatomic) NSString *undoJSONRepresentation;

- (BOOL)needsUndoState;
- (void)createUndoState;

// Use for generic data load - specifically needed for undo
- (void)reloadContent;

@end
