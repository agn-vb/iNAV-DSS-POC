//
//  UIColor+AGNColor.h
//  AGNDirect
//
//  Created by Adam McLain on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (AGNColor)

+ (UIColor *)AGNColorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue;

// UITableViewCell selected background
// UITableView seperator
+ (UIColor *)AGNCobalt;

// Used with UITableViewCell background
+ (UIColor *)AGNNorilskSneg;

// Selected UITableViewCell detail label text color
+ (UIColor *)AGNSilberLining;

// UITableViewCell detail label text color
+ (UIColor *)AGNSecondGrayd;

// UITableView header background
// Search text field
+ (UIColor *)AGNDarkGray;

// UITableViewCell main label text color
+ (UIColor *)AGNGreyMatter;

+ (UIColor *)AGNOrange;

+ (UIColor *)AGNNavbarChar;

+ (UIColor *)AGNWAwawa;

+ (UIColor *)AGNPresentime;

+ (UIColor *)AGNEleventhHour;

+ (UIColor *)AGNHighliteWhite;

+ (UIColor *)AGNDropShadow;

+ (UIColor *)AGNWarny;

+ (UIColor *)AGNTangelo;

@end
