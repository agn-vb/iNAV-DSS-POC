//
//  AGNTransferViewController.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 9/29/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNTransferViewController.h"
#import "AGNAvailableSampleHeaderCell.h"
#import "AGNTransferHeaderCell.h"
#import "AGNAvailableSampleCell.h"
#import "AGNInventoryTransactionLineCell.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNTransferToCell.h"
#import "AGNSingleLineCell.h"
#import "AGNSampleInventoryTransaction.h"
#import "AGNInventoryTransactionSummaryCell.h"
#import "AGNEligibilityHelper.h"
#import "AGNCategoryHeaders.h"
#import "UITextField+NSIndexPath.h"
#import "AGNTableViewHeader.h"

@interface AGNTransferViewController ()

@property (strong,nonatomic) NSMutableArray * lines;
@property (strong,nonatomic) NSMutableArray * availableSamples;
@property (weak, nonatomic) AGNDataManager * dataManager;
@property (strong, nonatomic) NSArray * availableSKUs;
@property (assign, nonatomic) BOOL shouldDisplayExtraSampleCell;

@property (strong, nonatomic) AGNProductSKU *selectedSKU;
@property (strong, nonatomic) AGNSimplePopoverTableViewController *lotPickerPopover;
@property (strong, nonatomic) NSIndexPath *lotPickerSelectedCellIndexPath;
@property (strong, nonatomic) AGNTransferToCell *transferToCell;
@property (strong, nonatomic) AGNSimplePopoverTableViewController *transferToPopover;
@property (copy, nonatomic) NSString *transactionGuid;
@property (strong, nonatomic) UITextField *activeField;
@property (strong, nonatomic) NSIndexPath *returnToIndexPath;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;
@property BOOL editing;


@end

@implementation AGNTransferViewController

static const int kHeight=44;

@synthesize topHeaderViewConstraint;


- (void)rebuildAvailableSKUs {
    NSMutableSet * skus = [NSMutableSet set];
    for (AGNSampleInventoryLine * line in self.availableSamples) {
        [skus addObject:line.product];
    }
    
    self.availableSKUs = [[skus allObjects] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"productDescription" ascending:YES]]];
}

// Load all data
- (void)reloadContent {
    // core data objects purged & reloaded
    if ([self.transaction isFault]) {
        self.transaction = (AGNSampleInventoryTransaction *)[self.dataManager objectOfType:@"AGNSampleInventoryTransaction"
                                                                                   forGuid:self.transactionGuid];
    }
    // If we have a transaction already saved to database, then we need to reload lines
    if (self.transaction && !self.transaction.isNew) {
        // Reload lines
        
        self.lines = [[self.transaction.sampleInventoryTransactionLines allObjects] mutableCopy];
    }
    
    // If we do not have a transaction, we need to create one.
    else if (!self.transaction) {
        // Create a new transaction
        self.transaction = (AGNSampleInventoryTransaction*)
                [NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryTransaction"
                                              inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
        self.transaction.deleteOnRevert = NO;
        self.transaction.status = kOpenStatusType;
        self.transaction.from = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
        self.transaction.fromSalesForceId = self.transaction.from.salesForceId;
        self.transaction.transactionType = self.targetType;
        self.transaction.guid = [[NSUUID UUID] UUIDString];
        self.transaction.sfdcCreatedDate = [NSDate date];
        self.transaction.inventoryDate = [NSDate date];
        self.transaction.mobileCreateTimestamp = [NSDate date];
        self.transaction.mobileLastUpdateTimestamp = [NSDate date];
        
        // TODO: other fields?
        
        // No lines yet
        self.lines = [NSMutableArray array];
    }
    
    // Need to reload available samples
    self.availableSamples = [[NSMutableArray alloc] init];
    NSArray *sils = [self.dataManager getSampleInventoryLines];
    for (AGNSampleInventoryLine *line in sils) {
        if ([line canShip]) {
            [self.availableSamples addObject:line];
        }
    }
    
    // Now we need to remove already added sample lines
    for (AGNSampleInventoryTransactionLine * line in self.lines) {
        if (line.sampleInventoryLine)
            [self.availableSamples removeObject:line.sampleInventoryLine];
    }
    
    [self rebuildAvailableSKUs];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.dataManager = [AGNAppDelegate sharedDelegate].dataManager;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    if ((self = [super initWithCoder:aDecoder])) {
        self.dataManager = [AGNAppDelegate sharedDelegate].dataManager;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
	self.tableView.tableFooterView = [[UIView alloc] init];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.transaction && ![self.transaction isFault]) {
        self.transactionGuid = self.transaction.guid;
    }
    if(self.transaction){
        log4Info(@"Loaded inventory transaction %@|%@ of type %@ and status %@",self.transaction.salesForceId,self.transaction.guid, self.transaction.transactionType, self.transaction.status);
    }else{
        log4Info(@"Start new transactions of type %@",self.targetType);
    }

    [self reloadContent];
    [self updateButton];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(quantitySelected) name:AGNTransferLineQuantityChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transferToSelected) name:AGNTransferToSelectedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(cellBeganEditing:)
                                                 name:AGNTransferCellDidBeginEditing object:nil];


    [self.transaction setUndoRepresentation];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNTransferLineQuantityChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNTransferToSelectedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNTransferCellDidBeginEditing object:nil];

}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.tableView.contentSize = newContentSize;
    
    if(self.activeField && [self.activeField isFirstResponder]){
        [self.activeField resignFirstResponder];
        [self.activeField becomeFirstResponder];
    }
}


- (void)updateButton {
    if (![self.transaction.status isEqualToString:kOpenStatusType]) {
        self.submitButton.hidden = YES;
    }
    else {
        if ([_transaction.transactionType isEqualToString:kOutboundTransferType])
            [self.submitButton setTitle:@"Submit Transfer" forState:UIControlStateNormal];
        else
            [self.submitButton setTitle:@"Submit Return" forState:UIControlStateNormal];
        
        
        if([self canSubmit]){
            self.submitButton.enabled=YES;
            self.submitButton.alpha=1.0;
        }
        else{
            self.submitButton.enabled=NO;
            self.submitButton.alpha=.5;
            
            if ([_transaction.transactionType isEqualToString:kOutboundTransferType] && ![self isDuplicateAuthID] )
                [self.submitButton setTitle:@"Submit Transfer" forState:UIControlStateNormal];
            else
                [self.submitButton setTitle:@"Auth ID: N/A" forState:UIControlStateNormal];
                
        }

        
    }
}

- (BOOL)canSubmit {
    
    NSString * strTemp = @"NA" ;
    // We need to have at least one line, all lines need to have valid quantities
    if (self.lines.count == 0)
        return NO;
    for (AGNSampleInventoryTransactionLine * line in self.lines) {
        if ([line.expectedQuantity intValue] <= 0)
            return NO;
        if ([line.expectedQuantity intValue] > [line.sampleInventoryLine.quantity intValue])
            return NO;
    }
    if([self.transaction isOutboundTransfer] && !self.transaction.to)
        return NO;
    
    if([self.transaction isOutboundTransfer] && [self isDuplicateAuthID])
    {
        self.submitButton.titleLabel.text = @"Auth ID: N/A";
        
        //[strTemp stringByAppendingString:self.transaction.transferAuthorizationNumber];
        //self.transaction.transferAuthorizationNumber = strTemp; //:@"NA" ];
        
        return NO;
    }
    if(![self.transaction.transferAuthorizationNumber AGNIsValidTransferNumber])
        return NO;
    
    return YES;
}

//barathan : 06202014 to check if Auth ID already used.
//getOutgoingSubmittedTransfersAndReturnsForLoggedInUser
-(BOOL) isDuplicateAuthID {
    
    _Bool bRetVal = false ;
    NSMutableArray *result = [[NSMutableArray alloc]init];
    [result addObjectsFromArray:[self.dataManager getOutgoingProductForLoggedInUser]];
    //[result addObjectsFromArray:[self.dataManager  getOutgoingSubmittedTransfersAndReturnsForLoggedInUser]];
    for(AGNSampleInventoryTransaction * objTxn in result) {
        log4Info( @"Dup Check Sample Inventory Txn  %@", objTxn);
        if ([objTxn.transactionType isEqualToString:kOutboundTransferType] &&
            [objTxn.transferAuthorizationNumber isEqualToString:self.transaction.transferAuthorizationNumber ]&&
             !([objTxn.guid isEqualToString:self.transaction.guid])
            )
        {
             bRetVal = true;
             break ;
        }
    }
    
    return bRetVal;
}

- (BOOL)canDismiss {
    if ([[AGNAppDelegate sharedDelegate] saveContext]) {
        self.transaction.deleteOnRevert = NO;
        return YES;
    }
    return NO;
}

- (void)presentLotPickerForIndexPath:(NSIndexPath *)indexPath {
    self.lotPickerSelectedCellIndexPath = indexPath;
    
    AGNProductSKU *sku = nil;
    NSMutableArray *sampleInventoryProducts = [NSMutableArray arrayWithCapacity:self.availableSamples.count];
    
    // Get related SKU for related tableViewCell
    if (self.shouldDisplayExtraSampleCell) {
        sku = self.selectedSKU;
    } else {
        AGNSampleInventoryTransactionLine * line = [self.lines objectAtIndex:indexPath.row];
        sku = line.product;
        [sampleInventoryProducts addObject:line.sampleInventoryLine];
    }
    
    // Build available products out of remaining samples
    for (AGNSampleInventoryLine * sample in self.availableSamples) {
        if (sample.product == sku)
            [sampleInventoryProducts addObject:sample];
    }
    
    NSAssert(sampleInventoryProducts.count > 0, @"Cannot open popover when there is no products");
        
    // sort the array by dates
    [sampleInventoryProducts sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        AGNSampleInventoryLine *sil1 = obj1;
        AGNSampleInventoryLine *sil2 = obj2;
        return [sil1.expiration compare:sil2.expiration];
    }];
    
    // create popover
    self.lotPickerPopover = nil;
    
    self.lotPickerPopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Available Lots", @"lot picker title")];
    
    
    // set properites on popover to display the sampleInventoryLines array
    self.lotPickerPopover.objectArray = sampleInventoryProducts;
    self.lotPickerPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        static NSString *CellIdentifier = @"CellIdentifier";
        
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        [cell agnSetStyledSelectedBackground];
        
        AGNSampleInventoryLine *sampleInventoryLine = [sampleInventoryProducts objectAtIndex:indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ (%@)", sampleInventoryLine.lotNumber, sampleInventoryLine.product.productDescription];
        cell.textLabel.font = [UIFont AGNAvenirHeavy16];
        cell.textLabel.textColor = [UIColor AGNGreyMatter];
        cell.textLabel.highlightedTextColor = [UIColor whiteColor];
        NSString *expiration = sampleInventoryLine.expiration ? [sampleInventoryLine.expiration agnFormattedDateString] : @"";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"EXP: %@     QTY: %@",  expiration, sampleInventoryLine.quantity];
        return cell;
    };
    
    // display the popover
    CGRect presentingRect = [self.tableView rectForRowAtIndexPath:indexPath];
    presentingRect.origin.y -= presentingRect.size.height / 2;
    [self.lotPickerPopover presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
    self.shouldDisplayExtraSampleCell = NO;
    [self.tableView reloadData];
    return YES;
}

- (void)objectSelected:(NSInteger)selected {
    BOOL shouldMakeQuantityFirstResponder = NO;
    
    AGNSampleInventoryLine * sil = (AGNSampleInventoryLine *)[self.lotPickerPopover.objectArray objectAtIndex:selected];
    if (!self.shouldDisplayExtraSampleCell) {
        AGNSampleInventoryTransactionLine * line = [self.lines objectAtIndex:self.lotPickerSelectedCellIndexPath.row];
        
        // Return the previously selected lot to available
        [self.availableSamples addObject:line.sampleInventoryLine];
        
        // Update the line
        line.sampleInventoryLine = sil;
        line.availableQuantity = sil.quantity;
        line.product = sil.product;
        line.productDescription = sil.product.productDescription;
        line.productSalesForceId = sil.product.salesForceId;
        line.productCode = sil.product.productCode;
        line.lotNumber = sil.lotNumber;
        line.expirationDate = sil.expiration;
        
        // Remove the newly selected slot
        [self.availableSamples removeObject:sil];
        
        // Update the added samples, but we don't need to update available samples, since they did not change
        [self.tableView reloadRowsAtIndexPaths:@[self.lotPickerSelectedCellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    } else {
        AGNSampleInventoryTransactionLine * line = (AGNSampleInventoryTransactionLine *)
                [NSEntityDescription
                 insertNewObjectForEntityForName:@"AGNSampleInventoryTransactionLine"
                            inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
        
        line.sampleInventoryLine = sil;
        line.guid = [[NSUUID UUID] UUIDString];
        line.expectedQuantity = 0;
        line.availableQuantity = sil.quantity;
        line.sampleInventoryTransaction = self.transaction;
        line.product = sil.product;
        line.productDescription = sil.product.productDescription;
        line.productSalesForceId = sil.product.salesForceId;
        line.productCode = sil.product.productCode;
        line.lotNumber = sil.lotNumber;
        line.expirationDate = sil.expiration;
        line.mobileCreateTimestamp = [NSDate date];
        line.mobileLastUpdateTimestamp = [NSDate date];
        
        if (!line.itemCode && line.lotNumber && line.productCode && [AGNAppDelegate sharedDelegate].loggedInSalesRep) {
            line.itemCode = [NSString stringWithFormat:@"%@-%@-%@", [AGNAppDelegate sharedDelegate].loggedInSalesRep.salesForceId, line.productCode, line.lotNumber];
        }

        [self.lines addObject:line];
        [self.availableSamples removeObject:sil];
        [self rebuildAvailableSKUs];
        
        shouldMakeQuantityFirstResponder = YES;
    }

    self.shouldDisplayExtraSampleCell = NO;
    [self.tableView reloadData];
    [self.lotPickerPopover dismissPopoverAnimated:YES];
    [self updateButton];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNTransferLineQuantityChangedNotificationKey object:nil];
    
    if (shouldMakeQuantityFirstResponder) {
        AGNInventoryTransactionLineCell *cell = (AGNInventoryTransactionLineCell *)[self.tableView cellForRowAtIndexPath:self.lotPickerSelectedCellIndexPath];
        [cell.quantityTextField becomeFirstResponder];
    }
}

- (IBAction)toggleEditMode:(id)sender {
    self.tableView.editing = !self.tableView.editing;
    self.editing = self.tableView.editing;
     
    // Force reload of first header view to display correct button title
    NSRange range = NSMakeRange(0, 1);
    NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
    [self.tableView reloadSections:section withRowAnimation:UITableViewRowAnimationNone];
}


//------------------------------------------------------------------------------
// MARK: - TableView Data Source
//------------------------------------------------------------------------------

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {    
    return 34.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        //AGNTransferHeaderCell * header = [tableView dequeueReusableCellWithIdentifier:@"TransferHeaderCell"];
        AGNTableViewHeader *header = [[AGNTableViewHeader alloc]init];
        [header.button addTarget:self action:@selector(toggleEditMode:) forControlEvents:UIControlEventTouchUpInside];
        if ([self.transaction isNew]) {
            header.leftLabel.text = [NSString stringWithFormat:@"NEW %@", [self.transaction.transactionType isEqualToString:kOutboundTransferType] ? @"TRANSFER" : @"RETURN"];
            header.rightLabel.hidden = YES;
            if (tableView.editing)
                [header setButtonLabelText:@"DONE"];
            else if (self.lines.count > 0)
                [header setButtonLabelText:@"EDIT"];
            else
                header.button.hidden = YES;
        }
        
        else if ([self.transaction.status isEqualToString:kOpenStatusType]) {
            header.leftLabel.text = [NSString stringWithFormat:@"DRAFT %@", [self.transaction.transactionType isEqualToString:kOutboundTransferType] ? @"TRANSFER" : @"RETURN"];
            header.rightLabel.hidden = YES;
            if (tableView.editing)
                [header setButtonLabelText:@"DONE"];
            else if (self.lines.count > 0)
                [header setButtonLabelText:@"EDIT"];
            else
                header.button.hidden = YES;
        }

        else {
            header.leftLabel.text = [self.transaction.transactionType isEqualToString:kOutboundTransferType] ? @"TRANSFER" : @"RETURN";
            header.button.hidden = YES;
            header.rightLabel.text = [NSString stringWithFormat:@"Submitted: %@", [self.transaction.sfdcCreatedDate agnFormattedDateString]];
        }
        [header setNeedsDisplay];
        return header;
    }
    else {
        AGNAvailableSampleHeaderCell * header = [tableView dequeueReusableCellWithIdentifier:@"AvailableSampleHeaderCell"];
        return header;
    }
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 33.0;
}

-(void)configureTransferToCell{
    self.transferToCell.selectionStyle=UITableViewCellSelectionStyleNone;
    self.transferToCell.transaction=self.transaction;
    self.transferToCell.transferNumberTextField.exclusiveTouch=YES;
    if([self.transaction isReturn]){
        self.transferToCell.transferToNameLabel.hidden=YES;
        self.transferToCell.transferToLabel.hidden=YES;
        self.transferToCell.toNameTextField.hidden=YES;
        
    }else{
        self.transferToCell.toNameTextField.exclusiveTouch=YES;
        self.transferToCell.toNameTextField.hidden=NO;
        self.transferToCell.toNameTextField.delegate=self;

    }
}

-(int)transferToIndex{
    if ([self.transaction.status isEqualToString:kReceivedStatusType] || [self.transaction.status isEqualToString:kCompleteStatusType])
        return -1;
    if (self.lines.count > 0 || self.shouldDisplayExtraSampleCell) {
        if(self.shouldDisplayExtraSampleCell)
            return self.lines.count+1;
        else
            return self.lines.count;
    }
    else
        return 1;
}


- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    static NSString * sampleCellIdentifier = @"InventoryTransactionLineCell";
    
    if (indexPath.section == 0) {
        if ([self.transaction.status isEqualToString:kReceivedStatusType] || [self.transaction.status isEqualToString:kCompleteStatusType]) {
            if(indexPath.row==0){
                static NSString *summaryIdentifier = @"AGNInventoryTransactionSummaryCell";
                AGNInventoryTransactionSummaryCell * cell = [tableView dequeueReusableCellWithIdentifier:summaryIdentifier ];
                if(!cell){
                    cell = [[AGNInventoryTransactionSummaryCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:summaryIdentifier];
                }
                if([self.transaction isOutboundTransfer]){
                    cell.leftLabel.text = [NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"Transfer to:", @"Closed transfer transfer to label"),[self.transaction toRepDisplayString]];
                    cell.rightLabel.text = [NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"Authorization #:", @"Closed transfer authorization number label"),[self.transaction.transferAuthorizationNumber uppercaseString]];
                }else{
                    cell.leftLabel.text = [NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"Authorization #:", @"Closed return authorization number label "),[self.transaction.transferAuthorizationNumber uppercaseString]];
                    cell.rightLabel.text = @"";
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                return cell;
            }
            else{
                AGNInventoryTransactionLineCell * cell = [tableView dequeueReusableCellWithIdentifier:sampleCellIdentifier];
                if (!cell)
                    cell = [[AGNInventoryTransactionLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:sampleCellIdentifier];
                
                cell.model = [self.lines objectAtIndex:indexPath.row-1];
                cell.editable = NO;
                cell.quantityTextField.indexPath=indexPath;
                if( [indexPath compare:self.lotPickerSelectedCellIndexPath]==NSOrderedSame){
                    //[((AGNCallProductSampleCell *)cell).quantityTextField becomeFirstResponder];
                    self.activeField = ((AGNInventoryTransactionLineCell *)cell).quantityTextField;
                    self.activeField.indexPath=indexPath;
                }
                return cell;
            }
        }
        else {
            if(indexPath.row==[self transferToIndex]){
                self.transferToCell =
                [tableView dequeueReusableCellWithIdentifier:@"TransferToCell" forIndexPath:indexPath];
                [self configureTransferToCell];
                self.transferToCell.transferNumberTextField.indexPath=indexPath;
                self.transferToCell.toNameTextField.indexPath=indexPath;
                return self.transferToCell;
            }
            if (self.lines.count > 0 || self.shouldDisplayExtraSampleCell) {
                AGNInventoryTransactionLineCell * cell = [tableView dequeueReusableCellWithIdentifier:sampleCellIdentifier];
                if (!cell)
                    cell = [[AGNInventoryTransactionLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:sampleCellIdentifier];
                
                cell.editable = YES;
                
                if (indexPath.row < self.lines.count) {
                    AGNSampleInventoryTransactionLine * line = [self.lines objectAtIndex:indexPath.row];
                    cell.model = line;
                }
                else if(self.shouldDisplayExtraSampleCell && indexPath.row == self.lines.count){
                    cell.sku = self.selectedSKU;
                    [self presentLotPickerForIndexPath:indexPath];
                }
                
                return cell;
            }
            else {
                    AGNAvailableSampleCell * cell = [tableView dequeueReusableCellWithIdentifier:@"AvailableSampleCell" forIndexPath:indexPath];
                    cell.label.text = NSLocalizedString(@"Choose a sample from the list below","Transfer screen: Choose a sample from the list below");
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    return cell;
                
            }
        }
    }
    else {
        AGNAvailableSampleCell * cell = [tableView dequeueReusableCellWithIdentifier:@"AvailableSampleCell" forIndexPath:indexPath];
        if (indexPath.row < self.availableSKUs.count) {
            AGNProductSKU * sku = [self.availableSKUs objectAtIndex:indexPath.row];
            cell.label.text = sku.productDescription;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
        else {
            cell.label.text = @"No samples available";
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        
        return cell;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if ([self.transaction.status isEqualToString:kOpenStatusType])
        return 2;
    else
        return 1;
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        if ([self.transaction.status isEqualToString:kReceivedStatusType] || [self.transaction.status isEqualToString:kCompleteStatusType]) {
            return self.lines.count+1; // add a transfer to line
        }
        else {
            if (self.lines.count > 0) {
                NSInteger count = self.lines.count;
                count++;
                if (self.shouldDisplayExtraSampleCell)
                    count++;
                return count;
            }
            else
                return 2;
        }
    }
    else {
        if (self.availableSKUs.count > 0)
            return self.availableSKUs.count;
        else
            return 1;
    }
}


-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [self showTransferToPopover];
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    [self.transferToCell.transferNumberTextField resignFirstResponder];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if(indexPath.section==0 && indexPath.row == [self transferToIndex]){
        //just make them tap the text field
//        if([self.transaction isOutboundTransfer])
//            [self showTransferToPopover];
    }
    else if (indexPath.section == 0 && self.lines.count > 0 && [self.transaction.status isEqualToString:kOpenStatusType]) {
        AGNSampleInventoryTransactionLine * line = [self.lines objectAtIndex:indexPath.row];
        AGNProductSKU * sku = line.product;
        
        self.selectedSKU = sku;
        self.shouldDisplayExtraSampleCell = NO;
        [self presentLotPickerForIndexPath:indexPath];

    }
    else if (indexPath.section == 1 && indexPath.row < self.availableSKUs.count) {
        self.selectedSKU = [self availableSKUs][indexPath.row];
        
        self.shouldDisplayExtraSampleCell = YES;
        [tableView reloadData];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (![self.transaction.status isEqualToString:kOpenStatusType])
        return NO;
    
    if (indexPath.section != 0)
        return NO;
    
    if (indexPath.section ==0 && indexPath.row == [self transferToIndex])
        return NO;
    
    return YES;
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (self.lines.count == 0)
            return UITableViewCellEditingStyleNone;
        else
            return UITableViewCellEditingStyleDelete;
    }
    else
        return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        
        AGNSampleInventoryTransactionLine * lineToDelete = [self.lines objectAtIndex:indexPath.row];
        [self.availableSamples addObject:lineToDelete.sampleInventoryLine];
        [self.lines removeObjectAtIndex:indexPath.row];
        [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:lineToDelete];

        // we're reloading data anyway so not sure there's a point
//        if (indexPath.row > 1) //account for the dummy row with the help text
//            [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
//        
        [self rebuildAvailableSKUs];
        [self updateButton];

    }


    // Adding a delay before calling reload data seems to fix swipe to delete ios7

    double delayInSeconds = .1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));

    // toggle editing off if there are no details or samples
    if (self.lines.count == 0){
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            tableView.editing = NO;
        });
    }

    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self.tableView reloadData];
    });
}

- (IBAction)submit:(id)sender {

    // Change the state
    self.transaction.status = kReceivedStatusType;
    self.transaction.mobileLastUpdateTimestamp = [NSDate date];

    
    [self.transaction.sampleInventoryTransactionLines enumerateObjectsUsingBlock:^(id obj, BOOL *stop) {
        ((AGNSampleInventoryTransactionLine *)obj).isAccepted = [NSNumber numberWithBool:YES];
        ((AGNSampleInventoryTransactionLine *)obj).mobileLastUpdateTimestamp = [NSDate date];
        [self updateSILFromSITL:(AGNSampleInventoryTransactionLine *)obj];
    }];
    
    [[AGNAppDelegate sharedDelegate] saveContext];
    
    [self addManageInventoryUpdateTransactionForSIT:self.transaction];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
}

- (void)addManageInventoryUpdateTransactionForSIT:(AGNSampleInventoryTransaction *)aSIT {    
    NSString *currentJSONRepresentation = [aSIT jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageInventory];
    upTxn.undoJSONRepresentation = self.transaction.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.modelClassName = @"AGNSampleInventoryTransaction";
    upTxn.guid = aSIT.guid;
    upTxn.salesForceId = aSIT.salesForceId;
    upTxn.deleteModelObjectOnRevert = [NSNumber numberWithBool:self.transaction.deleteOnRevert];
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:@[upTxn]]) {
        //TODO: error handling - display alert and refresh UI
        log4Error(@"Failed to save inventory transfer to core data");
    }
}

- (void)updateSILFromSITL:(AGNSampleInventoryTransactionLine *)sitl {
    // If there is a SIL relationship already on the SITL, update the quantity, otherwise
    // search for SIL by product SKU / lot # combination. If there is no existing SIL
    // create a new one. Update quantity based on actual amount in the SITL
    AGNSampleInventoryLine *sil = sitl.sampleInventoryLine;
    if (!sil) {
        log4Error(@"ERROR: there HAS to be a SIL in order to create an outgoing SIT");
    }
    else {
        sil.quantity = [NSNumber numberWithInt:(sil.quantity.intValue - sitl.expectedQuantity.intValue)];
    }
}

- (void)quantitySelected {
    [self updateButton];
}

-(void)transferToSelected{
    if(self.transferToPopover){
        [self.transferToPopover dismissPopoverAnimated:YES];
        self.transferToPopover = nil;
    }
    [self updateButton];
}


//------------------------------------------------------------------------------
// MARK: - Transfer To Popover
//------------------------------------------------------------------------------

-(void) showTransferToPopover {
    
    self.transferToPopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self.transferToCell andTitle:NSLocalizedString(@"Transfer To", @"Transfer To Popover Title")];
    
    self.transferToPopover.includeSearchBar=YES;
    self.transferToPopover.searchBarDelegate=self.transferToCell;
    self.transferToCell.popover=self.transferToPopover;
    [self.transferToCell.filteredReps removeAllObjects];
    [self.transferToCell.filteredReps addObjectsFromArray:[[AGNDataManager defaultInstance] getRepsValidForOutboundTransfer]];
    [AGNEligibilityHelper filterTransferEligibleReps:self.transferToCell.filteredReps];
    self.transferToPopover.objectArray = self.transferToCell.filteredReps;
    
    __weak AGNTransferViewController * _self = self;
    self.transferToPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        static NSString *CellIdentifier = @"CellIdentifier";
        
        AGNSingleLineCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        AGNSalesRep *rep = (AGNSalesRep *)_self.transferToCell.filteredReps[indexPath.row];
        cell.mainLabel.text = [rep formattedName];
        return cell;
    };
    
    CGRect rect = self.transferToCell.frame;
    rect = [self.view convertRect:rect fromView:self.transferToCell.superview];
    [self.transferToCell.transferNumberTextField resignFirstResponder];

    [self.transferToCell.toNameTextField resignFirstResponder];

    [self.transferToPopover presentPopoverFromRect:rect
                                  inView:self.view
                permittedArrowDirections:UIPopoverArrowDirectionAny
                                animated:YES];


    [self.transferToPopover.searchBar performSelector:@selector(becomeFirstResponder) withObject:nil afterDelay:.1];
}



//------------------------------------------------------------------------------
// MARK: - scroll above keyboard
//------------------------------------------------------------------------------

-(void)cellBeganEditing:(NSNotification *)notification{
    UITextField *textField=((UITextField *)notification.object);
    self.activeField=textField;
    self.activeField.indexPath=textField.indexPath;
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    
    UITableViewCell *cell = (UITableViewCell *)[self.tableView cellForRowAtIndexPath:self.activeField.indexPath];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    if(!indexPath)
        return;
    
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
    }
    else {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
    }
    
    
    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardHeight-kHeight, 0.0);
    self.tableView.contentInset = contentInsets;
    self.tableView.scrollIndicatorInsets = contentInsets;
    
    
    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.tableView.frame;
    aRect.size.height -= (keyboardHeight+kHeight);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        self.returnToIndexPath=[self firstVisibleRow];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

-(NSIndexPath *)firstVisibleRow{
    NSArray* indexPaths = [self.tableView indexPathsForVisibleRows];
    NSArray* sortedIndexPaths = [indexPaths sortedArrayUsingSelector:@selector(compare:)];
    return (NSIndexPath*)[sortedIndexPaths objectAtIndex:0];
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    // for some reason getting a UIKeyboardDidHideNotification on rotation even though the keyboard stays up
    // so hold on to the previous active field.
    //self.activeField = nil;
    
    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:[animationTime doubleValue] animations:^{
        UIEdgeInsets contentInsets = UIEdgeInsetsZero;
        self.tableView.contentInset = contentInsets;
        self.tableView.scrollIndicatorInsets = contentInsets;
    }];
    if(self.returnToIndexPath){
        [self.tableView scrollToRowAtIndexPath:self.returnToIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
        self.returnToIndexPath=nil;
    }
    
}

@end
