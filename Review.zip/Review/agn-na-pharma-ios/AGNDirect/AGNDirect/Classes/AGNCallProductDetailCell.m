//
//  AGNCallProductDetailCell.m
//  AGNDirect
//
//  Created by Mark Wells on 8/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNCallProductDetailCell.h"
#import "NSDate+AGNDate.h"

@interface AGNCallProductDetailCell()

@property NSLayoutConstraint *errorLabelContraint;

@end

@implementation AGNCallProductDetailCell
@synthesize label=_label;
@synthesize errorLabel=_errorLabel;
@synthesize model=_model;
@synthesize errorLabelContraint=_errorLabelContraint;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.label = [[UILabel alloc] init];
        self.label.font = [UIFont AGNAvenirHeavy14];
        self.label.textColor = [UIColor AGNGreyMatter];
        self.label.backgroundColor = [UIColor clearColor];
        self.label.highlightedTextColor = [UIColor whiteColor];
        [self.label setTranslatesAutoresizingMaskIntoConstraints:NO];

        self.errorLabel = [[UILabel alloc] init];
        self.errorLabel.font = [UIFont AGNAvenirHeavy14];
        self.errorLabel.textColor = [UIColor AGNGreyMatter];
        self.errorLabel.backgroundColor = [UIColor clearColor];
        self.errorLabel.highlightedTextColor = [UIColor whiteColor];
        [self.errorLabel setTranslatesAutoresizingMaskIntoConstraints:NO];


        [self.contentView addSubview:self.errorLabel];
        [self.contentView addSubview:self.label];
        NSDictionary *constraintsViewsDictionary = @{ @"label" : self.label, @"errorLabel": self.errorLabel };
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-22-[label]-(>=8)-[errorLabel]-22-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.label attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
         [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.errorLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.model = nil;
    self.label.text = nil;
    self.errorLabel.text = nil;

    self.editing = NO;
    [self setDefaultColors];
}

-(void)setDefaultColors{
    self.contentView.backgroundColor = [UIColor clearColor];
    self.label.textColor = [UIColor AGNGreyMatter];
    self.label.backgroundColor = [UIColor clearColor];
    self.label.highlightedTextColor = [UIColor whiteColor];
    self.errorLabel.textColor = [UIColor AGNGreyMatter];
    self.errorLabel.backgroundColor = [UIColor clearColor];
    self.errorLabel.highlightedTextColor = [UIColor whiteColor];
}



- (void)setModel:(AGNCallDetail *)model {
    _model = model;
    if (model == nil) {
        return;
    }
   [self updateValidationState];
}

- (void)updateValidationState {

    NSDate *callDate = [self.model.call projectedCloseDate];
    if([self.model.call isClosed] || [self.model isValidForDate:callDate]){
        [self setDefaultColors];
        self.errorLabel.text = @"";
        return;
    }

    NSString *message = @"";
    if(!self.model.detailPosition)
        message = NSLocalizedString(@"MISSING PRODUCT", @"Validation message for null detail position");

    if([self.model.detailPosition.effectiveDate compare:callDate]==NSOrderedDescending){
        message = [NSString stringWithFormat:@"EFFECTIVE %@",[self.model.detailPosition.effectiveDate agnFormattedDateString ]];
    }

    if([callDate compare:self.model.detailPosition.endDate]==NSOrderedDescending){
        message = [NSString stringWithFormat:@"EXPIRED %@",[self.model.detailPosition.endDate agnFormattedDateString ]];
    }

    self.contentView.backgroundColor = [UIColor redColor];
    self.label.textColor = [UIColor whiteColor];
    self.label.backgroundColor = [UIColor redColor];
    self.label.highlightedTextColor = [UIColor whiteColor];
    self.errorLabel.textColor = [UIColor whiteColor];
    self.errorLabel.backgroundColor = [UIColor redColor];
    self.errorLabel.highlightedTextColor = [UIColor whiteColor];
    self.errorLabel.text = message;

    if(!self.errorLabelContraint){
        self.errorLabelContraint = [NSLayoutConstraint constraintWithItem:self.errorLabel attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeWidth multiplier:.4 constant:0];

        [self.contentView addConstraint:self.errorLabelContraint];
//        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.errorLabel attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeWidth multiplier:.4 constant:0]];
    }


}

@end
