//
//  AGNGreyButton.m
//  AGNDirect
//
//  Created by Adam McLain on 10/1/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNGreyButton.h"

@implementation AGNGreyButton

- (id)init {
    if ((self = [super init])) {
        [self styleButton];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self styleButton];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self styleButton];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.  - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)styleButton {
    UIImage *defalut = [[UIImage imageNamed:@"btn-grey"] resizableImageWithCapInsets:UIEdgeInsetsMake(2.0f, 2.0f, 4.0f, 2.0f)];
    UIImage *highlighted = [[UIImage imageNamed:@"btn-grey-hi"] resizableImageWithCapInsets:UIEdgeInsetsMake(1.0f, 2.0f, 4.0f, 2.0f)];
    [self setBackgroundImage:defalut forState:UIControlStateNormal];
    [self setBackgroundImage:highlighted forState:UIControlStateHighlighted];
}

@end
