//
//  AGNScheduleCell.m
//  AGNDirect
//
//  Created by Adam McLain on 8/28/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNScheduleCell.h"

@implementation AGNScheduleCell

@end
