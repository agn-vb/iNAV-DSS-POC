//
//  UITableView+AGNTableView.m
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "UITableView+AGNTableView.h"
#import "AGNCategoryHeaders.h"

@implementation UITableView (AGNTableView)

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self AGNStyleTableView];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    self = [super initWithFrame:frame style:style];
    if (self) {
        [self AGNStyleTableView];
    }
    
    return self;
}

- (void)AGNStyleTableView {
    
}

@end
