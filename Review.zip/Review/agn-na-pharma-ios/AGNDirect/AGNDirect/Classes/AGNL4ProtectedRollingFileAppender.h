//
//  L4ProtectedFileAppender.h
//  Log4CocoaDebug
//
//  Created by Rebecca Gutterman on 8/9/12.
//  Copyright (c) 2012 Rebecca Gutterman. All rights reserved.
//

#import "L4RollingFileAppender.h"

/** http://developer.apple.com/library/ios/DOCUMENTATION/iPhone/Conceptual/iPhoneOSProgrammingGuide/AdvancedAppTricks/AdvancedAppTricks.html#//apple_ref/doc/uid/TP40007072-CH7-SW11

**/

@interface AGNL4ProtectedRollingFileAppender : L4RollingFileAppender

@end
