//
//  AGNHCPDetailViewController.m
//  AGNDirect
//
//  Created by Paul Gambill on 8/10/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  THIS BECOMES THE RIGHT PANE WHEN AN HCP IS SELECTED

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//

#import "AGNHCPDetailViewController.h"
#import "AGNCallDetailViewController.h"
#import "AGNCategoryHeaders.h"
#import "AGNDataManager.h"
#import "AGNCallHistoryCell.h"
#import "AGNContactCell.h"
#import "AGNSingleLineCell.h"
#import "AGNTableViewHeader.h"
#import "AGNScheduleViewController.h"
#import "AGNCategoryHeaders.h"
#import "AGNHCPContactEditViewController.h"
#import "AGNAddressAvailabilityCell.h"
#import "AGNHCPRatingCell.h"
#import "AGNAppDelegate.h"
#import "AGNTransientRatingFrequencyContainer.h"
#import "AGNCallHistoryViewController.h"
#import "AGNHCPFilterViewController.h"
#import "AGNEditAddressCell.h"
#import "AGNFormDetailViewController.h"
#import "AGNRequestFormCell.h"
#import "AGNReprintDetailViewController.h"

#define kAGNNumExtraFieldsInAddressSection 3

static NSString *kCellIdentifier = @"Cell";
static NSString *kClosedCallCellIdentifier = @"AGNClosedCallCell";
static NSString *kContactCellIdentifier = @"ContactCell";
static NSString *kAddressCellIdentifier = @"AddressCodeCell";
static NSString *kAddressAvailabilityCellIdentifier = @"AddressAvailabilityCell";
static NSString *kRatingCellIdentifier = @"RatingCell";

@interface AGNHCPDetailViewController ()

@property (nonatomic, strong) NSArray *contactData;
@property (nonatomic, strong) NSArray *callHistoryData;
@property (nonatomic, strong) NSArray *plannedCalls;
@property (nonatomic, strong) NSDictionary *ratings;
@property (strong, nonatomic) IBOutlet UILabel *doctorNameAndTitleLabel;
@property (nonatomic, weak) UIButton * openDraftButton; // Temporary pointer to Open Draft button while the popover is open
@property (nonatomic, strong) AGNSimplePopoverTableViewController *openDraftPopover;
@property (strong, nonatomic) NSArray *visibleAddresses;
@property (strong, nonatomic) NSArray *ratingKeys;
@property (weak, nonatomic) AGNAddress *selectedAddress;
@property (assign, nonatomic) BOOL isEditingHCP;
@property (assign, nonatomic) BOOL isEditingDraftCalls;
@property (strong, nonatomic) NSString * salesForceId;
@property (strong, nonatomic) NSArray * myPlannedCalls;
@property (nonatomic, assign) BOOL canOpenDrafts;
@property (nonatomic, strong) NSArray *formsData;
@property (weak, nonatomic) IBOutlet UIToolbar *toolbar;

@end

@implementation AGNHCPDetailViewController

@synthesize contactData;
@synthesize callHistoryData;
@synthesize plannedCalls;
@synthesize doctorNameAndTitleLabel;
@synthesize openDraftPopover;
@synthesize visibleAddresses;
@synthesize selectedAddress=_selectedAddress;
@synthesize myPlannedCalls=_myPlannedCalls;
@synthesize formsData;
@synthesize toolbar;

enum Sections {
    ContactSection = 0,
    AddressSection ,
    DraftCallsSection,
    CallHistorySection,
    MandatorySections
};

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.toolbar setBackgroundImage:[UIImage imageNamed:@"bar-bigblue"] forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsDefault];
    __weak AGNHCPDetailViewController * _self = self;
    
    self.menu.moreLabel = @"FORMS";
    self.menu.moreTitle = @"Create Form";
    self.menu.showFormsButtonBlock=^{
        // only need the "FORMS" button if we are showing everything
        if ([AGNAppDelegate sharedDelegate].canCreateCalls && [AGNAppDelegate sharedDelegate].canCreateForms && [AGNAppDelegate sharedDelegate].canCreateReprints)
            return YES;
        return NO;
    };
    self.menu.numberButtonsBlock =^{
       // fold up reprints & forms into one forms button if we have everything.
        if ([AGNAppDelegate sharedDelegate].canCreateCalls && [AGNAppDelegate sharedDelegate].canCreateForms && [AGNAppDelegate sharedDelegate].canCreateReprints)
            return 2;
        // in all other cases forms add two buttons and reprints / calls add one
        int numActions = 0;
        if([AGNAppDelegate sharedDelegate].canCreateCalls)
            numActions++;
        if([AGNAppDelegate sharedDelegate].canCreateReprints)
            numActions++;
        if([AGNAppDelegate sharedDelegate].canCreateForms)
            numActions+=2;

        return numActions;
    };

    [self.menu addItemWithLabel:^{
                    if(_self.myPlannedCalls.count>0)
                        return @"CALLS";
                    else
                        return @"CREATE CALL";
                        }
                          title:^{return @"Open Call";}
                        visible:^{
                            return [AGNAppDelegate sharedDelegate].canCreateCalls;
                        }
                        enabled: ^{
                            return YES;
                        }
                         action:^(UIButton* button) {
                             [_self openDraft:button];
                         }
                        displayUnderForms:NO
                        ];

    
    [self.menu addItemWithLabel:^{return @"MIR";}
                          title:^{return @"Create Medical Information Request";}
                        visible:^{
                            return [AGNAppDelegate sharedDelegate].canCreateForms;
                        }
                        enabled: NULL
                         action:^(UIButton* button){
                             [_self createForm:kAGNRequestFormTypeMIR];
                         }
                        displayUnderForms:YES
                        ];

    [self.menu addItemWithLabel:^{return @"ODR";}
                          title:^{return @"Create On Demand Request";}
                            visible:^{
                                return [AGNAppDelegate sharedDelegate].canCreateForms;
                            }
                        enabled: NULL
                         action:^(UIButton* button){
                             [_self createForm:kAGNRequestFormTypeODR];
                         }
                        displayUnderForms:YES
                        ];

    [self.menu addItemWithLabel:^{return @"REPRINTS";}
      title:^{return @"Create Marketing Collateral";}
    visible:^{
        return [AGNAppDelegate sharedDelegate].canCreateReprints;
    }
    enabled: NULL
     action:^(UIButton* button){
         [_self createReprint];
     }
     displayUnderForms:YES
     ];

    [self.menu addItemWithLabel:^{return @"HCPProfile";}
                          title:^{return @"View HCP Profile";}
                        visible:^{
                            return YES;
                        }
                        enabled: NULL
                         action:^(UIButton* button){
                             [_self openBrowser];
                         }
              displayUnderForms:YES
     ];
    
    [self.tableView registerClass:[AGNAddressCell class] forCellReuseIdentifier:kAddressCellIdentifier];
    [self.tableView registerClass:[AGNAddressAvailabilityCell class] forCellReuseIdentifier:kAddressAvailabilityCellIdentifier];
    self.openDraftPopover=nil;
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.allowsMultipleSelection = NO;
}

- (void)reloadContent {
        
    AGNAccount *refreshedObject = nil;
    // don't need guid since we don't create accounts
    if (self.salesForceId)
        refreshedObject = (AGNAccount *)[[AGNDataManager defaultInstance] undeletedObjectOfType:@"AGNAccount" forId:self.salesForceId];
    
    if (!refreshedObject)
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNCallHistorySelectedKey object:nil];
    
    else
        [self setAccount:refreshedObject];
    
    // Also, refresh the menu, just in case our sync changed permissions
    [self.menu setNeedsLayout];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if(self.account)
        [self setAccount:self.account];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleUpdateTransactionRevert:)
                                                 name:AGNUpdateTransactionRevertedNotificationKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleUpdateTransactionSuccessful:)
                                                 name:AGNUpdateTransactionSuccessfulNotificationKey
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(addressModified:)
                                                 name:AGNAddressModifiedNotificationKey
                                               object:nil];

    [self reloadContent];
    
    
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateTransactionRevertedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateTransactionSuccessfulNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNAddressModifiedNotificationKey object:nil];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)setAccount:(AGNAccount *)account
{
    if (_account != account) {
        self.selectedAddress = nil;
    }

    log4Info(@"Opening HCP %@",[account description]);
    // unfortunately, this optimization is having the effect of not refreshing the calls list
    // AL-887

//    if (account == _account) {
//        return;
//    }
    
    _account = account;
    self.salesForceId=account.salesForceId;
    //chosen account has changed, must reload table data
    self.isEditingHCP=NO;
    self.doctorNameAndTitleLabel.attributedText = [self doctorNameAndTitleFormatted];
    [self loadClosedCalls];
    AGNSalesRep *currentUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
    NSString *mySalesTeam = currentUser.salesTeamName;
    self.ratings = [account ratingsToDisplay];
    NSArray * keys = [self.ratings allKeys];
    // put our sales team at the top
    self.ratingKeys =  [keys sortedArrayUsingComparator: ^(NSString *obj1, NSString *obj2) {

        if ([obj1 isEqualToString:mySalesTeam]) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        
        if ([obj2 isEqualToString:mySalesTeam]) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        return (NSComparisonResult)NSOrderedSame;
    }];
    
    
    [self setupAddresses];
    [self loadForms];
    [self selectAddress];
    
}

-(void)selectAddress{
    if(self.selectedAddress){
        [self updateToSelectedAddress:self.selectedAddress];
        [self.tableView selectRowAtIndexPath:[self indexPathOfSelectedAccount] animated:NO scrollPosition:UITableViewScrollPositionNone];
    }
    else
        [self selectPrimaryAddress];

}

-(void)selectPrimaryAddress{
    if([self.visibleAddresses count]>0){
        [self updateToSelectedAddress:self.visibleAddresses[0]];
    }else{
        [self updateToSelectedAddress:nil];
    }
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:AddressSection];
    [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];

}

-(void)setupAddresses{
    NSArray *sortDescriptors = [NSArray arrayWithObjects:[NSSortDescriptor sortDescriptorWithKey:@"primary" ascending:NO],[NSSortDescriptor sortDescriptorWithKey:@"salesForceId" ascending:NO], nil];
//    self.visibleAddresses =  [[self.account visibleAddresses] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"primary" ascending:NO]]];
    self.visibleAddresses =  [[self.account visibleAddresses] sortedArrayUsingDescriptors:sortDescriptors];
//    if([self.visibleAddresses count]>0){
//        [self updateToSelectedAddress:self.visibleAddresses[0]];
//    }
}

-(BOOL)shouldShowOnlyMyClosedCalls{
    NSNumber *valueOfKey = (NSNumber *) [[AGNAppDelegate sharedDelegate] configSettingForKey:AGNFilterToMyClosedCalls];
    if(valueOfKey && [valueOfKey boolValue])
        return YES;
    return NO;
}

-(void)setShowOnlyMyClosedCalls:(BOOL)val{
    [[AGNAppDelegate sharedDelegate] setConfigSetting:[NSNumber numberWithBool:val] forKey:AGNFilterToMyClosedCalls];
}

-(BOOL)shouldShowOnlyMyPlannedCalls{
    NSNumber *valueOfKey = (NSNumber *) [[AGNAppDelegate sharedDelegate] configSettingForKey:AGNFilterToMyPlannedCalls];
    if(valueOfKey && [valueOfKey boolValue])
        return YES;
    return NO;
}

-(void)setShowOnlyMyPlannedCalls:(BOOL)val{
    [[AGNAppDelegate sharedDelegate] setConfigSetting:[NSNumber numberWithBool:val] forKey:AGNFilterToMyPlannedCalls];
}

-(BOOL)shouldShowOnlyMyForms{
    NSNumber *valueOfKey = (NSNumber *) [[AGNAppDelegate sharedDelegate] configSettingForKey:AGNFilterToMyForms];
    if(valueOfKey && [valueOfKey boolValue])
        return YES;
    return NO;
}

-(void)setShowOnlyMyForms:(BOOL)val{
    [[AGNAppDelegate sharedDelegate] setConfigSetting:[NSNumber numberWithBool:val] forKey:AGNFilterToMyForms];
}

-(void)loadPlannedCalls{
    BOOL restrictToMe = [self shouldShowOnlyMyPlannedCalls];
    if(self.selectedAddress && !([self.selectedAddress.primary boolValue])){
        self.plannedCalls = [[AGNDataManager defaultInstance] getPlannedCallsForHCP:self.account andAddress:self.selectedAddress restrictToCurrentUser:restrictToMe];
        self.myPlannedCalls = [[AGNDataManager defaultInstance] getPlannedCallsForHCP:self.account andAddress:self.selectedAddress restrictToCurrentUser:YES];

    }
    else{
        self.plannedCalls = [[AGNDataManager defaultInstance] getPlannedCallsForHCP:self.account restrictToCurrentUser:restrictToMe];
        self.myPlannedCalls = [[AGNDataManager defaultInstance] getPlannedCallsForHCP:self.account restrictToCurrentUser:YES];
    }
    
}

-(void)loadClosedCalls{
    BOOL restrictToMe = [self shouldShowOnlyMyClosedCalls];
    if(self.selectedAddress && !([self.selectedAddress.primary boolValue]))
        self.callHistoryData = [[AGNDataManager defaultInstance] getClosedCallsForHCP:self.account andAddress:self.selectedAddress restrictToCurrentUser:restrictToMe];
    else
        self.callHistoryData = [[AGNDataManager defaultInstance] getClosedCallsForHCP:self.account restrictToCurrentUser:restrictToMe];
}

-(void)loadForms{
    BOOL restrictToMe = [self shouldShowOnlyMyForms];
    NSArray * forms = [[AGNDataManager defaultInstance] getFormsForHCP:self.account restrictToCurrentUser:restrictToMe];
    NSArray * reprints = [[AGNDataManager defaultInstance] getMCDForHCP:self.account restrictToCurrentUser:restrictToMe];
    NSMutableArray * combinedForms = [[NSMutableArray alloc]init];
    [combinedForms addObjectsFromArray:reprints];
    [combinedForms addObjectsFromArray:forms];
    self.formsData = [combinedForms sortedArrayUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"startDate" ascending:NO]]];
}

- (void)setOpenDraftButtonEnablement {
    if ([self.myPlannedCalls count]>0) {
        self.canOpenDrafts = YES;
    }
    else {
        self.canOpenDrafts = NO;
    }
    [self.menu setNeedsLayout];    
}

- (NSAttributedString *)doctorNameAndTitleFormatted
{
    UIFont *boldFont = [UIFont AGNAvenirBlack21];
    UIFont *lightFont = [UIFont AGNAvenirRomanFontWithSize:21.0f];
    
    NSShadow *shadow = [[NSShadow alloc] init];
    shadow.shadowColor = [UIColor blackColor];
    shadow.shadowOffset = CGSizeMake(0.0f, 1.0f);
    
    NSDictionary *boldAttributes = @{ NSFontAttributeName : boldFont, NSForegroundColorAttributeName : [UIColor whiteColor], NSShadowAttributeName : shadow };
    NSDictionary *normalAttributes = @{ NSFontAttributeName : lightFont, NSForegroundColorAttributeName : [UIColor whiteColor], NSShadowAttributeName : shadow };
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] initWithString:[self.account formattedName] attributes:boldAttributes];
    if (self.account.professionalDesignation.length > 0) {
        NSString *profession = [NSString stringWithFormat:@" - %@", self.account.professionalDesignation];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:profession attributes:normalAttributes]];
    }
    
    return formattedString; //[NSString stringWithFormat:@"%@, %@ (%@)", [self.account.lastName uppercaseString], [self.account.firstName uppercaseString], self.account.professionalDesignation];
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    int totalSections = MandatorySections;
    if(self.formsData.count>0)
        totalSections++;
    if([self.ratings allKeys].count>0)
        totalSections++;
    return totalSections;
}

-(int)formsSection{
    if(self.formsData.count>0)
        return MandatorySections;
    return -1;
}

-(int)ratingsSection{
    if([self.ratings allKeys].count==0)
        return -1;
    if([self formsSection]<0)
        return MandatorySections;
    return [self formsSection]+1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section ==[self ratingsSection]){
        return [[self.ratings allKeys] count];
    }
    //Contact
    if (section == AddressSection) {
        return [self.visibleAddresses count];
    }
    
    if( section == ContactSection){
        return 3;
    }
    
    //Call History
    if (section == CallHistorySection){
        return self.callHistoryData.count>0?self.callHistoryData.count:1;
    }
    
    //Planned Calls
    if(section == DraftCallsSection){
        return self.plannedCalls.count>0?self.plannedCalls.count:1;
    }
    
    // RequestForms
    if (section==[self formsSection]) {
        return self.formsData.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AGNSalesRep *currentUser = [[AGNAppDelegate sharedDelegate] loggedInSalesRep];

    if(indexPath.section ==[self ratingsSection]){
     
        AGNHCPRatingCell *cell = [tableView dequeueReusableCellWithIdentifier:kRatingCellIdentifier];
        if (cell == nil) {
            cell = [[AGNHCPRatingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kRatingCellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.accessoryType=UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        
        NSString *ratingKey = self.ratingKeys[indexPath.row];
        
        AGNTransientRatingFrequencyContainer *rf = self.ratings[ratingKey];
        cell.frequencyLabel.text=rf.frequency;
        cell.ratingLabel.text=rf.rating;
        cell.salesTeamLabel.text=ratingKey;
        
        if([ratingKey isEqualToString:currentUser.salesTeamName])
            [cell setPrimarySalesTeam:YES];
        else
            [cell setPrimarySalesTeam:NO];
        return cell;
        
    }
    //Contact
    if (indexPath.section == AddressSection)
    {
        AGNAddressCell *cell = UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ?
            [tableView dequeueReusableCellWithIdentifier:kAddressAvailabilityCellIdentifier] :
            [tableView dequeueReusableCellWithIdentifier:kAddressCellIdentifier];
        cell.address = self.visibleAddresses[indexPath.row ];
        return cell; //AGNAddressCell
    }
    if(indexPath.section == ContactSection){

        AGNContactCell *cell = [tableView dequeueReusableCellWithIdentifier:kContactCellIdentifier];
        if (cell == nil) {
            cell = [[AGNContactCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kContactCellIdentifier];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

//        cell.selectedBackgroundView = [self backgroundSelectedView];
        cell.contactDetailLabel.text = @"";
        
        cell.contactCategoryLabel.textColor = [UIColor AGNSecondGrayd];
        cell.contactDetailLabel.textColor = [UIColor AGNGreyMatter];
        if (indexPath.row == 0) {
            cell.contactCategoryLabel.text = [NSLocalizedString(@"PHONE", @"Phone contact category") uppercaseString];
            if ([self phoneNumbersAsString] > 0 ) {
                cell.contactDetailLabel.attributedText = [self phoneNumbersAsString];
            }
        }
        
        if (indexPath.row == 1) {
            cell.contactCategoryLabel.text = [NSLocalizedString(@"EMAIL", @"Email contact category") uppercaseString];
        cell.contactDetailLabel.text = [self emailsAsString];
        }
        
        if (indexPath.row == 2) {
            cell.contactCategoryLabel.text = [NSLocalizedString(@"OFFICE STAFF", @"Office staff contact category") uppercaseString];
            
            if ([self.account liveContacts].count > 0 ) {
                cell.contactDetailLabel.attributedText = [self contactsAsAttributedString];
            } else {
                cell.contactDetailLabel.text = NSLocalizedString(@"No employees on file", @"No employees on file placeholder text");
            }
        }
        
    
        return cell; //AGNContactCell
    }
    
    //Forms
    if (indexPath.section==[self formsSection]) {
        if (self.formsData.count == 0) {
            AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier];
            if (cell == nil) {
                cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier];
            }
            cell.mainLabel.text=AGNPlaceholderText;
            
            return cell;

        }
        else {
            AGNCallHistoryCell *cell = [tableView dequeueReusableCellWithIdentifier:kClosedCallCellIdentifier];
            if (cell == nil) {
                cell = [[AGNCallHistoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kClosedCallCellIdentifier];
            }
            
            
            AGNHCPActivity * activity = self.formsData[indexPath.row];
            cell.mainLabel.text = [activity formattedDateAndRepName];
            cell.secondaryLabel.attributedText = [activity hcpDetailDescription];
            if(activity.salesRep == currentUser){
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.selectionStyle = UITableViewCellSelectionStyleGray;
            }
            else{
                cell.accessoryType = UITableViewCellAccessoryNone;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
            }

            // TODO: delete the code below, AGNRequestFormCell, and respective prototype cell in the storyboard IF we don't revert to using a separate cell class
            /*
            
            // Make sure the colors are right
            cell.dateLabel.textColor = [UIColor AGNGreyMatter];
            cell.dateLabel.highlightedTextColor = [UIColor whiteColor];
            cell.salesRepNameLabel.textColor = [UIColor AGNGreyMatter];
            cell.salesRepNameLabel.highlightedTextColor = [UIColor whiteColor];
            
            cell.statusLabel.textColor = [UIColor AGNSecondGrayd];
            cell.statusLabel.highlightedTextColor = [UIColor AGNSilberLining];
            
            [cell agnSetStyledSelectedBackground];
            
            AGNRequestForm * form = self.formsData[indexPath.row];
            if (form.salesRep == currentUser) {
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.selectionStyle = UITableViewCellSelectionStyleGray;
            }
            else {
                cell.accessoryType = UITableViewCellAccessoryNone;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;                
            }
                        
            if (form.startDate) {
                cell.dateLabel.text = [form.startDate agnFormattedDateString];
            }
            else
                cell.dateLabel.text = @"";
            
            if (form.salesRep)
                cell.salesRepNameLabel.text = form.salesRep.formattedName;
            else
                cell.salesRepNameLabel.text = @"UNKNOWN";
            cell.statusLabel.attributedText = [form formattedTypeAndStatus];
             */
            return cell;
        }
    }
    
    // Call History
    if (indexPath.section == CallHistorySection ) {
        AGNCallHistoryCell *cell = [tableView dequeueReusableCellWithIdentifier:kClosedCallCellIdentifier];
        if (cell == nil) {
        
            cell = [[AGNCallHistoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kClosedCallCellIdentifier];
        }
        
        if(self.callHistoryData.count ==0){
            cell.mainLabel.text=AGNPlaceholderText;
            cell.accessoryType=UITableViewCellAccessoryNone;
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.secondaryLabel.text=@"";
        }else{
            AGNCall *call = self.callHistoryData[indexPath.row];
            
            cell.mainLabel.text = [call formattedDateAndRepName];
            cell.secondaryLabel.attributedText = call.formattedSampleAndDetail;
            if(call.salesRep == currentUser){
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.selectionStyle = UITableViewCellSelectionStyleGray;
            }
            else{
                cell.accessoryType = UITableViewCellAccessoryNone;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;

            }
        }
        
        return cell;
        
    }
    
    //Planned Calls
    AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier];
    if (cell == nil) {
        cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier];
    }
    
    
    if(self.plannedCalls.count ==0){
        cell.mainLabel.text=AGNPlaceholderText;
        cell.accessoryType=UITableViewCellAccessoryNone;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }else{
        AGNCall * call = self.plannedCalls[indexPath.row];
        cell.mainLabel.text = [call formattedDateAndRepName];
        if (call.salesRep == currentUser) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;

        }
        else {
            cell.accessoryType = UITableViewCellAccessoryNone;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }
    return cell;

}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Delegate
//------------------------------------------------------------------------------

-(void)updateToSelectedAddress:(AGNAddress *)selected{
    log4Info(@"Selected address %@",selected);
    self.selectedAddress = selected;
    [self loadClosedCalls];
    [self loadPlannedCalls];
    [self.tableView reloadData];
    [self setOpenDraftButtonEnablement];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    int row = indexPath.row;
    
    // Address
    if (indexPath.section == AddressSection && row < [self.visibleAddresses count]) {
        if (self.visibleAddresses.count == 0) {
            return;
        }
        if ([indexPath compare:[self indexPathOfSelectedAccount]] != NSOrderedSame) {
            [self.tableView deselectRowAtIndexPath:[self indexPathOfSelectedAccount] animated:NO];
            [self updateToSelectedAddress:self.visibleAddresses[row]];
            [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
        return;
    }

    // Only deselect now, as we don't want to deselect address cells
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    AGNSalesRep *currentUser = [[AGNAppDelegate sharedDelegate] loggedInSalesRep];
    
    // Call History
    if (indexPath.section == CallHistorySection && [self.callHistoryData count] > 0) {
        AGNCall *call = self.callHistoryData[row];
        
        // if rep's call
        if (call.salesRep == currentUser)
            [self navigateToCall:call];
        
        return;
    }
    
    // Planned Calls
    if (indexPath.section == DraftCallsSection && [self.plannedCalls count] > 0) {
        AGNCall *call = self.plannedCalls[row];
      
        if (call.salesRep == currentUser)
            [self navigateToCall:call];
        
        return;
    }
    
    // Forms
    if (indexPath.section == [self formsSection] && [self.formsData count] > 0) {
        AGNHCPActivity * activity = self.formsData[row];

        
        if (activity.salesRep == currentUser){
            if([activity isKindOfClass:[AGNRequestForm class]])
                [self navigateToForm:(AGNRequestForm *)activity];
            else if([activity isKindOfClass:[AGNMarketingDisbursement class]])
                [self navigateToMCD:(AGNMarketingDisbursement *)activity];

        }
        
    }
    

}


- (NSIndexPath *)tableView:(UITableView *)tableView willDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([indexPath isEqual:[self indexPathOfSelectedAccount]]) {
        return nil;
    }
    return indexPath;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == AddressSection) {
        int fullHeight = UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ? kAddressAvailabilityCellHeight : kAddressCellHeight;
        AGNAddress *addr = self.visibleAddresses[indexPath.row];
        return fullHeight - ([addr numberOfLinesMissingInMultiLineFormattedString] * kAddressCellLineHeight);
    }
    if(indexPath.section ==ContactSection){
        if (indexPath.row == 0 && [self phoneNumbersAsString].length > 0) {
            return  [AGNContactCell heightForAttributedString:[self phoneNumbersAsString] withWidth:self.view.frame.size.width];
        }
        if (indexPath.row == 1   && [self emailsAsString].length > 0) {
            return  [AGNContactCell heightForString:[self emailsAsString] withWidth:self.view.frame.size.width];
        }
        if (indexPath.row == 2  && [self.account liveContacts].count > 0) {
            return [AGNContactCell heightForAttributedString:[self contactsAsAttributedString] withWidth:self.view.frame.size.width];
        }
        return 56.0f;
    }
    
    if (indexPath.section == CallHistorySection && self.callHistoryData.count > 0) {
        AGNCall *call = self.callHistoryData[indexPath.row];
        return [AGNCallHistoryCell heightForAttributedString:call.formattedSampleAndDetail withWidth:self.view.frame.size.width];
    }
    if (indexPath.section ==[self formsSection] ) {
        return self.formsData.count > 0 ? 60.0f : 37.0F;

    }
    else {
        return 37.0f;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if(section==[self ratingsSection] && ([[self.ratings allKeys] count]==0)) // easier than redo-ing the logic to reduce # of sections
        return 0.0f;
    return 28.0f;
}

-(void)flipClosedCallFilterState{
    NSIndexPath * selectedIndexPath = [self indexPathOfSelectedAccount];
    BOOL onlyMyClosedCalls = [self shouldShowOnlyMyClosedCalls];
    [self setShowOnlyMyClosedCalls:!onlyMyClosedCalls];
    [self loadClosedCalls];
    [self.tableView reloadData];
    [self.tableView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
}

-(void)flipFormsFilterState{
    NSIndexPath * selectedIndexPath = [self indexPathOfSelectedAccount];
    BOOL onlyMyForms = [self shouldShowOnlyMyForms];
    [self setShowOnlyMyForms:!onlyMyForms];
    [self loadForms];
    [self.tableView reloadData];
    [self.tableView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    
}


-(void)flipPlannedCallFilterState{
    NSIndexPath * selectedIndexPath = [self indexPathOfSelectedAccount];
    BOOL onlyMyPlannedCalls = [self shouldShowOnlyMyPlannedCalls];
    [self setShowOnlyMyPlannedCalls:!onlyMyPlannedCalls];
    [self loadPlannedCalls];
    [self.tableView reloadData];
    [self.tableView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];

}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    AGNTableViewHeader *headerView = [[AGNTableViewHeader alloc] init];
    
    if(section == [self ratingsSection]){
        headerView.leftLabel.text = [NSLocalizedString(@"Sales Team Info", @"") uppercaseString];
    }
    else if(section ==ContactSection) {
        headerView.leftLabel.text = [NSLocalizedString(@"HCP Contact", @"") uppercaseString];
        [headerView.button addTarget:self action:@selector(editHCPButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        if (self.isEditingDraftCalls) {
            [headerView setButtonLabelText:@"EDIT"];
            headerView.button.enabled = NO;
        }
        else {
            headerView.button.enabled = YES;
            [headerView setButtonLabelText:(self.isEditingHCP ? @"DONE" : @"EDIT")];
        }
        
    }
    else if (section == AddressSection) {
        headerView.leftLabel.text = [NSLocalizedString(@"HCP Addresses", @"") uppercaseString];
    }
    else if (section == CallHistorySection ) {
        headerView.leftLabel.text = [NSLocalizedString(@"Call History", @"") uppercaseString];
        [headerView.button addTarget:self action:@selector(flipClosedCallFilterState) forControlEvents:UIControlEventTouchUpInside];
        if ([self shouldShowOnlyMyClosedCalls]){
            [headerView setButtonLabelText:NSLocalizedString(@"SHOW ALL CALLS", @"Button to show all calls in hcp detail")];
        }else{
            [headerView setButtonLabelText:NSLocalizedString(@"SHOW MY CALLS", @"Button to show only my calls in hcp detail")];
        }
    }
    else if (section == [self formsSection]) {
//        if (self.account.forms) {
            headerView.leftLabel.text = [NSLocalizedString(@"Forms", @"") uppercaseString];
            [headerView.button addTarget:self action:@selector(flipFormsFilterState) forControlEvents:UIControlEventTouchUpInside];
           if([self shouldShowOnlyMyForms]){
               [headerView setButtonLabelText:NSLocalizedString(@"SHOW ALL FORMS", @"Button to show all forms in hcp detail")];
            }else{
                [headerView setButtonLabelText:NSLocalizedString(@"SHOW MY FORMS", @"Button to show only my forms in hcp detail")];
            }
//        }
    }
    else {
        headerView.leftLabel.text = [NSLocalizedString(@"Draft Calls", @"") uppercaseString];
        [headerView.button addTarget:self action:@selector(flipPlannedCallFilterState) forControlEvents:UIControlEventTouchUpInside];
        if([self shouldShowOnlyMyPlannedCalls]){
            [headerView setButtonLabelText:NSLocalizedString(@"SHOW ALL CALLS", @"Button to show all calls in hcp detail")];
        }else{
            [headerView setButtonLabelText:NSLocalizedString(@"SHOW MY CALLS", @"Button to show only my calls in hcp detail")];
        }
        // per AL-323, no edit mode.  Leave the code intact in case we change our minds
        
//        [headerView.button addTarget:self action:@selector(editDraftCallsButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
//        if (self.isEditingHCP) {
//            [headerView setButtonLabelText:@"EDIT"];
//            headerView.button.enabled = NO;
//        }
//        else {
//            headerView.button.enabled = YES;
//            [headerView setButtonLabelText:(self.isEditingDraftCalls ? @"DONE" : @"EDIT")];
//        }
    }
    
    return headerView;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == DraftCallsSection   || (indexPath.section == CallHistorySection && [self.callHistoryData count] == 0);
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AGNSalesRep * currentUser = [[AGNAppDelegate sharedDelegate]loggedInSalesRep];
    if (indexPath.section == DraftCallsSection || (indexPath.section == CallHistorySection && [self.callHistoryData count] == 0)) {
        if ([self.plannedCalls count] > indexPath.row) {
            AGNCall *call = [self plannedCalls][indexPath.row];
            if (call.isClosed || call.signatureCaptureDate || call.salesRep!=currentUser) {
                return UITableViewCellEditingStyleNone;
            }
            return UITableViewCellEditingStyleDelete;
        }
    }
    return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == DraftCallsSection || (indexPath.section == CallHistorySection && [self.callHistoryData count] == 0)) {
        if ([self.plannedCalls count] > 0) {
            AGNCall *draftCallToDelete = [self plannedCalls][indexPath.row];
            log4Info(@"Deleting call %@",draftCallToDelete.guid);

            draftCallToDelete.toBeDeletedFlag = @YES;
            [self addManageCallUpdateTransactionForCall:draftCallToDelete];
            [self saveContext];
            [self loadPlannedCalls];
            [self.tableView reloadData];
            [self setOpenDraftButtonEnablement];
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNScheduleCallDeletedKey object:self];
        }
    }
}


- (void)addManageCallUpdateTransactionForCall:(AGNCall *)callToBeDeleted {
    callToBeDeleted.mobileLastUpdateTimestamp = [NSDate date];    
    NSString *currentJSONRepresentation = [callToBeDeleted jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageCall];
    upTxn.undoJSONRepresentation = self.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.modelClassName = @"AGNCall";
    upTxn.guid = callToBeDeleted.guid;
    upTxn.salesForceId = callToBeDeleted.salesForceId;
    
    if ([[AGNUpdateQueueManager defaultManager] appendTransactions:@[upTxn]]) {
        self.undoJSONRepresentation = currentJSONRepresentation;
    }
    else {
        //TODO: error handling
        log4Error(@"Failed to save call to core data");
    }
}

- (void)handleUpdateTransactionSuccessful:(NSNotification *)notification {
    [self setAccount:self.account];
}

- (void)handleUpdateTransactionRevert:(NSNotification *)notification {
    [self setAccount:self.account];
}

- (void)addressModified:(NSNotification *)notification {
    [self setupAddresses];
    [self.tableView reloadData];
    [self selectPrimaryAddress];
}

- (NSIndexPath *)indexPathOfSelectedAccount {
    int selectedRow;
    selectedRow = [self.visibleAddresses indexOfObject:self.selectedAddress];
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:selectedRow inSection:AddressSection];
    return indexPath;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"CreateCallSegue"]) {
        AGNCallDetailViewController *callDetailVC = ((AGNCallDetailViewController *)segue.destinationViewController);
        if (sender) {
            callDetailVC.call = (AGNCall *)sender; 
        }else{
            callDetailVC.hcp = self.account;
            callDetailVC.hcpAddress = self.selectedAddress;
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
    }
}

//- (void)editDraftCallsButtonPressed:(id)sender {
//    self.isEditingDraftCalls = !self.isEditingDraftCalls;
//    [self.tableView setEditing:self.isEditingDraftCalls];
//    [self.tableView reloadData];
//}

- (void)editHCPButtonPressed:(id)sender {
    AGNHCPContactEditViewController *editVC = [[AGNHCPContactEditViewController alloc] init];
    editVC.account = self.account;
    editVC.saveBlock = ^{
        [self saveContext];
//        NSArray *indexPaths = @[[NSIndexPath indexPathForRow:0 inSection:1], [NSIndexPath indexPathForRow:1 inSection:1], [NSIndexPath indexPathForRow:2 inSection:1]];
//        [self.tableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
        //TODO: Figure out why the lines above cause a crash
        [self.tableView reloadData];
    };
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:editVC];
    [nav.navigationBar setBackgroundImage:[UIImage imageNamed:@"bar-bigblue"] forBarMetrics:UIBarMetricsDefault];
    
    
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier     
        NSShadow * shadow  = [[NSShadow alloc]init];
        shadow.shadowColor = [UIColor blackColor];
        [shadow setShadowOffset:CGSizeMake(1, 1)];
        [nav.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIFont AGNAvenirBlackFontWithSize:21], NSForegroundColorAttributeName : [UIColor whiteColor], NSShadowAttributeName : [NSValue valueWithUIOffset:UIOffsetMake(1.0f, 0.0f)], NSShadowAttributeName     : [UIColor blackColor] }];
    } else {
        // Load resources for iOS 7 or later
        nav.navigationBar.tintColor=[UIColor whiteColor];
    }

    NSShadow * shadow  = [[NSShadow alloc]init];
    shadow.shadowColor = [UIColor blackColor];
    [shadow setShadowOffset:CGSizeMake(1, 1)];
    [nav.navigationBar setTitleTextAttributes:@{NSFontAttributeName : [UIFont AGNAvenirBlackFontWithSize:21], NSForegroundColorAttributeName : [UIColor whiteColor], NSShadowAttributeName : shadow}];

    nav.modalPresentationStyle = UIModalPresentationFormSheet;
    [self.navigationController presentViewController:nav animated:YES completion:nil];
}

- (NSAttributedString *)phoneNumbersAsString {
    
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    UIFont *roman = [UIFont AGNAvenirRomanFontWithSize:16.0f];
    NSDictionary *heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    NSDictionary *romanAttributes = @{ NSFontAttributeName : roman, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    
    NSAttributedString *commaSpace = [[NSAttributedString alloc] initWithString:@", " attributes:romanAttributes];
    
    NSMutableAttributedString *formattedString = [[NSMutableAttributedString alloc] init];
    
    void (^appendPhoneNumber)(NSString *, NSString *) = ^(NSString *type, NSString *number){
        NSString *formattedType = [NSString stringWithFormat:@"%@: ", type];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:formattedType attributes:heavyAttributes]];
        [formattedString appendAttributedString:[[NSAttributedString alloc] initWithString:number attributes:romanAttributes]];
    };
    
    
    if (self.account.phone.length > 0) {
        appendPhoneNumber(@"Main", self.account.phone);
    }
    
    if (self.account.mobilePhone.length > 0) {
        if (formattedString.length > 0) {
            [formattedString appendAttributedString:commaSpace];
        }        
        appendPhoneNumber(@"Mobile", self.account.mobilePhone);
    }
    
    if (self.account.fax.length > 0) {
        if (formattedString.length > 0) {
            [formattedString appendAttributedString:commaSpace];
        }
        appendPhoneNumber(@"Fax", self.account.fax);
    }
    
    return formattedString;
}

- (NSAttributedString *)contactsAsAttributedString {
    NSArray *contacts = [[self.account liveContacts] allObjects];
    
    if (contacts.count > 0 ) {
        NSMutableAttributedString *contactsString = [[NSMutableAttributedString alloc] init];
        for (AGNContact *contact in contacts) {
            NSMutableAttributedString *contactString = [[contact attributedNameAndRole] mutableCopy];
            if (contact != contacts.lastObject) {
                NSAttributedString *commaSpace = [[NSAttributedString alloc] initWithString:@", " attributes:@{ NSFontAttributeName : [UIFont AGNAvenirRomanFontWithSize:16.0f], NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] }];
                [contactString appendAttributedString:commaSpace];
            }
            [contactsString appendAttributedString:contactString];
        }
        return contactsString;
    }
    
    return nil;
}

- (NSString *)emailsAsString {
    NSMutableString *email = [[NSMutableString alloc] init];
    NSMutableArray *emails = [[NSMutableArray alloc] init];
    if (self.account.email1.length > 0) [emails addObject:self.account.email1];
    if (self.account.email2.length > 0) [emails addObject:self.account.email2];
    if (self.account.email3.length > 0) [emails addObject:self.account.email3];
    
    for (NSString *anEmail in emails) {
        [email appendString:anEmail];
        if (anEmail == emails.lastObject) {
            break;
        } else {
            [email appendString:@", "];
        }
    }
    
    return email;
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark Selected Background View
//------------------------------------------------------------------------------

- (void) didRotateFromInterfaceOrientation: (UIInterfaceOrientation) fromInterfaceOrientation {
    if (self.openDraftPopover!=nil) {
        [self.openDraftPopover dismissPopoverAnimated: YES];
        self.openDraftPopover = nil;
        [self showOpenDraftPopover:self.openDraftButton];
    }
    
    //hack to prevent horizontal table scrolling
//    CGSize newContentSize = self.tableView.contentSize;
//    newContentSize.width = self.view.frame.size.width;
//    self.tableView.contentSize = newContentSize;
//    
    [self updateContentSize];
    [self.tableView reloadData];
    [self.tableView selectRowAtIndexPath:[self indexPathOfSelectedAccount] animated:NO scrollPosition:UITableViewScrollPositionNone];
}

-(void)updateContentSize{

    log4Info(@"Content Size");
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    newContentSize.height = self.view.frame.size.height;
    self.tableView.contentSize = newContentSize;
}

-(void)viewDidAppear:(BOOL)animated{
    [self updateContentSize];
    [self.tableView reloadData];
    [self selectAddress];
}
//------------------------------------------------------------------------------
// MARK: - AGNPopoverDelegate Protocol
//------------------------------------------------------------------------------

-(void) objectSelected:(NSInteger)selected{
    if(self.openDraftPopover){
        log4Debug(@"Call selected %@",self.myPlannedCalls[selected]);
        [self.openDraftPopover dismissPopoverAnimated:YES];
        if(selected < self.myPlannedCalls.count){
            [self navigateToCall:self.myPlannedCalls[selected]];
        }else{
            [self navigateToCall:nil];
        }
        self.openDraftPopover = nil;
    }
}


//------------------------------------------------------------------------------
// MARK: - Additional popover methods
//------------------------------------------------------------------------------


-(void) showOpenDraftPopover:(UIButton*)button {
    self.openDraftButton = button;
    self.openDraftPopover = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:NSLocalizedString(@"Multiple Drafts", @"Multiple Drafts Popover Title")];

    __weak AGNHCPDetailViewController * _self = self;

    self.openDraftPopover.numberRowsBlock = ^(UITableView *aTableView, NSInteger section) {
        NSInteger numberRows = _self.myPlannedCalls.count+1;
        return numberRows;
    };


    self.openDraftPopover.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
        AGNSingleLineCell *cell = [aTableView dequeueReusableCellWithIdentifier:kCellIdentifier];
        if (cell == nil) {
            cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier];
        }
        if(indexPath.row < _self.myPlannedCalls.count){
            AGNCall *call = _self.myPlannedCalls[indexPath.row];
            cell.mainLabel.text = [call formattedDateAndRepName];
        }else{
            cell.mainLabel.text = @"Create Call  +";
        }
        return cell;
    };
    
    CGRect rect = button.frame;
    rect = [self.view convertRect:rect fromView:button.superview];
    [self.openDraftPopover presentPopoverFromRect:rect
                                  inView:self.view
                permittedArrowDirections:UIPopoverArrowDirectionAny
                                animated:YES];
}


- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
    
    return YES;
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
    if ([popoverController isEqual:self.openDraftPopover]) {
		self.openDraftPopover = nil;
	}
    log4Debug(@"popover dismissed");
}

- (IBAction)openDraft:(id)sender {
    log4Debug(@"selected open draft - have %d planned calls ", [self.plannedCalls count]);
    NSArray *myPlannedCalls = [self myPlannedCalls];
    if([myPlannedCalls count]>0)
        [self showOpenDraftPopover:sender];
    else{
        [self navigateToCall:nil];

    }
}


-(void) navigateToCall:(AGNCall *)call {
    [self performSegueWithIdentifier:@"CreateCallSegue" sender:call];
}

- (void)navigateToForm:(AGNRequestForm*)form {
    AGNFormDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNFormDetailViewController"];

    detailVC.requestForm = form;
    [self.navigationController pushViewController:detailVC animated:YES];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

- (void)navigateToMCD:(AGNMarketingDisbursement*)mcd {
    AGNReprintDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNReprintDetailViewController"];

    detailVC.marketingDisbursement = mcd;
    [self.navigationController pushViewController:detailVC animated:YES];

    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

- (void)createForm:(NSString *)type {
    AGNFormDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNFormDetailViewController"];

    detailVC.hcp = self.account;
    detailVC.hcpAddress = self.selectedAddress;
    detailVC.requestFormType = type;
    [self.navigationController pushViewController:detailVC animated:YES];

    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

- (void)createReprint {
    AGNReprintDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNReprintDetailViewController"];

    detailVC.hcp = self.account;
    detailVC.hcpAddress = self.selectedAddress;
    [self.navigationController pushViewController:detailVC animated:YES];

    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

- (void)openBrowser {
    
    NSString* strURL =  [NSString stringWithFormat:@"%@/%@",[AGNAppDelegate sharedDelegate].homeUrl,self.salesForceId];
    NSString *strURL1 = [strURL stringByReplacingOccurrencesOfString:@"/home/home.jsp" withString:@""] ;
    
     NSURL *url = [NSURL URLWithString:strURL1];//[AGNAppDelegate sharedDelegate].homeUrl];
    [self navigateToExternalURL:url];
    
    }

- (void)navigateToExternalURL:(NSURL *)url {
    if ([AGNSyncManager isReplayingMockData] ||
        [AGNAppDelegate sharedDelegate].reachabilityObserver.networkStatus < RKReachabilityReachableViaWiFi) {
        log4Info(@"iNAV button pressed when offline, ignoring");
        // Just ignore the click
    }
    else {
        log4Info(@"iNAV button pressed, opening URL %@",url);
        
        [[UIApplication sharedApplication] openURL:url];
    }
}

- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.account.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
        }
    }
}

@end
