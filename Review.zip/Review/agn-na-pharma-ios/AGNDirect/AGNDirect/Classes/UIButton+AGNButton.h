//
//  UIButton+AGNButton.h
//  AGNDirect
//
//  Created by Adam McLain on 9/8/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (AGNButton)

+ (NSDictionary *)agnAttributedStringAttributes;

@end
