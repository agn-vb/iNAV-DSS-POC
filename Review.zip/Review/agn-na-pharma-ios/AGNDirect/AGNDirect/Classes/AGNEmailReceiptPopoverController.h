//
//  AGNViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 8/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNCategoryHeaders.h"

@protocol AGNEmailPopoverDelegate <NSObject>

// take action when item is selected
- (void)objectSelected:(NSInteger)selected;
- (void)addNewEmail:(NSString *)email;
- (int)currentSelection;

@end

@interface AGNEmailReceiptPopoverController : UIPopoverController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (weak, nonatomic) id<AGNEmailPopoverDelegate> popOverDelegate;
@property (strong, nonatomic) NSArray *objectArray;
@property (strong, nonatomic) UITextField *addEmailTextField;
@property (strong, nonatomic) UIButton *addButton;



-(id)initWithDelegate:(id<AGNEmailPopoverDelegate>)delegate andTitle:(NSString *)title;

@end
