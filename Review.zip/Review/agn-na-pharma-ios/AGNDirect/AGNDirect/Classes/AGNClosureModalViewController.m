///
//  AGNClosureModalViewController.m
//  AGNDirect
//
//  Created by Paul Gambill on 9/27/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  POPUP DIALOG FOR CLOSING A CALL - SELECTING DATE, CONTACTS

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNClosureModalViewController.h"
#import "AGNTableView.h"
#import "AGNCallDetailViewController.h"
#import "AGNCall.h"
#import "AGNAccount.h"
#import "AGNCallContact.h"
#import "AGNCallProductDetailCell.h"
#import "NSDate+AGNDate.h"

@interface AGNClosureModalViewController ()
@property (strong, nonatomic) IBOutlet AGNTableView *tableView;
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) NSArray *contacts;
@property (strong, nonatomic) IBOutlet UIButton *closeButton;
@property (weak, nonatomic) IBOutlet UILabel *whenLabel;
@property (weak, nonatomic) IBOutlet UIImageView *maskImage;

@end

@implementation AGNClosureModalViewController

const int kMaxDaysPastForCloseCall=30;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if ([[UIDevice currentDevice].systemVersion floatValue] > 6.1) {
        // separator causes header to look janky in ios7
        self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    }
    
    NSDate *currentDate = [NSDate date];
    self.datePicker.date = currentDate;
    self.datePicker.maximumDate = currentDate;
    
    // Prevent rep from selecting a closure date too far in the past.  If there's a signature capture date we'll use it.
    // So this only comes into play in detail only calls.
    double interval = kMaxDaysPastForCloseCall*24*60*60*(-1);
    self.datePicker.minimumDate = [currentDate dateByAddingTimeInterval:interval];

    AGNAccount *account = self.call.account;

    //  The HCP itself should be the first selectable contact
    NSMutableArray *objects = [@[account.callClosureDoctorNameAndDesignation] mutableCopy];
    NSArray * liveContacts = [[account liveContacts]allObjects];
    [objects addObjectsFromArray:liveContacts];
    self.contacts = objects;
    
    //enable fixed or scrollable tableView. tableView height is 201 and cell height is 33. 33*6=198
    if (self.contacts.count <= 6) {
        self.tableView.scrollEnabled = NO;
    }
    
    if (self.call.signatureCaptureDate || (self.contacts.count <= 1)) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0] ;
        [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionTop];

        // if there is a signature, set that captureDate as the minimum time
        self.datePicker.minimumDate = self.call.signatureCaptureDate;
        if(self.call.signatureCaptureDate){
            self.datePicker.hidden = YES;
            self.whenLabel.hidden=YES;
            self.maskImage.hidden=YES;
        }
        
    }
    

    // It is possible to add call contacts in SFDC to a draft call.  If so, they should be selected by default.
    for(AGNCallContact *callContact in self.call.callContacts){
        AGNContact *contact = callContact.contact;
        NSUInteger i = [self.contacts indexOfObject:contact];
        if(i==NSNotFound){
            // the actual contact object was deleted...
            log4Warn(@"Unable to find call contact %@ for call %@ in contact list for account %@",callContact.salesForceId,self.call.salesForceId,self.call.account.salesForceId);
        }else{
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:0] ;
            [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionTop];
        }
    }
    
    if([self timeIs24HourFormat]){
        [self.maskImage setImage:[UIImage imageNamed:@"pickermask24hr"]];
    }
    [self setCloseButtonInteractivity];
    
    self.tableView.tableFooterView = [[UIView alloc] init];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)cancelTapped:(UIButton *)sender
{
    log4Info(@"Cancelled out of call closure modal");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)closeCallTapped:(id)sender {
    log4Info(@"Closed call Tapped");

    AGNEligibilityHelper *eligibilityHelper = [[AGNEligibilityHelper alloc]initWithCall:self.call];
    if(![eligibilityHelper hasValidSalesRep]){
        log4Warn(@"In closure modal,  sales rep invalid, dismissing");
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
    }
    if(![eligibilityHelper hasValidAddress]  ){
        log4Warn(@"In closure modal,  address invalid, dismissing");
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
    }
    if(![eligibilityHelper hasValidSignature]  ){
        log4Warn(@"In closure modal, signature invalid, dismissing");
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
    }

    //close the call
    NSDate *chosenDate = self.datePicker.date;
    NSDate * now = [NSDate date];
    if([chosenDate compare:now]==NSOrderedDescending){
        chosenDate = now;
    }
    NSDate * closeDate = self.call.signatureCaptureDate?self.call.signatureCaptureDate:chosenDate;
    self.call.endDate = closeDate;
    self.call.callClosedTimestamp = closeDate;
    [self.call setStartDateAndDurationFromEndDate];
    self.call.callDate = self.call.startDate;

    if(![self.call canClose]){
        log4Warn(@"Tried to close call but some details are not valid for this date");
        NSString *message = [NSString stringWithFormat:@"Unable to close call on %@, some details are not valid for this date.",[closeDate agnFormattedDateString]];

        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Unable to Close Call" message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];
        return;
    }
    self.call.closed = [NSNumber numberWithInt:1];

    NSArray *indexPaths = self.tableView.indexPathsForSelectedRows;
    NSMutableArray * chosenContacts = [[NSMutableArray alloc]initWithCapacity:[indexPaths count]];
    
    // Need to sync up with any existing call contacts set up on the draft call in SFDC.
    // So check whether the selected contact already has a call contact relationship.  If not, add one.
    // Then look for an existing call contacts which weren't selected and remove the call contact relationship.  
    
    for (NSIndexPath *indexPath in indexPaths) {
        if (indexPath.row == 0) {
            continue;
        }
        AGNContact * contact = self.contacts[indexPath.row];
        [chosenContacts addObject:contact];
        if(![self.call hasContact:contact]){
            AGNCallContact *callContact = (AGNCallContact *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNCallContact" inManagedObjectContext:[self.call managedObjectContext]];
            callContact.call = self.call;
            callContact.guid = [[NSUUID UUID] UUIDString];
            callContact.contact = contact;
            callContact.mobileCreateTimestamp = [NSDate date];
            callContact.mobileLastUpdateTimestamp = [NSDate date];
        }
    }
    
    // find any existing call contact relationships we didn't select
    NSMutableArray * contactsToRemove = [[NSMutableArray alloc]init];
    for(AGNCallContact *callContact in self.call.callContacts){
        if(![chosenContacts containsObject:callContact.contact]){
            [contactsToRemove addObject:callContact];
        }else{
            callContact.mobileLastUpdateTimestamp = [NSDate date];
        }
    }
    
    // once we've collected them, remove the relationship and delete the relationship object
    for(AGNCallContact *contactToRemove in contactsToRemove){
        [self.call.callContacts removeObject:contactToRemove];
        [self.call.managedObjectContext deleteObject:contactToRemove];
    }
    
    // we always put the HCP itself first in the list, so easy to determine whether it's a non md call
    if ([indexPaths containsObject:[NSIndexPath indexPathForRow:0 inSection:0]]) {
        self.call.nonMDCall = @0;
    }else{
        self.call.nonMDCall = @1;
    }
    
    [self.call stampComplianceFields:YES];
    
    // Decrement SampleInventoryLine quantities for dropped samples
    for (AGNSampleDrop *drop in self.call.sampleDrops) {
        if (drop.sampleInventoryLine) {
            int newQuantity = [drop.sampleInventoryLine.quantity intValue] - [drop.quantity intValue];
            if (newQuantity < 0) {
                newQuantity = 0;
            }
            drop.sampleInventoryLine.quantity = [NSNumber numberWithInt:newQuantity];
        }
    }

    log4Info(@"Closed call at %@",self.call.callClosedTimestamp);


    if ([self.delegate respondsToSelector:@selector(closeCallModalDismissed)]) {
        [self.delegate closeCallModalDismissed];
    }
    
    [self dismissViewControllerAnimated:YES completion:^{
        [eligibilityHelper clearCurrentCallInfo];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
    }];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.contacts.count;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 33.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellIdentifier";

    AGNCallProductDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
      cell = [[AGNCallProductDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }

    [cell agnSetStyledSelectedBackground];
    if (indexPath.row == 0) {
      cell.label.attributedText = self.contacts[indexPath.row];
    }
    else {
      AGNContact *contact = self.contacts[indexPath.row];
      cell.label.attributedText = [contact callClosureAttributedNameAndRole];
    }
    
    NSArray *indexPaths = self.tableView.indexPathsForSelectedRows;
    if([indexPaths containsObject:indexPath]){
        cell.accessoryView = [[ UIImageView alloc ]initWithImage:
                                                             [UIImage imageNamed:@"checkmark" ]];
    }
    else{
        cell.accessoryView = UITableViewCellAccessoryNone;
    }


    
    return cell;
}

- (NSIndexPath *)tableView:(UITableView *)tableView willDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([indexPath compare:[NSIndexPath indexPathForRow:0 inSection:0]] == NSOrderedSame && (self.call.signatureCaptureDate || (self.contacts.count <= 1))) {
        return nil;
    }
    
    return indexPath;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView cellForRowAtIndexPath:indexPath].accessoryView = UITableViewCellAccessoryNone;
       [self setCloseButtonInteractivity];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView cellForRowAtIndexPath:indexPath].accessoryView =  [[ UIImageView alloc ]initWithImage:
                                                                                [UIImage imageNamed:@"checkmark" ]];
    [self setCloseButtonInteractivity];
}

- (void)setCloseButtonInteractivity {
    if (self.tableView.indexPathsForSelectedRows.count == 0) {
        self.closeButton.enabled = NO;
        self.closeButton.alpha = 0.5;
    }
    else {
        self.closeButton.enabled = YES;
        self.closeButton.alpha = 1.0;
    }
}

- (BOOL)timeIs24HourFormat {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterNoStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    NSString *dateString = [formatter stringFromDate:[NSDate date]];
    NSRange amRange = [dateString rangeOfString:[formatter AMSymbol]];
    NSRange pmRange = [dateString rangeOfString:[formatter PMSymbol]];
    BOOL is24Hour = amRange.location == NSNotFound && pmRange.location == NSNotFound;
    return is24Hour;
}

@end
