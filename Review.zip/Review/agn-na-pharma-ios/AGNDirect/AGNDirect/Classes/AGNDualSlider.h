//
//  AGNDualSlider.h
//  AGNDirect
//
//  Created by Adam McLain on 9/24/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNDualSlider : UIControl

@property(nonatomic) float selectedMinimumValue;	// Setting this property causes the receiver to redraw itself using the new value. The default value of this property is 0.0.
@property(nonatomic) float selectedMaximumValue;	// Setting this property causes the receiver to redraw itself using the new value. The default value of this property is 1.0.

@property(nonatomic) float minimumValue;	// The minimum value for the scale, default is 0.0
@property(nonatomic) float maximumValue;	// The maximum value for the scale, default 1.0

@property (nonatomic, strong) NSString* minimumLabelText; // the label for the minimal thumb slider
@property (nonatomic, strong) NSString* maximumLabelText; // the label for the maximum thumb slider
@property (strong, nonatomic) NSIndexPath *indexPath; // indexPath of cell containing slider

@end
