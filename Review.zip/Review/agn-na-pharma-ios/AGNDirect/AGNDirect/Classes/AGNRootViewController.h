//
//  AGNViewController.h
//  AGNDirect
//
//  Created by Mark Wells on 7/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNCallsViewController.h"
#import "AGNInventoryViewController.h"
#import "AGNSettingsViewController.h"
#import "AGNSyncStatusViewController.h"
#import "SFNativeRootViewController.h"

@interface AGNRootViewController : SFNativeRootViewController <UINavigationControllerDelegate>

@property (nonatomic, strong, readonly) UIViewController *currentViewController;
@property (nonatomic, strong) AGNCallsViewController *callsViewController;
@property (nonatomic, strong) AGNInventoryViewController *inventoryViewController;
@property (nonatomic, strong) AGNSettingsViewController *settingsViewController;
@property (nonatomic, strong) AGNSyncStatusViewController *syncStatusViewController;
@property (nonatomic, readonly) BOOL isSyncing;
@property (assign, nonatomic) BOOL syncViewVisible;

@property (weak, nonatomic) IBOutlet UIImageView *navBarBackground;

-(void)syncingStarted;
-(void)syncingStopped;
- (void)syncingStopped:(void (^)(void))completion;
-(void)setTasksComplete:(int)complete outOf:(int)total;

- (void)lowerCurtain:(BOOL)animated;
- (void)lowerCurtain:(BOOL)animated completion:(void (^)(void))completion;
- (void)raiseCurtain:(BOOL)animated;

-(void) navigateToCallsTab;

// Returns YES if the sync was triggered, NO if it was flagged
- (BOOL)triggerDownstreamSync;

- (void)showAppVersionForcedUpgradeNotice;
- (void)dismissIfVisibleAppVersionForcedUpgradeNotice;

-(void)showSyncInterruptedAlert;

@end
