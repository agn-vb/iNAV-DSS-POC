//
//  AGNReprintTableViewCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/12/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNReprintTableViewCell.h"

@implementation AGNReprintTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.quantity.delegate=self;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
   self.textFieldActiveBlock(textField);
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    if([textField.text length]==0){
        log4Info(@"Remove row %@",self.apc.apcCode);
        [self.quantities removeObjectForKey:self.apc.salesForceId];
    }else{
        NSNumberFormatter *nf = [[NSNumberFormatter alloc]init];
        NSNumber *quantity = [nf numberFromString:textField.text];
        NSInteger intQuantity = [quantity integerValue];
        quantity = [NSNumber numberWithInt:intQuantity];
 

        textField.text = quantity? quantity.stringValue : nil;
        self.quantities[self.apc.salesForceId]=quantity;
        log4Info(@"Add row %@ with quantity %@",self.apc.apcCode,quantity);

    }
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNReprintQuantityChangedNotificationKey object:nil];
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    NSNumber *inventoryNumber;

    NSString *inventoryString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    inventoryNumber = [numberFormatter numberFromString:inventoryString];
    

    if (([inventoryString length] > 0) && (inventoryNumber == nil || inventoryNumber.intValue<=0 || inventoryNumber.intValue > 999)) {
        return NO;
    } else {
        return YES;
    }
}



-(void)setApc:(AGNAPC *)apc {
    _apc=apc;
    self.quantity.delegate=self;
    if(apc){
        self.jobName.text=apc.jobName;
        self.apcCode.text=apc.apcCode;
        self.product.text=apc.productName;
    }else{
        self.jobName.text=@"No Data";
        self.apcCode.text=nil;
        self.product.text = nil;
    }
    self.quantity.hidden=NO;
    self.qtyReadOnly.hidden=YES;

}

-(void)setContent:(AGNMarketingCollateral *)content  {
    _content = content;
    self.jobName.text=content.apcJobName;
    self.apcCode.text=content.apcCode;
    self.product.text=content.apcProductName;
    self.quantity.hidden=YES;
    self.qtyReadOnly.hidden=NO;
    self.qtyReadOnly.text=[content.quantity stringValue];
}

@end
