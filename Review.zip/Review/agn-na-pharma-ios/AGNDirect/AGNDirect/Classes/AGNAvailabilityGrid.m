//
//  AGNAvailabilityGrid.m
//  AGNDirect
//
//  Created by Adam McLain on 10/22/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  USED FOR OFFICE HOURS

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#import "AGNAvailabilityGrid.h"

@interface AGNAvailabilityGrid ()
@property (strong, nonatomic) NSArray *headerRow;
@property (strong, nonatomic) NSArray *startRow;
@property (strong, nonatomic) NSArray *endRow;
@end

@implementation AGNAvailabilityGrid

- (id)init
{
    self = [super init];
    if (self) {
        UILabel *(^aLabel)(void) = ^{
            UILabel *label = [[UILabel alloc] init];
            [label setTranslatesAutoresizingMaskIntoConstraints:NO];
            label.textAlignment = NSTextAlignmentCenter;
            label.backgroundColor = [UIColor clearColor];
            label.font = [UIFont AGNAvenirHeavy16];
            label.minimumScaleFactor = 0.6f;
            label.adjustsFontSizeToFitWidth = YES;
            label.textColor = [UIColor AGNGreyMatter];
            label.highlightedTextColor = [UIColor whiteColor];
            [self addSubview:label];
            return label;
        };
        
        self.headerRow = @[aLabel(), aLabel(), aLabel(), aLabel(),aLabel(), aLabel()];
        self.startRow = @[aLabel(), aLabel(), aLabel(), aLabel(),aLabel(), aLabel()];
        self.endRow = @[aLabel(), aLabel(), aLabel(), aLabel(),aLabel(), aLabel()];
        
        void (^formatHeader)(UILabel *) = ^(UILabel *label){
            label.font = [UIFont AGNAvenirRoman16];
            label.textColor = [UIColor AGNSecondGrayd];
            label.highlightedTextColor = [UIColor AGNSilberLining];
        };
        
        [self.headerRow enumerateObjectsUsingBlock:^(UILabel *label, NSUInteger idx, BOOL *stop) {
            formatHeader(label);
        }];
        
        void(^hoizontalContraints)(NSArray *) = ^(NSArray *row){
            UILabel *label1 = row[0];
            UILabel *label2 = row[1];
            UILabel *label3 = row[2];
            UILabel *label4 = row[3];
            UILabel *label5 = row[4];
            UILabel *label6 = row[5];
            
            
            NSDictionary *views = NSDictionaryOfVariableBindings(label1, label2, label3, label4, label5, label6);
            UIView *parentView = self;
            [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|[label1(==70)][label2(label1)][label3(==label2)][label4(==label2)][label5(==label2)][label6(==label2)]" options:0 metrics:nil views:views]];
        };
        
        hoizontalContraints(self.headerRow);
        hoizontalContraints(self.startRow);
        hoizontalContraints(self.endRow);
        
        for (int idx = 0; idx < 6; idx++) {
            UILabel *headerLabel = self.headerRow[idx];
            UILabel *startLabel = self.startRow[idx];
            UILabel *endLabel = self.endRow[idx];
            
            NSDictionary *views = NSDictionaryOfVariableBindings(headerLabel, startLabel, endLabel);
            UIView *parentView = self;
            [parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[headerLabel(==30)][startLabel(==headerLabel)][endLabel(==headerLabel)]" options:0 metrics:nil views:views]];
            
            if (idx == 0) {
                headerLabel.text = NSLocalizedString(@"Hours", @"");
                headerLabel.textAlignment = NSTextAlignmentLeft;
                startLabel.text = NSLocalizedString(@"Start", @"");
                formatHeader(startLabel);
                startLabel.textAlignment = NSTextAlignmentLeft;
                endLabel.text = NSLocalizedString(@"End", @"");
                formatHeader(endLabel);
                endLabel.textAlignment = NSTextAlignmentLeft;
                continue;
            }
        }

    }
    return self;
}

- (void)setAvailabilityManager:(AGNHCPAvailabilityManager *)availabilityManager {
    if (_availabilityManager == availabilityManager) {
        return;
    }
    
    for (int idx = 1; idx < 6; idx++) {
        UILabel *headerLabel = self.headerRow[idx];
        UILabel *startLabel = self.startRow[idx];
        UILabel *endLabel = self.endRow[idx];
        
        AGNHCPDayAvailability *avail = [availabilityManager dayAvailabiliyForWeekday:idx];
        headerLabel.text = avail.day;
        
        if ([avail isUnavailable]) {
            startLabel.text = NSLocalizedString(@"-", @"");
            endLabel.text = NSLocalizedString(@"-", @"");
            continue;
        }
        
        static NSDateFormatter *dateFormatter;
        if (!dateFormatter) {
            dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setLocale:[NSLocale autoupdatingCurrentLocale]];
            [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
            [dateFormatter setAMSymbol:@"A"];
            [dateFormatter setPMSymbol:@"P"];
            [dateFormatter setDateFormat:@"h:mma"];
        }
        
        startLabel.text = [dateFormatter stringFromDate:avail.startTime];
        endLabel.text = [dateFormatter stringFromDate:avail.endTime];
    }

}

@end
