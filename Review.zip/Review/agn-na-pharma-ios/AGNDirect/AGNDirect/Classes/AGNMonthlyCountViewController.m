//
//  AGNMontlyCountViewController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 10/2/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNMonthlyCountViewController.h"
#import "AGNTableView.h"
#import "AGNInventoryCell.h"
#import "AGNBigBlueButton.h"
#import "AGNSampleInventoryTransaction.h"

#define SORTABLE_ROWS 3

@interface AGNMonthlyCountViewController ()
@property (strong, nonatomic) NSArray *sampleInventoryTransactionLines;
@property (strong, nonatomic) AGNSampleInventoryTransaction *reconciliationDraft;
@property (weak, nonatomic) IBOutlet AGNTableView *tableView;
@property (weak, nonatomic) IBOutlet AGNBigBlueButton *submitButton;
@property (strong, nonatomic) UITextField *activeField;
@property (strong, nonatomic) IBOutlet UIView *footerView;
@property (strong, nonatomic) NSMutableArray *currentSortDescriptors;
@property (weak, nonatomic) IBOutlet UIImageView *sampleImageView;
@property (weak, nonatomic) IBOutlet UIImageView *expiresImageView;
@property (weak, nonatomic) IBOutlet UIImageView *qtyImageView;
@property (weak, nonatomic) IBOutlet UILabel *qtyLabel;

@property (weak, nonatomic) IBOutlet UILabel *sampleNameHeader;
@property (weak, nonatomic) IBOutlet UILabel *expiresHeader;
@property (weak, nonatomic) IBOutlet UILabel *touchTargetSample;

@property (weak, nonatomic) IBOutlet UILabel *touchTargetExpires;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topHeaderViewConstraint;

@end

@implementation AGNMonthlyCountViewController
@synthesize sampleInventoryTransactionLines;
//@synthesize tableView;
@synthesize reconciliationDraft;
@synthesize submitButton=_submitButton;
@synthesize activeField=_activeField;
@synthesize topHeaderViewConstraint;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.topHeaderViewConstraint.constant=0.0f;
    } else {
        // Load resources for iOS 7 or later
        self.topHeaderViewConstraint.constant=20.0f;
    }
    self.tableView.tableFooterView = [[UIView alloc] init];
    //self.tableView.rowHeight = 42;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    log4Info(@"Opened view for monthly count");
    self.currentSortDescriptors=[[NSMutableArray alloc]initWithCapacity:SORTABLE_ROWS];

    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(quantityChanged)
                                                 name:AGNMonthlyCountsQuantityChangedNotificationKey object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidHide:)
                                                 name:UIKeyboardDidHideNotification object:nil];
    self.reconciliationDraft = [[AGNDataManager defaultInstance] getMonthlyReconciliationDraft];
    if(!self.reconciliationDraft){
        self.reconciliationDraft = [self createOpenDraft];
    }else{
        [self updateExistingDraft];
    }
    [self.reconciliationDraft setUndoRepresentation];
    
    
    UIGestureRecognizer * tapQty = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedQuantity:)];
    self.qtyLabel.userInteractionEnabled=YES;
    [self.qtyLabel addGestureRecognizer:tapQty];
    
    UIGestureRecognizer * tapQty2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedQuantity:)];
    self.qtyImageView.userInteractionEnabled=YES;
    [self.qtyImageView addGestureRecognizer:tapQty2];
    
    UIGestureRecognizer * tapSampleName = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedSampleName:)];
    self.sampleNameHeader.userInteractionEnabled=YES;
    [self.sampleNameHeader addGestureRecognizer:tapSampleName];
    
    UIGestureRecognizer * tapSampleName2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedSampleName:)];
    self.sampleImageView.userInteractionEnabled=YES;
    [self.sampleImageView addGestureRecognizer:tapSampleName2];

    
    UIGestureRecognizer * sampleTouchTarget = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedSampleName:)];
    self.touchTargetSample.userInteractionEnabled=YES;
    [self.touchTargetSample addGestureRecognizer:sampleTouchTarget];
    
    UIGestureRecognizer * tapExpiration = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedExpiration:)];
    self.expiresHeader.userInteractionEnabled=YES;
    [self.expiresHeader addGestureRecognizer:tapExpiration];
    
    UIGestureRecognizer * tapExpiration2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedExpiration:)];
    self.expiresImageView.userInteractionEnabled=YES;
    [self.expiresImageView addGestureRecognizer:tapExpiration2];
    
    UIGestureRecognizer * expiresTouchTarget = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tappedExpiration:)];
    self.touchTargetExpires.userInteractionEnabled=YES;
    [self.touchTargetExpires addGestureRecognizer:expiresTouchTarget];
    
       
    [self initSort];
}

-(void)initSort{
    [self.currentSortDescriptors removeAllObjects];
    [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"product.productDescription" ascending:YES]];
    [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"expirationDate" ascending:YES]];
    [self.currentSortDescriptors addObject:[NSSortDescriptor sortDescriptorWithKey:@"availableQuantity" ascending:YES]];
    
    self.sampleImageView.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
    self.expiresImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.qtyImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    
    [self loadData];
    [self.tableView reloadData];
}

- (int)indexOfDescriptorForKey:(NSString *)key{
    for(int i=0; i < SORTABLE_ROWS; i++ ){
        NSSortDescriptor *desc = self.currentSortDescriptors[i];
        if([desc.key isEqualToString:key])
            return i;
    }
    return -1;
}

- (void) updateToNewSort:(NSString *)sortKey{
    
    NSSortDescriptor *firstSort = self.currentSortDescriptors[0];
    
    if([firstSort.key isEqualToString:sortKey]){ // just switch sort order
        BOOL ascending=!firstSort.ascending;
        self.currentSortDescriptors[0]=[NSSortDescriptor sortDescriptorWithKey:sortKey ascending:ascending];
        
    }else{
        int index = [self indexOfDescriptorForKey:sortKey];
        NSSortDescriptor *existing = self.currentSortDescriptors[index];
        NSSortDescriptor *newDescriptor = [NSSortDescriptor sortDescriptorWithKey:sortKey ascending:!existing.ascending];
        for(int i=index-1; i >=0 ; i--){
            self.currentSortDescriptors[i+1]=self.currentSortDescriptors[i];
        }
        self.currentSortDescriptors[0]=newDescriptor;
    }
    
    [self updateImages];
    [self loadData];
    [self.tableView reloadData];
    
}

-(void) updateImages{
    self.sampleImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.expiresImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    self.qtyImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
    
    for(int i=0; i < SORTABLE_ROWS; i++){
        NSSortDescriptor *sort = self.currentSortDescriptors[i];
        if([sort.key isEqualToString:@"product.productDescription"]){
            if(i==0)
                self.sampleImageView.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.sampleImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.sampleImageView setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.sampleImageView setTransform:rotate];
            }
        }
        if([sort.key isEqualToString:@"expirationDate"]){
            if(i==0)
                self.expiresImageView.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.expiresImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.expiresImageView setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.expiresImageView setTransform:rotate];
            }
        }
        if([sort.key isEqualToString:@"availableQuantity"]){
            if(i==0)
                self.qtyImageView.image=[UIImage imageNamed:@"icn-sort-sel~ipad.png"];
            else
                self.qtyImageView.image=[UIImage imageNamed:@"icn-sort-unsel~ipad.png"];
            if(sort.ascending){
                CGAffineTransform rotate = CGAffineTransformMakeRotation( M_PI );
                [self.qtyImageView setTransform:rotate];
            }else{
                CGAffineTransform rotate = CGAffineTransformMakeRotation( 0 );
                [self.qtyImageView setTransform:rotate];
            }
            
        }
    }
    
    
}

- (void)tappedSampleName:(UITapGestureRecognizer *)sender {
    NSString *sortKey = @"product.productDescription";
    [self updateToNewSort:sortKey];
}

- (void)tappedQuantity:(UITapGestureRecognizer *)sender {
    NSString *sortKey = @"availableQuantity";
    [self updateToNewSort:sortKey];
}

- (void)tappedExpiration:(UITapGestureRecognizer *)sender {
    NSString *sortKey = @"expirationDate";
    [self updateToNewSort:sortKey];
}

-(void) reloadContent{
    [self loadData];
}

-(void)loadData{
    
    self.sampleInventoryTransactionLines =
    [[reconciliationDraft.sampleInventoryTransactionLines allObjects] sortedArrayUsingDescriptors:self.currentSortDescriptors];
     
    [self setButtonEnablement];
    [self.tableView reloadData];

}


- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setActiveField:(UITextField *)activeField{
    _activeField=activeField;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    self.tableView.contentSize = newContentSize;
    [self.tableView reloadData];
    [self scrollActiveToMiddle];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(AGNSampleInventoryTransaction *)createOpenDraft {
    AGNSampleInventoryTransaction * sit = (AGNSampleInventoryTransaction *)
    [NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryTransaction" inManagedObjectContext:[[AGNAppDelegate sharedDelegate]managedObjectContext]];
    sit.transactionType = kInventoryCountType;
    sit.transactionSubtype = kInventoryCountSubtype;
    sit.status = kOpenStatusType;
    sit.mobileCreateTimestamp = [NSDate date];
    sit.mobileLastUpdateTimestamp = [NSDate date];
    sit.guid = [[NSUUID UUID] UUIDString];
    

    NSArray * sampleInventoryLines = [[AGNDataManager defaultInstance]getSampleInventoryLines];
    for(AGNSampleInventoryLine *line in sampleInventoryLines){
        AGNSampleInventoryTransactionLine *transactionLine =(AGNSampleInventoryTransactionLine *)
        [NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryTransactionLine" inManagedObjectContext:[[AGNAppDelegate sharedDelegate]managedObjectContext]];
        [transactionLine populateFromSIL:line];
        // Monthly count expects the availableQuantity field to contain the SIL quantity
        // unlike everywhere else that uses expectedQuantity for that purpose. In monthly
        // count, the availableQuantity field holds the counted quantity (totally screwy!!).
        // That is the reason we are switching fields in the next two lines
        transactionLine.availableQuantity = transactionLine.expectedQuantity;
        transactionLine.expectedQuantity = nil;
        transactionLine.sampleInventoryTransaction=sit;
        transactionLine.mobileCreateTimestamp = [NSDate date];
        transactionLine.mobileLastUpdateTimestamp = [NSDate date];
        transactionLine.guid = [[NSUUID UUID] UUIDString];

    }
    [[AGNAppDelegate sharedDelegate] saveContext];
    return sit;
}

-(void)updateExistingDraft{
    NSArray * sampleInventoryLines = [[AGNDataManager defaultInstance]getSampleInventoryLines];
    for(AGNSampleInventoryLine *line in sampleInventoryLines){
        AGNSampleInventoryTransactionLine *transactionLine = [self existingTxnLineForLine:line];
        if(transactionLine)
            transactionLine.availableQuantity = line.quantity;
        else{ // must have gotten new inventory since we created the draft - make a new entry for it
            AGNSampleInventoryTransactionLine *transactionLine =(AGNSampleInventoryTransactionLine *)
            [NSEntityDescription insertNewObjectForEntityForName:@"AGNSampleInventoryTransactionLine" inManagedObjectContext:[[AGNAppDelegate sharedDelegate]managedObjectContext]];
            [transactionLine populateFromSIL:line];
            // Monthly count expects the availableQuantity field to contain the SIL quantity
            // unlike everywhere else that uses expectedQuantity for that purpose. In monthly
            // count, the availableQuantity field holds the counted quantity (totally screwy!!).
            // That is the reason we are switching fields in the next two lines
            transactionLine.availableQuantity = transactionLine.expectedQuantity;
            transactionLine.expectedQuantity = nil;
            transactionLine.sampleInventoryTransaction=self.reconciliationDraft;
            transactionLine.mobileCreateTimestamp = [NSDate date];
            transactionLine.mobileLastUpdateTimestamp = [NSDate date];
            transactionLine.guid = [[NSUUID UUID] UUIDString];
        }
    }
    
    for(AGNSampleInventoryTransactionLine *txn in [self.reconciliationDraft sampleInventoryTransactionLines]){
        if(!txn.sampleInventoryLine)
            [self.reconciliationDraft.managedObjectContext deleteObject:txn];
    }
    
    [[AGNAppDelegate sharedDelegate] saveContext];
}

-(AGNSampleInventoryTransactionLine *)existingTxnLineForLine:(AGNSampleInventoryLine *)sil{
    for(AGNSampleInventoryTransactionLine *txnLine in [self.reconciliationDraft sampleInventoryTransactionLines]){
        if([txnLine.sampleInventoryLine isEqual:sil])
            return txnLine;
    }
    return nil;
}

-(void)quantityChanged{
    [self setButtonEnablement];
    [[AGNAppDelegate sharedDelegate] saveContext];
}

-(void)setButtonEnablement{
    
    if([self.sampleInventoryTransactionLines count]==0){
        self.submitButton.enabled=NO;
        self.submitButton.alpha=.5;
        return;
    }
    
    for(AGNSampleInventoryTransactionLine *line in self.sampleInventoryTransactionLines) {
        if(!line.expectedQuantity || [line.expectedQuantity intValue]<0) { //count value existis in this field, not the actualQuantity field for monthly count
            self.submitButton.enabled=NO;
            self.submitButton.alpha=.5;
            return;
        }
    }
    self.submitButton.enabled=YES;
    self.submitButton.alpha=1;
    
}

- (IBAction)submitCountsPressed:(id)sender {
    log4Info(@"Submitted the monthly count");
    self.reconciliationDraft.status = kReceivedStatusType;
    [self addManageInventoryUpdateTransactionForSIT:self.reconciliationDraft];
    NSString * message = NSLocalizedString(@"Inventory count has been saved and will be submitted.", @"Save monthly count confirmation dialog message");
    NSString * title = NSLocalizedString(@"Inventory Count Saved", @"Save monthly count confirmation dialog title");
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alertView show];
}


-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPoppedNotificationKey object:nil];
}

- (void)addManageInventoryUpdateTransactionForSIT:(AGNSampleInventoryTransaction *)aSIT {
    NSString *currentJSONRepresentation = [aSIT jsonRepresentationForUpdate];
    AGNUpdateTransactionValueHolder *upTxn = [[AGNUpdateTransactionValueHolder alloc] init];
    upTxn.createTimestamp = [NSDate date];
    upTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageInventory];
    upTxn.undoJSONRepresentation = aSIT.undoJSONRepresentation;
    upTxn.currentJSONRepresentation = currentJSONRepresentation;
    upTxn.modelClassName = @"AGNSampleInventoryTransaction";
    upTxn.guid = aSIT.guid;
    upTxn.salesForceId = aSIT.salesForceId;
    
    if (![[AGNUpdateQueueManager defaultManager] appendTransactions:@[upTxn]]) {
        //TODO: error handling - display alert and refresh UI
        log4Error(@"Failed to save inventory transfer to core data");
    }
}

//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.sampleInventoryTransactionLines count]>0?[self.sampleInventoryTransactionLines count]:1;
}


-(CGFloat)tableView:(UITableViewCell*)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat result ;
    switch ([indexPath row])
    {
        case 0:
        {
            result = 30;
            break;
        }
        default :
            result = 42;
            
    }
    return result; // whatever
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *SampleInventoryCellIdentifier = @"SampleInventoryCell";
    
    //Sample Inventory Line Cell
    AGNInventoryCell *cell = [tableView dequeueReusableCellWithIdentifier:SampleInventoryCellIdentifier];
    if (cell == nil) {
        cell = [[AGNInventoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SampleInventoryCellIdentifier];
    }
    
    
    if([self.sampleInventoryTransactionLines count]==0){
        cell.sampleLabel.text = AGNPlaceholderText;
        cell.lotNumber.text = nil;
        cell.expirationDate.text = nil;
        cell.quantityLabel.text = nil;
        cell.varianceLabel.text = nil;
        cell.actualQuantityTextField.hidden=YES;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    AGNSampleInventoryTransactionLine *sampleInventoryTransactionLine = self.sampleInventoryTransactionLines[indexPath.row];
    cell.line = sampleInventoryTransactionLine;
    
    if ([sampleInventoryTransactionLine.product productCode]) {
        cell.sampleLabel.text = UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ?
        [sampleInventoryTransactionLine.product fullDescription] :
        [sampleInventoryTransactionLine.product productDescription];
    }
    else {
        cell.sampleLabel.text = @"UNKNOWN SAMPLE";
    }
    
    if (sampleInventoryTransactionLine.lotNumber) {
        cell.lotNumber.text = sampleInventoryTransactionLine.lotNumber;
    }
    else {
        cell.lotNumber.text = @"UNKNOWN";
    }
    
    if (sampleInventoryTransactionLine.expirationDate)  {
        cell.expirationDate.text = [sampleInventoryTransactionLine.expirationDate agnFormattedDateString];
        if([sampleInventoryTransactionLine.expirationDate isExpired])
            cell.expirationDate.textColor = [UIColor AGNWarny];
        else
            cell.expirationDate.textColor = [UIColor AGNGreyMatter];
    }
    else {
        cell.expirationDate.text = @"UNKNOWN";
    }
    
    if ([sampleInventoryTransactionLine.availableQuantity stringValue]) {
        int qty = [sampleInventoryTransactionLine.availableQuantity intValue];
        cell.quantityLabel.text = [[NSNumber numberWithInt:qty] stringValue];
    }
    else {
        cell.quantityLabel.text = @"---";
    }
    
    cell.textFieldActiveBlock = ^(UITextField *textField){
        self.activeField = textField;
    };
    
    
    return cell;
    
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITextFieldDelegate methods
//------------------------------------------------------------------------------

-(void)scrollActiveToMiddle{
    if(self.activeField){
        AGNInventoryCell *cell = (AGNInventoryCell *)[[self.activeField superview] superview];
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

- (void)keyboardWasShown:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];

    AGNInventoryCell *cell = (AGNInventoryCell *)[[self.activeField superview] superview];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    // Get keyboard height. It returns opposite (incorrect) values when in landscape
    CGFloat keyboardHeight;
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.width;
    }
    else {
        keyboardHeight = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
    }
    
    
    // Set content insets accordingly
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardHeight-self.footerView.frame.size.height, 0.0);
    self.tableView.contentInset = contentInsets;
    self.tableView.scrollIndicatorInsets = contentInsets;
    
    
    // If the cell containing activeField is hidden by keyboard, scroll the view so the cell is visible
    CGRect aRect = self.tableView.frame;
    aRect.size.height -= (keyboardHeight+self.footerView.frame.size.height);
    CGPoint cellAdjustedOrigin = cell.frame.origin;
    cellAdjustedOrigin.y += cell.frame.size.height; //adjust this point to look at the bottom of the cell rather than top
    if (!CGRectContainsPoint(aRect, cellAdjustedOrigin) ) {
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}


- (void)keyboardDidHide:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    NSNumber *animationTime = (NSNumber *)info[UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:[animationTime doubleValue] animations:^{
        UIEdgeInsets contentInsets = UIEdgeInsetsZero;
        self.tableView.contentInset = contentInsets;
        self.tableView.scrollIndicatorInsets = contentInsets;
    }];    
}

@end
