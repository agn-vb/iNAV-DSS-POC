//
//  AGNFormDetailViewController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/29/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNViewController.h"
#import "AGNBigBlueButton.h"
#import "AGNRequestForm.h"
#import "AGNTableView.h"
#import "AGNSmallBlueButton.h"
#import "AGNSimplePopoverTableViewController.h"
#import "AGNDeliveryMethodSortControl.h"
#import "AGNRequestFormItemCell.h"
#import "AGNSignatureView.h"

@interface AGNFormDetailViewController : AGNViewController <UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,AGNPopoverDelegate,UITextFieldDelegate, UIPopoverControllerDelegate, AGNRequestFormItemCellDelegate>


@property (strong, nonatomic) AGNRequestForm *requestForm;
@property (strong, nonatomic) AGNAccount *hcp;
@property (strong, nonatomic) AGNAddress *hcpAddress;
@property (strong, nonatomic) NSString * requestFormType;

@property (strong, nonatomic) UIButton *editButton;
@property (weak, nonatomic) IBOutlet UIView *formHeaderView;

@property (weak, nonatomic) IBOutlet UIView *headerContainerView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headerHeightConstraint;

@property (weak, nonatomic) IBOutlet AGNBigBlueButton *submitFormButton;

@property (weak, nonatomic) IBOutlet UIView *footerView;

@property (weak, nonatomic) IBOutlet UILabel *hcpNameAddressLabel;

@property (weak, nonatomic) IBOutlet UIView *submitButton;

@property (weak, nonatomic) IBOutlet UILabel *phoneLabel;

@property (weak, nonatomic) IBOutlet UILabel *deliveryMethodLabel;

@property (weak, nonatomic) IBOutlet AGNTableView *requestItemsTableView;


@property (weak, nonatomic) IBOutlet UITextField *reasonTextField;


@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;

@property (weak, nonatomic) IBOutlet UITextField *rssTextField;

@property (weak, nonatomic) IBOutlet AGNDeliveryMethodSortControl *deliveryMethodControl;


@property (weak, nonatomic) IBOutlet UILabel *doctorInfoLabel;

@property (weak, nonatomic) IBOutlet UILabel *deliveryInfoLabel;

@property (weak, nonatomic) IBOutlet UIButton *getSignatureButton;

@property (weak, nonatomic) IBOutlet AGNSignatureView *signatureView;

@property (weak, nonatomic) IBOutlet UIView *detailsView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *detailsTopConstraint;

@property (weak, nonatomic) IBOutlet AGNSmallBlueButton *switchHCPButton;

@end
