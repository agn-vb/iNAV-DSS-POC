//
//  AGNCallProductSampleCell.h
//  AGNDirect
//
//  Created by Mark Wells on 8/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSampleDrop.h"

static NSString * const AGNSampleCellQuantityChangedNotification = @"AGNSampleCellQuantityChangedNotification";
static NSString * const AGNSampleCellDidBeginEditing = @"AGNSampleCellDidBeginEditing";


@interface AGNCallProductSampleCell : UITableViewCell <UITextFieldDelegate>

@property (strong, nonatomic) UILabel *label;
@property (strong, nonatomic) UILabel *quantityLabel;
@property (strong, nonatomic) UITextField *quantityTextField;
@property (strong, nonatomic) AGNSampleDrop *model;
@property (strong, nonatomic) AGNProductSKU * sku;
@property (strong, nonatomic)  UILabel *expiredLotLabel;
@property (strong, nonatomic)  UILabel *actualQuantityLabel;

@end
