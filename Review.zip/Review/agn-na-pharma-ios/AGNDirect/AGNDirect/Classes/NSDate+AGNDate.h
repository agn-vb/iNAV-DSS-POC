//
//  NSDate+AGNDate.h
//  AGNDirect
//
//  Created by Adam McLain on 8/16/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//


@interface NSDate (AGNDate)

+ (NSDate *)agnDateRoundedDownToThirtyMinutes:(NSDate *)date;

+ (NSDate *)agnDateRoundedUpToThirtyMinutes:(NSDate *)date;

+ (NSDate *)agnDateFromString:(NSString *)dateString;

+ (NSDate *)agnDateTimeFromString:(NSString *)dateString;

+ (NSDate *)agnDateFromDateTimeComponents:(NSString *)dateString :(NSString *)timeString;

+ (NSDate *)agnDateFromRFC3339TimestampString:(NSString *)dateString;

+ (NSDate *)dateFromAddressAvailabilityString:(NSString *)string;

+ (NSDate *)agnUTCDateFromDateString:(NSString *)dateString andTimeString:(NSString *)timeString;

+ (NSDate *)agnGMTDateFromString:(NSString *)dateString;

+ (NSDate *)agnDateFromTimestampString:(NSString *)dateString;

- (NSString *)agnAvailabilityString;

- (NSString *)agnStringFromDate;

- (NSString *)agnGMTStringFromDate;

- (NSString *)agnStringFromDateTime;

- (NSString *)agnStringFromRFC3339Timestamp;

- (NSString *)agnFormattedDateString;

- (NSString *)agnFormattedTimestampString;

- (NSString *)agnRFC3339FormattedTimestampString;

- (NSString *)agnSfdcDateComponentString;

- (NSString *)agnSfdcTimeComponentString;

- (NSString *)agnLocalTimeString;

- (NSDate*)agnMidnightEastCoast;

- (NSString *)agnUpsertTimestampString;

- (BOOL)isExpired;

-(BOOL)isSameDay:(NSDate *)date;

@end
