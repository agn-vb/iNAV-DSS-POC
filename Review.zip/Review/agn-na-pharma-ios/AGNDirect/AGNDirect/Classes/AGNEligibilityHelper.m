//
//  AGNEligibilityHelper.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 9/5/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  USED BY THE CALLS SCREEN TO SIMPLIFY HANDLING OF ELIGIBILITY RULES 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#import "AGNEligibilityHelper.h"

@implementation AGNEligibilityHelper

@synthesize blacklistProductIds=_blacklistProductIds;
@synthesize dataManager=_dataManager;
@synthesize call=_call;

- (id)initWithCall:(AGNCall *)call 
{
    self = [super init];
    if (self) {
        // Initialization code
        _call = call;
        _dataManager = [[AGNDataManager alloc]initWithManagedObjectContext:[call managedObjectContext]];
    }
    return self;
}

-(NSSet *)blacklistProductIds{
    if(_blacklistProductIds)
        return _blacklistProductIds;
    _blacklistProductIds = [self.call.account blacklistProducts];
    return _blacklistProductIds ;
}

-(NSArray *) eligibleDetailPositions{
    NSMutableArray * eligibleDetailPositions = [[NSMutableArray alloc]init];
    NSArray *dps = [self.dataManager getAllDetailPositions];
    for(AGNDetailPosition *dp in dps){
        NSString *productId = dp.product.salesForceId; //barathan 10/7/2014
        //NSString *productId = dp.salesForceProductId;
        NSLog(@"Detail Position item %@",productId);
        if([self.blacklistProductIds containsObject:productId]){
            log4Debug(@"item %@ blacklisted for %@ ",[dp productDescription],[self.call.account doctorNameAndDesignation]);
        }else{
            if([dp isValidForDate:[self.call projectedCloseDate] ])
                [eligibleDetailPositions addObject:dp];
        }
    }
    return eligibleDetailPositions;
    
}

+(NSArray *) filteredDetailsForHCP:(AGNAccount *)hcp fromDetails:(NSOrderedSet *)details{
    NSMutableArray *filteredResults = [[NSMutableArray alloc]initWithCapacity:[details count]];
    NSSet * blacklist = [hcp blacklistProducts];
    for(AGNCallDetail *dp in details){
        NSString *productId = dp.detailPosition.product.salesForceId;
        if([blacklist containsObject:productId]){
            log4Debug(@"item %@ blacklisted for %@ ",[dp.detailPosition productDescription],[hcp doctorNameAndDesignation]);
        }else{
            [filteredResults addObject:dp];
        }
    }
    return filteredResults;
}

+(NSArray *) filteredSamplesForHCP:(AGNAccount *)hcp fromSamples:(NSOrderedSet *)samples atAddress:(AGNAddress *)address{
    NSMutableArray *filteredResults = [[NSMutableArray alloc]initWithCapacity:[samples count]];
    if(![hcp canSampleAtAddress:address]){
        return filteredResults;
    }
    for(AGNSampleDrop *drop in samples){
       if([drop.sampleInventoryLine hasSamplePermission])
          [filteredResults addObject:drop];
    }
    return filteredResults;
}


-(NSArray *) eligibleSampleInventoryLines{
    NSMutableArray * eligibleLines = [[NSMutableArray alloc]init];
    NSArray *sils = [self.dataManager getSampleInventoryLines];
    for(AGNSampleInventoryLine *line in sils){
        if([line canSample]){ 
            [eligibleLines addObject:line];
        }
    }
    return eligibleLines;
}

// delete sample drops that have become ineligible for reasons other than expiration date
-(void) deleteIneligibleDrops{
    NSOrderedSet *liveSampleDrops = [self.call liveSampleDrops];
    for(AGNSampleDrop *sampleDrop in liveSampleDrops){
        if(!sampleDrop.sampleInventoryLine || ![sampleDrop.sampleInventoryLine hasSamplePermission ] || ![self hasSamplingSection]){
            log4Info(@"Deleting sample drop %@ from call %@, no longer eligible",sampleDrop.salesForceId, self.call.salesForceId);
            sampleDrop.toBeDeletedFlag = @YES;
        }
    }
}

// remove drop objects that have not been sent to the server yet
-(void) removeIneligibleDrops{
    NSMutableOrderedSet * sampleDrops = [[NSMutableOrderedSet alloc] initWithOrderedSet: self.call.sampleDrops];
    for(AGNSampleDrop *drop in self.call.sampleDrops){
        if(![drop.sampleInventoryLine hasSamplePermission ] || ![self hasSamplingSection]){
            [sampleDrops removeObject:drop];
            [self.call.managedObjectContext deleteObject:drop];
        }
    }
    self.call.sampleDrops=sampleDrops;
}

-(void) deleteIneligibleDetails{
    NSOrderedSet *liveDetails = [self.call liveCallDetails];
    for(AGNCallDetail *detail in liveDetails){
        AGNDetailPosition *dp = detail.detailPosition;
        NSString *productId = dp.product.salesForceId;
        if([self.blacklistProductIds containsObject:productId]){
            log4Info(@"Deleting detail %@ - blacklisted for %@ ",[dp productDescription],[self.call.account doctorNameAndDesignation]);
            detail.toBeDeletedFlag = @YES;
        }
        
    }
}
-(void) removeIneligibleDetails{
    NSMutableOrderedSet * details = [[NSMutableOrderedSet alloc] initWithOrderedSet: self.call.callDetails];
    for(AGNCallDetail *detail in self.call.callDetails){
        AGNDetailPosition *dp = detail.detailPosition;
        NSString *productId = dp.product.salesForceId;
        if([self.blacklistProductIds containsObject:productId]){
            [details removeObject:detail];
            [self.call.managedObjectContext deleteObject:detail];
        }
        
    }
    self.call.callDetails=details;
}



-(BOOL) hasSignaturePane{
    if([self hasSamplingSection] ){
        if([[self eligibleSampleInventoryLines]count]>0)
            return YES;
    }
    return NO;
}

// if call eligible but there's no inventory to drop, show an empty available samples section but not signature pane
-(BOOL) hasSamplingSection{
    if([self.call isClosed]){
        return [self.call liveSampleDrops].count>0;
    }else{
        return [self.call.account canSampleAtAddress:self.call.address] && [self.call.salesRep canSample];
    }
}


#pragma mark - Static Utilities

// remove sales reps from array that aren't eligible to receive samples
+ (void)filterTransferEligibleReps:(NSMutableArray *)reps {
    if (reps) {
        AGNSalesRep *loggedInUser = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
        [reps removeObject:loggedInUser];
        [reps filterUsingPredicate:[NSPredicate predicateWithFormat:@"(canSample == YES) && (businessUnit == %@)", loggedInUser.businessUnit]];
    }
}

-(BOOL)hasStampedAddress{
    if(self.call.signatureCaptureDate && self.call.stampAddressLine1){
        log4Info(@"Found stamped address");
        return YES;
    }
    return NO;
}

-(BOOL)hasValidAddress{
    if(!self.call.address &&![self hasStampedAddress]){
        log4Warn(@"No address is set on the call!  Warning user");
        UIAlertView *shouldntHappenAlert = [[UIAlertView alloc] initWithTitle:@"Address is missing" message:@"The call is no longer associated with an address; address may have been deleted. Please use Switch HCP to select a new address, or create a new call." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [shouldntHappenAlert show];
        return NO;
    }
    return YES;
}

-(BOOL) hasValidSignature{
    if(self.call.signatureCaptureDate){
        if(self.call.signatureJSON && self.call.signatureJSON.length>0)
            return YES;
        log4Info(@"Signature JSON is null, trying to regenerate from image %@",self.call.signatureImage);
        NSData *imageData = UIImagePNGRepresentation(self.call.signatureImage);
        self.call.signatureJSON = [imageData agnBase64EncodedString];
        log4Info(@"Generated signature JSON %@",[self.call.signatureJSON substringToIndex:100]);

        if(!self.call.signatureJSON || !self.call.signatureJSON.length>0){
            log4Error(@"Unable to regenerate signature JSON!!!");
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"ERROR!!  Unable to export signature" message:@"Unable to send signature to the server; you may be running low on memory.  Please close some applications and try again. " delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
           
            [alertView show];
            return NO;
        }else{
            log4Info(@"Successfully regenerated signature %@",[self.call.signatureJSON substringToIndex:100]);
            return YES;
        }
        
    }
    return YES;
}

// Call this prior to creating any upsert requests so we can verify all necessary fields are set
-(BOOL)isValidForUpsert{

    if(![self hasValidAddress])
        return NO;
    if(![self hasValidSalesRep])
        return NO;
    if(!self.call.salesForceRepId || !self.call.startDate ){
        log4Warn(@"Call is not valid for upsert: %@", self.call.jsonRepresentationForUpdate);
        UIAlertView *shouldntHappenAlert = [[UIAlertView alloc] initWithTitle:@"Unexpected Error" message:@"Error saving call - missing required information.  Please perform a full sync and try again." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [shouldntHappenAlert show];
        return NO;
    }
    
    return YES;
}

-(BOOL)hasValidSalesRep{
    // first try to fix
    if(!self.call.salesRep){
        log4Error(@"Sales rep not set on the call %@, attempting to set it ", self.call);
        AGNSalesRep * salesRep = [AGNAppDelegate sharedDelegate].loggedInSalesRep;
        NSString *lastLoggedIn = [AGNAppDelegate sharedDelegate].lastLoggedInUserSFDCID;
        if(salesRep && salesRep.salesForceId){
            self.call.salesRep = salesRep;
        }else {
            salesRep =  lastLoggedIn ? [[AGNDataManager defaultInstance] getRepForId:lastLoggedIn] : nil;
        }
        if(salesRep){
            log4Info(@"Was able to set the sales rep to %@ for call %@",salesRep,self.call);
            self.call.salesRep = salesRep;
        }else{
            log4Info(@"Unable to find logged in user for call %@",self.call);
        }
    }

    if(!self.call.salesForceRepId){
        if(self.call.salesRep)
            self.call.salesForceRepId = self.call.salesRep.salesForceId;
    }

    if(!self.call.salesForceRepId)
        return NO;
    return YES;
}

-(void)clearCurrentCallInfo{
    log4Info(@"Clearing CurrentCallRestoreStateKey");
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:kCurrentCallRestoreStateKey];
}


-(void)persistCurrentCallInfo{
    AGNCall *currentCall = self.call;
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:kCurrentCallRestoreStateKey];

    NSString *objectId = currentCall.salesForceId;
    if(!objectId)
        objectId = currentCall.guid;
    if(objectId){
        [standardUserDefaults setValue:objectId forKey:kCurrentCallRestoreStateKey];
        log4Info(@"Setting CurrentCallRestoreStateKey to %@",objectId);

    }
}

@end
