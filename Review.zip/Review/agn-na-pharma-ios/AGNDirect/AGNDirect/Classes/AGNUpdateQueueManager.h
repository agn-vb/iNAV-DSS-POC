//
//  AGNUpdateQueueManager.h
//  AGNDirect
//
//  Created by Mark Wells on 9/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGNUpdateTransaction.h"
#import "RestKit.h"

static NSString * AGNUpdateQueueCountChangedNotificationKey = @"AGNUpdateQueueCountChangedNotification";
static NSString * AGNUpsyncInProgressNotificationKey = @"AGNUpsyncInProgressNotification";
static NSString * AGNUpsyncStoppedNotificationKey = @"AGNUpsyncStoppedNotification";
static NSString * AGNUpdateTransactionSuccessfulNotificationKey = @"AGNUpdateTransactionSuccessfulNotification";
static NSString * AGNUpdateTransactionRevertedNotificationKey = @"AGNUpdateTransactionRevertedNotification";

@interface AGNUpdateQueueManager : NSObject <RKRequestDelegate>

+ (AGNUpdateQueueManager *)defaultManager;

- (BOOL)appendTransactions:(NSArray *)transactions;
- (NSUInteger)pendingUpdateCount;

@property (readonly, nonatomic) BOOL isSyncing;

- (void)testInsertNewAddress;

- (void)processQueue; // Tells the queue manager to check if it can start syncing.
- (void)clearQueue; // Only to be used when switching SFDC environments (for SIT/UAT testing only)

@end
