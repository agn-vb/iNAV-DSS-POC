//
//  AGNCallHistoryViewController.m
//  AGNDirect
//
//  Created by Adam McLain on 8/8/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  RIGHT SIDE OF CALLS LANDING PAGE

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



#import "AGNCallHistoryViewController.h"
#import "AGNCallHistoryCell.h"
#import "AGNCallDetailViewController.h"
#import "AGNTableViewHeader.h"
#import "AGNScheduleViewController.h"
#import "AGNSingleLineCell.h"
#import "AGNFormDetailViewController.h"
#import "AGNReprintDetailViewController.h"

@interface AGNCallHistoryViewController ()

@property (nonatomic, strong) NSArray *savedDrafts;
@property (nonatomic, strong) NSMutableArray *closedCallDates;
@property (nonatomic, strong) NSMutableArray *submittedFormDates;
@property (nonatomic, strong) NSArray * filteredClosedCalls;
@property (nonatomic, strong) NSArray * filteredSubmittedForms;
@property (nonatomic, strong) NSArray * allClosedCallDates;
@property (nonatomic, strong) NSArray * allSubmittedFormDates;
@property (nonatomic, strong) NSDateComponents *selectedClosedCallDateComponents;
@property (nonatomic, strong) NSDateComponents *selectedSubmittedFormDateComponents;
@property (nonatomic, assign) BOOL showingAllDrafts;
@property (nonatomic, strong) AGNSimplePopoverTableViewController *closedCallFilterPicker;
@property (nonatomic, strong) AGNSimplePopoverTableViewController *submittedFormFilterPicker;
@property AGNTableViewHeader *savedDraftsHeader;
@property (nonatomic, strong) UIButton *deleteButton;
@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (nonatomic, strong) IBOutlet UIToolbar *toolbar;
@property (nonatomic, strong) NSIndexPath *topIndexPath;

@end

@implementation AGNCallHistoryViewController
@synthesize savedDrafts = _savedDrafts;
@synthesize filteredClosedCalls = _filteredClosedCalls;
@synthesize closedCallDates = _closedCallDates;
@synthesize selectedClosedCallDateComponents = _selectedClosedCallDateComponents;
@synthesize savedDraftsHeader = _savedDraftsHeader;
@synthesize deleteButton = _deleteButton;
@synthesize allClosedCallDates = _allClosedCallDates;
@synthesize toolbar;
BOOL editingSavedDrafts;



//------------------------------------------------------------------------------
#pragma mark -
#pragma mark View Lifecycle
//------------------------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.backgroundColor = [UIColor AGNNorilskSneg];
    self.tableView.separatorColor = [UIColor whiteColor];
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.allowsMultipleSelectionDuringEditing = YES;
    
    log4Debug(@"Loading Call History");
    [self.toolbar setBackgroundImage:[UIImage imageNamed:@"bar-bigblue"] forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsDefault];


    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void) viewWillAppear:(BOOL)animated   {
    [super viewWillAppear:animated];


    
    [self loadData];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleUpdateTransactionRevert)
                                                 name:AGNUpdateTransactionRevertedNotificationKey
                                               object:nil];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateTransactionRevertedNotificationKey object:nil];
}

-(void)updateContentSize{

    log4Info(@"Content Size");
    //hack to prevent horizontal table scrolling
    CGSize newContentSize = self.tableView.contentSize;
    newContentSize.width = self.view.frame.size.width;
    newContentSize.height = self.view.frame.size.height;
    self.tableView.contentSize = newContentSize;
}

-(void)viewDidAppear:(BOOL)animated{
    [self updateContentSize];
    [self.tableView reloadData];
}

-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    self.topIndexPath = [[self.tableView indexPathsForVisibleRows] objectAtIndex:0];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //hack to prevent horizontal table scrolling
    [self updateContentSize];
    [self.tableView reloadData];

    [self.tableView scrollToRowAtIndexPath:self.topIndexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];

    if (self.closedCallFilterPicker!=nil) {
        [self.closedCallFilterPicker dismissPopoverAnimated: NO];
        self.closedCallFilterPicker = nil;
        [self filterClosedCalls];
    }
    if (self.submittedFormFilterPicker!=nil) {
        [self.submittedFormFilterPicker dismissPopoverAnimated: NO];
        self.submittedFormFilterPicker = nil;
        [self filterSubmittedForms];
    }


}

- (void)loadData{
    AGNDataManager *dataManager = [AGNDataManager defaultInstance];
    AGNSalesRep *rep = [[AGNAppDelegate sharedDelegate]loggedInSalesRep];
    log4Info(@"Opening call history view");
    if(rep){
        self.savedDrafts = [dataManager getSavedDraftsForRep:rep];
        self.allClosedCallDates = [dataManager getClosedCallDatesForRep:rep];
        [self configureClosedCallsDates];
        self.filteredClosedCalls = [dataManager getClosedCallsForCurrentRepWithinMonth:self.selectedClosedCallDateComponents];

        NSMutableArray * combinedFormDates = [[NSMutableArray alloc]init];
        [combinedFormDates addObjectsFromArray:[dataManager submittedFormDatesForRep:rep]];
        [combinedFormDates addObjectsFromArray:[dataManager submittedMCDDatesForRep:rep]];

        self.allSubmittedFormDates = [combinedFormDates copy];
        [self configureSubmittedFormDates];

        NSMutableArray * combinedFilteredForms = [[NSMutableArray alloc] init];
        [combinedFilteredForms addObjectsFromArray:[dataManager submittedFormsForCurrentRepWithinMonth:self.selectedSubmittedFormDateComponents]];
        [combinedFilteredForms addObjectsFromArray:[dataManager submittedMCDsForCurrentRepWithinMonth:self.selectedSubmittedFormDateComponents]];

        self.filteredSubmittedForms = [combinedFilteredForms sortedArrayUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:@"startDate" ascending:NO]]];

    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//------------------------------------------------------------------------------
#pragma mark - Private Utilities
//------------------------------------------------------------------------------
- (void)handleUpdateTransactionRevert
{
    [self loadData];
    [self.tableView reloadData];
}


//------------------------------------------------------------------------------
#pragma mark -
#pragma mark UITableView Data Source
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(editingSavedDrafts) // hide closed calls while editing per WF
        return 1;
    if([AGNAppDelegate sharedDelegate].shouldSyncForms)
        return 3;
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    
    if (section == 0) {
        if (self.savedDrafts.count <= 6 || self.showingAllDrafts) {
            return self.savedDrafts.count>0?self.savedDrafts.count:1;
        } else {
            return 6;
        }
    }
    else if (section == 1)
        return self.filteredClosedCalls.count > 0 ? self.filteredClosedCalls.count : 1;
    else
        return self.filteredSubmittedForms.count > 0 ? self.filteredSubmittedForms.count : 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    static NSString *ClosedCallCellIdentifier = @"AGNClosedCallCell";
    
    //Closed Calls
    if (indexPath.section == 1) {
        AGNCallHistoryCell *cell = [tableView dequeueReusableCellWithIdentifier:ClosedCallCellIdentifier];
        if (cell == nil) {
            cell = [[AGNCallHistoryCell  alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:@"AGNCallHistoryCell"];
        }
        if(self.filteredClosedCalls.count > 0){
            AGNCall *call = (AGNCall *)self.filteredClosedCalls[indexPath.row];
            cell.mainLabel.text = [call formattedDateAndHCPName];
            cell.secondaryLabel.attributedText = [call formattedSampleAndDetail];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;


        }else{
            cell.mainLabel.text = AGNPlaceholderText;
            cell.accessoryType = UITableViewCellAccessoryNone;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;

        }
        
        return cell;
    }
    
    // Forms
    if (indexPath.section == 2) {
        AGNCallHistoryCell *cell = [tableView dequeueReusableCellWithIdentifier:ClosedCallCellIdentifier];
        if (cell == nil)
            cell = [[AGNCallHistoryCell  alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:@"AGNCallHistoryCell"];
        
        if (self.filteredSubmittedForms.count > 0){
            AGNHCPActivity * form = (AGNHCPActivity *)self.filteredSubmittedForms[indexPath.row];
            cell.mainLabel.text = [form formattedDateAndHCPName];
            cell.secondaryLabel.attributedText = [form hcpDetailDescription];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
        else {
            cell.mainLabel.text = AGNPlaceholderText;
            cell.accessoryType = UITableViewCellAccessoryNone;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
        }
        
        return cell;
    }
    
    //Planned Calls
    AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:CellIdentifier];
    }
    if([self.savedDrafts count]>0){
        AGNCall *call = (AGNCall *)self.savedDrafts[indexPath.row];
        cell.mainLabel.text = [call formattedDateAndHCPName];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.selectionStyle = UITableViewCellSelectionStyleGray;

    }else{
        cell.mainLabel.text = AGNPlaceholderText;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

    }
    
    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    log4Debug(@"prep for segue %@ , sender :%@", segue, sender);
    if ([sender isKindOfClass:[AGNCall class]]) {
        AGNCallDetailViewController * controller = [segue destinationViewController];
        controller.call = sender;
    }
    else {
        AGNFormDetailViewController * controller = segue.destinationViewController;
        controller.requestForm = sender;
    }
}

- (void)navigateToCall:(AGNCall *)call {
    [self performSegueWithIdentifier:@"CreateCallSegue" sender:call];
}

- (void)navigateToForm:(AGNRequestForm *)form {
    [self performSegueWithIdentifier:@"OpenFormSegue" sender:form];
}

- (void)navigateToMCD:(AGNMarketingDisbursement *)mcd {
    AGNReprintDetailViewController *detailVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AGNReprintDetailViewController"];
    detailVC.marketingDisbursement = mcd;
    [self.navigationController pushViewController:detailVC animated:YES];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:self];
}

-(void) tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(editingSavedDrafts)
        [self setDeleteButtonCount:[[self.tableView indexPathsForSelectedRows]count]];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 2) {
        if(self.filteredSubmittedForms.count == 0)
            return;
        // Forms
        AGNHCPActivity * activity = self.filteredSubmittedForms[indexPath.row];
        if([activity isKindOfClass:[AGNRequestForm class]])
            [self navigateToForm:(AGNRequestForm *)activity];
        else if([activity isKindOfClass:[AGNMarketingDisbursement class]])
            [self navigateToMCD:(AGNMarketingDisbursement *)activity];

    }
    else {
        // Calls
        AGNCall *call = nil;
        
        if (indexPath.section == 0) {
            if(self.savedDrafts.count==0)
                return;
            if(editingSavedDrafts){
                [self setDeleteButtonCount:[[self.tableView indexPathsForSelectedRows]count]];
                return;
            }
            call = self.savedDrafts[indexPath.row];
        } else {
            if(self.filteredClosedCalls.count==0)
                return;
            call = self.filteredClosedCalls[indexPath.row];
        }
        
        [self performSegueWithIdentifier:@"CreateCallSegue" sender:call];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNViewControllerPushedNotificationKey object:nil];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 1 && self.filteredClosedCalls.count > 0) {
        AGNCall *call = self.filteredClosedCalls[indexPath.row];
        return [AGNCallHistoryCell heightForAttributedString:call.formattedSampleAndDetail withWidth:self.view.frame.size.width];
    }
    else if (indexPath.section == 2 && self.filteredSubmittedForms.count > 0)
        return 60.0f;
    else
        return 37.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 28.0f;
}

-(BOOL)showEditButton{
    if (self.savedDrafts.count > 6 && !self.showingAllDrafts){
        return NO;
    }
    return YES;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    AGNTableViewHeader *headerView = [[AGNTableViewHeader alloc] init];
    
    if (section == 0) {
        headerView.leftLabel.text = [NSLocalizedString(@"Draft Calls", @"") uppercaseString];
        
        if (self.savedDrafts.count > 0){
            UIButton *editButton = [[UIButton alloc] init];
            if(editingSavedDrafts){
                [headerView addSecondaryButton:editButton withTitle:@"Cancel"];
                [headerView moveSecondaryToEdge];
                [editButton addTarget:self action:@selector(editTapped) forControlEvents:UIControlEventTouchUpInside];

            }
            else if([self showEditButton]){
                [headerView addSecondaryButton:editButton withTitle:@"Edit"];
            [editButton addTarget:self action:@selector(editTapped) forControlEvents:UIControlEventTouchUpInside];
            }
        }

        if (self.savedDrafts.count > 6) {
            NSString * buttonTitle = [NSString stringWithFormat:@"Show All %d",self.savedDrafts.count ];
            if (self.showingAllDrafts) {
                buttonTitle = @"Show Less";
            }
            [headerView.button addTarget:self action:@selector(displayAllDrafts) forControlEvents:UIControlEventTouchUpInside];
            [headerView setButtonLabelText:buttonTitle];
        } else {
            [headerView setButtonLabelText:@""];
            [headerView moveSecondaryToEdge];
        }
    }
    else if (section == 1) {
        headerView.leftLabel.text = [NSLocalizedString(@"Closed Calls", @"") uppercaseString];
        NSString * buttonTitle = [self stringFromDateComponents:self.selectedClosedCallDateComponents];
        [headerView.button addTarget:self action:@selector(filterClosedCalls) forControlEvents:UIControlEventTouchUpInside];
        if([self.closedCallDates count]==1){
            headerView.button.enabled=NO;
            headerView.button.alpha=.5;
        }
        [headerView setButtonLabelText:buttonTitle];
    }
    else {
        headerView.leftLabel.text = [NSLocalizedString(@"Forms", @"") uppercaseString];
        NSString * buttonTitle = [self stringFromDateComponents:self.selectedSubmittedFormDateComponents];
        [headerView.button addTarget:self action:@selector(filterSubmittedForms) forControlEvents:UIControlEventTouchUpInside];
        if([self.submittedFormDates count]==1){
            headerView.button.enabled=NO;
            headerView.button.alpha=.5;
        }
        [headerView setButtonLabelText:buttonTitle];
    }
    
    
    return headerView;
}

- (float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if(editingSavedDrafts && section==0){
        return 44.0f;
    }
    return 0.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {

    if(editingSavedDrafts && section==0){
        UIView *view = [[UIView alloc]init];
        UIButton *deleteButton = [self deleteButton];
        [self setDeleteButtonCount:[[tableView indexPathsForSelectedRows]count]];
        [view addSubview:deleteButton];
        [deleteButton addTarget:self action:@selector(deleteTapped) forControlEvents:UIControlEventTouchUpInside];
        NSDictionary *dict1 = NSDictionaryOfVariableBindings(view,deleteButton);
        [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(>=3)-[deleteButton]-(>=3)-|" options:0 metrics:nil views:dict1]];
        [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[deleteButton(==200)]" options:0 metrics:nil views:dict1]];
        [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[deleteButton(==35)]" options:0 metrics:nil views:dict1]];
        [view addConstraint:[NSLayoutConstraint constraintWithItem:deleteButton attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [view addConstraint:[NSLayoutConstraint constraintWithItem:deleteButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];


        return view;
    }
    
    return nil;
}

-(void)deleteTapped{
    
    NSArray *paths = [self.tableView indexPathsForSelectedRows];
    NSMutableArray *txns = [NSMutableArray array];
    for (NSIndexPath *path in paths) {
        if (path.section!=0)
            continue;
        AGNCall *call = (AGNCall *)self.savedDrafts[path.row];
        call.toBeDeletedFlag = [NSNumber numberWithBool:YES];
        log4Info(@"Deleting call %@",call);
        AGNUpdateTransactionValueHolder *deleteTxn = [self createManageCallUpdateTransactionForDeletedCall:call];
        if (deleteTxn) {
            [txns addObject:deleteTxn];
        }
    }
    
    [[AGNUpdateQueueManager defaultManager] appendTransactions:txns];
    
    [self loadData];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGNScheduleCallDeletedKey object:self];

    [self editTapped];
}

-(UIButton *)deleteButton{
    if(!_deleteButton){
        UIButton *newButton = [[UIButton alloc]init];
        [newButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [newButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateNormal];
        [newButton setBackgroundImage:[[UIImage imageNamed:@"btn-grey-hi"] stretchableImageWithLeftCapWidth:2 topCapHeight:0] forState:UIControlStateHighlighted];
        [newButton setContentEdgeInsets:UIEdgeInsetsMake(0, 22, 0, 22)];
        newButton.hidden = NO;
        newButton.opaque=YES;
        _deleteButton=newButton;
    }
    return _deleteButton;
}


-(void)setDeleteButtonCount:(NSUInteger)count{
    NSMutableString *buttonText = [[NSMutableString alloc]initWithString:NSLocalizedString(@"DELETE", @"Delete button for edit saved drafts text")];
    if(count>0){
        [buttonText appendFormat:@" (%d)",count];
        self.deleteButton.enabled=YES;
    }else{
        self.deleteButton.enabled=NO;
    }
    NSAttributedString *buttonString = [[NSAttributedString alloc] initWithString:buttonText attributes:[UIButton agnAttributedStringAttributes]];
    [self.deleteButton setAttributedTitle:buttonString forState:UIControlStateNormal];
}



-(void)editTapped{
    editingSavedDrafts = !editingSavedDrafts;
    self.showingAllDrafts = editingSavedDrafts;
    [self.tableView setEditing:editingSavedDrafts];
    [self.tableView reloadData];
}



- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        if(editingSavedDrafts)
            return UITableViewCellEditingStyleDelete | UITableViewCellEditingStyleInsert;
        else
            return UITableViewCellEditingStyleDelete;
    }else{
        return UITableViewCellEditingStyleNone;
    }
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==0){
        return YES;
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        AGNCall *call = (AGNCall *)self.savedDrafts[indexPath.row];
        // Here we need to mark the call as deleted, then create a transaction to send it to SFDC
        call.toBeDeletedFlag = [NSNumber numberWithBool:YES];
        log4Info(@"Deleting call %@",call);

        AGNUpdateTransactionValueHolder *deleteTxn = [self createManageCallUpdateTransactionForDeletedCall:call];
        if (deleteTxn) {
            [[AGNUpdateQueueManager defaultManager] appendTransactions:@[deleteTxn]];
        }
        [self loadData];
        [self.tableView reloadData];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNScheduleCallDeletedKey object:self];
    }
}

// Calls can be delete from this screen : this method will create the request to send to SFDC
- (AGNUpdateTransactionValueHolder *)createManageCallUpdateTransactionForDeletedCall:(AGNCall *)call {
    if (call) {
        call.mobileLastUpdateTimestamp = [NSDate date];
        NSString *deleteJSONRepresentation = [call jsonRepresentationForUpdate];
        AGNUpdateTransactionValueHolder *deleteTxn = [[AGNUpdateTransactionValueHolder alloc] init]; //transient - never saved to core data
        deleteTxn.createTimestamp = [NSDate date];
        deleteTxn.apexWrapperServiceId = [NSNumber numberWithInt:AGNApexWrapperManageCall];
        deleteTxn.currentJSONRepresentation = deleteJSONRepresentation;
        deleteTxn.deleteModelObjectOnRevert = NO;
        deleteTxn.guid = call.guid;
        deleteTxn.modelClassName = @"AGNCall";
        deleteTxn.salesForceId = call.salesForceId;
        
        return deleteTxn;
    }
    return nil;
}

- (void)displayAllDrafts {
    self.showingAllDrafts = !self.showingAllDrafts;
    
    NSRange range = NSMakeRange(0, 1);
    NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
    [self.tableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (void)filterSubmittedForms {
    if (!self.submittedFormFilterPicker) {
        self.submittedFormFilterPicker = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:@"Month"];
        __weak AGNCallHistoryViewController *weakSelf = self;
        
        self.submittedFormFilterPicker.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"CellIdentifier";
            
            UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            [cell agnSetStyledSelectedBackground];
            
            NSDateComponents *dateComponents = [weakSelf.submittedFormDates objectAtIndex:indexPath.row];
            
            cell.textLabel.text = [weakSelf stringFromDateComponents:dateComponents];
            return cell;
        };
        
    }
    
    self.submittedFormFilterPicker.objectArray = self.submittedFormDates;
    self.submittedFormFilterPicker.delegate=self;
    
    CGRect presentingRect = [self.tableView rectForHeaderInSection:2];
    presentingRect.origin.y -= presentingRect.size.height / 2;
    [self.submittedFormFilterPicker presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    
}

- (void)filterClosedCalls {
    if (!self.closedCallFilterPicker) {
        self.closedCallFilterPicker = [[AGNSimplePopoverTableViewController alloc] initWithDelegate:self andTitle:@"Month"];
        __weak AGNCallHistoryViewController *weakSelf = self;
        
        self.closedCallFilterPicker.cellBlock = ^(UITableView *aTableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"CellIdentifier";
            
            UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            [cell agnSetStyledSelectedBackground];

            NSDateComponents *dateComponents = [weakSelf.closedCallDates objectAtIndex:indexPath.row];

            cell.textLabel.text = [weakSelf stringFromDateComponents:dateComponents];
            return cell;
        };

    }
    
    self.closedCallFilterPicker.objectArray = self.closedCallDates;
    self.closedCallFilterPicker.delegate=self;
    
    CGRect presentingRect = [self.tableView rectForHeaderInSection:1];
    presentingRect.origin.y -= presentingRect.size.height / 2;
    log4Info(@"Launching Closed Call Months Filter Popover");
    [self.closedCallFilterPicker presentPopoverFromRect:presentingRect inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    
}

- (NSString *)stringFromDateComponents:(NSDateComponents *)dateComponents{
    
    /*
     10/23/2012 - Reggie Fenton
     Adding null value validation for dateComponent to elimiate a sarcastic exception 
     message that's thrown and handled by the OS when dateComponents is a null value 
     upon first launch of the app after installation
     */
    
    if (dateComponents != nil)
    {
        NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDate * date = [gregorian dateFromComponents:dateComponents];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MMM yyyy"];
        return [dateFormatter stringFromDate:date];

    }
    else return @"";
  }

//  Month/Year selected from popover
- (void)objectSelected:(NSInteger)selected {
    if (self.closedCallFilterPicker) {
        self.selectedClosedCallDateComponents = self.closedCallDates[selected];
        log4Info(@"Selected closed call date %@",self.selectedClosedCallDateComponents);
        self.filteredClosedCalls = [[AGNDataManager defaultInstance]getClosedCallsForCurrentRepWithinMonth:self.selectedClosedCallDateComponents];
        [self.tableView reloadData];
        [self.closedCallFilterPicker dismissPopoverAnimated:YES];
        self.closedCallFilterPicker=nil;
    }
    else {
        self.selectedSubmittedFormDateComponents = self.submittedFormDates[selected];
        log4Info(@"Selected submitted form date components %@",self.selectedSubmittedFormDateComponents);
        
        [self loadData];
        [self.tableView reloadData];
        [self.submittedFormFilterPicker dismissPopoverAnimated:YES];
        self.submittedFormFilterPicker=nil;
        
    }
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
    if ([popoverController isEqual:self.closedCallFilterPicker])
		self.closedCallFilterPicker = nil;
	
    else if (popoverController == self.submittedFormFilterPicker)
        self.submittedFormFilterPicker = nil;
}

- (NSMutableArray *)closedCallDates{
    if(!_closedCallDates) {
        _closedCallDates = [[NSMutableArray alloc]init];
    }
    return _closedCallDates;
}

- (NSMutableArray *)submittedFormDates {
    if(!_submittedFormDates) {
        _submittedFormDates = [[NSMutableArray alloc]init];
    }
    return _submittedFormDates;
}


// Set up the list of Month/Years to display in the closed calls date popover
- (void) configureClosedCallsDates{
    
    // want to include current month even if we have no calls.
    // so do some work to stick this month in the right place in the array
    
    [self.closedCallDates removeAllObjects];

    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    // datecomponents for the current month
    NSDateComponents *thisMonth =  [gregorian components:(  NSYearCalendarUnit | NSMonthCalendarUnit ) fromDate:[NSDate date]];
    
    // calculating the first day of next month
    NSDateComponents *startOfThisMonth =  [gregorian components:(  NSYearCalendarUnit | NSMonthCalendarUnit ) fromDate:[NSDate date]];
    [startOfThisMonth setDay:1];
    NSDate *startDate = [gregorian dateFromComponents:startOfThisMonth];
    NSDateComponents *addMonthComponent = [[NSDateComponents alloc]init];
    [addMonthComponent setMonth:1];
    NSDate *startOfNextMonth = [gregorian dateByAddingComponents:addMonthComponent toDate:startDate options:0];
    
   

    for(NSDictionary *dict in self.allClosedCallDates){
        NSDate *startDate = (NSDate*)dict[@"startDate"];
        if(!startDate)
            continue;
        NSDateComponents *dateComponents =  [gregorian components:(  NSYearCalendarUnit | NSMonthCalendarUnit ) fromDate:startDate];
        // if we've gone into an earlier month, put this month into the array if it's not there already
        // this is for the case when there are no calls scheduled for this month
        if(([startDate compare:startOfNextMonth]==NSOrderedAscending)){
            if(![self.closedCallDates containsObject:thisMonth]){
                [self.closedCallDates addObject:thisMonth];
            }
        }
        if(![self.closedCallDates containsObject:dateComponents]){
            [self.closedCallDates addObject:dateComponents];
        }
        
    }

    // if we didn't already, we should add in the current month now
    if(![self.closedCallDates containsObject:thisMonth]){
        [self.closedCallDates addObject:thisMonth];
    }
    
    if(!self.selectedClosedCallDateComponents){
        self.selectedClosedCallDateComponents = thisMonth;
    }

}

- (void)configureSubmittedFormDates{
    
    // want to include current month even if we have no calls.
    // so do some work to stick this month in the right place in the array
    
    [self.submittedFormDates removeAllObjects];
    
    NSCalendar * gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    // datecomponents for the current month
    NSDateComponents *thisMonth =  [gregorian components:(  NSYearCalendarUnit | NSMonthCalendarUnit ) fromDate:[NSDate date]];
    
    // calculating the first day of next month
    NSDateComponents *startOfThisMonth =  [gregorian components:(  NSYearCalendarUnit | NSMonthCalendarUnit ) fromDate:[NSDate date]];
    [startOfThisMonth setDay:1];
    NSDate *startDate = [gregorian dateFromComponents:startOfThisMonth];
    NSDateComponents *addMonthComponent = [[NSDateComponents alloc]init];
    [addMonthComponent setMonth:1];
    NSDate *startOfNextMonth = [gregorian dateByAddingComponents:addMonthComponent toDate:startDate options:0];
    
    
    
    for (NSDictionary * dict in self.allSubmittedFormDates) {
        NSDate * startDate = (NSDate*)dict[@"startDate"];
        if (!startDate)
            continue;
        
        NSDateComponents * dateComponents =  [gregorian components:(  NSYearCalendarUnit | NSMonthCalendarUnit ) fromDate:startDate];

        // if we've gone into an earlier month, put this month into the array if it's not there already
        // this is for the case when there are no calls scheduled for this month
        if (([startDate compare:startOfNextMonth] == NSOrderedAscending)) {
            if (![self.submittedFormDates containsObject:thisMonth])
                [self.submittedFormDates addObject:thisMonth];
        }
        
        if (![self.submittedFormDates containsObject:dateComponents])
            [self.submittedFormDates addObject:dateComponents];
        
    }
    
    // if we didn't already, we should add in the current month now
    if (![self.submittedFormDates containsObject:thisMonth])
        [self.submittedFormDates addObject:thisMonth];
    
    
    if (!self.selectedSubmittedFormDateComponents)
        self.selectedSubmittedFormDateComponents = thisMonth;
    
}

- (void)reloadContent {
    [self loadData];
    [self.tableView reloadData]; 
}

@end
