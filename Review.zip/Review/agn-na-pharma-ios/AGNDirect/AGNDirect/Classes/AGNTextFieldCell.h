//
//  AGNTextFieldCell.h
//  AGNDirect
//
//  Created by Adam McLain on 10/7/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNTextFieldCell : UITableViewCell
@property (nonatomic, strong, readonly) UILabel *label;
@property (nonatomic, strong, readonly) UITextField *textField;

@end
