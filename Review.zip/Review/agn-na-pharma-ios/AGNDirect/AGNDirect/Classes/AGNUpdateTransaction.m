//
//  AGNUpdateTransaction.m
//  AGNDirect
//
//  Created by Mark Wells on 9/23/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNUpdateTransaction.h"
#import "AGNModelProtocol.h"
#import "AGNAppDelegate.h"


@implementation AGNUpdateTransaction

@dynamic guid;
@dynamic salesForceId;
@dynamic undoJSONRepresentation;
@dynamic currentJSONRepresentation;
@dynamic retryCount;
@dynamic modelClassName;
@dynamic apexWrapperServiceId;
@dynamic createTimestamp;
@dynamic deleteModelObjectOnRevert;
@dynamic mustSucceed;

- (void)initFrom:(AGNUpdateTransactionValueHolder *)transientTxn {
    self.guid = transientTxn.guid;
    self.salesForceId = transientTxn.salesForceId;
    self.undoJSONRepresentation = transientTxn.undoJSONRepresentation;
    self.currentJSONRepresentation = transientTxn.currentJSONRepresentation;
    self.modelClassName = transientTxn.modelClassName;
    self.apexWrapperServiceId = transientTxn.apexWrapperServiceId;
    self.createTimestamp = transientTxn.createTimestamp;
    self.deleteModelObjectOnRevert = transientTxn.deleteModelObjectOnRevert;
    self.mustSucceed = transientTxn.mustSucceed;
    self.retryCount = [NSNumber numberWithInt:0];
}

- (BOOL)updateFrom:(AGNUpdateTransactionValueHolder *)transientTxn {
    // transientTxn createTimestamp must be later than my createTimestamp, have the same wrapper service
    if (![transientTxn isValid] || !([transientTxn.createTimestamp compare:self.createTimestamp] == NSOrderedDescending) || ![self matches:transientTxn]) {
        return NO;
    }
    // Keep the same undoJSON, but update the currentJSON from the transientTxn
    self.currentJSONRepresentation = transientTxn.currentJSONRepresentation;
    // Not sure that this can happen - statement may not be necessary
    if (!self.salesForceId && transientTxn.salesForceId) {
        self.salesForceId = transientTxn.salesForceId;
    }
    return YES;
}

- (BOOL)matches:(AGNUpdateTransactionValueHolder *)txn {
    if (![self isValid] || ![txn isValid]) {
        return NO;
    }
    if (txn.apexWrapperServiceId != self.apexWrapperServiceId) {
        return NO;
    }
    // Assuming here that there is not a mismatch between SFIDs and GUIDs - that should not happen
    return (self.guid && txn.guid && [self.guid isEqualToString:txn.guid]) ||
            (self.salesForceId && txn.salesForceId && [self.salesForceId isEqualToString:txn.salesForceId]);
}

- (BOOL)isValid {
    if (!(self.apexWrapperServiceId && self.currentJSONRepresentation)) {
        return NO;
    }
    if (!(self.guid || self.salesForceId)) {
        return NO;
    }
    return YES;
}

- (NSDictionary *)dictionaryFromJsonRepresentation:(NSString *)jsonRepresentation {
    NSError *error = nil;
    NSData * jsonData = [jsonRepresentation dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
    return jsonDict;
}

- (BOOL) isDeleteRequest{
    if(self.currentJSONRepresentation){
        NSDictionary *jsonDict = [self dictionaryFromJsonRepresentation:self.currentJSONRepresentation];
        if(jsonDict[@"toBeDeleted"]!=nil && ![jsonDict[@"toBeDeleted"] isEqual:[NSNull null]] && [jsonDict[@"toBeDeleted"] boolValue] ){
            return YES;
        }
    }
    return NO;
}

- (void)revert {
    if (!self.modelClassName || !(self.salesForceId || self.guid)) {
        log4Error(@"Unable to revert %@",self);
        return;
    }
    id<AGNModelProtocol> modelObject;
    
    if (self.salesForceId) {
        modelObject = (id<AGNModelProtocol>)[[AGNAppDelegate sharedDelegate].dataManager undeletedObjectOfType:self.modelClassName forId:self.salesForceId];
    }
    if (!modelObject && self.guid) {
        modelObject = (id<AGNModelProtocol>)[[AGNAppDelegate sharedDelegate].dataManager undeletedObjectOfType:self.modelClassName forGuid:self.guid];
    }
    if (modelObject) {

        if ([self.deleteModelObjectOnRevert boolValue]) {  //new object - insert failed - must delete locally
            log4Info(@"About to undo an insert for transaction: %@", self);
            [[AGNAppDelegate sharedDelegate].managedObjectContext deleteObject:modelObject];
            [[AGNAppDelegate sharedDelegate] saveContext];
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionRevertedNotificationKey object:nil];
        }
        else if (self.undoJSONRepresentation) {
            log4Info(@"About to undo an update for transaction: %@", self);
            NSDictionary *jsonDict = [self dictionaryFromJsonRepresentation:self.undoJSONRepresentation];
            [modelObject undoWithDictionary:jsonDict];
            [[AGNAppDelegate sharedDelegate] saveContext];
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionRevertedNotificationKey object:nil];
        }
        else {
            log4Info(@"Unable to revert update: %@", self);
            dispatch_async(dispatch_get_main_queue(), ^{
                NSString * messageString = NSLocalizedString(@"A transaction which can not be reverted failed to save to the server.  It is recommended that you perform a full sync to be sure your data is consistent.", @"Error message in case of failure to upsync a transaction with no undoJSONRepresentation");
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upsync Failed" message:messageString delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"OK") otherButtonTitles:nil];
                [alert show];
            });

        }
    }
    else if([self isDeleteRequest]){
        log4Info(@"About to undo a delete for transaction: %@", self);
        id<AGNModelProtocol> modelEntity = [NSEntityDescription insertNewObjectForEntityForName:self.modelClassName inManagedObjectContext:[AGNAppDelegate sharedDelegate].managedObjectContext];
        NSDictionary *jsonDict = [self dictionaryFromJsonRepresentation:self.currentJSONRepresentation];
        [modelEntity undoWithDictionary:jsonDict];
        [[AGNAppDelegate sharedDelegate] saveContext];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGNUpdateTransactionRevertedNotificationKey object:nil];
    }
}



-(NSString *)jsonForLogging{
    NSError * error;
    NSData * jsonData = [self.currentJSONRepresentation dataUsingEncoding:NSUTF8StringEncoding];

    NSMutableDictionary *jsonDict =  [[NSMutableDictionary alloc]initWithDictionary:[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error]];
    NSString * signatureString = jsonDict[@"HCPsignature"];
    if(signatureString){
        jsonDict[@"HCPsignature"]= [NSString stringWithFormat:@"%@ ...",[signatureString substringToIndex:100] ];
    }
    NSData *outputData = [NSJSONSerialization dataWithJSONObject:jsonDict
                                                         options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                           error:&error];
    return  [[NSString alloc] initWithData:outputData encoding:NSUTF8StringEncoding];
}


@end
