//
//  DDSFSyncItem.m
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "DDSFSyncItem.h"

@implementation DDSFSyncItem

- (void)execute {
    NSAssert(0, @"Needs to be overridden");
}

- (void)cancel {
    NSAssert(0, @"Needs to be overridden");
}


@end
