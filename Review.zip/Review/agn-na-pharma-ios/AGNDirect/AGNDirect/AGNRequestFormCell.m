//
//  AGNRequestFormCell.m
//  AGNDirect
//
//  Created by Satao, Krunal (US - Mumbai) on 5/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNRequestFormCell.h"

@implementation AGNRequestFormCell

@end
