//
//  AGNHCPActivity.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNScheduleEntry.h"

@interface AGNHCPActivity : AGNScheduleEntry

@property (nonatomic, retain) NSDate * mobileCreateTimestamp;
@property (nonatomic, retain) NSDate * mobileLastUpdateTimestamp;

@property (nonatomic, retain) NSString * salesForceAccountId;
@property (nonatomic, retain) NSString * salesForceAddressId;

@property (nonatomic, retain) NSString * signature;
@property (nonatomic, retain) UIImage * signatureImage;
@property (nonatomic, retain) NSDate * signatureCaptureDate;

@property (nonatomic, retain) AGNAccount *account;
@property (nonatomic, retain) AGNAddress *address;

@property (nonatomic, retain) AGNSalesRep *salesRep;

@property (nonatomic, retain) NSString * stampAddressLine1;
@property (nonatomic, retain) NSString * stampAddressLine2;
@property (nonatomic, retain) NSString * stampAddressLine3;
@property (nonatomic, retain) NSString * stampAddressCity;
@property (nonatomic, retain) NSString * stampAddressCountry;
@property (nonatomic, retain) NSString * stampAddressState;
@property (nonatomic, retain) NSString * stampAddressZip;
@property (nonatomic, retain) NSString * stampHCPFirstName;
@property (nonatomic, retain) NSString * stampHCPLastName;
@property (nonatomic, retain) NSString * stampHCPMiddleName;
@property (nonatomic, retain) NSString * stampHCPMDMID;
@property (nonatomic, retain) NSDate * stampLicenseExpirationDate;
@property (nonatomic, retain) NSString * stampLicenseState;
@property (nonatomic, retain) NSString * stampLicenseNumber;
@property (nonatomic, retain) NSString * stampPhysicianSpecialty;
@property (nonatomic, retain) NSString * stampProfessionalDesignation;
@property (nonatomic, retain) NSString * stampRepManagerName;
@property (nonatomic, retain) NSString * stampSalesTeam;
@property (nonatomic, retain) NSString * stampTerritory;

@property (nonatomic, retain) NSString * repFirstName;
@property (nonatomic, retain) NSString * repLastName;
@property (nonatomic, retain) NSString * repMiddleName;


- (NSString *)formattedDateAndHCPName;
- (NSString *)formattedDateAndRepName;
- (NSAttributedString *)hcpDetailDescription;
@end
