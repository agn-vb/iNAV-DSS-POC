//
//  DDSFDownsreamSync.m
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFSyncItem.h"
#import "NSError+DDSFExtensions.h"
#import "DDSFDownstreamSync.h"

NSString * const kDDSFNotificationSyncStarted = @"kDDSFNotificationSyncStarted";
NSString * const kDDSFNotificationSyncStageUpdated = @"kDDSFNotificationSyncStageUpdated";
NSString * const kDDSFNotificationSyncEnded = @"kDDSFNotificationSyncEnded";
NSString * const kDDSFNotificationSyncProgressUpdated = @"kDDSFNotificationSyncProgressUpdated";

NSString * const kDDSFDownstreamSyncMockModeDefaultsKey = @"sync_mock_mode";
NSString * const kDDSFDownstreamSyncMockModeCaptureValue = @"capture";
NSString * const kDDSFDownstreamSyncMockModeLiveValue = @"live";
NSString * const kDDSFDownstreamSyncMockModeReplayPrefix = @"replay:";


@interface DDSFDownstreamSync ()


@end


@implementation DDSFDownstreamSync {
    int _currentItemIndex;
    int _processingTriggersCompleted;
    int _startingUpsyncCount;
}

@synthesize mockMode = _mockMode;
@synthesize mockPath = _mockPath;


- (void) handleAuthenticationFailure{

}

- (void) handleServerBusyError{

}

- (BOOL)canBeCanceled {
    if (_mode == kDDSFDownstreamSyncModeInitial)
        return NO;

    if (_stage == kDDSFDownstreamSyncStageProcess)
        return NO;

    return YES;
}

- (id)init {
    if ((self = [super init])) {
        _processingQueue = [[NSOperationQueue alloc] init];
        _processingQueue.name = @"DDSFSDK.downstream";
        _processingQueue.maxConcurrentOperationCount = 1; // Serial queue!
    }
    return self;
}

- (void)notify:(NSString*)notificationName {
    log4Debug(@"Dispatching %@ with progress %f", notificationName, self.progress);
    dispatch_async(dispatch_get_main_queue(), ^{
        NSNotification * notification = [NSNotification notificationWithName:notificationName object:self];
        [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostWhenIdle coalesceMask:NSNotificationCoalescingOnName | NSNotificationCoalescingOnSender forModes:@[NSRunLoopCommonModes]];
    });
}

- (void)executeNextStep {
    if (self.aborted)
        return;

    switch (self.stage) {
        case kDDSFDownstreamSyncStagePush:


            NSAssert(0, @"Not impletented yet.");
            return; // Pretend it's done

        case kDDSFDownstreamSyncStageFetch:
            if (self.currentItem)
                [self.currentItem execute];

            else {
                // We're done with the fetch stage
                _stage = kDDSFDownstreamSyncStageProcess;
                _currentItemIndex = 0;
                [self notify:kDDSFNotificationSyncStageUpdated];
                if (self.preProcess) {
                    [self.processingQueue addOperationWithBlock:^{
                        if (self.aborted)
                            return;

                        self.preProcess(self);
                        _processingTriggersCompleted++;

                        [self notify:kDDSFNotificationSyncProgressUpdated];
                        [self.processingQueue addOperationWithBlock:^{
                            [self executeNextStep];
                        }];
                    }];
                }
                else
                    [self.processingQueue addOperationWithBlock:^{
                        [self executeNextStep];
                    }];
            }
            break;

        case kDDSFDownstreamSyncStageProcess:
            if (self.currentItem)
                [self.currentItem execute];

            else {
                // We're done unless we have a post-process trigger
                if (self.postProcess) {
                    self.postProcess(self);
                    _processingTriggersCompleted++;
                }

                NSError * error = nil;
                [self.managedContext save:&error];

                _status = kDDSFDownstreamSyncStatusCompleted;
                [self notify:kDDSFNotificationSyncEnded];
                _managedContext = nil; // This should force the destruction of the managed context, assuming this was the last strong reference
            }
            break;

        default:
            NSAssert(0, @"Why are we here?");
            break;
    }
}

- (DDSFSyncItem *)currentItem {
    DDSFSyncItem *item = nil;

    if (_currentItemIndex < self.groups.count) {
        item = self.groups[_currentItemIndex];
    }

    return item;
}

- (void) execute{
    NSAssert(_status == kDDSFDownstreamSyncStatusNew, @"Trying to execute a sync that has already started executing");

    if(self.pendingUpdateCount > 0){
        _startingUpsyncCount=self.pendingUpdateCount;
        _status = kDDSFDownstreamSyncStatusInProgress;
        _stage = kDDSFDownstreamSyncStagePush;
        [self notify:kDDSFNotificationSyncProgressUpdated];
        [self notify:kDDSFNotificationSyncStageUpdated];

        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkUpsync:) name:AGNUpdateQueueCountChangedNotificationKey object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncAbortedOnUpsync:) name:AGNUpsyncStoppedNotificationKey object:nil];

        [[AGNUpdateQueueManager defaultManager] processQueue]; // Just in case


    }else{
        [self downsync];
    }

}

-(void)syncAbortedOnUpsync:(NSNotification*)notification {
    // todo set syncAborted flag
}

- (void)checkUpsync:(NSNotification*)notification {
    if (!self.aborted) {
        // Need to wait for changes to go to the server
        if (self.pendingUpdateCount > 0) {
            [self notify:kDDSFNotificationSyncProgressUpdated];
        }
        else {
            // Done with upsync
            [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpdateQueueCountChangedNotificationKey object:nil];
            [[NSNotificationCenter defaultCenter] removeObserver:self name:AGNUpsyncStoppedNotificationKey object:nil];
            [self notify:kDDSFNotificationSyncStageUpdated];
            [self downsync];
        }
    }
}

- (void)setupMockMode {
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    id value = [defaults objectForKey:kDDSFDownstreamSyncMockModeDefaultsKey];
    if (!value || ![value isKindOfClass:[NSString class]]) // No default value, go with live
        _mockMode = kDDSFRequestMockModeLive;

    else if ([kDDSFDownstreamSyncMockModeLiveValue isEqualToString:value])
        _mockMode = kDDSFRequestMockModeLive;

    else if ([kDDSFDownstreamSyncMockModeCaptureValue isEqualToString:value]) {
        _mockMode = kDDSFRequestMockModeCapture;

        // Need to create a directory with a current timestamp
        NSDateFormatter * df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"yyyyMMddHHmmss"];
        NSString * folderName = [df stringFromDate:[NSDate date]];

        NSArray * pathArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString * documentsFolder = [pathArray lastObject];
        _mockPath = [documentsFolder stringByAppendingPathComponent:folderName];

        // attempt to create the folder
        NSError * error = nil;
        NSFileManager * manager = [NSFileManager defaultManager];
        if (![manager createDirectoryAtPath:_mockPath withIntermediateDirectories:YES attributes:nil error:&error]) {
            log4Error(@"Unable to create directory for capturing live data: %@", error);
            _mockMode = kDDSFRequestMockModeLive;
            _mockPath = nil;
        }
    }
    else if ([value hasPrefix:kDDSFDownstreamSyncMockModeReplayPrefix]) {
        NSString * folderName = [value substringFromIndex:kDDSFDownstreamSyncMockModeReplayPrefix.length];
        _mockPath = [[NSBundle mainBundle] pathForResource:folderName ofType:nil];

        if (_mockPath) {
            // Check if the directory exists

            NSFileManager * manager = [NSFileManager defaultManager];
            BOOL isDirectory;

            if (![manager fileExistsAtPath:_mockPath isDirectory:&isDirectory])
                _mockPath = nil;
            else if (!isDirectory)
                _mockPath = nil;
        }

        if (!_mockPath) {
            log4Error(@"Unable to go into replay mode.  Folder named %@ either not found or is not a folder", folderName);
            _mockMode = kDDSFRequestMockModeLive;
        }
        else
            _mockMode = kDDSFRequestMockModeReplay;
    }
    else // Some weird value, go with live
        _mockMode = kDDSFRequestMockModeLive;
}

- (void)downsync {
    [self setupMockMode];

    // We need to become the delegate and sync property for all the sync items
    for (DDSFSyncItem * item in self.groups) {
        item.delegate = self;
        item.sync = self;
        item.processingQueue = self.processingQueue;
    }


    _status = kDDSFDownstreamSyncStatusInProgress;

    // TODO: implement push stage.
    // TODO: if there was a push stage for this sync, remember to post kDDSFNotificationSyncStageUpdated before fetching
    // This will probably require splitting into several methods, due to the async nature

    _stage = kDDSFDownstreamSyncStageFetch;
    _currentItemIndex = 0;
    [self notify:kDDSFNotificationSyncStarted];

    if (self.preFetch)
        [self.processingQueue addOperationWithBlock:^{
            // Create the managed context. Apparenty it has to be created on the same thread where it will be used.
            _managedContext = [[AGNAppDelegate sharedDelegate] temporaryMOC];


            self.preFetch(self);
            [self executeNextStep];
        }];

    else
        [self.processingQueue addOperationWithBlock:^{
            // Create the managed context. Apparenty it has to be created on the same thread where it will be used.
            _managedContext = [[AGNAppDelegate sharedDelegate] temporaryMOC];

            [self executeNextStep];
        }];
}

- (void)cancel {
    log4Info(@"%s", __PRETTY_FUNCTION__);
    self.aborted = YES;
    [self.currentItem cancel];
    [self.managedContext reset]; // Rollback all changes
    if (self.stage == kDDSFDownstreamSyncStageProcess) {
        __weak DDSFDownstreamSync * weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf syncItem:nil failedWithError:nil];
        });
    }
}

- (void)abortWithError:(NSError *)error {
    log4Info(@"%s", __PRETTY_FUNCTION__);
    self.aborted = YES;
    [self.currentItem cancel];
    [self.managedContext reset]; // Rollback all changes
    __weak DDSFDownstreamSync * weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf syncItem:nil failedWithError:error];
    });
}

- (CGFloat)progress {
    int totalTasks = 0;
    CGFloat completedTasks = 0;

    // Need to calculate progress - by stage
    switch (self.stage) {
        case kDDSFDownstreamSyncStagePush:
            totalTasks = _startingUpsyncCount;
            completedTasks = _startingUpsyncCount-self.pendingUpdateCount;
            break;

        case kDDSFDownstreamSyncStageFetch:
            for (DDSFSyncItem * item in self.groups) {
                totalTasks += item.numberOfFetchTasks;
                completedTasks += item.numberOfFetchTasksCompleted;
            }
            break;

        case kDDSFDownstreamSyncStageProcess:
            if (self.preProcess)
                totalTasks++;

            if (self.postProcess)
                totalTasks++;

            completedTasks = _processingTriggersCompleted;

            for (DDSFSyncItem * item in self.groups) {
                totalTasks += item.numberOfProcessTasks;
                completedTasks += item.numberOfProcessTasksCompleted;
            }
            break;

        default:
            NSAssert(0, @"Why are we here?");
            break;
    }

    if (totalTasks == 0)
        return 1.0f;

    log4Debug(@"Progress calculation: %d out of %d", (int)completedTasks, totalTasks);

    return completedTasks / totalTasks;
}

- (NSString*)labelForStage:(DDSFDownstreamSyncStage)stage {
    switch (stage) {
        case kDDSFDownstreamSyncStagePush:
            return NSLocalizedString(@"Sending changes...", @"Sending changes label");

        case kDDSFDownstreamSyncStageFetch:
            return NSLocalizedString(@"Downloading data...", @"Downloading data label");

        case kDDSFDownstreamSyncStageProcess:
            return NSLocalizedString(@"Processing data...", @"Processing data label");

        default:
            NSAssert1(0, @"Unknown sync stage: %d", stage);
            return @"Doing something...";
    }
}

- (NSString*)labelForMode:(DDSFDownstreamSyncMode)mode {
    switch (mode) {
        case kDDSFDownstreamSyncModeFull:
            return NSLocalizedString(@"Full Sync", @"Full Sync Label");

        case kDDSFDownstreamSyncModeInitial:
            return NSLocalizedString(@"Initial Sync", @"Initial Sync Label");

        case kDDSFDownstreamSyncModeIncremental:
            return NSLocalizedString(@"Delta Sync", @"Incremental Sync Label");

        default:
            NSAssert1(0, @"Unknown sync mode: %d", mode);
            return [NSString stringWithFormat:@"Sync Mode #%d", mode];
    }
}

- (id)freshCopy {
    DDSFDownstreamSync * sync = [[[self class] alloc] init];
    sync.mode = self.mode;
    return sync;
}

#pragma mark -
#pragma mark DDSFSyncItemDelegate

- (void)syncItemCompleted:(DDSFSyncItem*)item {
    _currentItemIndex++; // Move to the next one
    [self notify:kDDSFNotificationSyncProgressUpdated];
    [self.processingQueue addOperationWithBlock:^{
        [self executeNextStep];
    }];
}

- (void)syncItem:(DDSFSyncItem *)step failedWithError:(NSError *)error {
    if (error) { // If error == nil, that means the user cancelled the sync

        _status = kDDSFDownstreamSyncStatusFailed;
        [self notify:kDDSFNotificationSyncEnded];

        if (error.ddsf_category == kDDSFErrorCategoryAuthenticationFailure) {
            // TODO: Need to reauthenticate and try again
            //            [self.client retrySyncAfterAuthentication:self];

        }
        else if (error.ddsf_category != kDDSFErrorCategoryCanceled) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:error.ddsf_categoryName
                                                            message:[NSString stringWithFormat:@"ERROR: %@", error.localizedDescription]
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    }
    else {
        _status = kDDSFDownstreamSyncStatusCancelled;
        [self notify:kDDSFNotificationSyncEnded];
    }
}

#pragma mark -
#pragma mark Error handling overrideables

- (NSError*)detectErrorFromResponse:(NSDictionary*)json statusCode:(int)httpStatus {
    return nil;
}

- (NSError*)categorizeError:(NSError*)error {
    if ([@"INVALID_SESSION_ID" isEqual:error.userInfo[kDDSFErrorCodeKey]])
        return [error ddsf_errorWithCategory:kDDSFErrorCategoryAuthenticationFailure];

    return error;
}


@end

@implementation NSNotification (DDSFDownstreamSyncExtensions)

- (DDSFDownstreamSync*)sync {
    return self.object;
}

@end
