//
//  main.m
//  AGNDirect
//
//  Created by Mark Wells on 7/26/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AGNAppDelegate.h"


//Function prototypes
void __iOS7B5CleanConsoleOutput(void);
int __pyStderrWrite(void *inFD, const char *buffer, int size);


typedef int (*PYStdWriter)(void *, const char *, int);

static PYStdWriter _oldStdWrite;

//Function prototypes
void __iOS7B5CleanConsoleOutput(void);
int __pyStderrWrite(void *inFD, const char *buffer, int size);


int main(int argc, char *argv[])
{
    NSLog(@"**********  There is code in main.m that needs to be removed in beta 6  ******");
    
    //Calling the cleaning function
    __iOS7B5CleanConsoleOutput();
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AGNAppDelegate class]));
    }
}

//implemented functions
int __pyStderrWrite(void *inFD, const char *buffer, int size)
{
    if ( strncmp(buffer, "AssertMacros:", 13) == 0 ) {
        return 0;
    }
    return _oldStdWrite(inFD, buffer, size);
}

void __iOS7B5CleanConsoleOutput(void)
{
    _oldStdWrite = stderr->_write;
    stderr->_write = __pyStderrWrite;
    
}