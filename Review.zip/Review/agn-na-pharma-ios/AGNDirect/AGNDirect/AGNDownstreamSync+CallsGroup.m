//
//  AGNDownstreamSync+CallsGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+CallsGroup.h"
#import "AGNCallContact.h"

@implementation AGNDownstreamSync (CallsGroup)

- (void)buildCallsRelationships {
    NSArray *calls = [self allEntities:@"AGNCall"];
    for (AGNCall * call in calls)
        [call buildRelationships];
    
    NSArray *callDetails = [self allEntities:@"AGNCallDetail"];
    for (AGNCallDetail * detail in callDetails)
        [detail buildRelationships];
    
    NSArray *sampleDrops = [self allEntities:@"AGNSampleDrop"];
    for (AGNSampleDrop * drop in sampleDrops)
        [drop buildRelationships];
    
    NSArray *detailPositions = [self allEntities:@"AGNDetailPosition"];
    for (AGNDetailPosition * pos in detailPositions)
        pos.product = [self productBrandBySFDCID:pos.salesForceProductId];
    
    NSArray *callContacts = [self allEntities:@"AGNCallContact"];
    for (AGNCallContact * contact in callContacts)
        [contact buildRelationships];
}


- (DDSFSyncItem*)callsGroup {
    __weak AGNDownstreamSync * _self = self;

    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];
    
    DDSFSyncStep * incremental = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncCalls)
            return nil;
        
        NSString *distantPastString = @"utctimestamp=2000-01-01 00:00:01";
        NSString *nonDeltaString = @"&isdeltaload=0";
        NSString *deltaTimestampString = distantPastString;
        NSString *isDeltaString = nonDeltaString;
        
        if (_self.syncManager.utcCurrentSyncLastTimestamp) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
            deltaTimestampString = [NSString stringWithFormat:@"utctimestamp=%@", [df stringFromDate:_self.syncManager.utcCurrentSyncLastTimestamp]];
            isDeltaString = @"&isdeltaload=1";
        }
        
        NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/OfflineSync?%@&syncgroup=call%@"], deltaTimestampString, isDeltaString];
        return [DDSFRequest getRequestForPath:urlString];
        
    }];
    incremental.name = @"delta-calls";
    
    incremental.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        log4Info(@"Syncing calls - logged in user timezone is %@", _self.loggedInSalesRep.userTimeZone);
        
        [_self updateEntities:json[@"Calls"] withName:@"AGNCall" whereIdWithKey:@"Id" notIn:_self.addedCallIds];
        [_self updateEntities:json[@"Call_Details"] withName:@"AGNCallDetail" whereIdWithKey:@"Call__c" notIn:_self.addedCallIds];
        [_self updateEntities:json[@"Sample_Drops"] withName:@"AGNSampleDrop" whereIdWithKey:@"Call__c" notIn:_self.addedCallIds];
        [_self updateEntities:json[@"Call_Contacts"] withName:@"AGNCallContact" whereIdWithKey:@"Call__c" notIn:_self.addedCallIds];
    
        NSError * error = nil;
        [_self.managedContext save:&error];
        
        if (error)
            log4Error(@"Got error saving context: %@", error);
    };
    
    [group setSteps:@[incremental] forMode:kDDSFDownstreamSyncModeIncremental];
    
    NSInteger numMonthsOfCallHistoryToRetrieve = [AGNAppDelegate sharedDelegate].monthsCallHistory;
    NSDate *earliestDate = [NSDate dateWithTimeIntervalSinceNow:(-numMonthsOfCallHistoryToRetrieve*30*24*3600)];
    NSString *earliestDateString = [earliestDate agnStringFromDate];
   
    DDSFSyncStep * full = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if ([AGNAppDelegate sharedDelegate].shouldSyncCalls)
            return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"CallsQueryString.txt", earliestDateString, nil];
        else
            return nil;
    }];
    full.name = @"full-calls";
    
    full.estimatedNumberOfPages = 8; // Current average seems to be 6, so 8 is a safe choice
                               
    full.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        log4Info(@"Syncing calls - logged in user timezone is %@", _self.loggedInSalesRep.userTimeZone);
        
        NSArray *callRecords = (NSArray *)json[@"records"];
        [self addEntities:callRecords withName:@"AGNCall"];
        
        // TODO: For now just add to core data, relationships are built once all objects are added: TODO - not true anymore!
        for (NSDictionary *record in callRecords) {
            NSString * sfdcId = [record objectForKey:@"Id"];
            _self.currentCall = [_self callBySFDCID:sfdcId];
            
            NSDictionary *details = (NSDictionary *) record[@"Product_Details__r"];
            if (details && ![details isEqual:[NSNull null]]) {
                [_self addEntities:details[@"records"] withName:@"AGNCallDetail"];
            }
            NSDictionary *samples = (NSDictionary *) record[@"Samples__r"];
            if (samples && ![samples isEqual:[NSNull null]]) {
                [_self addEntities:samples[@"records"] withName:@"AGNSampleDrop"];
            }
            NSDictionary *contacts = (NSDictionary *) record[@"Call_Contacts__r"];
            if (contacts && ![contacts isEqual:[NSNull null]]) {
                [_self addEntities:contacts[@"records"] withName:@"AGNCallContact"];
            }
        }
        [_self resetCalls];
        log4Debug(@"Added %d calls.", [json[@"records"] count]);
        
        NSError * error = nil;
        [_self.managedContext save:&error];
        
        if (error)
            log4Error(@"Got error saving context: %@", error);
    };
    
    [group setSteps:@[full] forMode:kDDSFDownstreamSyncModeFull];
    
    group.postProcess = ^(DDSFDownstreamSync * sync) {
        [_self buildCallsRelationships];
        [_self saveContext];
    };
    
    return group;
}

@end
