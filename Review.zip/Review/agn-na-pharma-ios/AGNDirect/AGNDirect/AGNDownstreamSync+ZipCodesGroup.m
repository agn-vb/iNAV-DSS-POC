//
//  AGNDownstreamSync+ZipCodesGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+ZipCodesGroup.h"

@implementation AGNDownstreamSync (ZipCodesGroup)

- (DDSFSyncItem *)zipCodesGroup {
    __weak AGNDownstreamSync * _self = self;
    
    // Need to create a group since we have different steps depending on incremental vs. full
    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];
    
    
    DDSFSyncStep * full = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest requestWithQueryFromFileNamed:@"ZipCodesQueryString.txt"]];
    full.name = @"full-zipcodes";
    full.estimatedNumberOfPages = 21;
    
    full.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        [_self addEntities:json[@"records"] withName:@"AGNZipCode"];
        log4Info(@"==> fullZipCodes processing");
        NSError * error = nil;
        [sync.managedContext save:&error];
        
        if (error)
            log4Error(@"Got error saving context: %@", error);
    };
    
    [group setSteps:@[full] forMode:kDDSFDownstreamSyncModeFull];
    
    
    DDSFSyncStep * incremental = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        NSString *distantPastString = @"utctimestamp=2000-01-01 00:00:01";
        NSString *nonDeltaString = @"&isdeltaload=0";
        NSString *deltaTimestampString = distantPastString;
        NSString *isDeltaString = nonDeltaString;
        
        if (_self.syncManager.utcCurrentSyncLastTimestamp) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
            deltaTimestampString = [NSString stringWithFormat:@"utctimestamp=%@", [df stringFromDate:_self.syncManager.utcCurrentSyncLastTimestamp]];
            isDeltaString = @"&isdeltaload=1";
        }
        
        NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/OfflineSync?%@&syncgroup=zipcode%@"], deltaTimestampString, isDeltaString];
        return [DDSFRequest getRequestForPath:urlString];
        
    }];
    incremental.name = @"delta-zipcodes";
    
    incremental.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        [_self updateEntities:json[@"Zipcode"] withName:@"AGNZipCode" whereIdWithKey:nil notIn:nil];
        log4Info(@"==> incremental ZipCodes processing");

        NSError * error = nil;
        [sync.managedContext save:&error];
        
        if (error)
            log4Error(@"Got error saving context: %@", error);
    };
    
    [group setSteps:@[incremental] forMode:kDDSFDownstreamSyncModeIncremental];
    
    return group;
}

@end
