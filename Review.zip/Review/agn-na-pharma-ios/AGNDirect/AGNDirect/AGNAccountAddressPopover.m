//
//  AGNSwitchAccountPopoverController.m
//  AGNDirect
//
//  Created by Alexei Peterkin on 5/5/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNAccountAddressPopover.h"
#import "AGNTableView.h"
#import "AGNSingleLineCell.h"
#import "AGNAddressCell.h"
#import "AGNSelectAddressViewController.h"
#import "AGNSelectAccountViewController.h"

static const float kMaxHeightPercentage=.66;

@interface AGNAccountAddressPopover ()

@property (nonatomic, readwrite, copy) AGNAccountAddressSelectedBlock onSelect;

@property (strong, nonatomic, readwrite) AGNSelectAccountViewController * accountsViewController;

@end


@implementation AGNAccountAddressPopover


- (id)initWithTitle:(NSString*)title onSelect:(AGNAccountAddressSelectedBlock)onSelect {
    // Create view controller hierarcy to use with super constructor
    AGNSelectAccountViewController * vc = [[AGNSelectAccountViewController alloc] init];
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    if (vc && nav && (self = [super initWithContentViewController:nav])) {
        // Save navigation controller
        _navigationController = nav;
        
        // Copy the block
        self.onSelect = onSelect;
        
        // Setup accounts view controller
        self.accountsViewController = vc;
        self.accountsViewController.title = title;
        
        vc.popover = self;
        
        return self;
    }
    else
        return nil;
}

- (void)presentPopoverFromRect:(CGRect)rect inView:(UIView *)view permittedArrowDirections:(UIPopoverArrowDirection)arrowDirections animated:(BOOL)animated {
    CGRect screenSize = [[UIScreen mainScreen] bounds];
    CGFloat minSize = fminf(screenSize.size.width, screenSize.size.height);
    _maxHeight = floorf(minSize * 500.0f / 768.0f); // Take it as percentage, to make it survive future form factors
    [self.accountsViewController calculateSize];
    self.popoverContentSize = self.accountsViewController.contentSize;    
    [super presentPopoverFromRect:rect inView:view permittedArrowDirections:arrowDirections animated:animated];
}




@end
