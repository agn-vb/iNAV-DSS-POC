//
//  AGNRequestFormItemCell.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNRequestFormItemCell.h"
#import "QuartzCore/QuartzCore.h"

NSString * const kAGNNotificationRequestFormBeganEditing = @"kAGNNotificationRequestFormBeganEditing";

@interface AGNRequestFormItemCell ()

@property (strong, nonatomic) UIView * tapArea;
@property (strong, nonatomic) UITextView * questionTextView;
@property (strong, nonatomic) UILabel * charactersRemainingLabel;
@property (nonatomic, strong) UITapGestureRecognizer * tap;
@property (nonatomic, strong) UILabel * productPlaceholder;
@property (nonatomic, strong) UILabel * questionPlaceholder;
@property (nonatomic, strong) UIView * divider;

@end

@implementation AGNRequestFormItemCell

- (UIView*)viewForPopover {
    return self.tapArea;
}

- (void)setReadonly:(BOOL)readonly {
    _readonly= readonly;
    
    if (_readonly) {
        if (self.tap) {
            [self.tapArea removeGestureRecognizer:self.tap];
            self.tap = nil;
            self.tapArea.userInteractionEnabled = NO;
        }
        self.charactersRemainingLabel.hidden = YES;
        self.questionTextView.editable = NO;
        self.questionTextView.userInteractionEnabled = NO;
    }
    else {
        if (!self.tap) {
            self.tapArea.userInteractionEnabled = YES;
            self.tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(productLabelTapped:)];
            [self.tapArea addGestureRecognizer:self.tap];
            
        }
        self.questionTextView.editable = YES;
        [self updatePlaceholders];
    }
}

- (void)updatePlaceholders {
    if ([self.item.productName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length > 0)
        self.productPlaceholder.hidden = YES;
    else
        self.productPlaceholder.hidden = NO;
    
    if ([self.item.question stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length > 0)
        self.questionPlaceholder.hidden = YES;
    else
        self.questionPlaceholder.hidden = NO;
}

- (void)update {
    self.productLabel.text = self.item.productName;
    self.questionTextView.text = self.item.question;
    [self updateCharactersRemaining];
    [self updatePlaceholders];
}

- (void)setItem:(AGNRequestFormItem *)item {
    _item = item;
    [self update];
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.productLabel.text = nil;
    self.questionTextView.text = nil;
    self.charactersRemainingLabel.text = nil;
    self.item = nil;
    self.charactersRemainingLabel.hidden = YES;
    self.productHighlighted = NO;
}

- (void)setProductHighlighted:(BOOL)productHighlighted {
    _productHighlighted = productHighlighted;
    
    if (_productHighlighted) {
        self.tapArea.backgroundColor = [UIColor AGNCobalt];
        self.productLabel.textColor = [UIColor AGNSilberLining];
        self.productPlaceholder.textColor = [UIColor AGNSilberLining];
    }
    else {
        self.tapArea.backgroundColor = [UIColor clearColor];
        self.productLabel.textColor = [UIColor AGNGreyMatter];
        self.productPlaceholder.textColor = [UIColor AGNDarkGray];
   }
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor AGNNorilskSneg];
        self.contentView.backgroundColor = [UIColor AGNNorilskSneg];
        
        self.divider = [[UIView alloc] initWithFrame:CGRectZero];
        self.divider.userInteractionEnabled = NO;
        self.divider.backgroundColor = [UIColor whiteColor];
        self.divider.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.divider];
        
        self.tapArea = [[UIView alloc] init];
        self.tapArea.backgroundColor = [UIColor clearColor];
        self.tapArea.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.tapArea];
        
        self.productPlaceholder = [[UILabel alloc] init];
        self.productPlaceholder.font = [UIFont AGNAvenirRoman13];
        self.productPlaceholder.textColor = [UIColor AGNDarkGray];
        self.productPlaceholder.textAlignment = NSTextAlignmentLeft;
        self.productPlaceholder.translatesAutoresizingMaskIntoConstraints = NO;
        self.productPlaceholder.backgroundColor = [UIColor clearColor];
        self.productPlaceholder.numberOfLines = 0;
        self.productPlaceholder.lineBreakMode = NSLineBreakByWordWrapping;
        self.productPlaceholder.preferredMaxLayoutWidth = 100.0f;
        self.productPlaceholder.text = [NSLocalizedString(@"Select product", @"Placeholder for products") uppercaseString];
        [self.contentView addSubview:self.productPlaceholder];
        
        self.productLabel = [[UILabel alloc] init];
        self.productLabel.font = [UIFont AGNAvenirHeavy14];
        self.productLabel.textColor = [UIColor AGNGreyMatter];
        [self.productLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.productLabel.backgroundColor = [UIColor clearColor];
        self.productLabel.numberOfLines = 0; 
        self.productLabel.lineBreakMode = NSLineBreakByWordWrapping;
        [self.productLabel setPreferredMaxLayoutWidth:100.0f];
        [self.contentView addSubview:self.productLabel];
        
        self.questionPlaceholder = [[UILabel alloc] init];
        self.questionPlaceholder.font = [UIFont AGNAvenirRoman13];
        self.questionPlaceholder.textColor = [UIColor AGNDarkGray];
        self.questionPlaceholder.textAlignment = NSTextAlignmentLeft;
        self.questionPlaceholder.translatesAutoresizingMaskIntoConstraints = NO;
        self.questionPlaceholder.backgroundColor = [UIColor clearColor];
        self.questionPlaceholder.text = [NSLocalizedString(@"Enter question", @"Placeholder for questions") uppercaseString];
        [self.contentView addSubview:self.questionPlaceholder];

        self.questionTextView = [[UITextView alloc] init];
        self.questionTextView.font = [UIFont AGNAvenirHeavy14];
        self.questionTextView.textColor = [UIColor AGNGreyMatter];
        self.questionTextView.backgroundColor = [UIColor clearColor];
        self.questionTextView.delegate = self;
        self.questionTextView.returnKeyType = UIReturnKeyDone;
        [self.questionTextView setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.contentView addSubview:self.questionTextView];

        self.charactersRemainingLabel = [[UILabel alloc] init];
        self.charactersRemainingLabel.font = [UIFont AGNAvenirLightFontWithSize:11];
        self.charactersRemainingLabel.textColor = [UIColor AGNGreyMatter];
        self.charactersRemainingLabel.backgroundColor = [UIColor AGNHighliteWhite];
        self.charactersRemainingLabel.alpha=0.6f;
        self.charactersRemainingLabel.textAlignment=NSTextAlignmentCenter;
        self.charactersRemainingLabel.layer.borderColor = [UIColor AGNColorWithRed:195 green:216 blue:252].CGColor;
        self.charactersRemainingLabel.layer.borderWidth = 0.8;
        self.charactersRemainingLabel.numberOfLines=1;
        self.charactersRemainingLabel.layer.shadowColor=[UIColor AGNDropShadow].CGColor;
        [self.charactersRemainingLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.charactersRemainingLabel.hidden = YES;
        [self.contentView addSubview:self.charactersRemainingLabel];
        
        NSDictionary *constraintsViewsDictionary = @{
                                                     @"productLabel" : self.productLabel,
                                                     @"questionTextView" : self.questionTextView,
                                                     @"charactersRemainingLabel" : self.charactersRemainingLabel,
                                                     @"tapArea" : self.tapArea,
                                                     @"productPlaceholder" : self.productPlaceholder,
                                                     @"questionPlaceholder" : self.questionPlaceholder,
                                                     @"divider": self.divider
                                                     };

        
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
            @"|-[productLabel(==100)]-[questionTextView]-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                          @"[charactersRemainingLabel(==100)]-12-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                          @"|-0-[tapArea(==119)][divider(==1)]" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                          @"|-[productPlaceholder(==100)]" options:0 metrics:nil views:constraintsViewsDictionary]];
        
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[divider]|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-2-[questionTextView]-2-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[tapArea]|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[productLabel]" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[productPlaceholder]" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[charactersRemainingLabel(==22)]-4-|" options:0 metrics:nil views:constraintsViewsDictionary]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.productLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.productPlaceholder attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.questionPlaceholder attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.questionPlaceholder attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.questionTextView attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:5]];
        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.questionPlaceholder attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.questionTextView attribute:NSLayoutAttributeWidth multiplier:1.0 constant:-5]];
//        [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.tapArea attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
        
         [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.questionTextView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];

    }
    return self;
}

- (void)productLabelTapped:(id)sender {
    [self.questionTextView resignFirstResponder];
    [self.delegate displayProductPopoverForCell:self forView:self.tapArea];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([@"\n" isEqualToString:text]) {
        // We're done
        [textView resignFirstResponder];
        return NO;
    }
    
    NSUInteger newLength = (textView.text.length - range.length) + text.length;
    
    if(newLength <= kAGNQuestionMaxChars)
    {
        return YES;
    } else {
        NSUInteger emptySpace = kAGNQuestionMaxChars - (textView.text.length - range.length);
        textView.text = [[[textView.text substringToIndex:range.location]
                          stringByAppendingString:[text substringToIndex:emptySpace]]
                         stringByAppendingString:[textView.text substringFromIndex:(range.location + range.length)]];
        return NO;
    }
}


- (void)textViewDidChange:(UITextView *)textView {
    [self updateCharactersRemaining];
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    self.questionPlaceholder.hidden = YES;
    self.charactersRemainingLabel.hidden = NO;
    [[NSNotificationCenter defaultCenter] postNotificationName:kAGNNotificationRequestFormBeganEditing object:textView];
}


-(void)textViewDidEndEditing:(UITextView *)textView {
    // Save the value
    self.item.question = [self.questionTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    [self updatePlaceholders];
    
    // Notify the view controller, so that the view controller can update button enabledment
    [self.delegate questionUpdatedOnCell:self];
    self.charactersRemainingLabel.hidden = YES;
}

-(void)updateCharactersRemaining{
    int length = self.questionTextView.text.length;
    int remaining = kAGNQuestionMaxChars - length;
    self.charactersRemainingLabel.text = [NSString stringWithFormat:@"%d remaining",remaining];

}

- (void)beginEditing {
    [self.questionTextView becomeFirstResponder];
}

- (void)chooseProduct {
    [self productLabelTapped:nil];
}

@end
