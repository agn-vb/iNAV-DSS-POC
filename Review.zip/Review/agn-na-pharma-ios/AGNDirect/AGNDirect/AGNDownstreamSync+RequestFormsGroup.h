//
//  AGNDownstreamSync+RequestFormsGroup.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/24/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync.h"

@interface AGNDownstreamSync (RequestFormsGroup)

- (DDSFSyncItem*)requestFormsGroup;
- (DDSFSyncItem *)requestFormsReferenceGroup;

@end
