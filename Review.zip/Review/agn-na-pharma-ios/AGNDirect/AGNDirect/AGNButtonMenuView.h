//
//  AGNButtonMenuView.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNSimplePopoverTableViewController.h"

typedef BOOL (^AGNCheckBlock) ();
typedef void (^AGNActionBlock) (UIButton *);
typedef NSString * (^AGNButtonTextBlock) ();
typedef NSString * (^AGNActionTitleBlock) ();
typedef int (^NumberButtonsBlock)();
typedef BOOL (^ShowFormsButtonBlock)();

@interface AGNButtonMenuView : UIView <AGNPopoverDelegate, UIPopoverControllerDelegate>

@property (nonatomic, strong) NSString * moreLabel; // Short, for the button
@property (nonatomic, strong) NSString * moreTitle; // Long, for the popover
@property (nonatomic, copy) NumberButtonsBlock numberButtonsBlock;
@property (nonatomic, copy) ShowFormsButtonBlock showFormsButtonBlock;

- (void)addItemWithLabel:(AGNButtonTextBlock)label title:(AGNActionTitleBlock)title visible:(AGNCheckBlock)visibleBlock enabled:(AGNCheckBlock)enabledBlock action:(AGNActionBlock)actionBlock displayUnderForms:(BOOL)displayUnderForms;

@end
