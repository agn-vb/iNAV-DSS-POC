//
//  AGNContactInfoPopoverController.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AGNCategoryHeaders.h"

enum Modes{
    Email=0,
    Phone,
    None
};


typedef int (^AGNContactInfoSelectedIndexBlock) ();
typedef void (^AGNContactInfoOnSelectBlock) (int index);
typedef void (^AGNContactInfoOnAddBlock) (NSString *text);

@interface AGNContactInfoPopoverController :  UIPopoverController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (strong, nonatomic) NSArray *objectArray;
@property (strong, nonatomic) UITextField *addInfoTextField;
@property (strong, nonatomic) UIButton *addButton;

@property (nonatomic, readwrite, copy) AGNContactInfoSelectedIndexBlock selected;
@property (nonatomic, readwrite, copy) AGNContactInfoOnSelectBlock onSelect;
@property (nonatomic, readwrite, copy) AGNContactInfoOnAddBlock onAdd;

@property int mode;

-(id)initWithDelegate:(id<UIPopoverControllerDelegate>)delegate andTitle:(NSString *)title;
-(id)initWithDelegate:(id<UIPopoverControllerDelegate>)delegate andTitle:(NSString *)title andMode:(int)mode;

@end
