//
//  AGNDownstreamSync+UserGroup.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync.h"

@interface AGNDownstreamSync (UserGroup)

- (DDSFSyncItem *)userGroup;

// These methods are internal, but exposed for the purposes of user info sync after session refresh
+ (AGNSalesRep*)syncUserSyncGroup:(NSDictionary *) dictionary moc:(NSManagedObjectContext*)moc;
+ (BOOL)processPermissions:(NSManagedObjectContext*)moc salesRep:(AGNSalesRep*)rep json:(NSDictionary*)json sync:(AGNDownstreamSync*)sync;
+ (DDSFRequest*)userInfoRequest;

@end
