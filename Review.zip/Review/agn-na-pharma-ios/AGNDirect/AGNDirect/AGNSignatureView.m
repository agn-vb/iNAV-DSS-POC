//
//  AGNSignatureView.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/13/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNSignatureView.h"

@interface AGNSignatureView ()

@property (nonatomic, strong) UILabel * acceptedLabel;
@property (nonatomic, strong) UILabel * dottedLine;
@property (nonatomic, strong) UILabel * dateLabel;
@property (nonatomic, strong) UIImageView * signatureImageView;

@end

@implementation AGNSignatureView

- (void)setSignatureCapturedMode:(UIImage*)image {
    self.signatureImageView.image = image;
    self.signatureImageView.hidden = NO;
    self.acceptedLabel.hidden = YES;
    self.dottedLine.hidden = YES;
    self.dateLabel.hidden = YES;
}

- (void)setClosedMode:(NSString*)dateString {
    self.dateLabel.text = dateString ? dateString : @"missing date";
    self.signatureImageView.hidden = YES;
    self.acceptedLabel.hidden = NO;
    self.dottedLine.hidden = NO;
    self.dateLabel.hidden = NO;
}

- (void)setupConstraints {
    [self removeConstraints:self.constraints]; // Remove previons ones, just in case
    
    NSDictionary *constraintsViewsDictionary = @{
                                                 @"accepted" : self.acceptedLabel,
                                                 @"dotted" : self.dottedLine,
                                                 @"date" : self.dateLabel,
                                                 @"image" : self.signatureImageView
                                                 };
    
    
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                          @"|[image]|" options:0 metrics:nil views:constraintsViewsDictionary]];
    
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.signatureImageView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.signatureImageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:self.signatureImageView attribute:NSLayoutAttributeWidth multiplier:192.0/696.0 constant:0]];
    
    
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                          @"|-10-[dotted]-10-|" options:0 metrics:nil views:constraintsViewsDictionary]];
    
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                          @"|-50-[accepted]-10-|" options:0 metrics:nil views:constraintsViewsDictionary]];
    
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                          @"|-10-[date]" options:0 metrics:nil views:constraintsViewsDictionary]];
        
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.dottedLine attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.acceptedLabel attribute:NSLayoutAttributeBaseline relatedBy:NSLayoutRelationEqual toItem:self.dottedLine attribute:NSLayoutAttributeBaseline multiplier:1.0 constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.dateLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.dottedLine attribute:NSLayoutAttributeBottom multiplier:1.0 constant:10.0f]];
}

- (void)setupViews {
    self.signatureImageView = [[UIImageView alloc] init];
    self.signatureImageView.translatesAutoresizingMaskIntoConstraints = NO;
    self.signatureImageView.contentMode = UIViewContentModeScaleAspectFit;
    [self addSubview:self.signatureImageView];
    
    self.dottedLine = [[UILabel alloc] init];
    self.dottedLine.translatesAutoresizingMaskIntoConstraints = NO;
    self.dottedLine.font = [UIFont fontWithName:@"Helvetica" size:26];
    self.dottedLine.backgroundColor = [UIColor clearColor];
    self.dottedLine.lineBreakMode = NSLineBreakByClipping;
    self.dottedLine.text = @"x_________________________________________";
    [self addSubview:self.dottedLine];
    
    self.acceptedLabel = [[UILabel alloc] init];
    self.acceptedLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.acceptedLabel.font = [UIFont fontWithName:@"Helvetica" size:26];
    self.acceptedLabel.backgroundColor = [UIColor clearColor];
    self.acceptedLabel.text = @"Signature Accepted";
    [self addSubview:self.acceptedLabel];
    
    
    self.dateLabel = [[UILabel alloc] init];
    self.dateLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.dateLabel.font = [UIFont systemFontOfSize:16.0];
    self.dateLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:self.dateLabel];
    
    [self setupConstraints];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupViews];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    if ((self = [super initWithCoder:aDecoder])) {
        [self setupViews];
    }
    return self;
}

- (id)init {
    if ((self = [super init])) {
        [self setupViews];
    }
    return self;
}


@end
