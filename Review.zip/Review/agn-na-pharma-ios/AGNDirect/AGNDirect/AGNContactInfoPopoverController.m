//
//  AGNContactInfoPopoverController.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNContactInfoPopoverController.h"
#import "AGNTableView.h"

static const float kMaxHeightPercentage=.66;

@interface AGNContactInfoPopoverController ()
@property (nonatomic, strong) AGNTableView *tableView;
@property (nonatomic, strong) UINavigationController *navigationController;


@end

@implementation AGNContactInfoPopoverController

@synthesize addInfoTextField=_addEmailTextField;
@synthesize addButton=_addButton;


- (UITextField *) addInfoTextField{
    if(!_addEmailTextField){
        _addEmailTextField=[[UITextField alloc]init];
        _addEmailTextField.autocapitalizationType=UITextAutocapitalizationTypeNone;
        _addEmailTextField.returnKeyType = UIReturnKeyDone;
    }
    return _addEmailTextField;
}

- (UIButton * )addButton{
    if(!_addButton){
        _addButton = [[UIButton alloc]init];
    }
    return _addButton;
}

-(id)initWithDelegate:(id<UIPopoverControllerDelegate>)delegate andTitle:(NSString *)title {
    return [self initWithDelegate:delegate andTitle:title andMode:None];
}

-(id)initWithDelegate:(id<UIPopoverControllerDelegate>)delegate andTitle:(NSString *)title andMode:(int)mode{
    AGNTableView *table = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view = table;
    vc.title = title;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    self = [super initWithContentViewController:nav];
    if (self) {
        table.delegate = self;
        table.dataSource = self;
        self.tableView = table;
        self.delegate = delegate;
        self.mode=mode;
        self.navigationController = nav;
        self.addInfoTextField.borderStyle = UITextBorderStyleRoundedRect;
        self.addInfoTextField.font = [UIFont AGNAvenirHeavy16];
        self.addInfoTextField.textColor = [UIColor AGNGreyMatter];
        self.addInfoTextField.delegate = self;

    }
    return self;
}



-(void)setTextFieldDelegate:(id<UITextFieldDelegate>)textFieldDelegate{
    self.addInfoTextField.delegate=textFieldDelegate;
}

- (void)presentPopoverFromRect:(CGRect)rect inView:(UIView *)view permittedArrowDirections:(UIPopoverArrowDirection)arrowDirections animated:(BOOL)animated {
    [self.tableView reloadData];
    [self.tableView layoutIfNeeded];
    CGSize size = [self.tableView contentSize];

    if(view){
        float height = size.height;
        float maxHeight =  view.frame.size.height *kMaxHeightPercentage;
        float width = view.frame.size.width;
        if(size.height > maxHeight)
            height = maxHeight;
        if (height <= self.tableView.contentSize.height) {
            self.tableView.scrollEnabled = NO;
        } else {
            self.tableView.scrollEnabled = YES;
        }
        height += self.navigationController.navigationBar.frame.size.height;
        size = CGSizeMake(width,height);
    }
    if (self.mode==Email) {
        self.popoverContentSize = CGSizeMake(480, size.height);
    }
    else{
        self.popoverContentSize = CGSizeMake(320, size.height);
    }

    [super presentPopoverFromRect:rect inView:view permittedArrowDirections:arrowDirections animated:animated];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section==0)return 1;
    else
        return self.objectArray.count;
}

- (void)addButtonClicked{
    log4Debug([NSString stringWithFormat:@"Add Button clicked %@ ",self.addInfoTextField.text]);
    if(self.addInfoTextField.text.length &&  self.onAdd){
        self.onAdd(self.addInfoTextField.text);
        [self dismissPopoverAnimated:YES];

    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    log4Debug([NSString stringWithFormat:@"Text view did end editing %@ ",textField.text]);
    if(textField.text.length && self.onAdd){
        self.onAdd(textField.text);
        [self dismissPopoverAnimated:YES];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{

//    if(indexPath.section==0){
//        if([self.addInfoTextField canBecomeFirstResponder]){
//             BOOL result = [self.addInfoTextField becomeFirstResponder];
//            log4Info(@"text field becoming first responder, result: %d  is: %d",result,self.addInfoTextField.isFirstResponder);
//            [self.addInfoTextField setNeedsDisplay];
//        }else{
//            log4Info(@"text field can not become first responder right now");
//        }
//    }
    if(indexPath.section==0){
        [self.addInfoTextField performSelector:@selector(becomeFirstResponder) withObject:nil afterDelay:.1];
    }

}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        static NSString *CellIdentifier = @"AddNewCellIdentifier";

        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];

            self.addInfoTextField.translatesAutoresizingMaskIntoConstraints=NO;
            self.addButton.translatesAutoresizingMaskIntoConstraints=NO;
            NSDictionary *constraintsViewsDictionary =
            @{
              @"superview" : cell.contentView ,
              @"textView" : self.addInfoTextField,
              @"addButton": self.addButton
              };

            cell.textLabel.hidden=YES;
            [cell.contentView addSubview:self.addInfoTextField];
            [cell.contentView addSubview:self.addButton];


            self.addInfoTextField.placeholder=@"Add New";
            if(self.mode==Email)
                self.addInfoTextField.keyboardType = UIKeyboardTypeEmailAddress;
            if(self.mode==Phone)
                self.addInfoTextField.keyboardType = UIKeyboardTypePhonePad;

            [self.addButton setTitle:@"+" forState:UIControlStateNormal];
            [self.addButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [self.addButton addTarget:self action:@selector(addButtonClicked) forControlEvents:UIControlEventTouchUpInside];

            [cell.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[textView(>=250)]" options:0 metrics:nil views:constraintsViewsDictionary]];
            [cell.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"[addButton(==20)]" options:0 metrics:nil views:constraintsViewsDictionary]];

            [cell.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-8-[textView]-22-[addButton]-8-|" options:0 metrics:nil views:constraintsViewsDictionary]];

            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.addInfoTextField attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:cell.contentView  attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.addButton attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:cell.contentView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];


        }
        return cell;


    }
    else {
        static NSString *CellIdentifier = @"CellIdentifier";

        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        [cell agnSetStyledSelectedBackground];

        NSString* address = self.objectArray[indexPath.row];
        cell.textLabel.text = address;
        cell.textLabel.font = [UIFont AGNAvenirHeavy14];
        cell.textLabel.textColor = [UIColor AGNGreyMatter];

        int indexSelected = self.selected? self.selected():-1;
        if(indexPath.row==indexSelected){
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }else{
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        return cell;
    }

    return nil;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        [self.addInfoTextField becomeFirstResponder];
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        return;
    }

    if(self.onSelect){
        self.addInfoTextField.text=nil;
        self.onSelect(indexPath.row);

    }

    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    [self dismissPopoverAnimated:YES];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if(self.mode==Phone)
        return [self textField:textField phoneShouldChangeCharactersInRange:range replacementString:string];
    return YES;
}


- (BOOL)textField:(UITextField *)textField phoneShouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    newString = [self stripCharacters:newString];

    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];

    NSNumber *phoneNumber;

    range = NSMakeRange(0, newString.length);

    [numberFormatter getObjectValue:&phoneNumber forString:newString range:&range error:nil];

    if ((newString.length > 0) && (phoneNumber == nil || range.length < newString.length)) {
        return NO;
    }

    NSString *strippedPhoneString = [self formatNumber:newString];

    if ([self stripCharacters:textField.text].length == 10 && strippedPhoneString.length == 10) {
        return NO;
    }

    textField.text = [self formatPhoneNumber:strippedPhoneString];

    return NO;
}


-(NSString *)stripCharacters:(NSString*)number
{
    static NSArray *forbiddenCharecters;
    if (!forbiddenCharecters) {
        forbiddenCharecters = @[@"(", @")", @" ", @"-", @"+"];
    }

    for (NSString *letter in forbiddenCharecters) {
        number = [number stringByReplacingOccurrencesOfString:letter withString:@""];
    }

    return number;
}

-(NSString*)formatNumber:(NSString*)number
{
    number = [self stripCharacters:number];

    int length = [number length];
    if(length > 10)
    {
        number = [number substringFromIndex: length-10];
    }

    return number;
}

-(NSString *)formatPhoneNumber:(NSString *)strippedPhoneString {

    int length = strippedPhoneString.length;

    NSMutableString *formattedString = [[NSMutableString alloc] init];

    if (length <= 3) {
        [formattedString appendFormat:@"%@", strippedPhoneString];
    }

    if(length > 3)
    {
        [formattedString appendFormat:@"(%@)",[strippedPhoneString  substringToIndex:3]];
    }

    if (length > 3 && length < 6) {
        NSRange newRange = NSMakeRange(3, strippedPhoneString.length - 3);
        [formattedString appendFormat:@" %@", [strippedPhoneString substringWithRange:newRange]];
    }

    if(length >= 6)
    {
        NSRange newRange = NSMakeRange(3, 3);
        [formattedString appendFormat:@" %@", [strippedPhoneString substringWithRange:newRange]];
    }


    if (length > 6 && length <= 10) {
        NSRange newRange = NSMakeRange(6, strippedPhoneString.length - 6);
        [formattedString appendFormat:@"-%@", [strippedPhoneString substringWithRange:newRange]];
    }

    return formattedString;
}






@end
