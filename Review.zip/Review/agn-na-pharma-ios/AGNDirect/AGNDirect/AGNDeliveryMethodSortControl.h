//
//  AGNDeliveryMethodSortControl.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/10/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNDeliveryMethodSortControl : UISegmentedControl

@end
