//
//  DDSFNativeRequest.h
//  DDSFTestApp
//
//  Created by Adam McLain on 1/2/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFRequest.h"

@interface DDSFNativeRequest : DDSFRequest

- (id)initWithSFRestRequest:(SFRestRequest *)request;

@end
