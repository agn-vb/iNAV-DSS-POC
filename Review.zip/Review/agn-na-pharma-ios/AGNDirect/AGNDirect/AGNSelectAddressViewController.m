//
//  AGNSelectAddressViewController.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/6/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNSelectAddressViewController.h"
#import "AGNTableView.h"
#import "AGNAddressCell.h"
#import "AGNAccountAddressPopover.h"

@interface AGNSelectAddressViewController ()

@property (nonatomic, strong) AGNTableView * tableView;
@property (nonatomic, strong) NSArray * addresses;
@property (nonatomic, assign) CGSize contentSize;

@end

@implementation AGNSelectAddressViewController

- (void)setAccount:(AGNAccount *)account {
    _account = account;
    self.addresses = [account visibleAddresses];
}

- (id)init {
    if ((self = [super init])) {
        self.title = NSLocalizedString(@"Choose Address", @"Switch HCP - Address Popover Title");
    }
    return self;
}

- (void)loadView {
    self.tableView = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.translatesAutoresizingMaskIntoConstraints = YES;
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    self.view = self.tableView;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.tableView reloadData];
    [self.tableView layoutIfNeeded];
    
    CGSize size = [self.tableView contentSize];
    
    float height = size.height;
    float width = 480.0f;
    
    if (size.height > self.popover.maxHeight)
        height = self.popover.maxHeight;
    
    if (height <= self.tableView.contentSize.height)
        self.tableView.scrollEnabled = NO;
    else
        self.tableView.scrollEnabled = YES;
    
    self.contentSize = CGSizeMake(width,height);
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.contentSizeForViewInPopover = size;  // iOS 6
    } else {
        // Load resources for iOS 7 or later
        self.preferredContentSize = size;  // iOS 7
    }
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    CGSize size = self.contentSize;
    size.height += self.navigationController.navigationBar.frame.size.height - 7.0f; // 7.0f to compensate for popover frame
    
    
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        self.popover.popoverContentSize = size;
    } else {
        [self.popover setPopoverContentSize:size animated:NO];
        //Disabling the animation as it creates bouncing effect.
    } 
    
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.addresses count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString * AddressCellIdentifier = @"AddressCodeCell";
    AGNAddressCell *cell = [tableView dequeueReusableCellWithIdentifier:AddressCellIdentifier];
    if (cell == nil) {
        cell = [[AGNAddressCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:AddressCellIdentifier];
    }
    cell.editMode = NO;
    cell.address = self.addresses[indexPath.row];
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return nil;
}

#pragma mark -
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kAddressCellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    AGNAddress * address = self.addresses[indexPath.row];
    if (self.popover.onSelect)
        self.popover.onSelect(self.account, address);
}


@end
