//
//  DDSFRestKitRequest.m
//  DDSFTestApp
//
//  Created by Adam McLain on 1/2/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFRestKitRequest.h"
#import "SFRestAPI.h"
#import "Errors.h"
#import "RKClient+DDSFExtensions.h"
#import "NSError+DDSFExtensions.h"

@interface DDSFRestKitRequest ()

@property (nonatomic, strong) NSString * resourcePath;
@property (nonatomic, strong) NSObject<RKRequestSerializable> * params;
@property (nonatomic, strong) NSDictionary * queryParams;
@property (nonatomic) RKRequestMethod method;

@property (nonatomic, strong) RKRequest * request;

@end

@implementation DDSFRestKitRequest

- (id)initWithResourcePath:(NSString*)path params:(NSObject<RKRequestSerializable>*)params method:(RKRequestMethod)method {
    if ((self = [super init])) {
        self.resourcePath = path;
        self.params = params;
        self.method = method;
    }
    return self;
}

- (id)initWithResourcePath:(NSString*)path queryParams:(NSDictionary*)queryParams method:(RKRequestMethod)method {
    if ((self = [super init])) {
        self.resourcePath = path;
        self.queryParams = queryParams;
        self.method = method;
    }
    return self;
}

- (void)send {
    self.request = [[SFRestAPI sharedInstance].rkClient requestForPath:self.resourcePath method:self.method params:self.params delegate:self withBackgroundPolicy:RKRequestBackgroundPolicyCancel];
    [self.request sendAsynchronously];
}

- (void)cancel {
    [self.request cancel];
    [super cancel];
}

- (NSError*)categorizeError:(NSError*)error {
    error = [super categorizeError:error];
    if (error.ddsf_category > kDDSFErrorCategoryUncategorized)
        return error;
    
    // path not found, coming from SFDC as body response
    if ([error.userInfo[kDDSFHttpStatusKey] intValue] == 404)
        return [error ddsf_errorWithCategory:kDDSFErrorCategoryRequestError];

    return error; // Uncategorized still, but we cannot do anything
}

- (NSError*)detectErrorFromResponse:(NSDictionary*)jsonResponse statusCode:(int)httpStatus {
    NSError * error = [super detectErrorFromResponse:jsonResponse statusCode:httpStatus];
    if (error)
        return error;
    
    NSString * errorCode = [jsonResponse objectForKey:@"errorCode"];
    
    // Avoid false positives
    if ([errorCode isEqual:[NSNull null]])
        errorCode = nil;
    
    if ([errorCode stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length == 0)
        errorCode = nil;
    
    if (errorCode) {
        NSDictionary * userInfo = @{
                                    kDDSFErrorCodeKey: errorCode,
                                    kDDSFResponseBodyKey: jsonResponse,
                                    NSLocalizedDescriptionKey: [jsonResponse objectForKey:@"message"],
                                    kDDSFHttpStatusKey: [NSNumber numberWithInt:httpStatus]
                                    };
        
        return [NSError errorWithDomain:kDDSFErrorDomain code:kDDSFErrorCodeGeneric userInfo:userInfo];
    }
    
    return nil;
}

#pragma mark - 
#pragma mark RKRequestDelegate

-(NSString *)requestDescription :(RKRequest*)request{

    NSString *requestInfo = nil;
    if([request isKindOfClass:RKRequest.class]){
        requestInfo = [NSString stringWithFormat:@"RKRequest: %@",request.URLRequest.URL];
    }else{
        if([request isKindOfClass:SFRestRequest.class]){
            SFRestRequest * restRequest = (SFRestRequest*)request;
            requestInfo = [NSString stringWithFormat:@"SFRestRequest: %@ %@",restRequest.path?restRequest.path:@"",restRequest.queryParams?restRequest.queryParams:@""];
        }
    }

    return requestInfo;
}

/**
 * Sent when a request has finished loading
 */
- (void)request:(RKRequest *)request didLoadResponse:(RKResponse *)response {
    log4Info(@"Loaded response for request : %@, about to process. ",[self requestDescription:request]);

    NSData * jsonData = response.body;
    NSInteger statusCode = response.statusCode;
    // Ignoring headers for now
    
    if (jsonData.length < 1000) {
        NSString *body = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        log4Debug(@"%@", body);
    }
    else {
        log4Debug(@"Received %d bytes of response", jsonData.length);
    }
    
    id json = nil;
    if (jsonData) {
        NSError *error = nil;
        json = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        if (!json) {
            log4Warn(@"Invalid json response parsing: %@", json);
            [self handleError:[error ddsf_errorWithCategory:kDDSFErrorCategoryServerError]];
            return;
        }
    }
    
    if (!json)
        json = [NSDictionary dictionary]; // Empty response
    
    else if ([json isKindOfClass:[NSArray class]] ){
        if(self.onConvert)
            json = self.onConvert(json);
        else
            json = [json lastObject];
    }
    
    if (![json isKindOfClass:[NSDictionary class]]) {
        log4Warn(@"Resulting json is not a dictionary: %@", json);
        json = nil;
    }
    
    NSError * error = [self detectErrorFromResponse:json statusCode:statusCode];
    if (error) {
        [self handleError:[self categorizeError:error]];
        return;
    }
    
    [self processResponse:json];
}

/**
 * Sent when a request has failed due to an error
 */
- (void)request:(RKRequest *)request didFailLoadWithError:(NSError *)error {
    [self handleError:[self categorizeError:error]];
}

/**
 * Sent to the delegate when a request was cancelled
 */
- (void)requestDidCancelLoad:(RKRequest *)request {
    // Need to create a new error for cancellation
    [self handleError:[NSError ddsf_cancellationError]];
}


/**
 * Sent to the delegate when a request has timed out. This is sent when a
 * backgrounded request expired before completion.
 */
- (void)requestDidTimeout:(RKRequest *)request {
    [self handleError:[NSError ddsf_timeoutError]];
}



@end
