//
//  DDSFRequest.m
//  DDSFTestApp
//
//  Created by Adam McLain on 12/27/12.
//  Copyright (c) 2012 Deloitte Digittal. All rights reserved.
//

/*
 
 Mutlithreading notes:
 
 - SFDC SDK will always return callbacks on the main thread.
 - Mocking response with a timer does not work from operation queues - need to be on the main thread
 - Thus, we're gonna force all processing to be on the main thread.
 - Property methods should be thread safe
 
 */

#import "DDSFRequest.h"
#import "DDSFNativeRequest.h"
#import "DDSFRestKitRequest.h"

#import "SFRestAPI.h"
#import "Errors.h"

@interface DDSFRequest ()
@property (nonatomic, strong) NSTimer * mockResponseTimer;
@property (nonatomic, strong) NSString * nextPageURL;

@property (nonatomic, strong) NSString *tempFilePath;

@end

@implementation DDSFRequest {
    BOOL _isMocked;
}

@synthesize jsonResponse = _jsonResponse;

+(DDSFRequest *)requestWithQueryFromFileNamed:(NSString*)fileName {
    NSError *error = nil;
    NSString *queryStringFilePath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSString *queryString = [NSString stringWithContentsOfFile:queryStringFilePath encoding:NSUTF8StringEncoding error:&error];
    //TODO: handle error
    return [DDSFRequest requestWithSFRestRequest:[[SFRestAPI sharedInstance] requestForQuery:queryString]];
}

+(DDSFRequest *)requestWithQueryFromFileNameWithArgs:(NSString*)fileName, ... {
    va_list argumentList;
    
    NSError *error = nil;
    NSString *queryStringFilePath;
    NSMutableString *queryString;
    id arg;
    int i=0;
    
    va_start(argumentList, fileName);
    queryStringFilePath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    queryString = [[NSString stringWithContentsOfFile:queryStringFilePath encoding:NSUTF8StringEncoding error:&error] mutableCopy];

    while ((arg = va_arg(argumentList, id))) {
        i++;
        [queryString replaceOccurrencesOfString:[NSString stringWithFormat:@"$%d", i] withString:arg options:0 range:NSMakeRange(0,queryString.length)];
    }
    va_end(argumentList);
    //TODO: handle error
    return [DDSFRequest requestWithSFRestRequest:[[SFRestAPI sharedInstance] requestForQuery:queryString]];
}

+(DDSFRequest *)requestWithSFRestRequest:(SFRestRequest *)aSFRestRequest {
    return [[DDSFNativeRequest alloc] initWithSFRestRequest:aSFRestRequest];
}

+ (DDSFRequest *)getRequestForPath:(NSString *)resourcePath {
    return [[DDSFRestKitRequest alloc] initWithResourcePath:resourcePath params:nil method:RKRequestMethodGET];
}

+ (DDSFRequest *)getRequestForPath:(NSString *)resourcePath queryParams:(NSDictionary *)queryParams {
    return [[DDSFRestKitRequest alloc] initWithResourcePath:resourcePath queryParams:queryParams method:RKRequestMethodGET];
}

+ (DDSFRequest *)postRequestForPath:(NSString *)resourcePath params:(NSObject<RKRequestSerializable> *)params {
    return [[DDSFRestKitRequest alloc] initWithResourcePath:resourcePath params:params method:RKRequestMethodPOST];
}

+ (DDSFRequest *)putRequestForPath:(NSString *)resourcePath params:(NSObject<RKRequestSerializable> *)params {
    return [[DDSFRestKitRequest alloc] initWithResourcePath:resourcePath params:params method:RKRequestMethodPUT];
}

+ (DDSFRequest *)deleteRequestForPath:(NSString *)resourcePath {
    return [[DDSFRestKitRequest alloc] initWithResourcePath:resourcePath params:nil method:RKRequestMethodDELETE];
}


- (NSDictionary*)jsonResponse {
    @synchronized (self) {
        if (!_jsonResponse) {
            if (self.tempFilePath) {
                NSError * error = nil;
                NSData *data = [NSData dataWithContentsOfFile:_tempFilePath options:NSDataReadingUncached
                                                        error:&error];
                
                if (data) {
                    id json = [NSJSONSerialization JSONObjectWithData:data
                                                           options:0
                                                             error:&error];
                    if (!json) {
                        log4Warn(@"Error creating json object from data: %@", error);
                    }
                    
                    if (![json isKindOfClass:[NSDictionary class]]) {
                        log4Warn(@"Resulting json is not a dictionary: %@", json);
                        json = nil;
                    }
                    
                    _jsonResponse = json;
                }
                else {
                    log4Warn(@"Error reading data from file %@ : %@", [_tempFilePath lastPathComponent], error);
                }

            }
        }
    }
    return _jsonResponse;
}

- (id)init {
    if ((self = [super init])) {
        self.mockResponseDelay = 0.2f;
        self.mockHTTPStatus = 200;
    }
    
    return self;
}

- (void)execute {
    
    // Force the execution to be on the main thread
    if (![NSThread isMainThread]) {
        [self performSelectorOnMainThread:@selector(execute) withObject:nil waitUntilDone:NO];
        return;
    }

    // TODO: do we need to start the spinner here?
    
    // Mock mode
    if (self.mockMode == kDDSFRequestMockModeReplay) {
        _isMocked = YES;
        
        // Process contents of the first file after a timer
        self.mockResponseTimer = [NSTimer scheduledTimerWithTimeInterval:self.mockResponseDelay
                                                                  target:self
                                                                selector:@selector(mockResponse)
                                                                userInfo:nil
                                                                 repeats:NO];
    } else {
        [self send];
    }
}

- (void)cancel {
    // stop spinner
    // call error method
    
    if (_isMocked) {
        [self.mockResponseTimer invalidate];
        self.mockResponseTimer = nil;
    }
    
    [self deleteResponse];
    [self.delegate request:self failedWithError:nil];
}


- (void)mockResponse {
    self.mockResponseTimer = nil;

    id json = nil;
    NSData *data = nil;
    NSError *error = nil;
    if (self.mockFileNames.count > 0) {

        // Read the first file into a JSON dictionary
        
        NSString * mockFilePath = self.mockFileNames[0];
        if (![mockFilePath hasPrefix:@"/"]) // Not an absolute path, then need to find in the bundle
            mockFilePath = [[NSBundle mainBundle] pathForResource:self.mockFileNames[0] ofType:nil];
        
        if (!mockFilePath) {
            error = [NSError ddsf_errorWithDomain:kDDSFErrorDomain
                                             code:kDDSFErrorCodeMockFailure
                                         userInfo:@{NSLocalizedDescriptionKey: [NSString stringWithFormat:@"Unable to find mock file %@", self.mockFileNames[0]]}
                                         category:kDDSFErrorCategoryRequestError];
            [self handleError:error];
            return;
        }
            

        data = [NSData dataWithContentsOfFile:mockFilePath options:NSDataReadingUncached
                                                error:&error];
        
        if (error) {
            [self handleError:[error ddsf_errorWithCategory:kDDSFErrorCategoryRequestError]];
            return;
        }
    
        if (data) {
            json = [NSJSONSerialization JSONObjectWithData:data
                                                   options:0
                                                     error:&error];
            if (error) {
                // Need to modify the localized description to include debug description
                NSString * debugDescription = error.userInfo[@"NSDebugDescription"];
                if (debugDescription) {
                    NSString * localizedDescription = [NSString stringWithFormat:@"%@\n%@", error.localizedDescription, debugDescription];
                    error = [NSError ddsf_errorWithDomain:error.domain code:error.code userInfo:@{NSLocalizedDescriptionKey: localizedDescription} category:kDDSFErrorCategoryServerError];
                    [self handleError:error];
                }
                else
                    [self handleError:[error ddsf_errorWithCategory:kDDSFErrorCategoryServerError]]; // Response was invalid, so we're pretending it's server problem
                return;
            }
            
            if (!json)
                json = [NSDictionary dictionary];

            else if ([json isKindOfClass:[NSArray class]] && self.onConvert)
                json = self.onConvert(json);

            if (![json isKindOfClass:[NSDictionary class]]) {
                log4Warn(@"Resulting json is not a dictionary: %@", json);
                json = nil;
            }
        }
        else {
            log4Warn(@"Error reading data from file %@ : %@", [mockFilePath lastPathComponent], error);
        }

        if (json) // Set temporary file path to point to the mock file.
            self.tempFilePath = mockFilePath;
    }
    else {
        json = [NSDictionary dictionary]; // Empty response
    }

    if (self.mockError) {
        // Need to throw back the error
        [self handleError:[self categorizeError:self.mockError]];
        return;
    }
    else {
        error = [self detectErrorFromResponse:json statusCode:self.mockHTTPStatus];
        if (error)
            [self handleError:[self categorizeError:error]];
        else
            [self processResponse:json];
    }
}

- (void)handleError:(NSError *)error {
    [_delegate request:self failedWithError:error];
}

- (NSError*)detectErrorFromResponse:(NSDictionary*)jsonResponse statusCode:(int)httpStatus {
    if ([_delegate respondsToSelector:@selector(request:detectErrorFromResponse:statusCode:)])
        return [_delegate request:self detectErrorFromResponse:jsonResponse statusCode:httpStatus];
    
    return nil;
}

- (NSError*)categorizeError:(NSError*)error {
    if (error.ddsf_category > kDDSFErrorCategoryUncategorized)
        return error; // Already categorized
    
    if ([_delegate respondsToSelector:@selector(request:categorizeError:)]) {
        error = [_delegate request:self categorizeError:error];
        if (error.ddsf_category > kDDSFErrorCategoryUncategorized)
            return error; // Already categorized by the delegate
    }
    
    // Core Network errors
    if ([error.domain isEqualToString:@"NSURLErrorDomain"]) {
        switch (error.code) {
            case NSURLErrorUnknown:
            case NSURLErrorBadURL:
            case NSURLErrorUnsupportedURL:
            case NSURLErrorUserAuthenticationRequired: // we're failing to submit the token
                return [error ddsf_errorWithCategory:kDDSFErrorCategoryRequestError];
                
            case NSURLErrorCancelled:
            case NSURLErrorUserCancelledAuthentication: // I don't think we'd ever get this one, but just in case
                return [error ddsf_errorWithCategory:kDDSFErrorCategoryCanceled];
                
            case NSURLErrorHTTPTooManyRedirects:
            case NSURLErrorResourceUnavailable:
            case NSURLErrorRedirectToNonExistentLocation:
            case NSURLErrorBadServerResponse:
            case NSURLErrorZeroByteResource:
            case NSURLErrorCannotDecodeRawData:
            case NSURLErrorCannotDecodeContentData:
            case NSURLErrorCannotParseResponse:
            case NSURLErrorDataLengthExceedsMaximum:
            case NSURLErrorFileDoesNotExist: // this shouldn't really happen as this is for local urls
            case NSURLErrorFileIsDirectory: // same
            case NSURLErrorNoPermissionsToReadFile: // same
            case NSURLErrorSecureConnectionFailed:
            case NSURLErrorServerCertificateHasBadDate:
            case NSURLErrorServerCertificateUntrusted:
            case NSURLErrorServerCertificateHasUnknownRoot:
            case NSURLErrorServerCertificateNotYetValid:
            case NSURLErrorClientCertificateRejected:
            case NSURLErrorClientCertificateRequired:
            case NSURLErrorDownloadDecodingFailedMidStream:
            case NSURLErrorDownloadDecodingFailedToComplete:
                return [error ddsf_errorWithCategory:kDDSFErrorCategoryServerError];
                
            case NSURLErrorTimedOut:
            case NSURLErrorCannotFindHost:
            case NSURLErrorCannotConnectToHost:
            case NSURLErrorNetworkConnectionLost:
            case NSURLErrorDNSLookupFailed:
            case NSURLErrorNotConnectedToInternet:
            case NSURLErrorCannotLoadFromNetwork:
            case NSURLErrorInternationalRoamingOff:
            case NSURLErrorCallIsActive:
            case NSURLErrorDataNotAllowed:
            case NSURLErrorRequestBodyStreamExhausted:
            default:
                return [error ddsf_errorWithCategory:kDDSFErrorCategoryNetworkFailure];
                
                
                /*
                 We're skipping the following as they seem to be non-applicable.  Treating them as network failure through the default: label.
                 
                 NSURLErrorCannotCreateFile = 		kCFURLErrorCannotCreateFile,
                 NSURLErrorCannotOpenFile = 			kCFURLErrorCannotOpenFile,
                 NSURLErrorCannotCloseFile = 		kCFURLErrorCannotCloseFile,
                 NSURLErrorCannotWriteToFile = 		kCFURLErrorCannotWriteToFile,
                 NSURLErrorCannotRemoveFile = 		kCFURLErrorCannotRemoveFile,
                 NSURLErrorCannotMoveFile = 			kCFURLErrorCannotMoveFile,
                 NSURLErrorDownloadDecodingFailedMidStream = kCFURLErrorDownloadDecodingFailedMidStream,
                 NSURLErrorDownloadDecodingFailedToComplete =kCFURLErrorDownloadDecodingFailedToComplete,
                 */
        }
    }
    
    // RestKit errors
    if ([error.domain isEqualToString:RKRestKitErrorDomain]) {
        if (error.code == RKRequestBaseURLOfflineError || error.code == RKRequestConnectionTimeoutError)
            return [error ddsf_errorWithCategory:kDDSFErrorCategoryNetworkFailure];
        else
            
            return [error ddsf_errorWithCategory:kDDSFErrorCategoryServerError];
    }
    
    return error; // Cannot categorize
}


- (void)processResponse:(NSDictionary*)json {
    // TODO: stop spinning
    _totalCount = [[json objectForKey:@"totalSize"] intValue];
    _currentCount = [[json objectForKey:@"records"] count];
    log4Debug(@"Received %d records out of %d", _currentCount, _totalCount);
    if (![[json objectForKey:@"done"] boolValue])
        self.nextPageURL = [json objectForKey:@"nextRecordsUrl"];
    
    _jsonResponse = json;
    
    [_delegate requestCompleted:self withJson:json];

    if (self.shouldSaveResponse) {
        if (_isMocked){
            log4Debug(@"This is mocked response.  Not saving.  Will use %@ for response.", _tempFilePath);
        }
        else
            [self saveResponse:json temporary:YES];
    }
    
    if (self.mockMode == kDDSFRequestMockModeCapture) {
        // Need to save the response to the target path
        [self saveResponse:json temporary:NO];
    }
    
    _jsonResponse = nil; // Free up memory for now
    
}

- (DDSFRequest*)requestForNextPage {
    if (!self.nextPageURL)
        return nil;

    // Prepare an SF request
    SFRestRequest *req = [[SFRestRequest alloc] init];
    NSString *  nextRecordsUrl = [self.nextPageURL substringFromIndex:kSFDefaultRestEndpoint.length];
    [req setPath:nextRecordsUrl];
    [req setMethod:SFRestMethodGET];
    req.endpoint = kSFDefaultRestEndpoint;
    
    // Create DDSFRequest
    DDSFRequest * request = [DDSFRequest requestWithSFRestRequest:req];
    
    // Configure DDSFRequest with mock parameters
    request.mockResponseDelay = self.mockResponseDelay;
    request.mockHTTPStatus = self.mockHTTPStatus;
    request.shouldSaveResponse = self.shouldSaveResponse;
    
    // For mock files, copy all the filenames starting with the second.
    if (self.mockFileNames.count > 1)
        request.mockFileNames = [self.mockFileNames subarrayWithRange:NSMakeRange(1, self.mockFileNames.count-1)];
    
    return request;
}

- (void)saveResponse:(id)json temporary:(BOOL)isTemp {
    if (!json)
        return; // Nothing to save

    NSError *error = nil;
    NSData * jsonData = [NSJSONSerialization dataWithJSONObject:json
                                                        options:0
                                                          error:&error];

    if (!jsonData)
        return; // Nothing to save
    
    if (isTemp) {
        NSString * tempPath = NSTemporaryDirectory();
        
        NSFileManager *manager = [[NSFileManager alloc] init];
        BOOL isDirectory;
        
        // if the folder doesn't exist...
        if (![manager fileExistsAtPath:tempPath isDirectory:&isDirectory]) {
            // attempt to create the folder
            if (![manager createDirectoryAtPath:tempPath withIntermediateDirectories:YES attributes:nil error:NULL]) {
                // and return nil on error
                tempPath = nil;
            }
        } else {
            // or it does exist, and isn't a directory...
            if (!isDirectory) {
                // return a nil path
                tempPath = nil;
            }
        }

        if (tempPath) {
            NSString * filename = [[NSUUID UUID] UUIDString];
            
            self.tempFilePath = [tempPath stringByAppendingPathComponent:filename];
            [jsonData writeToFile:_tempFilePath atomically:YES];

            log4Debug(@"Saved data to temporary file %@", _tempFilePath);
        }
        else
            log4Warn(@"Unable to save response into a temporary file - invalid temporary directory");
    }
    else if (self.mockPath)
        [jsonData writeToFile:self.mockPath atomically:YES];
}

- (void)deleteResponse {
    if (self.tempFilePath && !_isMocked) {
        // Delete the file
        NSError * error = nil;
        [[NSFileManager defaultManager] removeItemAtPath:_tempFilePath error:&error];
        
        if (error)
            log4Warn(@"Error deleting temporary file %@: %@", _tempFilePath, error);
    }
}

- (void)send {
    NSAssert(0, @"Need to override");
}

- (void)dealloc {
    [self.mockResponseTimer invalidate];
    [self deleteResponse];
}

@end
