//
//  NSError+DDSFExtensions.m
//  DDSFSDK
//
//  Created by Alexey Piterkin on 3/12/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "NSError+DDSFExtensions.h"

NSString * const kDDSFErrorDomain = @"kDDSFErrorDomain";
NSString * const kDDSFResponseBodyKey = @"kDDSFResponseBodyKey";
NSString * const kDDSFErrorCodeKey = @"kDDSFErrorCodeKey";
NSString * const kDDSFHttpStatusKey = @"kDDSFHttpStatusKey";
NSString * const kDDSFCategoryKey = @"kDDSFCategoryKey";

@implementation NSError (DDSFExtensions)

- (DDSFErrorCategory)ddsf_category {
    return [self.userInfo[kDDSFCategoryKey] intValue];
}

- (NSString*)ddsf_categoryName {
    switch (self.ddsf_category) {
        case kDDSFErrorCategoryNetworkFailure:
            return NSLocalizedString(@"Network Error", @"Network Error Title");
            
        case kDDSFErrorCategoryAuthenticationFailure:
            return NSLocalizedString(@"Authentication Error", @"Authentication Error Title");
            
        case kDDSFErrorCategoryServerError:
            return NSLocalizedString(@"Server Error", @"Server Error Title");
            
        case kDDSFErrorCategoryRequestError:
            return NSLocalizedString(@"Invalid Request", @"Request Error Title");
            
        case kDDSFErrorCategoryCanceled:
            return NSLocalizedString(@"Aborted", "Canceled Error Title");
            
        default:
            return NSLocalizedString(@"Error", @"Unclassifed Error Title");
    }
    
}

+ (NSError*)ddsf_cancellationError {
    return [NSError ddsf_errorWithDomain:kDDSFErrorDomain
                                    code:kDDSFErrorCodeRequestCanceled
                                userInfo:@{NSLocalizedDescriptionKey: NSLocalizedString(@"Server request aborted", @"User message for when request is cancelled")}
                                category:kDDSFErrorCategoryCanceled];
}

+ (NSError*)ddsf_timeoutError {
    return [NSError ddsf_errorWithDomain:kDDSFErrorDomain
                                    code:kDDSFErrorCodeRequestTimeout
                                userInfo:@{NSLocalizedDescriptionKey: NSLocalizedString(@"Server request timed out", @"User message for when request is timed out")}
                                category:kDDSFErrorCategoryNetworkFailure];
}


- (NSError*)ddsf_errorWithCategory:(DDSFErrorCategory)category {
    return [NSError ddsf_errorWithDomain:self.domain code:self.code userInfo:self.userInfo category:category];
}

+ (id)ddsf_errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(NSDictionary *)dict category:(DDSFErrorCategory)category {
    NSMutableDictionary * userInfo;
    if (dict)
        userInfo = [NSMutableDictionary dictionaryWithDictionary:dict];
    else
        userInfo = [NSMutableDictionary dictionaryWithCapacity:1];
    
    userInfo[kDDSFCategoryKey] = [NSNumber numberWithInt:category];
    
    return [NSError errorWithDomain:domain code:code userInfo:userInfo];
}

- (int)httpStatus{
    NSNumber * number =  self.userInfo[kDDSFHttpStatusKey];
    return [number intValue];
}


@end
