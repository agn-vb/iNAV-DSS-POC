//
//  AGNDownstreamSync+SalesTeamGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+SalesTeamGroup.h"

@implementation AGNDownstreamSync (SalesTeamGroup)

- (RKRequestSerialization *)requestSerializationForRatingsQuery {
    
    NSError *error = nil;
    NSDictionary *dict = @{@"AccountIds" : [self.allHCPIds allObjects], @"SalesTeamIds" : @[self.loggedInSalesRep.salesForceSalesTeamId], @"Rating_Types" : @[@"FREQ", @"DECILE"] };
    log4Info(@"requestSerializationForRatingsQuery, for sales team %@ and %d ids",self.loggedInSalesRep.salesForceSalesTeamId, [self.allHCPIds count]);
    NSData *data = [dict JSONDataWithOptions:JKSerializeOptionNone
                                       error:&error];
    log4Debug(@"converted to JSON: %@", [[NSString alloc] initWithData:data
                                                              encoding:NSUTF8StringEncoding]);
    if (error) {
        log4Error(@"Error converting accountIds:%@ to json: %@", self.allHCPIds, error);
        return nil;
    }
    
    return [RKRequestSerialization serializationWithData:data
                                                MIMEType:RKMIMETypeJSON];
}

- (DDSFSyncItem*)salesTeamGroup {
    __weak AGNDownstreamSync * _self = self;
    
    DDSFSyncStep * step = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        NSString *distantPastString = @"utctimestamp=2000-01-01 00:00:01";
        NSString *nonDeltaString = @"&isdeltaload=0";
        NSString *deltaTimestampString = distantPastString;
        NSString *isDeltaString = nonDeltaString;
        
        if (_self.syncManager.utcCurrentSyncLastTimestamp) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
            deltaTimestampString = [NSString stringWithFormat:@"utctimestamp=%@", [df stringFromDate:_self.syncManager.utcCurrentSyncLastTimestamp]];
            isDeltaString = @"&isdeltaload=1";
        }
        
        NSInteger numMonthsOfCallHistoryToRetrieve = [AGNAppDelegate sharedDelegate].monthsCallHistory;
        numMonthsOfCallHistoryToRetrieve++; // get an extra one for safety
        
        NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/OfflineRatingSync?%@&syncgroup=rating%@&month=%d"],
                                                           distantPastString, nonDeltaString, numMonthsOfCallHistoryToRetrieve];
        return [DDSFRequest postRequestForPath:urlString params:[_self requestSerializationForRatingsQuery]];
    }];
    step.name = @"sales-team";
    
    step.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        log4Info(@"==> sales team processing");

        [_self addEntities:json[@"Rating"] withName:@"AGNHCPRating"];
        [_self addEntities:json[@"Detail_Positions"] withName:@"AGNDetailPosition"];
        [_self addEntities:json[@"Sample_Permissions"] withName:@"AGNSamplePermission"];
        [_self addEntities:json[@"DetailBlacklist"] withName:@"AGNDetailBlacklist"];
    };
    
    step.postProcess = ^(DDSFDownstreamSync * sync) {
        // Rebuild ratings relations
        NSArray *accounts = [_self allEntities:@"AGNAccount"];
        for(AGNAccount *account in accounts){
            NSArray *ratings = [_self objectsOfType:@"AGNHCPRating" forAccount:account.salesForceId];
            log4Trace(@"Adding %d ratings for %@ ", [ratings count], [account formattedName]);
            
            for(AGNHCPRating * rate in ratings){
                if([rate.salesTeamName isEqualToString:_self.loggedInSalesRep.salesTeamName]){
                    if([rate.ratingType isEqualToString:kRatingKey])
                        account.sort_rating = rate.ratingValue;
                    if([rate.ratingType isEqualToString:kFrequencyKey]){
                        NSNumberFormatter *nf = [[NSNumberFormatter alloc]init];
                        account.sort_frequency = [nf numberFromString:rate.ratingValue];
                    }
                }
            }
        }
        
        NSArray * permissions = [self allEntities:@"AGNSamplePermission"];
        for (AGNSamplePermission * perm in permissions){
            perm.product = [self productSKUBySFDCID:perm.salesForceProductId];
            perm.salesRep = [self salesRepBySFDCID:perm.salesForceSalesRepId];
        }
 
        NSArray * blacklistItems = [self allEntities:@"AGNDetailBlacklist"];
        for (AGNDetailBlacklist *item in blacklistItems) {
            item.product = (AGNProductBrand *)[self productBrandBySFDCID:item.salesForceProductId];
            item.account = [self accountBySFDCID:item.salesForceAccountId];
            log4Info(@"blacklisting %@ to %@ %@ %@",item.product.productDescription,item.account.salesForceId,item.account.firstName, item.account.lastName);
        }

        [_self saveContext];
    };
    
    return step;
}

@end
