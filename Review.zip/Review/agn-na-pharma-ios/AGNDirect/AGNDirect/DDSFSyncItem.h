//
//  DDSFSyncItem.h
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>

@class DDSFDownstreamSync;

typedef void (^DDSFSyncCallback) (DDSFDownstreamSync * sync);

@class DDSFSyncItem;

@protocol DDSFSyncItemDelegate <NSObject>
@required

- (void)syncItemCompleted:(DDSFSyncItem*)item;

/**
 * If request is canceled, error will be nil.
 */
- (void)syncItem:(DDSFSyncItem *)step failedWithError:(NSError *)error;

@end



@interface DDSFSyncItem : NSObject

@property (nonatomic, strong) NSString * name; // This name will be used for logging and for capturing/replaying sync data.
                                               // Since this name can be part of filenames, make it filename-compatible.  Spaces not recommended.

@property (nonatomic, weak) id <DDSFSyncItemDelegate> delegate;

@property (nonatomic, weak) DDSFDownstreamSync * sync;

@property (nonatomic, copy) DDSFSyncCallback preFetch;
@property (nonatomic, copy) DDSFSyncCallback postFetch;
@property (nonatomic, copy) DDSFSyncCallback preProcess;
@property (nonatomic, copy) DDSFSyncCallback postProcess;

- (void)execute; // Will execute based on the sync's stage
- (void)cancel;

@property (nonatomic, readonly) int numberOfFetchTasks;
@property (nonatomic, readonly) int numberOfFetchTasksCompleted;
@property (nonatomic, readonly) int numberOfProcessTasks;
@property (nonatomic, readonly) int numberOfProcessTasksCompleted;

@property (nonatomic, weak) NSOperationQueue * processingQueue;

@end
