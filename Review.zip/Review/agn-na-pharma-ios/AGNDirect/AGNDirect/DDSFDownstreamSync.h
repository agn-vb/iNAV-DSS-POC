//
//  DDSFDownsreamSync.h
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDSFSyncItem.h"
#import <CoreData/CoreData.h>
#import "DDSFRequest.h"

// Notifications

extern NSString * const kDDSFNotificationSyncStarted;
extern NSString * const kDDSFNotificationSyncStageUpdated;
extern NSString * const kDDSFNotificationSyncEnded;
extern NSString * const kDDSFNotificationSyncProgressUpdated;

typedef enum {
    kDDSFDownstreamSyncStagePush = 0,
    kDDSFDownstreamSyncStageFetch,
    kDDSFDownstreamSyncStageProcess
} DDSFDownstreamSyncStage;

typedef enum {
    kDDSFDownstreamSyncModeIncremental = 0, // We want incremental by default
    kDDSFDownstreamSyncModeFull,
    kDDSFDownstreamSyncModeInitial
} DDSFDownstreamSyncMode;

typedef enum {
    kDDSFDownstreamSyncStatusNew = 0,
    kDDSFDownstreamSyncStatusInProgress,
    kDDSFDownstreamSyncStatusCompleted,
    kDDSFDownstreamSyncStatusFailed,
    kDDSFDownstreamSyncStatusCancelled
} DDSFDownstreamSyncStatus;


extern NSString * const kDDSFDownstreamSyncMockModeDefaultsKey; // 'sync_mock_mode'
extern NSString * const kDDSFDownstreamSyncMockModeCaptureValue; // 'capture'
extern NSString * const kDDSFDownstreamSyncMockModeLiveValue; // 'live'
extern NSString * const kDDSFDownstreamSyncMockModeReplayPrefix; // 'replay:', followed by a folder name 

@interface DDSFDownstreamSync : NSObject <DDSFSyncItemDelegate>

@property (nonatomic, strong) NSArray * groups;
@property (nonatomic, readonly) CGFloat progress;
@property (nonatomic) DDSFDownstreamSyncMode mode;
@property (nonatomic, readonly) DDSFDownstreamSyncStage stage;
@property (nonatomic, readonly) DDSFDownstreamSyncStatus status;
@property (nonatomic, readonly) int pendingUpdateCount;

@property (nonatomic, readonly) BOOL canBeCanceled;

/**
 * If assigned, this trigger will execute before fetch begins. 
 *
 * This would be an ideal place to setup internal sync variables to their initial state.  
 *
 * This trigger does not count towards the total number of fetch steps for the purpose of progress tracking.
 */
@property (nonatomic, copy) DDSFSyncCallback preFetch;

/**
 * If assigned, this trigger will execute after fetch ends successfully, but before processing begins.
 *
 * Good place to clean up database items that will be replaced by the fetched data.
 *
 * This trigger DOES count towards the total number of processing steps for the purpose of progress tracking.
 */
@property (nonatomic, copy) DDSFSyncCallback preProcess;

/**
 * If assigned, this trigger will execute after processing steps are done executing.
 *
 * Good place to clean up after sync.
 *
 * This trigger DOES count towards the total number of processing steps for the purpose of progress tracking.
 */
@property (nonatomic, copy) DDSFSyncCallback postProcess;


/**
 * All processing will happen on this queue serially (to ensure thread safety of managed object contexts, if they are used).
 */
@property (nonatomic, readonly) NSOperationQueue * processingQueue;

/**
 * While the sync is executing, this property will point to the Core Data managed object context created specifically for this sync.
 *
 * The property is assigned automatically.  At the end, the context will be saved and destroyed.
 */
@property (nonatomic, readonly, strong) NSManagedObjectContext * managedContext;

- (void)execute;
- (void)cancel;
- (void)abortWithError:(NSError*)error;
- (void) handleAuthenticationFailure;
- (void) handleServerBusyError;


@property (nonatomic) BOOL aborted;



/** name: methods to override */

/**
 * This method should return a fresh sync with the same configuration as current sync.
 *
 * By default it will only copy the mode of the sync. If subclasses introduce other important properties, they should be copied in the overridden method, but remember to
 * call the super method first and amend the returned instance.
 *
 * @return a copy of the current sync that is in its initial state (as if before attempting to sync)
 */
- (id)freshCopy;


- (NSError*)detectErrorFromResponse:(NSDictionary*)json statusCode:(int)httpStatus;
- (NSError*)categorizeError:(NSError*)error;

- (NSString*)labelForStage:(DDSFDownstreamSyncStage)stage;
// If you don't want to display the mode, override the method to always return nil
- (NSString*)labelForMode:(DDSFDownstreamSyncMode)mode;

/////// Methods for mock mode
@property (nonatomic, readonly) DDSFRequestMockMode mockMode;
@property (nonatomic, readonly, strong) NSString * mockPath; // Only for capture and replay modes

@end

// Convenience property (really just for compilation, as it type-casts the object property
@interface NSNotification (DDSFDownstreamSyncExtensions)

@property (nonatomic, readonly) DDSFDownstreamSync * sync;

@end

