//
//  DDSFRestKitRequest.h
//  DDSFTestApp
//
//  Created by Adam McLain on 1/2/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFRequest.h"
#import "RKRequest.h"

@interface DDSFRestKitRequest : DDSFRequest <RKRequestDelegate>

- (id)initWithResourcePath:(NSString*)path params:(NSObject<RKRequestSerializable>*)params method:(RKRequestMethod)method;
- (id)initWithResourcePath:(NSString*)path queryParams:(NSDictionary*)queryParams method:(RKRequestMethod)method;

@end
