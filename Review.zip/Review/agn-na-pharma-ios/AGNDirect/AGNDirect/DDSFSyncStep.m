//
//  DDSFSyncStep.m
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFSyncStep.h"
#import "DDSFDownstreamSync.h"

@interface DDSFDownstreamSync ()
- (void)notify:(NSString*)notificationName;
@end

@interface DDSFSyncStep ()

@property (nonatomic, strong) NSMutableArray * requests;
@property (nonatomic, strong) DDSFRequest * currentRequest;
@property (nonatomic, copy) DDSFRequestBlock requestBlock;

@end


@implementation DDSFSyncStep {
    int _currentStep;
    int _processingBlocksCompleted;
    int _estimatedNumberOfRequests;
}

- (id)initWithRequest:(DDSFRequest *)request {
    if ((self = [super init])) {
        _request = request;
        request.delegate = self;
        request.shouldSaveResponse = YES;
        self.requests = [NSMutableArray array];
        self.estimatedNumberOfPages = 1;
    }
    return self;
}

- (id)initWithRequestBlock:(DDSFRequestBlock)requestBlock {
    if ((self = [super init])) {
        self.requestBlock = requestBlock;
        self.requests = [NSMutableArray array];
        self.estimatedNumberOfPages = 1;
    }
    return self;
}


- (void)finishFetching {
    if (self.sync.aborted)
        return;

    if (self.postFetch)
        self.postFetch(self.sync);
    
    [self.delegate syncItemCompleted:self];
}

- (void)finishProcessing {
    if (self.sync.aborted)
        return;

    if (self.postProcess) {
        self.postProcess(self.sync);
        _processingBlocksCompleted++;
        [self.sync notify:kDDSFNotificationSyncProgressUpdated];
    }
    
    [self.delegate syncItemCompleted:self];
}

- (void)processNextRequest {
    if (self.sync.aborted)
        return;
    
    DDSFRequest * request = nil;
    if (_currentStep < self.requests.count) {
        request = [self.requests objectAtIndex:_currentStep];
        _currentStep++;
    }
    
    if (request && self.onProcess) {
        // Need to process the request
        self.onProcess(self.sync, request.jsonResponse);
        [self.sync notify:kDDSFNotificationSyncProgressUpdated];
        [self.processingQueue addOperationWithBlock:^{
            [self processNextRequest];
        }];
    }
    else // We're done
        [self.processingQueue addOperationWithBlock:^{
            [self finishProcessing];
        }];
}

- (void)setupRequestForMockMode:(DDSFRequest*)request {
    switch (request.mockMode = self.sync.mockMode) {
        case kDDSFRequestMockModeCapture: {
            if (!self.name) {
                log4Error(@"Unable to set up capture mode as %@ does not have name", self);
                NSAssert(0, @"Missing step name");
                abort();
            }
            NSString * filename = [self.name stringByAppendingFormat:@"-%d.json", self.requests.count];
            request.mockPath = [self.sync.mockPath stringByAppendingPathComponent:filename];
            break;
        }
            
        case kDDSFRequestMockModeReplay: {
            if (!self.name) {
                log4Error(@"Unable to set up replay mode as %@ does not have name", self);
                NSAssert(0, @"Missing step name");
                abort();
            }

            if (!request.mockFileNames) {
                NSMutableArray * filenames = [NSMutableArray array];
                NSFileManager * manager = [NSFileManager defaultManager];

                for (int i=0; YES; i++) {
                    NSString * filename = [self.name stringByAppendingFormat:@"-%d.json", i];
                    NSString * filepath = [self.sync.mockPath stringByAppendingPathComponent:filename];
                    if ([manager fileExistsAtPath:filepath])
                        [filenames addObject:filepath];
                    else
                        break;
                }

                request.mockFileNames = filenames;
            }
            break;
        }
            
        default:
            break;
    }
}

- (void)execute {
    if (self.sync.aborted)
        return;

    if (self.sync.stage == kDDSFDownstreamSyncStageFetch) {
        if (self.preFetch)
            self.preFetch(self.sync);

        if (!_request && _requestBlock) {
            _request = _requestBlock();
            _request.delegate = self;
            _request.shouldSaveResponse = YES;
        }
        
        if (_request) {
            [self setupRequestForMockMode:_request];
            
            self.currentRequest = _request;
            self.currentRequest.onConvert = self.onConvert;
            [self.currentRequest execute];
        }
        else // Nothing to do
            [self.processingQueue addOperationWithBlock:^{
                [self finishFetching];
            }];
    }
    else {
        _currentStep = 0;
        
        if (self.preProcess) {
            self.preProcess(self.sync);
            _processingBlocksCompleted++;
            [self.sync notify:kDDSFNotificationSyncProgressUpdated];

            [self.processingQueue addOperationWithBlock:^{
                [self processNextRequest];
            }];
        }
        else
            [self.processingQueue addOperationWithBlock:^{
                [self processNextRequest];
            }];
    }
}

- (void)cancel {
    log4Info(@"%s", __PRETTY_FUNCTION__);
    if (self.sync.stage == kDDSFDownstreamSyncStageFetch)
        [self.currentRequest cancel];
}

-(void)resetEstimatedNumberOfPages{
    if (_estimatedNumberOfPages>1) {
        _estimatedNumberOfPages-=1;
    }
}
- (int)numberOfFetchTasks {
    if (_estimatedNumberOfRequests){
        [self resetEstimatedNumberOfPages];
        return _estimatedNumberOfRequests;
    }
   
    return _estimatedNumberOfPages;
}

- (int)numberOfFetchTasksCompleted {
    return self.requests.count;
}

- (int)numberOfProcessTasks {
    int count = self.onProcess ? self.requests.count : 0;
    
    if (self.preProcess)
        count++;
    
    if (self.postProcess)
        count++;
    
    return count;
}

- (int)numberOfProcessTasksCompleted {
    return (self.onProcess ? _currentStep : 0)+ _processingBlocksCompleted;
}

#pragma mark -
#pragma mark DDSFRequestDelegate

- (void)requestCompleted:(DDSFRequest *)request withJson:(NSDictionary *)json {
    // Store it
    [self.requests addObject:request];

    [self.processingQueue addOperationWithBlock:^{        
        if (self.sync.aborted)
            return;

        if (self.onFetch)
            self.onFetch(self.sync, json);
        
        // Check for more
        self.currentRequest = [request requestForNextPage];
        if (self.currentRequest) {
            // Need to re-estimate the number of requests and update progress
            int recordCount = 0;
            for (DDSFRequest * request in self.requests)
                recordCount += request.currentCount;
            
            float recordsPerPage = (float) recordCount / (float) [_requests count];
            _estimatedNumberOfRequests = (int)ceilf(self.request.totalCount / recordsPerPage);

            [self.sync notify:kDDSFNotificationSyncProgressUpdated];
            
            self.currentRequest.delegate = self;
            self.currentRequest.onConvert = self.onConvert;
            [self setupRequestForMockMode:self.currentRequest];
            [self.currentRequest execute];
        }
        else  {
            // We're done
            _estimatedNumberOfRequests = self.requests.count;
            [self.sync notify:kDDSFNotificationSyncProgressUpdated];
            [self finishFetching];
        }
    }];
}

- (void)request:(DDSFRequest *)request failedWithError:(NSError *)error {
    if (self.currentRequest == request) {
        if (error.ddsf_category == kDDSFErrorCategoryAuthenticationFailure) {
            // TODO: integrate into authentication
//            [self.sync.client.authenticationManager refreshSessionWithObserver:self];
            [self.sync handleAuthenticationFailure];
        }else if (error.ddsf_category == kDDSFErrorCategoryServerBusy){
            [self.sync handleServerBusyError];
        }
        else {
            [self.delegate syncItem:self failedWithError:error];
        }
    }
}

- (NSError*)request:(DDSFRequest*)request detectErrorFromResponse:(NSDictionary*)json statusCode:(int)httpStatus {
    // We only want to do anything if we're getting response to the current request
    if (request == self.currentRequest)
        return [self.sync detectErrorFromResponse:json statusCode:httpStatus];
    
    return nil;
}

- (NSError*)request:(DDSFRequest*)request categorizeError:(NSError*)error {
    // We only want to do anything if we're getting response to the current request
    if (request == self.currentRequest)
        return [self.sync categorizeError:error];
    
    return error;
}

#pragma mark -
#pragma mark DDSFSessionObserver

- (void)sessionRefreshed {
    [self.currentRequest execute];
}
- (void)sessionFailedToRefreshWithError:(NSError*)error {
    [self.delegate syncItem:self failedWithError:error];
}


@end
