
#import <Foundation/Foundation.h>

#import "L4Layout.h"

@interface L4XMLLayout : L4Layout {
    
}

+ (L4XMLLayout *) XMLLayout;

@end
