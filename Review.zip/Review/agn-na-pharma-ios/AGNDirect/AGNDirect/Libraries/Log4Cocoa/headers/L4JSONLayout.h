#import <Foundation/Foundation.h>

#import "L4Layout.h"

/**
 *  This class represents formating a JSON object for error.
 */
@interface L4JSONLayout : L4Layout {
    
}

+ (L4JSONLayout *) JSONLayout;

@end
