//
//  AGNPagedRequestDelegate.m
//  AGNDirect
//
//  Created by Dennis Jacobs on 10/19/12.
//  Copyright (c) 2012 Mark Wells. All rights reserved.
//

#import "AGNPagedRequestDelegate.h"
#import "SFRestAPI.h"

@interface AGNPagedRequestDelegate ()
@property (weak, nonatomic) id <SFRestDelegate> parent;
@property (weak, nonatomic) SFRestRequest *primeRequest;
@property (assign, nonatomic) NSInteger pageCount;
@end

@implementation AGNPagedRequestDelegate

- (AGNPagedRequestDelegate *)initWithParent:(id <SFRestDelegate>)delegate {
    self = [super init];
    if (self) {
        self.parent = delegate;
        self.pageCount = 0;
    }
    return self;
}


#pragma mark - SFRestDelegate

- (void)request:(SFRestRequest *)request didLoadResponse:(id)jsonResponse {
    if (!self.primeRequest) {
        self.primeRequest = request;
    }
    
    if ([self responseContainsError:jsonResponse]) {
        if (self.parent) {
            [self.parent request:self.primeRequest didLoadResponse:jsonResponse];
        }
        return;
    }
    
    //TODO: perform iterative update
    
    // Fetch next request
    NSDictionary *json = (NSDictionary *)jsonResponse;
    BOOL done = [json[@"done"] boolValue];
    if (!done) {
        SFRestRequest *req = [[SFRestRequest alloc] init];
        NSString *nextRecordsUrl = (NSString *)[jsonResponse objectForKey:@"nextRecordsUrl"];
        nextRecordsUrl = [nextRecordsUrl substringFromIndex:kSFDefaultRestEndpoint.length];
        [req setPath:nextRecordsUrl];
        [req setMethod:SFRestMethodGET];
        req.endpoint = kSFDefaultRestEndpoint;
        [[SFRestAPI sharedInstance] send:req delegate:self];
    } else if (self.parent) {
        // notify parent delegate all pages processed
        [self.parent request:self.primeRequest didLoadResponse:jsonResponse];
    }
}

- (void)request:(SFRestRequest *)request didFailLoadWithError:(NSError*)error {
    if (self.parent) {
        [self.parent request:(self.primeRequest ? self.primeRequest : request) didFailLoadWithError:error];
    }
}

- (void)requestDidCancelLoad:(SFRestRequest *)request {
    if (self.parent) {
        [self.parent requestDidCancelLoad:(self.primeRequest ? self.primeRequest : request)];
    }
}

- (void)requestDidTimeout:(SFRestRequest *)request {
    if (self.parent) {
        [self.parent requestDidTimeout:(self.primeRequest ? self.primeRequest : request)];
    }
}


#pragma mark - Private Utilities

- (BOOL)responseContainsError:(id)jsonResponse {
    if ([jsonResponse isKindOfClass:[NSArray class]] && [jsonResponse count] > 0) {
        NSArray *json = (NSArray*)jsonResponse;
        return ([json count] > 0) && [json[0] isKindOfClass:[NSDictionary class]] && ((NSString *)[json[0] valueForKey:@"errorCode"]).length > 0;
    }
    return NO;
}

@end
