//
//  AGNDownstreamSync+RequestFormsGroup.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 4/24/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+RequestFormsGroup.h"
#import "NSManagedObjectContext+DDSFExtensions.h"
#import "AGNODRReason.h"
#import "AGNRequestForm.h"
#import "NSArray+AGNOnConvert.h"

@implementation AGNDownstreamSync (RequestFormsGroup)

- (void)buildRequestFormsRelationships {
}


- (DDSFSyncItem*)requestFormsGroup {
    __weak AGNDownstreamSync * _self = self;
    
    NSInteger numMonthsOfCallHistoryToRetrieve = [AGNAppDelegate sharedDelegate].monthsCallHistory;
    NSDate * earliestDate = [NSDate dateWithTimeIntervalSinceNow:(-numMonthsOfCallHistoryToRetrieve*30*24*3600)];
    NSString * earliestDateString = [earliestDate agnRFC3339FormattedTimestampString];

    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];
    
    DDSFSyncStep * full = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
           return nil;

        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"RequestFormsQueryString.txt", earliestDateString, nil];
    }];
    full.name = @"full-forms";
    
    full.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        [_self addEntities:json[@"records"] withName:@"AGNRequestForm"];
        log4Debug(@"Added %d  forms.", [json[@"records"] count]);
    };

    [group setSteps:@[full] forMode:kDDSFDownstreamSyncModeFull];
    
//    DDSFSyncStep * ids = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
//        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
//            return nil;
//        
//        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"RequestFormIDsQueryString.txt", earliestDateString, nil];
//    }];
    NSString * path = [NSString stringWithFormat:@"/services/apexrest/FetchRecordIds?syncobject=Request_Form__c&applySharing=true&createdDate=%@",earliestDateString];
    DDSFSyncStep * idService = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest getRequestForPath:path]];

    idService.name = @"delta-form-ids";
    
    idService.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;

        log4Info(@"==> requestForm ids fetched");

//        NSArray * records = json[@"records"];
//        NSMutableSet * serverIds = [NSMutableSet setWithArray:[records valueForKey:@"Id"]];
        NSMutableSet * serverIds = [NSMutableSet setWithArray:json[@"ids"]];

        NSSet * localIds = [_self.managedContext ddsf_idsForAllEntitiesNamed:@"AGNRequestForm"];
        
        // Identify forms to delete
        _self.deletedFormIds = [NSMutableSet setWithSet:localIds];
        [_self.deletedFormIds minusSet:serverIds];
        
        // Remaining is everything we don't have as of right now
        _self.remainingFormIds = serverIds;
        [_self.remainingFormIds minusSet:localIds];
        
        _self.addedFormIds = [NSSet setWithSet:_self.remainingFormIds]; // All of these are not present locally, and we need to preserve the ids for processing
    };

    idService.onConvert = ^(NSArray * array) {
        return [array AGNconvertResponseToDictionaryWithKey:@"ids"];

    };


    idService.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;

        // Just need to delete the forms marked for deletion
        if (_self.deletedFormIds.count > 0) {
            for (NSString * salesForceId in _self.deletedFormIds) {
                AGNRequestForm * form = [_self.managedContext ddsf_objectOfType:@"AGNRequestForm" forId:salesForceId];
                if (form)
                    [_self.managedContext deleteObject:form];
            }
            [_self saveContext];
        }
    };

    DDSFSyncStep * idsDirect = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return nil;

        if(_self.remainingFormIds || _self.deletedFormIds || _self.addedFormIds)
            return nil;// already fetched the ids, can skip that step

        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"MarketingIDsQueryString.txt", earliestDateString, nil];
    }];
    idsDirect.name = @"delta-form-ids-direct";

    idsDirect.onConvert = ^(NSArray * array) {
        NSMutableDictionary * dictionary = [[NSMutableDictionary alloc]init];
        dictionary[@"ids"]=array;
        return dictionary;
    };

    idsDirect.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;

        log4Info(@"==> form ids fetched");

        NSMutableSet * serverIds = [NSMutableSet setWithArray:json[@"ids"]];
        NSSet * localIds = [_self.managedContext ddsf_idsForAllEntitiesNamed:@"AGNMarketingDisbursement"];

        // Identify forms to delete
        _self.deletedFormIds = [NSMutableSet setWithSet:localIds];
        [_self.deletedFormIds minusSet:serverIds];

        // Remaining is everything we don't have as of right now
        _self.remainingFormIds = serverIds;
        [_self.remainingFormIds minusSet:localIds];

        _self.addedFormIds = [NSSet setWithSet:_self.remainingFormIds]; // All of these are not present locally, and we need to preserve the ids for processing
    };

    idsDirect.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;

        // Just need to delete the forms marked for deletion
        if (_self.deletedFormIds.count > 0) {
            for (NSString * salesForceId in _self.deletedFormIds) {
                AGNRequestForm * form = [_self.managedContext ddsf_objectOfType:@"AGNRequestForm" forId:salesForceId];
                if (form)
                    [_self.managedContext deleteObject:form];
            }
            [_self saveContext];
        }
    };

    
    DDSFSyncStep * modified = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return nil;
        
        NSString * modifiedSinceDateString = earliestDateString;
        if (_self.syncManager.utcCurrentSyncLastTimestamp)
            modifiedSinceDateString = [_self.syncManager.utcCurrentSyncLastTimestamp agnRFC3339FormattedTimestampString];
        
        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"RequestFormsModifiedQueryString.txt", earliestDateString, modifiedSinceDateString, nil];
    }];
    modified.name = @"delta-form-modified";

    modified.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;

        log4Info(@"==> modified requestForms fetched");

        NSArray * records = json[@"records"];
        NSSet * receivedIds = [NSSet setWithArray:[records valueForKey:@"Id"]];
        log4Debug(@"Received Ids: %@", receivedIds);
        
        // Since we may have received some of the missing ones, let's update our remaining Ids
        [_self.remainingFormIds minusSet:receivedIds];
        log4Debug(@"Remaining Ids: %@", _self.remainingFormIds);
    };
    
    modified.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;

        NSArray * records = json[@"records"];
        if (records.count > 0) {
            for (NSDictionary * form in records) {
                NSString * salesForceId = form[@"Id"];
                if ([_self.addedFormIds containsObject:salesForceId]) {
                    [_self addEntities:@[form] withName:@"AGNRequestForm"];
                    log4Debug(@"Added 1 form.");
                }
                else {
                    [_self updateEntities:@[form] withName:@"AGNRequestForm" whereIdWithKey:@"Id" notIn:nil];
                    log4Debug(@"Updated 1 form.");
                }
            }
            [_self saveContext];
        }
    };

    
    DDSFSyncStep * missing = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return nil;
        
        if (_self.remainingFormIds.count == 0)
            return nil;

        NSString * ids = [_self.remainingFormIds.allObjects componentsJoinedByString:@"','"];
        return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"RequestFormsMissingQueryString.txt",
                [NSString stringWithFormat:@"'%@'", ids], nil];
    }];
    missing.name = @"delta-form-missing";
    
    missing.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return;
   
        [_self addEntities:json[@"records"] withName:@"AGNRequestForm"];
        log4Debug(@"Added %d  forms.", [json[@"records"] count]);
    };
    

    [group setSteps:@[idService, modified, missing] forMode:kDDSFDownstreamSyncModeIncremental];
    
    group.postProcess = ^(DDSFDownstreamSync * sync) {
        NSArray * forms = [self.managedContext ddsf_allEntitiesNamed:@"AGNRequestForm"];
        for (AGNRequestForm * form in forms)
            [form buildRelationships];
        
        [self saveContext];
    };

    return group;
}

- (DDSFSyncItem *)requestFormsReferenceGroup {
    __weak AGNDownstreamSync * _self = self;


    NSInteger numMonthsOfCallHistoryToRetrieve =  [AGNAppDelegate sharedDelegate].monthsCallHistory;
    NSDate *earliestDate = [NSDate dateWithTimeIntervalSinceNow:(-numMonthsOfCallHistoryToRetrieve*30*24*3600)];
    NSString *earliestDateString = [earliestDate agnStringFromDate];


    // Need to create a group since we have multiple steps, even though they are the same for both full and incremental
    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];

    DDSFSyncStep * allProductBrands = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if ([AGNAppDelegate sharedDelegate].shouldSyncForms)
            return [DDSFRequest requestWithQueryFromFileNamed:@"AllProductBrandsQueryString.txt"];
        else
            return nil;
    }];
    allProductBrands.name = @"all-product-brands";
    
    allProductBrands.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        [_self addEntities:json[@"records"] withName:@"AGNRequestFormProduct"];
        log4Debug(@"Added %d  product brands.", [json[@"records"] count]);
    };

    DDSFSyncStep * odrReason = [[DDSFSyncStep alloc]initWithRequestBlock:^DDSFRequest *{
        if ([AGNAppDelegate sharedDelegate].shouldSyncForms) {
            SFRestRequest * metaData = [[SFRestAPI sharedInstance] requestForDescribeWithObjectType:@"Request_Form__c"];
            return [DDSFRequest requestWithSFRestRequest:metaData];
        }
        else
            return nil;
    }];
    odrReason.name = @"odr-reasons";

    odrReason.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        NSArray * fields = json[@"fields"];
        for (NSDictionary * dict in fields) {
            if ([dict[@"name"] isEqualToString:@"ODR_Reason__c"]) {
                NSArray * picklistArray = dict[@"picklistValues"];
                for (NSDictionary * picklistValue in picklistArray) {

                    BOOL active = [picklistValue[@"active"] boolValue];
                    if (active) {
                        AGNODRReason * odrReason = [NSEntityDescription insertNewObjectForEntityForName:@"AGNODRReason" inManagedObjectContext:self.managedContext];
                        odrReason.label = picklistValue[@"label"];
                        odrReason.value = picklistValue[@"value"];
                    }
                }
            }
        }
    };

    DDSFSyncStep * rss = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if (![AGNAppDelegate sharedDelegate].shouldSyncForms)
            return nil;

        NSString * param = [NSString stringWithFormat:@"'%@'",_self.loggedInSalesRep.salesTeamName];

                return [DDSFRequest requestWithQueryFromFileNameWithArgs:@"RSSQueryString.txt", param,earliestDateString, nil];
    }];
    rss.name = @"rss";
    
    rss.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        [_self addEntities:json[@"records"] withName:@"AGNRSS"];
        log4Debug(@"Added %d  RSS.", [json[@"records"] count]);
    };
    
    [group setSteps:@[allProductBrands,odrReason,rss] forMode:kDDSFDownstreamSyncModeFull];
    [group setSteps:@[allProductBrands,odrReason,rss] forMode:kDDSFDownstreamSyncModeIncremental];

    group.postProcess = ^(DDSFDownstreamSync *sync) {
        [_self buildRequestFormsRelationships];
        [_self saveContext];
    };

    return group;
}


@end
