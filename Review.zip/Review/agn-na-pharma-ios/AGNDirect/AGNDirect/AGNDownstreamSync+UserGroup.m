//
//  AGNDownstreamSync+UserGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+UserGroup.h"
#import "NSManagedObjectContext+DDSFExtensions.h"
#import "AGNRootViewController.h"

@implementation AGNDownstreamSync (UserGroup)

+ (NSString *)userInfoURL {
    NSString * version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/userinfo?version=%@"], version];
    log4Info(@"Built versioned userinfo path %@",urlString);
    return urlString;
}

+ (void)setupContactRolesUsing:(NSArray *)roles moc:(NSManagedObjectContext*)moc {
    if ([roles count] > 0) {
        log4Debug(@"Importing Contact Roles - deleting existing roles.");
        [moc ddsf_deleteAllEntitiesNamed:@"AGNContactRole"];
        for (NSString *role in roles) {
            AGNContactRole * contactRole = [NSEntityDescription insertNewObjectForEntityForName:@"AGNContactRole" inManagedObjectContext:moc];
            contactRole.roleName=role;
            log4Debug(@"Inserted Contact Role: %@", role);
        }
    }
}

+ (void)updateSuppressedAddressObjectsForRep:(AGNSalesRep *)rep moc:(NSManagedObjectContext*)moc {
    for (AGNSuppressedAddress * obj in [moc ddsf_allEntitiesNamed:@"AGNSuppressedAddress"]){
        if([rep.salesForceId isEqualToString:obj.salesForceSalesRepId]){
            obj.salesRep=rep;
        }
    }
}

+ (AGNSalesRep*)syncUserSyncGroup:(NSDictionary *) dictionary moc:(NSManagedObjectContext*)moc {
    NSArray * contactRoles = [self nullCheck:[dictionary objectForKey:@"Professional_Role"]];
    if (contactRoles) {
        [self setupContactRolesUsing:contactRoles moc:moc];
    }
    
    NSString *supportEmailAliases = [self nullCheck:[dictionary objectForKey:@"emailIds"]];
    if (supportEmailAliases.length > 0) {
        [[NSUserDefaults standardUserDefaults] setValue:supportEmailAliases forKey:AGNSupportEmailAddresses];
    }else{
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:AGNSupportEmailAddresses];
    }
    
    NSString *maxDaysForIncrementalSync = [self nullCheck:[dictionary objectForKey:@"maxDaysForIncrementalSync"]];
    if (maxDaysForIncrementalSync.length > 0) {
        NSInteger days = [maxDaysForIncrementalSync integerValue];
        [[NSUserDefaults standardUserDefaults] setInteger:days forKey:AGNIncrementalSyncMaxDaysSinceLastSyncKey];
    }
    
    NSString *maxNewAccountsForIncrementalSync = [self nullCheck:[dictionary objectForKey:@"maxNewAccountsForIncrementalSync"]];
    if (maxNewAccountsForIncrementalSync.length > 0) {
        NSInteger maxAccts = [maxNewAccountsForIncrementalSync integerValue];
        [[NSUserDefaults standardUserDefaults] setInteger:maxAccts forKey:AGNIncrementalSyncMaxNewAccountsKey];
    }
    
    NSString *minutesFromMidnightBatchStart = [self nullCheck:[dictionary objectForKey:@"minutesFromMidnightBatchStart"]];
    if (minutesFromMidnightBatchStart.length > 0) {
        NSInteger batchStart = [minutesFromMidnightBatchStart integerValue];
        [[NSUserDefaults standardUserDefaults] setInteger:batchStart forKey:AGNBatchWindowStartTimeKey];
    }
    
    NSString *minutesFromMidnightBatchEnd = [self nullCheck:[dictionary objectForKey:@"minutesFromMidnightBatchEnd"]];
    if (minutesFromMidnightBatchEnd.length > 0) {
        NSInteger batchEnd = [minutesFromMidnightBatchEnd integerValue];
        [[NSUserDefaults standardUserDefaults] setInteger:batchEnd forKey:AGNBatchWindowEndTimeKey];
    }
    
    NSDictionary *userInfoDict = [self nullCheck:dictionary[@"userData"]];
    NSString *userId;
    AGNSalesRep * rep = nil;
    if (userInfoDict) {
        userId = [self nullCheck:userInfoDict[@"Id"]];
    }
    if (userId) {
        rep = [moc ddsf_objectOfType:@"AGNSalesRep" forId:userId];
    }
    if (!rep) {
        rep = (AGNSalesRep *)[NSEntityDescription insertNewObjectForEntityForName:@"AGNSalesRep" inManagedObjectContext:moc];
    }
    [rep initWithDictionary:dictionary];
    [self updateSuppressedAddressObjectsForRep:rep moc:moc];
    
    [AGNAppDelegate sharedDelegate].lastLoggedInUserSFDCID = rep.salesForceId;
    
    // clear existing TOT to prevent duplicates
    [moc ddsf_deleteAllEntitiesNamed:@"AGNTimeOffTerritory"];
    
    if([self nullCheck:userInfoDict[@"Time_Off_Territory__r"]] ){
        id entities = [self nullCheck:userInfoDict[@"Time_Off_Territory__r"][@"records"]];
        [self addEntities:entities withName:@"AGNTimeOffTerritory" moc:moc];
    }
    
    return rep;
}



- (void)buildTOTRelationships {
    NSArray * all_tot = [self allEntities:@"AGNTimeOffTerritory"];
    for (AGNTimeOffTerritory * tot in all_tot)
        tot.salesRep = (AGNSalesRep *)[self.managedContext ddsf_objectOfType:@"AGNSalesRep" forId:tot.salesForceRepId];;
}

// returns YES if sync should proceed (assuming there is a sync), and no if it should be cancelled
+ (BOOL)processPermissions:(NSManagedObjectContext*)moc salesRep:(AGNSalesRep*)rep json:(NSDictionary*)json sync:(AGNDownstreamSync*)sync {
    // Need to update permissions - they affect the rest of the sync!
    [AGNAppDelegate sharedDelegate].canCreateForms = [json[@"canCreateForms"] boolValue];
    [AGNAppDelegate sharedDelegate].canCreateCalls = [json[@"canCreateCalls"] boolValue];
    [AGNAppDelegate sharedDelegate].canCreateReprints =[json[@"canCreateMCD"] boolValue];

    BOOL shouldSyncCalls = [json[@"shouldSyncCalls"] boolValue];
    BOOL shouldSyncForms = [json[@"shouldSyncForms"] boolValue];
    BOOL shouldSyncReprints = [json[@"canSyncMCD"] boolValue];

    // If those values changed compared to what we had, we need to force a full sync
    if ((shouldSyncForms && ![AGNAppDelegate sharedDelegate].shouldSyncForms) ||
        (!shouldSyncForms && [AGNAppDelegate sharedDelegate].shouldSyncForms) ||
        (shouldSyncCalls && ![AGNAppDelegate sharedDelegate].shouldSyncCalls) ||
        (!shouldSyncCalls && [AGNAppDelegate sharedDelegate].shouldSyncCalls) ||
        (shouldSyncReprints && ![AGNAppDelegate sharedDelegate].shouldSyncReprints) ||
        (!shouldSyncReprints && [AGNAppDelegate sharedDelegate].shouldSyncReprints)) {
        
        log4Info(@"sync settings have changed, forcing full sync...");
        sync.mode = kDDSFDownstreamSyncModeFull;
        
        // Also set a flag in NSUserDefaults, in case we're processing this on session refresh
        [AGNAppDelegate sharedDelegate].syncManager.needFullSync = YES;
        
        [AGNAppDelegate sharedDelegate].shouldSyncCalls = shouldSyncCalls;
        [AGNAppDelegate sharedDelegate].shouldSyncForms = shouldSyncForms;
        [AGNAppDelegate sharedDelegate].shouldSyncReprints = shouldSyncReprints;
    }
    
    id value = [self nullCheck:json[@"RFProductLimit"]];
    NSUInteger allowedNumberOfQuestions = [value intValue];
    if (allowedNumberOfQuestions == 0 || allowedNumberOfQuestions > 10)
        allowedNumberOfQuestions = 10;
    
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[NSNumber numberWithInt:allowedNumberOfQuestions] forKey:kAGNUserDefaultsKeyAllowedNumberOfQuestions];
    [defaults synchronize];
    
    NSString *errorString = (NSString *)[json objectForKey:@"errorMessage"];
    NSString *appVersionStatus = (NSString *)[json objectForKey:@"appVersionStatus"];
    NSString *appVersionMessage = (NSString *)[json objectForKey:@"appVersionMessage"];
    
    log4Info(@"Got app version status: %@, message: %@",appVersionStatus,appVersionMessage);
    
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (errorString && errorString.length > 0) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNAbortSyncNotificationKey object:nil];
            [AGNAppDelegate sharedDelegate].syncManager.userNotConfiguredAlertView = [[UIAlertView alloc] initWithTitle:@"Invalid User Configuration" message:[NSString stringWithFormat:@"The account you are logged in as is not properly configured to use this application. Please contact Home Office to resolve the issue or log in as a different user. \nSFDC Error: %@", errorString] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [[AGNAppDelegate sharedDelegate].syncManager.userNotConfiguredAlertView show];
        });
    }
    else if (appVersionStatus && [appVersionStatus isEqualToString:kAGNAppStatusKill]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:AGNAbortSyncNotificationKey object:nil];
            [standardUserDefaults setValue:appVersionMessage forKey:kAGNKillSwitchMessage];
            AGNRootViewController *rootViewController = (AGNRootViewController*)[AGNAppDelegate sharedDelegate].rootViewController;
            [rootViewController showAppVersionForcedUpgradeNotice];
        });
        
        return NO;
    }
    else {
        [standardUserDefaults removeObjectForKey:kAGNKillSwitchMessage];
        AGNRootViewController *rootViewController = (AGNRootViewController*)[AGNAppDelegate sharedDelegate].rootViewController;
        [rootViewController dismissIfVisibleAppVersionForcedUpgradeNotice];
        
        if (appVersionStatus && [appVersionStatus isEqualToString:kAGNAppStatusWarn]) {
            // Proceed with the sync after the user dismisses the upgrade warning
            dispatch_async(dispatch_get_main_queue(), ^{
                [AGNAppDelegate sharedDelegate].syncManager.versionWarningAlertView = [[UIAlertView alloc] initWithTitle:@"Upgrade Notice" message:appVersionMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [AGNAppDelegate sharedDelegate].syncManager.versionWarningBlock = ^{
                    // TODO: figure out how to resume the sync.  Do we even need to pause it?
                };
                [[AGNAppDelegate sharedDelegate].syncManager.versionWarningAlertView show];
            });
        }
    }
    return YES;
}

+ (DDSFRequest*)userInfoRequest {
    return [DDSFRequest getRequestForPath:[self userInfoURL]];
}

- (DDSFSyncItem *)userGroup {
    __weak AGNDownstreamSync * _self = self;
    
    DDSFSyncStep * step = [[DDSFSyncStep alloc] initWithRequest:[AGNDownstreamSync userInfoRequest]];
    step.name = @"user";
    
    step.onConvert = ^(NSArray * array) {
        return (NSDictionary *)[array lastObject];
    };
    
    step.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        log4Info(@"==> userGroup fetched");
        // set sales rep on sync context - needed for other requests during sync
        _self.loggedInSalesRep = [[AGNSalesRep alloc] initWithEntity:[NSEntityDescription entityForName:@"AGNSalesRep"
                                                                                 inManagedObjectContext:self.managedContext]
                                      insertIntoManagedObjectContext:nil];
        
        [_self.loggedInSalesRep initWithDictionary:json];
        
        if (![AGNDownstreamSync processPermissions:_self.managedContext salesRep:self.loggedInSalesRep json:json sync:_self])
            [_self cancel];
    };
    
    step.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        AGNSalesRep * rep = [AGNDownstreamSync syncUserSyncGroup:json moc:_self.managedContext];
        [self saveContext];
        
        // Now we can update the loggedInSalesRep object on the main thread
        dispatch_sync(dispatch_get_main_queue(), ^{
            AGNSalesRep * loggedInSalesRep = (AGNSalesRep*)[[AGNAppDelegate sharedDelegate].managedObjectContext objectWithID:rep.objectID];
            [AGNAppDelegate sharedDelegate].loggedInSalesRep = loggedInSalesRep;
        });

    };
    
    step.postProcess = ^ (DDSFDownstreamSync * sync) {
        [_self buildTOTRelationships];
        [_self saveContext];
    };
    
    return step;
}


@end
