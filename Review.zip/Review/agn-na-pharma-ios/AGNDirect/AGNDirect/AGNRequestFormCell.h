//
//  AGNRequestFormCell.h
//  AGNDirect
//
//  Created by Satao, Krunal (US - Mumbai) on 5/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNRequestFormCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *dateLabel;
@property (strong, nonatomic) IBOutlet UILabel *salesRepNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *statusLabel;

@end
