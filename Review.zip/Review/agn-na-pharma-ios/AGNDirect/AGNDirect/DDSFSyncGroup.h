//
//  DDSFSyncGroup.h
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDSFSyncItem.h"
#import "DDSFDownstreamSync.h"

@interface DDSFSyncGroup : DDSFSyncItem <DDSFSyncItemDelegate>

- (void)setSteps:(NSArray*)steps forMode:(DDSFDownstreamSyncMode)type;

@end
