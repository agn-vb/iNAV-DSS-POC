//
//  AGNAPC.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/11/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNAPC.h"


@implementation AGNAPC

@dynamic apcCode;
@dynamic salesForceId;
@dynamic effectiveDate;
@dynamic endDate;
@dynamic salesTeamRemoteId;
@dynamic jobName;
@dynamic productName;

@dynamic value;

static NSDictionary *fieldMapping = nil;

+(void)initialize{
    fieldMapping =
    @{
      @"Id"         : @"salesForceId",
      @"APC_Code__c"    :@"apcCode",
      @"Effective_Date__c" :@"effectiveDate",
      @"End_Date__c"   :   @"endDate",
      @"Name" : @"jobName",
      @"Sales_Team__c" : @"salesTeamRemoteId",
      @"Product__c":@"productName",
      @"Value__c":@"value"
      };
}

+ (BOOL)canCreateFromDictionary:(NSDictionary *)dict {
    NSDictionary *  objectDict = dict;
    NSString * key = @"Id";
    if(!objectDict[key] || [objectDict[key] isEqual:[NSNull null]]){
        log4Warn(@"Unable to create object from dictionary %@",dict);
        return NO;
    }
    return YES;

}

-(id)copyWithZone:(NSZone *)zone{
    return [[[self class] allocWithZone:zone] init];
}
- (void)initWithDictionary:(NSDictionary *)dict{
    NSDictionary * objectDict = dict;
    for(NSString *key in objectDict){
        id value = objectDict[key];
        if ([value isEqual:[NSNull null]]) {
            value = nil;
        }

        NSString *objectKey = fieldMapping[key];
        if(objectKey){
            if([key isEqualToString:@"End_Date__c"]) {
                self.endDate = [NSDate agnDateFromString:value];
            }else if([key isEqualToString:@"Effective_Date__c"]){
                self.effectiveDate = [NSDate agnDateFromString:value];
            }else{
                [self setValue:value forKey:objectKey];
            }
        }
    }
}


@end
