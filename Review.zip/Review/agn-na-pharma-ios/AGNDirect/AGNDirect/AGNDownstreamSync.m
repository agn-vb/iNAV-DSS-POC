//
//  AGNDownstreamSync.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/9/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync.h"
#import "AGNSyncManager.h"
#import "DDSFSyncStep.h"
#import "AGNAppDelegate.h"
#import "AGNRootViewController.h"
#import "DDSFSyncGroup.h"
#import "NSManagedObjectContext+DDSFExtensions.h"

// sync groups
#import "AGNDownstreamSync+UserGroup.h"
#import "AGNDownstreamSync+TimestampGroup.h"
#import "AGNDownstreamSync+AccountIDsGroup.h"
#import "AGNDownstreamSync+ZipCodesGroup.h"
#import "AGNDownstreamSync+InventoryGroup.h"
#import "AGNDownstreamSync+AccountsGroup.h"
#import "AGNDownstreamSync+NewAccountsAndCallsGroup.h"
#import "AGNDownstreamSync+SalesTeamGroup.h"
#import "AGNDownstreamSync+SalesRepGroup.h"
#import "AGNDownstreamSync+CallsGroup.h"
#import "AGNDownstreamSync+RequestFormsGroup.h"
#import "AGNDownstreamSync+ReprintsGroup.h"

NSString * const kAGNAppStatusKill = @"KILL";
NSString * const kAGNAppStatusWarn = @"WARN";

@interface AGNDownstreamSync ()




@property (nonatomic, strong) NSMutableDictionary * addresses;
@property (nonatomic, strong) NSMutableDictionary * productBrands;
@property (nonatomic, strong) NSMutableDictionary * productSKUs;
@property (nonatomic, strong) NSMutableDictionary * inventoryLines;
@property (nonatomic, strong) NSMutableDictionary * accounts;
@property (nonatomic, strong) NSMutableDictionary * salesReps;
@property (nonatomic, strong) NSMutableDictionary * calls; // Will only contain a current set of calls
@property (nonatomic, strong) NSMutableDictionary * detailPositions;
@property (nonatomic, strong) NSMutableDictionary * contactRoles;
@property (nonatomic, strong) NSMutableDictionary * contacts;
@property (nonatomic, strong) NSMutableDictionary * rssRecords;
@property (nonatomic, strong) NSMutableDictionary * marketingDisbursements;
@property (nonatomic, strong) NSMutableDictionary * marketingContents;



@end

@implementation AGNDownstreamSync

-(void)handleAuthenticationFailure{
    dispatch_async(dispatch_get_main_queue(), ^{
        AGNRootViewController *rootViewController = (AGNRootViewController*)[AGNAppDelegate sharedDelegate].rootViewController;
        [rootViewController syncingStopped];
        AGNAppDelegate * appDelegate = [AGNAppDelegate sharedDelegate];
        appDelegate.syncManager.syncInProgress = NO;
        appDelegate.shouldSyncAfterLogin = YES;
        log4Info(@"Handling auth failure - setting syncAfterLogin flag and attempting to log back in");
        [appDelegate login];
    });
}

-(void)handleServerBusyError{

    dispatch_async(dispatch_get_main_queue(), ^{
        AGNAppDelegate * delegate = [AGNAppDelegate sharedDelegate];
        [delegate presentBatchIsRunningAlert];
        [delegate deferSync];
        [delegate clearInterruptedSyncKey];
        [delegate.syncManager completeDownstreamSync]; // Needs to happen on the main thread
    });

}

-(void)syncAbortedOnUpsync:(NSNotification*)notification {
    log4Debug(@"sync aborted on upsync");
    [self handleServerBusyError];
}


- (NSError*)detectErrorFromResponse:(NSDictionary*)json statusCode:(int)httpStatus {
    NSString *  errorCode = (NSString *)[json valueForKey:@"errorCode"];

    if(httpStatus==200 && (errorCode == nil || (id)errorCode == [NSNull null]))
        return nil;

    NSString * messageString = (NSString *)[json valueForKey:@"message"];
    if(!messageString){
        messageString = errorCode;
    }
    
    NSDictionary * userInfo =   @{
                                kDDSFErrorCodeKey: errorCode,
                                NSLocalizedDescriptionKey: messageString,
                                kDDSFHttpStatusKey: [NSNumber numberWithInt:httpStatus]
                                };


    return  [NSError ddsf_errorWithDomain:kDDSFErrorDomain
                                     code:kDDSFErrorCodeGeneric
                                 userInfo:userInfo
                                 category:kDDSFErrorCategoryUncategorized];

}

- (NSError*)categorizeError:(NSError*)error {


    if ([@"INVALID_SESSION_ID" isEqual:error.userInfo[kDDSFErrorCodeKey]] || [@"invalid_grant" isEqual:error.userInfo[kDDSFErrorCodeKey]] || [error httpStatus]==401){
        log4Info(@"Authentication Failure: %@ ",error.userInfo);
        return [error ddsf_errorWithCategory:kDDSFErrorCategoryAuthenticationFailure];
    }

    if ([@"BATCH_IS_RUNNING" isEqual:error.userInfo[kDDSFErrorCodeKey]] ){
        log4Info(@"Server Busy : %@",error.userInfo);
        return [error ddsf_errorWithCategory:kDDSFErrorCategoryServerBusy];
    }

    if([error httpStatus]==500){
        log4Info(@"Server error %@",error.userInfo);
        return [error ddsf_errorWithCategory:kDDSFErrorCategoryServerError];
    }

    return [error ddsf_errorWithCategory:kDDSFErrorCategoryUncategorized];
}


- (void)setupSyncGroups {
 
    __weak AGNDownstreamSync * _self = self;
    
    self.groups = @[
                    [self timestampGroup],
                    [self userGroup],
                    [self accountIdsGroup], // This group is only executed during incremental and may change the mode to full
                    [self zipCodesGroup],
                    [self requestFormsReferenceGroup],
                    [self addedAccountsAndCallsGroup],
                    [self accountsGroup],
                    [self salesRepGroup],
                    [self inventoryGroup],
                    [self salesTeamGroup],
                    [self callsGroup],
                    [self requestFormsGroup],
                    [self reprintsReferenceGroup],
                    [self reprintsGroup]
                    ];

    
    self.preFetch = ^ (DDSFDownstreamSync * sync) {
        _log4Info(@"==== SYNC PRE-FETCH ====");
        
        _self.syncManager.localSyncStartedTimestamp = [NSDate date];

        if (sync.mode == kDDSFDownstreamSyncModeFull)
            _self.syncManager.utcCurrentSyncLastTimestamp = nil;
        else
            _self.syncManager.utcCurrentSyncLastTimestamp = _self.syncManager.utcLastCompleteSyncTimestamp;
    };

    self.preProcess = ^ (DDSFDownstreamSync * sync) {
        _log4Info(@"==== SYNC PRE-PROCESS ====");

        [[AGNAppDelegate sharedDelegate] setInterruptedSyncKey];

        // Clean old data before inserting new
        if (sync.mode == kDDSFDownstreamSyncModeFull)
            [_self clearAllData];
        else
            [_self clearIncrementalData];
    };
    
    self.postProcess = ^ (DDSFDownstreamSync * sync) {
        _log4Info(@"==== SYNC POST-PROCESS ====");
        [_self saveContext];
        
        // The following needs to be performed on the main thread as it uses a different thread context
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_self.syncManager upsertSyncRecord];
        });
        
        [[AGNAppDelegate sharedDelegate] clearInterruptedSyncKey];
#if DEBUG
        [_self inspectAddresses];
#endif
        _self.syncManager.utcLastCompleteSyncTimestamp = _self.syncManager.utcCurrentSyncTimestamp;
        _self.syncManager.localLastSyncStartedTimestamp = _self.syncManager.localSyncStartedTimestamp;
        _self.syncManager.utcCurrentSyncTimestamp = nil;
        _self.syncManager.utcCurrentSyncLastTimestamp = nil;
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_self.syncManager completeDownstreamSync]; // Needs to happen on the main thread
        });
    };
    
}

#pragma mark -
#pragma mark Data Methods

- (void)inspectAddresses{
    for(AGNAccount *acct in [self allEntities:@"AGNAccount"]){
        log4Trace(@"Account %@ has %d addresses",[acct formattedName],[acct.addresses count]);
    }
    
}

- (NSArray *)allEntities:(NSString*)entityName {
    return [self.managedContext ddsf_allEntitiesNamed:entityName];
}

- (void)deleteAllEntities:(NSString*)entityName {
    log4Debug(@"Deleting all %@ objects",entityName);
    NSArray *entities = [self allEntities:entityName];
    // Don't delete draft transactions
    if ([[entities lastObject] isKindOfClass:[AGNSampleInventoryTransaction class]]) {
        for(AGNSampleInventoryTransaction *trans in entities) {
            if (![trans isDraft]) {
                [self.managedContext deleteObject:trans];
            }
        }
    }
    else {
        for(NSManagedObject* obj in entities)
            [self.managedContext deleteObject:obj];
    }
}

- (void)clearAllData {
    
    log4Debug(@"Deleting all existing entities");
    
    [self deleteAllEntities:@"AGNZipCode"];
    
    [self deleteAllEntities:@"AGNProductBrand"];
    [self deleteAllEntities:@"AGNProductSKU"];
    [self deleteAllEntities:@"AGNSampleInventoryLine"];
    [self deleteAllEntities:@"AGNSampleInventoryTransaction"];
    
    [self deleteAllEntities:@"AGNSalesRep"];
    [self deleteAllEntities:@"AGNTimeOffTerritory"];
    
    [self deleteAllEntities:@"AGNAccount"];
    [self deleteAllEntities:@"AGNAddress"];
    [self deleteAllEntities:@"AGNContact"];
    [self deleteAllEntities:@"AGNLicense"];
    
    [self deleteAllEntities:@"AGNHCPRating"];
    [self deleteAllEntities:@"AGNSamplePermission"];
    [self deleteAllEntities:@"AGNDetailPosition"];
    [self deleteAllEntities:@"AGNDetailBlacklist"];
    
    [self deleteAllEntities:@"AGNCall"];
    [self deleteAllEntities:@"AGNCallDetail"];
    [self deleteAllEntities:@"AGNSampleDrop"];
    [self deleteAllEntities:@"AGNCallContact"];
    
    // not clear why we would delete from the upsert queue
    // if our in-memory queue is inaccurate, we lose transactions
    // [self deleteAllEntities:@"AGNUpdateTransaction"];
    [self deleteAllEntities:@"AGNContactRole"];
    [self deleteAllEntities:@"AGNODRReason"];
    [self deleteAllEntities:@"AGNRequestFormProduct"];
    [self deleteAllEntities:@"AGNRequestFormItem"];
    [self deleteAllEntities:@"AGNRequestForm"];
    [self deleteAllEntities:@"AGNRSS"];

    // reprints
    [self deleteAllEntities:@"AGNAPC"];
    [self deleteAllEntities:@"AGNMarketingDisbursement"];
    [self deleteAllEntities:@"AGNMarketingCollateral"];

    [self saveContext];
}

- (void)clearIncrementalData {
    // retain account & call groups, these will be updated only
    log4Debug(@"Deleting entities for incremental");
    
    // Inventory group
    [self deleteAllEntities:@"AGNProductBrand"];
    [self deleteAllEntities:@"AGNProductSKU"];
    [self deleteAllEntities:@"AGNSampleInventoryLine"];
    [self deleteAllEntities:@"AGNSampleInventoryTransaction"];
    
    // User / SalesRep group
    [self deleteAllEntities:@"AGNSalesRep"];
    [self deleteAllEntities:@"AGNTimeOffTerritory"];
    
    // SalesTeam group
    [self deleteAllEntities:@"AGNHCPRating"];
    [self deleteAllEntities:@"AGNSamplePermission"];
    [self deleteAllEntities:@"AGNDetailPosition"];
    [self deleteAllEntities:@"AGNDetailBlacklist"];
    
    // not clear why we would delete from the upsert queue
    // if our in-memory queue is inaccurate, we lose transactions
    // [self deleteAllEntities:@"AGNUpdateTransaction"];
    
    [self deleteAllEntities:@"AGNContactRole"];
    [self deleteAllEntities:@"AGNODRReason"];
    [self deleteAllEntities:@"AGNRequestFormProduct"];
    [self deleteAllEntities:@"AGNRSS"];


    // Reprint reference data
    [self deleteAllEntities:@"AGNAPC"];


    [self saveContext];
}

- (void)saveContext {
    NSError *error = nil;
    if ([self.managedContext hasChanges] && ![self.managedContext save:&error]) {
        //TODO: Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        log4Error(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
}

+ (void)addEntities:(NSArray *)entities withName:(NSString *)entityName moc:(NSManagedObjectContext*)moc {
    for (NSDictionary * dictionary in entities) {
        NSDictionary *details = dictionary;
        
        if (![[details valueForKey:@"IsDeleted"] boolValue]) {
            Class EntityClass = NSClassFromString(entityName);
            
            if ([EntityClass conformsToProtocol:@protocol(AGNModelProtocol) ]) {
                Class <AGNModelProtocol> AGNModelClass = EntityClass;
                if ([AGNModelClass canCreateFromDictionary:dictionary]) {
                    id <AGNModelProtocol> mp = [NSEntityDescription insertNewObjectForEntityForName:entityName inManagedObjectContext:moc];
                    [mp initWithDictionary:details];
                }else{
                    log4Warn(@"Unable to create a %@ model object from dictionary %@",entityName,dictionary);
                }
            }
        }
        else
            log4Info(@"Found deleted record");
        
    } // for    
}

- (void)addEntities:(NSArray *)entities withName:(NSString *)entityName {
    [AGNDownstreamSync addEntities:entities withName:entityName moc:self.managedContext];
}

- (void)updateEntities:(NSArray *)entities withName:(NSString *)entityName whereIdWithKey:(NSString *)key notIn:(NSSet *)addedIds {
    log4Debug(@"Updating entities of type %@", entityName);
    
    AGNDataManager *dataManager = [[AGNDataManager alloc] initWithManagedObjectContext:self.managedContext];
    for (NSDictionary *dictionary in entities) {
        NSDictionary *details = dictionary[@"sobjectDetails"];
        if(details.count==0)
            details=dictionary;
        if (![addedIds containsObject:[details valueForKey:key]]) {
            // Note: Naive implementation fetching each object separately. If not performant, modify to fetch in bulk
            // Classes conforming to AGNModelProtocol should use key Id for object's salesforce id
            id <AGNModelProtocol> mp = (id<AGNModelProtocol>)[dataManager undeletedObjectOfType:entityName
                                                                                          forId:[details valueForKey:@"Id"]];
            
            
            //  See https://ubermind.jira.com/browse/AL-1083
            //  Retrieving by GUID might be ambiguous - if call deleted on server & closed on device
            //  there will be two sales force ids for the same guid.
            //  Server changed so that we get the response w/ sales force ids on retries
            //  So should always have SFDC ID on downsync, only retrieve by that
            
            //            if(!mp){ // didn't find an object with that sales force id
            //                    //  try retrieving by GUID - in case we never got the success response
            //                    //  AL-1036
            //                mp = (id<AGNModelProtocol>)[dataManager undeletedObjectOfType:entityName
            //                                                               forGuid:[details valueForKey:@"GUID__c"]];
            //                log4Info(@"Did not find %@ for id %@, lookup by guid %@ found %@",entityName,[details valueForKey:@"Id"],[details valueForKey:@"GUID__c"],mp);
            //
            //            }
            
            
            if (mp) {
                if ([[details valueForKey:@"IsDeleted"] boolValue]) {
                    [self.managedContext deleteObject:mp];
                } else {
                    [mp initWithDictionary:dictionary];
                }
            }
            
            else {
                if (![[details valueForKey:@"IsDeleted"] boolValue]) {
                    log4Debug(@"Unable to find local %@ with sfId %@, adding", entityName, [details valueForKey:@"Id"]);
                    [self addEntities:[NSArray arrayWithObject:dictionary] withName:entityName];
                }
            }
        }
        else {
            log4Debug(@"Treating %@ with sfId %@ as added new, skipping", entityName, [details valueForKey:@"Id"]);
        }
    }
}


- (NSArray*)objectsOfType:(NSString*)entityName forAccount:(NSString*)accountId {
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:self.managedContext];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"salesForceAccountId = %@", accountId];
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *objects = [self.managedContext executeFetchRequest:request error:&error];
    log4Trace(@"Fetched %d objects for entity %@", [objects count], entityName);
    if(error)
        log4Error(@"Error fetching %@ ",entityName,error);
    return objects;
}

#pragma mark -
#pragma mark Utility Methods

- (RKRequestSerialization *)requestSerializationForIds:(NSSet *)accountIds {
    
    NSError *error = nil;
    NSDictionary *dict = @{@"AccountIds" : [accountIds allObjects]};
    NSData *data = [dict JSONDataWithOptions:JKSerializeOptionNone
                                       error:&error];
    log4Debug(@"converted to JSON: %@", [[NSString alloc] initWithData:data
                                                              encoding:NSUTF8StringEncoding]);
    if (error) {
        log4Error(@"Error converting accountIds:%@ to json: %@", accountIds, error);
        return nil;
    }
    
    return [RKRequestSerialization serializationWithData:data
                                                MIMEType:RKMIMETypeJSON];
}

+ (NSDictionary *)dictionaryWithStandardizedKeysFrom:(NSDictionary *)dict {
    NSMutableDictionary *sDict = [[NSMutableDictionary alloc] init];
    [dict enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        NSString *sKey = key;
        NSUInteger ix = [((NSString *)key) rangeOfString:@"__c" options:NSCaseInsensitiveSearch].location;
        if (ix != NSNotFound) {
            sKey = [((NSString *)key) substringToIndex:ix];
        }
        [sDict setObject:obj forKey:sKey];
    }];
    return sDict;
}

- (id)nullCheck:(id)value {
    if ([value isEqual:[NSNull null]])
        return nil;
    
    return value;
}


+ (id)nullCheck:(id)value {
    if ([value isEqual:[NSNull null]])
        return nil;
    
    return value;
}


#pragma mark -
#pragma mark The rest

- (id)init {
    if ((self = [super init])) {
        // Create cache variables
        self.accounts = [NSMutableDictionary dictionaryWithCapacity:1000];
        self.contacts = [NSMutableDictionary dictionaryWithCapacity:1000];
        self.addresses = [NSMutableDictionary dictionaryWithCapacity:1000];
        self.productBrands = [NSMutableDictionary dictionaryWithCapacity:20];
        self.productSKUs = [NSMutableDictionary dictionaryWithCapacity:20];
        self.inventoryLines = [NSMutableDictionary dictionaryWithCapacity:50];
        self.salesReps = [NSMutableDictionary dictionaryWithCapacity:1000];
        self.calls = [NSMutableDictionary dictionaryWithCapacity:1000];
        self.detailPositions = [NSMutableDictionary dictionaryWithCapacity:10];
        self.contactRoles = [NSMutableDictionary dictionaryWithCapacity:50];
        self.rssRecords = [NSMutableDictionary dictionaryWithCapacity:20];
        self.marketingDisbursements = [NSMutableDictionary dictionaryWithCapacity:1000];
        self.marketingContents = [NSMutableDictionary dictionaryWithCapacity:1000];

        // Setup sync structure
        [self setupSyncGroups];
    }
    return self;
}

- (void)registerAddress:(AGNAddress *)address {
    [self.addresses setObject:address forKey:address.salesForceId];
}

- (AGNAddress*)addressBySFDCID:(NSString *)sfdcId {
    AGNAddress * address = [self.addresses objectForKey:sfdcId];
    if (!address) {
        address = (AGNAddress *)[self.managedContext ddsf_objectOfType:@"AGNAddress" forId:sfdcId];
        if (address)
            [self.addresses setObject:address forKey:sfdcId];
    }
    return address;
}

-(void)registerRSS:(AGNRSS *)rss{
    [self.rssRecords setObject:rss forKey:rss.salesForceId];
}

- (AGNRSS*)rssBySFDCID:(NSString *)sfdcId {
    AGNRSS * rss = [self.rssRecords objectForKey:sfdcId];
    if (!rss) {
        rss = (AGNRSS *)[self.managedContext ddsf_objectOfType:@"AGNRSS" forId:sfdcId];
        if (rss)
            [self.rssRecords setObject:rss forKey:sfdcId];
    }
    return rss;
}


- (void)registerProductBrand:(AGNProductBrand*)productBrand {
    [self.productBrands setObject:productBrand forKey:productBrand.salesForceId];
}

- (AGNProductBrand*)productBrandBySFDCID:(NSString*)sfdcId {
    return (AGNProductBrand*)[self.productBrands objectForKey:sfdcId];
}

- (void)registerProductSKU:(AGNProductSKU*)product {
    [self.productSKUs setObject:product forKey:product.salesForceId];
}

- (AGNProductSKU*)productSKUBySFDCID:(NSString*)sfdcId {
    return (AGNProductSKU*)[self.productSKUs objectForKey:sfdcId];
}

- (void)registerSampleInventoryLine:(AGNSampleInventoryLine*)inventoryLine {
    [self.inventoryLines setObject:inventoryLine forKey:inventoryLine.salesForceId];
}

- (AGNSampleInventoryLine*)inventoryLineBySFDCID:(NSString*)sfdcId {
    AGNSampleInventoryLine * line = [self.inventoryLines objectForKey:sfdcId];
    return line;
}

- (void)registerAccount:(AGNAccount*)account {
    [self.accounts setObject:account forKey:account.salesForceId];
}

- (AGNAccount*)accountBySFDCID:(NSString*)sfdcId {
    AGNAccount * account = [self.accounts objectForKey:sfdcId];
    if (!account) {
        account = (AGNAccount *)[self.managedContext ddsf_objectOfType:@"AGNAccount" forId:sfdcId];
        if (account)
            [self.accounts setObject:account forKey:sfdcId];
    }
    return account;
}

- (void)registerSalesRep:(AGNSalesRep*)salesRep {
    [self.salesReps setObject:salesRep forKey:salesRep.salesForceId];
}

- (AGNSalesRep*)salesRepBySFDCID:(NSString*)sfdcId {
    AGNSalesRep * salesRep = [self.salesReps objectForKey:sfdcId];
    //    NSAssert1(salesRep, @"not found sales rep with id %@", sfdcId);
    return salesRep;
}

- (void)resetCalls {
    [self.calls removeAllObjects];
}

- (void)registerCall:(AGNCall*)call {
    [self.calls setObject:call forKey:call.salesForceId];
}

- (AGNCall*)callBySFDCID:(NSString*)sfdcId {
    AGNCall * call = [self.calls objectForKey:sfdcId];
    if (!call) {
        call = (AGNCall *)[self.managedContext ddsf_objectOfType:@"AGNCall" forId:sfdcId];
    }
    return call;
}

- (void)registerMarketingDisbursement:(AGNMarketingDisbursement*)disbursement {
    [self.marketingDisbursements setObject:disbursement forKey:disbursement.salesForceId];
}

- (AGNMarketingDisbursement*)disbursementBySFDCID:(NSString*)sfdcId {
    AGNMarketingDisbursement * marketingDisbursement = [self.marketingDisbursements objectForKey:sfdcId];
    if (!marketingDisbursement) {
        marketingDisbursement = (AGNMarketingDisbursement *)[self.managedContext ddsf_objectOfType:@"AGNMarketingDisbursement" forId:sfdcId];
    }
    return marketingDisbursement;
}

- (void)registerMarketingContent:(AGNMarketingCollateral*)content {
    [self.marketingContents setObject:content forKey:content.salesForceId];
}

- (AGNMarketingCollateral*)marketingContentBySFDCID:(NSString*)sfdcId {
    AGNMarketingCollateral * content = [self.marketingContents objectForKey:sfdcId];
    if (!content) {
        content = (AGNMarketingCollateral *)[self.managedContext ddsf_objectOfType:@"AGNMarketingCollateral" forId:sfdcId];
    }
    return content;
}


- (void)registerDetailPosition:(AGNDetailPosition*)detailPosition {
    [self.detailPositions setObject:detailPosition forKey:detailPosition.salesForceId];
}

- (AGNDetailPosition*)detailPositionBySFDCID:(NSString*)sfdcId {
    AGNDetailPosition * detailPosition = [self.detailPositions objectForKey:sfdcId];
    //    NSAssert(detailPosition, @"Could not find detail position");
    return detailPosition;
}

- (void)registerContact:(AGNContact*)contact {
    [self.contacts setObject:contact forKey:contact.salesForceId];
}

- (AGNContact*)contactBySFDCID:(NSString*)sfdcId {
    AGNContact * contact = [self.contacts objectForKey:sfdcId];
    if (!contact) {
        contact = (AGNContact *)[self.managedContext ddsf_objectOfType:@"AGNContact" forId:sfdcId];
        if (contact)
            [self.contacts setObject:contact forKey:sfdcId];
    }
    return contact;
}

- (void)dealloc {
    log4Debug(@"Registered %d accounts.", self.accounts.count);
    log4Debug(@"Registered %d contacts.", self.contacts.count);
    log4Debug(@"Registered %d addresses.", self.addresses.count);
    log4Debug(@"Registered %d product brands.", self.productBrands.count);
    log4Debug(@"Registered %d product SKUs.", self.productSKUs.count);
    log4Debug(@"Registered %d inventory lines.", self.inventoryLines.count);
    log4Debug(@"Registered %d sales reps.", self.salesReps.count);
    log4Debug(@"Registered %d detail positions.", self.detailPositions.count);
    log4Debug(@"Registered %d contact roles.", self.contactRoles.count);
}

-(int)pendingUpdateCount{
    return [AGNUpdateQueueManager defaultManager].pendingUpdateCount;
}

@end
