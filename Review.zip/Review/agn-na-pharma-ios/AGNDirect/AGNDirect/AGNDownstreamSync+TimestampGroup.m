//
//  AGNDownstreamSync+TimestampGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+TimestampGroup.h"

@implementation AGNDownstreamSync (TimestampGroup)

- (DDSFSyncItem *)timestampGroup {
    __weak AGNDownstreamSync * _self = self;
    
    DDSFSyncStep * step = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest getRequestForPath:@"/services/apexrest/currentservertime"]];
    step.name = @"timestamp";
        
    step.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        
        NSString *dateString = json[@"currentServerTime"];
        if (dateString) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
            _self.syncManager.utcCurrentSyncTimestamp = [df dateFromString:dateString];
        }
        else {
            log4Warn(@"No currentServerTime for timestampRequest!");
        }
        
        log4Info(@"==> timestampGroup fetched");
    };
    
    step.onConvert = ^(NSArray * array) {
        return (NSDictionary *)[array lastObject];
    };
    
    return step;
}

@end
