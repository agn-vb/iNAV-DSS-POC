//
//  AGNDownstreamSync+NewAccountsAndCallsGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+NewAccountsAndCallsGroup.h"


@implementation AGNDownstreamSync (NewAccountsAndCallsGroup)

- (DDSFSyncItem*)addedAccountsAndCallsGroup {
    __weak AGNDownstreamSync * _self = self;
    
    // Need to create a group since this group only runs on incremental sync
    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];
    
    DDSFSyncStep * step = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        if(_self.addedHCPIds.count==0){
            log4Info(@"No addedHCPIds, not adding FetchSyncGroupInfo request");
            return nil;
        }else{
            log4Info(@"Will call FetchSyncGroupInfo with %d ids ",[_self.addedHCPIds count]);
            return [DDSFRequest postRequestForPath:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/FetchSyncGroupInfo"] params:[_self requestSerializationForIds:self.addedHCPIds]];
        }
    }];
    step.name = @"delta-accounts-calls";
    step.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary * json) {
        log4Info(@"==> new account/calls processing");

        [_self addEntities:json[@"Accounts"] withName:@"AGNAccount"];
        [_self addEntities:json[@"Licenses"] withName:@"AGNLicense"];
        [_self addEntities:json[@"Contacts"] withName:@"AGNContact"];
        [_self addEntities:json[@"Addresses"] withName:@"AGNAddress"];
        
        [_self addEntities:json[@"Calls"] withName:@"AGNCall"];
        [_self addEntities:json[@"Call_Details"] withName:@"AGNCallDetail"];
        [_self addEntities:json[@"Sample_Drops"] withName:@"AGNSampleDrop"];
        [_self addEntities:json[@"Call_Contacts"] withName:@"AGNCallContact"];
        
        // Build the set of added call ids for later
        NSArray *calls = json[@"Calls"];
        NSMutableSet *workingSet = [[NSMutableSet alloc] initWithCapacity:[calls count]];
        for (NSDictionary *record in calls) {
            id sObject = [self nullCheck:record[@"sobjectDetails"]];
            id ws = [self nullCheck:sObject[@"Id"]];
            [workingSet addObject:ws];
        }
        _self.addedCallIds = workingSet;
    };

    [group setSteps:@[step] forMode:kDDSFDownstreamSyncModeIncremental];

    
    return group;
}

@end
