//
//  AGNSelectAccountViewController.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/6/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNSelectAccountViewController.h"
#import "AGNTableView.h"
#import "AGNSingleLineCell.h"
#import "AGNSelectAddressViewController.h"
#import "AGNAccountAddressPopover.h"

@interface AGNSelectAccountViewController ()

@property (nonatomic, strong) AGNTableView * tableView;

@property (nonatomic, retain) NSMutableArray * sectionsArray;
@property (nonatomic, retain) UILocalizedIndexedCollation * collation;

@property (strong, nonatomic) NSArray * accounts;

@property (strong, nonatomic) UISearchBar * searchBar;
@property (strong, nonatomic) UIView * headerView;

@end

@implementation AGNSelectAccountViewController

- (void)setAccounts:(NSArray *)accounts {
    _accounts = accounts;
    [self configureSections];
}

- (void)loadView {

    // Setup accounts view controller
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:nil action:nil];
    self.view = [[UIView alloc] initWithFrame:CGRectZero];
    self.view.autoresizesSubviews = YES;
    self.view.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.view.backgroundColor = [UIColor AGNNorilskSneg];
    
    // And its table view
    self.tableView = [[AGNTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.tableView];
    
    // Setup header view
    self.headerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.headerView];
    
    // Setup constraints
    NSDictionary *viewsDict = @{ @"table" : self.tableView, @"header" :self.headerView };
    
    NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[header]|" options:0 metrics:nil views:viewsDict];
    [self.view addConstraints:constraints];
    constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[table]|" options:0 metrics:nil views:viewsDict];
    [self.view addConstraints:constraints];
    constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[header(==44)][table]|" options:0 metrics:nil views:viewsDict];
    [self.view addConstraints:constraints];
    
    self.accounts = [[AGNDataManager defaultInstance] getAllHCPs];
}

- (void)calculateSize {
    [self.tableView reloadData];
    [self.tableView layoutIfNeeded];
    CGSize size = [self.tableView contentSize] ;
    
    float height = size.height + self.headerView.frame.size.height;
    float width = 480.0f;
        
    if (height  > self.popover.maxHeight)
        height = self.popover.maxHeight;
    
    self.contentSize = CGSizeMake(width,height);
    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.contentSizeForViewInPopover = self.contentSize;  // iOS 6
    } else {
        // Load resources for iOS 7 or later
        self.preferredContentSize = self.contentSize;  // iOS 7
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    CGSize size = self.contentSize;
    size.height += self.navigationController.navigationBar.frame.size.height;
    


    if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
        // Load resources for iOS 6.1 or earlier
        self.contentSizeForViewInPopover = size;  // iOS 6
    } else {
        // Load resources for iOS 7 or later
        self.preferredContentSize = size;  // iOS 7
    }
    self.popover.popoverContentSize = size;
    [self.searchBar becomeFirstResponder];
}

- (UIView *)headerView {
    if(!_headerView){
        _headerView = [[UIView alloc]init];
        self.searchBar = [[UISearchBar alloc]init];
        self.searchBar.delegate = self;
        self.searchBar.translatesAutoresizingMaskIntoConstraints = NO;
        [self.headerView addSubview:self.searchBar];
        
        NSDictionary *viewsDict = @{ @"searchBar" : self.searchBar, @"view" :self.headerView };
        NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"|[searchBar]|" options:0 metrics:nil views:viewsDict];
        [self.headerView addConstraints:constraints];
        constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[searchBar(==44)]" options:0 metrics:nil views:viewsDict];
        [self.headerView addConstraints:constraints];
        constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[view(==searchBar)]" options:0 metrics:nil views:viewsDict];
        [self.headerView addConstraints:constraints];
    
        if ([[UIDevice currentDevice].systemVersion floatValue] <= 6.1) {
            self.searchBar.backgroundImage = [UIImage imageNamed:@"bar-bigblue"];
        }else{
            self.searchBar.backgroundImage = [UIImage imageNamed:@"bar-biggrey"];
            
        }

        self.headerView.frame = CGRectMake(0,0, 480, 44);
    }
    return _headerView;
}

- (void)configureSections {
	
	// Get the current collation and keep a reference to it.
	self.collation = [UILocalizedIndexedCollation currentCollation];
	
	NSInteger index, sectionTitlesCount = [[self.collation sectionTitles] count];
	
	NSMutableArray *newSectionsArray = [[NSMutableArray alloc] initWithCapacity:sectionTitlesCount];
	
	for (index = 0; index < sectionTitlesCount; index++) {
		NSMutableArray *array = [[NSMutableArray alloc] init];
		[newSectionsArray addObject:array];
	}
	
	for (AGNAccount *account in self.accounts) {
		
		// Ask the collation which section number the object belongs in
		NSInteger sectionNumber = [self.collation sectionForObject:account collationStringSelector:@selector(lastName)];
		
		// Get the array for the section.
		NSMutableArray *sectionArray = [newSectionsArray objectAtIndex:sectionNumber];
		
		//  Add  to the section.
		[sectionArray addObject:account];
	}
	
	// Now that all the data's in place, each section array needs to be sorted.
	for (index = 0; index < sectionTitlesCount; index++) {
		
		NSMutableArray *arrayForSection = [newSectionsArray objectAtIndex:index];
		
		// If the table view or its contents were editable, you would make a mutable copy here.
		NSArray *sortedArrayForSection = [self.collation sortedArrayFromArray:arrayForSection collationStringSelector:@selector(lastName)];
		
		// Replace the existing array with the sorted array.
		[newSectionsArray replaceObjectAtIndex:index withObject:sortedArrayForSection];
	}
	
	self.sectionsArray = newSectionsArray;
}

#pragma mark -
#pragma mark UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)aSearchText {
    aSearchText = [aSearchText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (aSearchText==nil || aSearchText.length < 1)
        self.accounts = [[AGNDataManager defaultInstance] getAllHCPs];
    else
        self.accounts = [[AGNDataManager defaultInstance] getHCPSWithNameMatching:aSearchText];
    
    [self.tableView reloadData];
    [self.searchBar becomeFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // The number of sections is the same as the number of titles in the collation.
    return [[self.collation sectionTitles] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray * objectsInSection = [self.sectionsArray objectAtIndex:section];
    return [objectsInSection count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"AccountCell";
    
    AGNSingleLineCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[AGNSingleLineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    
    NSArray * accountsInSection = [self.sectionsArray objectAtIndex:indexPath.section];
    AGNAccount * account = [accountsInSection objectAtIndex:indexPath.row];
    cell.mainLabel.text = [account formattedName];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return [[self.collation sectionTitles] objectAtIndex:section];
}


- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    return [self.collation sectionIndexTitles];
}


- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    return [self.collation sectionForSectionIndexTitleAtIndex:index];
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.0;
}

#pragma mark -
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    // Do not resign first responder on the searchbar!  it screws up animations!
    
    NSArray * accountsInSection = [self.sectionsArray objectAtIndex:indexPath.section];
    
    // Show address controller
    AGNSelectAddressViewController * vc = [[AGNSelectAddressViewController alloc] init];
    vc.popover = self.popover;
    vc.account = [accountsInSection objectAtIndex:indexPath.row];
    
    [self.navigationController pushViewController:vc animated:YES];
}

@end
