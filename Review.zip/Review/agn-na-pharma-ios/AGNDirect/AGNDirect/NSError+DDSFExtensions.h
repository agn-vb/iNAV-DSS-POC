//
//  NSError+DDSFExtensions.h
//  DDSFSDK
//
//  Created by Alexey Piterkin on 3/12/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    kDDSFErrorCategoryUncategorized = 0,
    kDDSFErrorCategoryNetworkFailure,
    kDDSFErrorCategoryAuthenticationFailure,
    kDDSFErrorCategoryServerError,
    kDDSFErrorCategoryRequestError,
    kDDSFErrorCategoryServerBusy,
    kDDSFErrorCategoryCanceled
} DDSFErrorCategory;


extern NSString * const kDDSFErrorDomain;
#define kDDSFErrorCodeGeneric               100
#define kDDSFErrorCodeRequestCanceled       101
#define kDDSFErrorCodeRequestTimeout        102
#define KDDSFErrorCodeNoRefreshToken        103
#define kDDSFErrorCodeMockFailure           104


extern NSString * const kDDSFResponseBodyKey;
extern NSString * const kDDSFErrorCodeKey;
extern NSString * const kDDSFHttpStatusKey;
extern NSString * const kDDSFCategoryKey;


@interface NSError (DDSFExtensions)

@property (nonatomic, readonly) DDSFErrorCategory ddsf_category;
@property (nonatomic, readonly) NSString * ddsf_categoryName;

+ (NSError*)ddsf_cancellationError;
+ (NSError*)ddsf_timeoutError;

// Convenience methods
+ (id)ddsf_errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(NSDictionary *)dict category:(DDSFErrorCategory)category;
- (id)ddsf_errorWithCategory:(DDSFErrorCategory)category;

- (int)httpStatus;

@end
