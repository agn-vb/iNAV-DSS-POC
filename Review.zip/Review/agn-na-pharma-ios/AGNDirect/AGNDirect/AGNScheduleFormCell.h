//
//  AGNScheduleFormCell.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNScheduleFormCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *statusLabel;
@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UIImageView * icon;

@end
