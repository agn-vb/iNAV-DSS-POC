//
//  AGNDownstreamSync+InventoryGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+InventoryGroup.h"
#import "NSManagedObjectContext+DDSFExtensions.h"

@implementation AGNDownstreamSync (InventoryGroup)

- (void)buildInventoryRelationships {
    NSArray * sampleInventoryLines = [self allEntities:@"AGNSampleInventoryLine"];
    for (AGNSampleInventoryLine * line in sampleInventoryLines)
        line.product = [self productSKUBySFDCID:line.productSalesForceId];

    NSArray * sampleInventoryTxnLines = [self allEntities:@"AGNSampleInventoryTransactionLine"];
    
    for (AGNSampleInventoryTransactionLine * txnLine in sampleInventoryTxnLines) {
        txnLine.product = [self productSKUBySFDCID:txnLine.productSalesForceId];
        txnLine.productDescription = txnLine.product.productDescription;
        
        txnLine.sampleInventoryLine = [self inventoryLineBySFDCID:txnLine.sampleInventoryLineSalesForceId];
        if (!txnLine.sampleInventoryTransaction && txnLine.sampleInventoryTransactionSalesForceId)
            txnLine.sampleInventoryTransaction = [self.managedContext ddsf_objectOfType:@"AGNSampleInventoryTransaction" forId:txnLine.sampleInventoryTransactionSalesForceId];
    }
    
    NSArray * sampleInventoryTxns = [self allEntities:@"AGNSampleInventoryTransaction"];
    
    for (AGNSampleInventoryTransaction * txn in sampleInventoryTxns)
        [txn buildRelationships];
    
}

- (DDSFSyncItem*)inventoryGroup {
    __weak AGNDownstreamSync * _self = self;
    
    DDSFSyncStep * step = [[DDSFSyncStep alloc] initWithRequestBlock:^DDSFRequest *{
        NSString *distantPastString = @"utctimestamp=2000-01-01 00:00:01";
        NSString *nonDeltaString = @"&isdeltaload=0";
        NSString *deltaTimestampString = distantPastString;
        NSString *isDeltaString = nonDeltaString;
        
        if (_self.syncManager.utcCurrentSyncLastTimestamp) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            [df setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
            deltaTimestampString = [NSString stringWithFormat:@"utctimestamp=%@", [df stringFromDate:_self.syncManager.utcCurrentSyncLastTimestamp]];
            isDeltaString = @"&isdeltaload=1";
        }
        
        NSString * urlString = [NSString stringWithFormat:[AGNAppDelegate serviceUrlForPath:@"/services/apexrest/OfflineSync?%@&syncgroup=inventory%@"], distantPastString, nonDeltaString];
        return [DDSFRequest getRequestForPath:urlString];
        
    }];
    step.name = @"inventory";
    
    step.onConvert = ^(NSArray * array) {
        return (NSDictionary *)[array lastObject];
    };
    
    step.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        log4Info(@"==> inventory group processing");

        [_self addEntities:json[@"Product_Brand"] withName:@"AGNProductBrand"];
        [_self addEntities:json[@"Product"] withName:@"AGNProductSKU"];
        [_self addEntities:json[@"SampleInventoryLine"] withName:@"AGNSampleInventoryLine"];
        [_self addEntities:json[@"SampleInventoryTransactionLine"] withName:@"AGNSampleInventoryTransactionLine"];
        [_self addEntities:json[@"SampleInventoryTransaction"] withName:@"AGNSampleInventoryTransaction"];
    };
    
    
    step.postProcess = ^(DDSFDownstreamSync * sync) {
        [self buildInventoryRelationships];
    };
    
    return step;
}

@end
