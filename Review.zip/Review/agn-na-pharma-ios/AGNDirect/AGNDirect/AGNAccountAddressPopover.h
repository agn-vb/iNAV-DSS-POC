//
//  AGNSwitchAccountPopoverController.h
//  AGNDirect
//
//  Created by Alexei Peterkin on 5/5/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNAccount.h"
#import "AGNAddress.h"


typedef void (^AGNAccountAddressSelectedBlock) (AGNAccount * account, AGNAddress * address);

@interface AGNAccountAddressPopover : UIPopoverController 

@property (nonatomic, readonly, copy) AGNAccountAddressSelectedBlock onSelect;

@property (nonatomic, readonly) UINavigationController * navigationController;
@property (nonatomic, readonly) CGFloat maxHeight;

- (id)initWithTitle:(NSString*)title onSelect:(AGNAccountAddressSelectedBlock)onSelect;

@end
