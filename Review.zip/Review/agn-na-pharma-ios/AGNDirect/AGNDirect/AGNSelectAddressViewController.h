//
//  AGNSelectAddressViewController.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/6/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AGNAccountAddressPopover;

@interface AGNSelectAddressViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) AGNAccount * account;
@property (nonatomic, weak) AGNAccountAddressPopover * popover;

@end
