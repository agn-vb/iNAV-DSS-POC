//
//  AGNDeliveryMethodSortControl.m
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/10/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNDeliveryMethodSortControl.h"

@implementation AGNDeliveryMethodSortControl

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

// want to be notified of change even if segment stays the same, as this means our sort order reversed
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    int current = self.selectedSegmentIndex;
    [super touchesBegan:touches withEvent:event];
    if(current==self.selectedSegmentIndex)
        [self sendActionsForControlEvents:UIControlEventValueChanged];
}

@end
