//
//  DDSFNativeRequest.m
//  DDSFTestApp
//
//  Created by Adam McLain on 1/2/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import "DDSFNativeRequest.h"
#import "NSError+DDSFExtensions.h"
#import "SFRestAPI.h"

@interface DDSFNativeRequest ()
@property (nonatomic, strong) SFRestRequest *request;
@property (nonatomic, assign) BOOL canceled;
@end

@implementation DDSFNativeRequest

- (id)initWithSFRestRequest:(SFRestRequest *)request {
    if ((self = [super init])) {
        self.request = request;
    }
    return self;
}

- (void)send {
    [[SFRestAPI sharedInstance] send:self.request delegate:self];
}

- (void)cancel {
    self.canceled = YES;
    self.request.delegate=nil;
    [super cancel];
}

- (NSError*)categorizeError:(NSError*)error {
    // First, we need to merge the error message into the localized description
    NSString * message = error.userInfo[@"message"];
    if (message) {
        NSMutableDictionary * newUserInfo = [NSMutableDictionary dictionaryWithDictionary:error.userInfo];
        NSString * localizedDescription = error.localizedDescription;
        if (localizedDescription)
            newUserInfo[NSLocalizedDescriptionKey] = [NSString stringWithFormat:@"%@\n%@", localizedDescription, message];
        else
            newUserInfo[NSLocalizedDescriptionKey] = message;
        
        error = [NSError errorWithDomain:error.domain code:error.code userInfo:newUserInfo];
    }
    
    error = [super categorizeError:error];
    if (error.ddsf_category > kDDSFErrorCategoryUncategorized)
        return error;
    
    if ([@"invalid_grant" isEqualToString:error.userInfo[@"error"]])
        return [error ddsf_errorWithCategory:kDDSFErrorCategoryAuthenticationFailure];
    
    // For now let's treat all errors are request errors
    // TODO: as we get more errorCodes, we can do more detailed analysis
    return [error ddsf_errorWithCategory:kDDSFErrorCategoryRequestError];
}

- (void)request:(SFRestRequest *)request didLoadResponse:(id)jsonResponse {
    if (self.canceled) {
        return;
    }
    
    if (![jsonResponse isKindOfClass:[NSDictionary class]]) {
        log4Warn(@"Resulting json is not a dictionary: %@", jsonResponse);
        jsonResponse = nil;
    }
    
    // We do not expect to receive this callback is there was an error, so we can just proceed to processing
    
    [self processResponse:jsonResponse];
}

- (void)request:(SFRestRequest *)request didFailLoadWithError:(NSError*)error {
    [self handleError:[self categorizeError:error]];
}

- (void)requestDidCancelLoad:(SFRestRequest *)request {
    if (!self.canceled)
        [self handleError:[NSError ddsf_cancellationError]];
}

- (void)requestDidTimeout:(SFRestRequest *)request {
    [self handleError:[NSError ddsf_timeoutError]];
}

@end
