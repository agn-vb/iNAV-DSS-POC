//
//  AGNScheduleFormCell.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNScheduleFormCell.h"

@implementation AGNScheduleFormCell

@end
