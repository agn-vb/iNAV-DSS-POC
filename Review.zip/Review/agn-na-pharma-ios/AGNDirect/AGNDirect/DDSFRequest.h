//
//  DDSFRequest.h
//  DDSFTestApp
//
//  Created by Adam McLain on 12/27/12.
//  Copyright (c) 2012 Deloitte Digittal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSError+DDSFExtensions.h"
#import "RKRequest.h"
#import "SFRestRequest.h"

@class DDSFRequest;

typedef NSDictionary * (^DDSFArrayToDictionaryCoversionBlock) (NSArray *json);


typedef enum {
    kDDSFRequestMockModeLive = 0, // No mocking
    kDDSFRequestMockModeCapture,
    kDDSFRequestMockModeReplay
} DDSFRequestMockMode;


@protocol DDSFRequestDelegate <NSObject>

/**
 * Called when request is executed successfully and response JSON dictionary is received.
 *
 * @param request DDSFRequest for which the delegate method is called
 * @param json an NSDictionary containing the parsed representation of the response body
 */

- (void)requestCompleted:(DDSFRequest *)request withJson:(NSDictionary *)json;

/**
 * If request is canceled, error will have ddsf_category equal to kDDSFErrorCategoryCanceled
 *
 * @param request DDSFRequest for which the delegate method is called
 * @param error the error object containing information about the cause
 */
- (void)request:(DDSFRequest *)request failedWithError:(NSError *)error;


@optional

/**
 * Called when request response is successfully received in order to detect errors contained in JSON body.
 * 
 * Return nil if you detect no error.  You don't have to categorize the error right away, as categorization method will be called afterwards.
 * If you do categorize the error right away, the categorization method will not be called.
 *
 * @param request DDSFRequest for which the delegate method is called
 * @param json an NSDictionary containing the parsed representation of the response body
 * @param httpStatus the integer value for http status (e.g. 200 for success).
 * @return error object or nil
 */
- (NSError*)request:(DDSFRequest*)request detectErrorFromResponse:(NSDictionary*)json statusCode:(int)httpStatus;

/**
 * This method is called to categorize custom error or re-categorize standard errors
 *
 * This method is only called if the detected error is not already categorized. See DDSFErrorCategory enum for possible values.
 *
 * @param request DDSFRequest for which the delegate method is called
 * @param error the error object to be categorized. 
 * @return new error object with a category or same object if could not categorize
 */
- (NSError*)request:(DDSFRequest*)request categorizeError:(NSError*)error;

@end


@interface DDSFRequest : NSObject <RKRequestDelegate, SFRestDelegate>

@property (nonatomic, weak) id <DDSFRequestDelegate> delegate;
@property (nonatomic, copy) DDSFArrayToDictionaryCoversionBlock onConvert; // A block to convert an array response to dictionary (since all requests expect to return a dictionary)

// Convenience methods for SFDC Native Queries
+ (DDSFRequest *)requestWithQueryFromFileNamed:(NSString*)fileName;
+ (DDSFRequest *)requestWithQueryFromFileNameWithArgs:(NSString*)fileName, ... NS_REQUIRES_NIL_TERMINATION;
+ (DDSFRequest *)requestWithSFRestRequest:(SFRestRequest *)aSFRestRequest;

// Convenience methods for Rest Kit requests
+ (DDSFRequest *)getRequestForPath:(NSString *)resourcePath;
+ (DDSFRequest *)getRequestForPath:(NSString *)resourcePath queryParams:(NSDictionary *)queryParams;
+ (DDSFRequest *)postRequestForPath:(NSString *)resourcePath params:(NSObject<RKRequestSerializable> *)params;
+ (DDSFRequest *)putRequestForPath:(NSString *)resourcePath params:(NSObject<RKRequestSerializable> *)params;
+ (DDSFRequest *)deleteRequestForPath:(NSString *)resourcePath;


/**
 * default set to NO.
 */
@property (atomic, assign) BOOL shouldSaveResponse;
@property (atomic, readonly, strong) NSDictionary *jsonResponse;

- (void)execute;
- (void)cancel;
- (void)processResponse:(NSDictionary*)json;
- (void)handleError:(NSError*)error;

// Error detection methods, override as needed
- (NSError*)detectErrorFromResponse:(NSDictionary*)jsonResponse statusCode:(int)httpStatus;
- (NSError*)categorizeError:(NSError*)error;


// Pagination
@property (readonly, atomic) NSUInteger totalCount;
@property (readonly, atomic) NSUInteger currentCount;

- (DDSFRequest*)requestForNextPage;

// Mock mode
@property (assign, atomic) DDSFRequestMockMode mockMode;
@property (strong, atomic) NSString * mockPath; // For capture purposes

@property (strong, atomic) NSArray * mockFileNames;
@property (assign, atomic) NSTimeInterval mockResponseDelay;
@property (assign, atomic) int mockHTTPStatus;
@property (strong, atomic) NSError * mockError;

@end
