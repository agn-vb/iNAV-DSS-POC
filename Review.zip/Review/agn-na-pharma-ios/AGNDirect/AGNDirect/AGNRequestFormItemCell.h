//
//  AGNRequestFormItemCell.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 5/8/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGNRequestFormItem.h"

extern NSString * const kAGNNotificationRequestFormBeganEditing;

@class AGNRequestFormItemCell;

@protocol AGNRequestFormItemCellDelegate <NSObject>

- (void)displayProductPopoverForCell:(AGNRequestFormItemCell*)cell forView:(UIView*)view;
- (void)questionUpdatedOnCell:(AGNRequestFormItemCell*)cell;

@end

@interface AGNRequestFormItemCell : UITableViewCell <UITextViewDelegate>

@property (strong, nonatomic) AGNRequestFormItem * item;
@property (nonatomic, assign) BOOL readonly;
@property (strong, nonatomic) UILabel * productLabel;
@property (nonatomic, weak) id <AGNRequestFormItemCellDelegate> delegate;

- (void)updateCharactersRemaining;
- (void)beginEditing;
- (void)chooseProduct;

- (void)update;

- (UIView*)viewForPopover;

@property (nonatomic, assign) BOOL productHighlighted;

@end
