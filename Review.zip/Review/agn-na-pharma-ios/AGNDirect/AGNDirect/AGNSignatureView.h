//
//  AGNSignatureView.h
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/13/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGNSignatureView : UIView

- (void)setupConstraints;

- (void)setSignatureCapturedMode:(UIImage*)image;
- (void)setClosedMode:(NSString*)dateString;

@end
