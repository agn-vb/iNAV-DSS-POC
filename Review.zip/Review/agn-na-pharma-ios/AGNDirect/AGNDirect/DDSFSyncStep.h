//
//  DDSFSyncStep.h
//  DDSFTestApp
//
//  Created by Alexey Piterkin on 1/8/13.
//  Copyright (c) 2013 Deloitte Digittal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDSFRequest.h"
#import "DDSFSyncItem.h"

@class DDSFDownstreamSync;

typedef void (^DDSFSyncCallbackWithData) (DDSFDownstreamSync * sync, NSDictionary *json);
typedef DDSFRequest * (^DDSFRequestBlock)(void);


@interface DDSFSyncStep : DDSFSyncItem <DDSFRequestDelegate>

@property (nonatomic, copy) DDSFSyncCallbackWithData onFetch; // If the response is paginated, then this block will be called for every page
@property (nonatomic, copy) DDSFSyncCallbackWithData onProcess; // If the response is paginated, then this block will be called for every page

@property (nonatomic, copy) DDSFArrayToDictionaryCoversionBlock onConvert;

@property (nonatomic, strong, readonly) DDSFRequest * request; // Initial request

@property (nonatomic) int estimatedNumberOfPages;  // By default - 1


- (id)initWithRequest:(DDSFRequest *)request;
- (id)initWithRequestBlock:(DDSFRequestBlock)requestBlock;

@end
