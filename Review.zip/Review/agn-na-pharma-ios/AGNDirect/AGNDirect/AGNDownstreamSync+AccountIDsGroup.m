//
//  AGNDownstreamSync+AccountIDsGroup.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 4/16/13.
//  Copyright (c) 2013 Mark Wells. All rights reserved.
//

#import "AGNDownstreamSync+AccountIDsGroup.h"
#import "NSManagedObjectContext+DDSFExtensions.h"

#define AGN_FULL_SYNC_ACCOUNT_THRESHOLD 20

@implementation AGNDownstreamSync (AccountIDsGroup)

- (int)maxNewAccountsForIncrementalSync {
    int result = AGN_FULL_SYNC_ACCOUNT_THRESHOLD;
    NSString *userDefaultValue = [[NSUserDefaults standardUserDefaults] objectForKey:AGNIncrementalSyncMaxNewAccountsKey];
    if (userDefaultValue) {
        result = [userDefaultValue intValue];
    }
    return result;
}


- (DDSFSyncItem *)accountIdsGroup {
    __weak AGNDownstreamSync * _self = self;
    
    // Need to create a group since we have different steps depending on incremental vs. full (none for full)
    DDSFSyncGroup * group = [[DDSFSyncGroup alloc] init];
    
    DDSFSyncStep * incremental = [[DDSFSyncStep alloc] initWithRequest:[DDSFRequest getRequestForPath:@"/services/apexrest/FetchAccountIds"]];
    incremental.name = @"account-ids";
    incremental.onFetch = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        log4Info(@"==> accountIdsGroup fetched");

        // if this is a full sync, then just get all the IDs of the currently visible accounts and we're done
        NSSet * allHCPIds = [NSSet setWithArray:json[@"AccountIds"]];
        _self.allHCPIds = allHCPIds; // Save for future use
        
        // We need to calculate how many new HCPs there are
        
        // fetch the HCP ids currently in CD
        AGNDataManager *dataManager = [[AGNDataManager alloc] initWithManagedObjectContext:_self.managedContext];
        
        // Optimized to fetch Ids only
        NSArray *currentHCPs = [dataManager getAllRecordsOfEntity:@"AGNAccount" withProperties:[NSArray arrayWithObject:@"salesForceId"]];
        NSMutableSet *currentIds = [[NSMutableSet alloc] initWithArray:[currentHCPs valueForKey:@"salesForceId"]];
        
        // build bucket of added account ids to detect the number of new ones
        NSMutableSet * workingSet = [allHCPIds mutableCopy];
        [workingSet minusSet:currentIds];
        
        //NSLog(@"working set %@",workingSet);
        _self.addedHCPIds = workingSet;
        
        // Here we will decide if we should go into full sync mode
        if ([workingSet count] >= [_self maxNewAccountsForIncrementalSync]) {
            sync.mode = kDDSFDownstreamSyncModeFull;
            // No need for the new HCPs - it's a full sync now
            _self.addedHCPIds = nil;
        }
        else {
            // We're staying incremental
            // Detect HCPs to remove later, in onProcess
            workingSet = [currentIds mutableCopy];
            [workingSet minusSet:allHCPIds];
            _self.deletedHCPIds = workingSet;
        }
    };
    
    incremental.onProcess = ^(DDSFDownstreamSync * sync, NSDictionary* json) {
        // All we need to do during this step is delete all accounts marked for deletion
        for (NSString * salesForceId in _self.deletedHCPIds) {
            AGNAccount * account = [self.managedContext ddsf_objectOfType:@"AGNAccount" forId:salesForceId];
            [_self.managedContext deleteObject:account];
        }
        
        NSError * error = nil;
        [sync.managedContext save:&error];
        
        if (error)
            log4Error(@"Got error saving context: %@", error);
    };
    
    [group setSteps:@[incremental] forMode:kDDSFDownstreamSyncModeIncremental];
    
    return group;
}

@end
