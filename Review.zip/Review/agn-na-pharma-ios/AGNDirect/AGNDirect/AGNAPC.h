//
//  AGNAPC.h
//  AGNDirect
//
//  Created by Rebecca Gutterman on 7/11/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface AGNAPC :  NSManagedObject <AGNModelProtocol, NSCopying>

@property (nonatomic, retain) NSString * apcCode;
@property (nonatomic, retain) NSString * salesForceId;
@property (nonatomic, retain) NSDate * effectiveDate;
@property (nonatomic, retain) NSDate * endDate;
@property (nonatomic, retain) NSString * salesTeamRemoteId;
@property (nonatomic, retain) NSString * jobName;
@property (nonatomic, retain) NSString * productName;
@property (nonatomic, retain) NSNumber * value;

@end
