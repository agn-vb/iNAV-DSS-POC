//
//  AGNHCPActivity.m
//  AGNDirect
//
//  Created by Alexey Piterkin on 5/9/13.
//  Copyright (c) 2013 Deloitte Digital. All rights reserved.
//

#import "AGNHCPActivity.h"

@implementation AGNHCPActivity

@dynamic mobileCreateTimestamp;
@dynamic mobileLastUpdateTimestamp;
@dynamic salesForceAccountId;
@dynamic salesForceAddressId;
@dynamic signatureImage;
@dynamic signatureCaptureDate;
@dynamic account;
@dynamic address;
@dynamic salesRep;
@dynamic signature;
@dynamic stampAddressLine1;
@dynamic stampAddressLine2;
@dynamic stampAddressLine3;
@dynamic stampAddressCity;
@dynamic stampAddressCountry;
@dynamic stampAddressState;
@dynamic stampAddressZip;
@dynamic stampHCPFirstName;
@dynamic stampHCPLastName;
@dynamic stampHCPMiddleName;
@dynamic stampHCPMDMID;
@dynamic stampLicenseExpirationDate;
@dynamic stampLicenseState;
@dynamic stampLicenseNumber;
@dynamic stampPhysicianSpecialty;
@dynamic stampProfessionalDesignation;
@dynamic stampRepManagerName;
@dynamic stampSalesTeam;
@dynamic stampTerritory;

@dynamic repFirstName;
@dynamic repLastName;
@dynamic repMiddleName;



- (NSString *)formattedDateAndHCPName {
    NSString *string = @"";
    NSDate *date = self.endDate ? self.endDate : self.startDate;
    
    
    if ([date agnFormattedDateString].length > 0) {
        string = [NSString stringWithFormat:@"%@    %@", [date agnFormattedDateString], self.account.formattedName.uppercaseString];
    } else {
        string =  self.account.formattedName.uppercaseString;
    }
    
    return string;
}


- (NSString *)formattedDateAndRepName {
    NSString *string = @"";
    NSDate *date = self.endDate ? self.endDate : self.startDate;


    if ([date agnFormattedDateString].length > 0) {
        string = [NSString stringWithFormat:@"%@    %@", [date agnFormattedDateString], self.formattedRepName.uppercaseString];
    } else {
        string = self.formattedRepName.uppercaseString;
    }

    return string;
}

- (NSString *)formattedRepName {
    NSString * result = self.salesRep.formattedName;
    return result ? result : @"UNKNOWN";
}

//subclasses should override
- (NSAttributedString *)hcpDetailDescription {
    UIFont *heavy = [UIFont AGNAvenirHeavyFontWithSize:16.0f];
    NSDictionary * heavyAttributes = @{ NSFontAttributeName : heavy, NSForegroundColorAttributeName : [UIColor AGNSecondGrayd] };
    NSMutableAttributedString * formattedString = [[NSMutableAttributedString alloc] initWithString:@"UNKNOWN" attributes:heavyAttributes];

    return formattedString;
}


@end
